CREATE TABLE IF NOT EXISTS `failed_login` (
  `ip_address` varchar(255) NOT NULL,
  `date` datetime NOT NULL
)