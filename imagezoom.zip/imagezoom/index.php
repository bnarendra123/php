<?php
$content ='
<script type="text/javascript" src="jquery-1.8.0.min.js"></script>
<link rel="stylesheet"  type="text/css" href="jquery.jqzoom.css">
<script type="text/javascript" src="jquery.jqzoom-core-pack.js"></script>
     <script type="text/javascript">
     jQuery(document).ready(function(){

                   jQuery(\'a#demo1\').jqzoom();

                jQuery(\'a#demo2\').jqzoom({
                zoomType: \'reverse\'
            });

                jQuery(\'a#demo3\').jqzoom({
                zoomType: \'drag\'
            });

                jQuery(\'a#demo4\').jqzoom({
                zoomType: \'innerzoom\'
            });
});

     </script>
     <div class="heading" ><h2>1 - Standard zoom</h2></div>
     <div class="clearfix demo">

                       <div class="clearfix" style="position:relative;">
                            <a href="images/1_big.png"  rel="gal1" id="demo1"  title="PHPGang.com ZoomIn" >
                                <img src="images/1_small.png"  title="PHPGang.com ZoomIn"  style="border: 1px solid #666;">
                            </a>
                        </div>
                </div>
                      <br /> <hr>
                <div class="heading" ><h2>2 - Reverse zoom</h2></div>
     <div class="clearfix demo">

                       <div class="clearfix" style="position:relative;">
                            <a href="images/2_big.png"  rel="gal1" id="demo2"  title="PHPGang.com ZoomIn" >
                                <img src="images/2_small.png"  title="PHPGang.com ZoomIn"  style="border: 1px solid #666;">
                            </a>
                        </div>
                </div>
                
                <br /> <hr>
                <div class="heading" ><h2>3 - Drag zoom</h2></div>
     <div class="clearfix demo">

                       <div class="clearfix" style="position:relative;">
                            <a href="images/3_big.png"  rel="gal1" id="demo3"  title="PHPGang.com ZoomIn" >
                                <img src="images/3_small.png"  title="PHPGang.com ZoomIn"  style="border: 1px solid #666;">
                            </a>
                        </div>
                </div>
                
                <br /> <hr>
                <div class="heading" ><h2>4 - Inner zoom</h2></div>
     <div class="clearfix demo">

                       <div class="clearfix" style="position:relative;">
                            <a href="images/4_big.png"  rel="gal1" id="demo4"  title="PHPGang.com ZoomIn" >
                                <img src="images/4_small.png"  title="PHPGang.com ZoomIn"  style="border: 1px solid #666;">
                            </a>
                        </div>
                </div>                  <br><br><br>

';




$pre = 1;
$title = "How to ZoomIn Images in jQuery";
$heading = "How to ZoomIn Images in jQuery example.";
include("html.inc");           
?>