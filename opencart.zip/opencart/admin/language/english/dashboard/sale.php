<?php
// Heading
$_['heading_title'] = 'Total Sales';

// Text
$_['text_view']     = 'View more...';