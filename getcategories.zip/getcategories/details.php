<?php
$pid=$_REQUEST['id'];
$con=mysql_connect("localhost","root","");
$db=mysql_select_db("test",$con);
$sql="select * from categories where parentid='$pid' ";
$result=mysql_query($sql,$con);

while($row=mysql_fetch_array($result)){
	?>
	<a href="get.php?id=<?php echo $row['parentid']; ?>"><?php echo $row['category']; ?></a><br>
	<?php
}
?>
