<?php
$parentid=$_REQUEST['id'];
$con=mysql_connect("localhost","root","");
$db=mysql_select_db("test",$con);
$sql="select * from details where id='$parentid' ";
$result=mysql_query($sql,$con);

while($row=mysql_fetch_array($result)){
	?>
	<?php echo $row['description']; ?><br>
	<?php
}
?>
