<?php
if(isset($_POST['submit'])){
	echo $long=$_POST['long'];
	echo $lat=$_POST['lat'];
	echo $location=$_POST['location'];
}
?>