<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>

<input type="text" name="nooftests" id="nooftests"/>
<br />
<div class="result"></div>

<script>
    $(document).ready(function() {
        $(document).on('keyup', 'input#nooftests', function() {
            if($(this).val().length > 0) {
                $.post('test.php', {"nooftests":$(this).val()}, function(data) {
                    $('div.result').html(data);
                });
            }
        });
    });
</script>