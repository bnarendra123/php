<?php
if(isset($_POST['nooftests'])){
$nooftests=$_POST['nooftests'];
}

for($i=0;$i<$nooftests;$i++){
	?>
	
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
<?php	
}
?> 
