<?php
if(isset($_POST['search'])){
$search=$_POST['search'];
}

if($search==1){
	?>
	
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam">
<?php	
}
?> 
<?php
if($search==2){ ?>
<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam">
<?php } ?>
<?php
if($search==3){ ?>
<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam">
<?php } ?>
<?php
if($search==4){ ?>
<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam">
	
<?php } ?>
<?php
if($search==5){ ?>
<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam"><br>
	<input type="text" name="name">
	<input type="tex" name="kname">
	<input type="text" name="test">
	<input type="text" name="exam">
<?php } ?>