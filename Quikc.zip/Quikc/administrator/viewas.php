<?php

define('QC_VALID', true);
define('QC_ADMIN', true);
define('QC_LOGGED', true);

require 'includes/core/application_top.php';

echo '<pre>';
$_SESSION['user']['viewas'] = $_GET['va'];

Base::_pageRedirect('/');


