<?php

define('QC_VALID', true);
define('QC_ADMIN', true);
define('QC_AJAX', true);

require 'includes/core/application_top.php';

// Unstripping the passed parameters for ajax
if(isset($_POST)){

	$_POST = $Validate->_stripslashes($_POST);
	
	if(isset($_POST['params'])){

	    $_POST['params'] = json_decode($_POST['params']);

    }

} 

$Action = Plugins::_runAction('ajax_page_start',$Action);

// Splitting the action variable into files
$actionSplitter = explode("/",$Action);

if( !is_array($actionSplitter) || count($actionSplitter) < 2 ){

	die('Invalid Ajax Page Request');

}

if( $actionSplitter[0] == '' && '/'.$actionSplitter[1] == Config::_get('plugins') ){
    
    if($Plugins->_checkPluginIdentifier($actionSplitter[2])){ 

        $Plugins->_loadPluginAjaxPage($actionSplitter[2],$Action);

    }

    $Admin->_displayDeveloperModeActions();

    die();

}

//This includes the lists for the files like get/list
if( ($actionSplitter[0] == 'get' && $actionSplitter[1] == 'list') ){
    
    $listName = $actionSplitter[count($actionSplitter)-1];

	// Including the default lists page in the core modules
    include Config::_getDir('admin').'/includes/core/modules/lists/default.php';

    if( file_exists(Config::_getDir('admin').'/includes/custom/modules/lists/default.php') ){

		// Including the default lists page in the core modules
        include Config::_getDir('admin').'/includes/custom/modules/lists/default.php';

    }

    if( file_exists(Config::_getDir('admin').'/includes/custom/modules/lists/'.$listName.'.php') ){

		// Including the lists page in the custom modules
        include Config::_getDir('admin').'/includes/custom/modules/lists/'.$listName.'.php';

    }else if( file_exists(Config::_getDir('admin').'/includes/core/modules/lists/'.$listName.'.php') ){

		// Including the lists page in the core modules
        include Config::_getDir('admin').'/includes/core/modules/lists/'.$listName.'.php';

    }

}

//This includes the forms for the files like check/, set/, get/edit
if( ($actionSplitter[0] == 'check' || ( $actionSplitter[0] == 'set' && isset($_POST['do']) && $_POST['do'] == 'edit') || $actionSplitter[1] == 'edit' ) ){
    
    $formName = $actionSplitter[count($actionSplitter)-1];

	// Including the default forms page in the core modules
    include Config::_getDir('admin').'/includes/core/modules/forms/default.php';

    if( file_exists(Config::_getDir('admin').'/includes/custom/modules/forms/default.php') ){

		// Including the default forms page in the core modules
        include Config::_getDir('admin').'/includes/custom/modules/forms/default.php';

    }

    if( file_exists(Config::_getDir('admin').'/includes/custom/modules/forms/'.$formName.'.php') ){

		// Including the forms page in the custom modules
        include Config::_getDir('admin').'/includes/custom/modules/forms/'.$formName.'.php';

    }else if( file_exists(Config::_getDir('admin').'/includes/core/modules/forms/'.$formName.'.php') ){

		// Including the default forms page in the core modules
        include Config::_getDir('admin').'/includes/core/modules/forms/'.$formName.'.php';

    }

}

if( file_exists(Config::_getDir('admin').'/includes/custom/modules/ajax/'.$Action.'.php') ){

	//Including the appropriate file from the custom modules if file doesnot exists
    include Config::_getDir('admin').'/includes/custom/modules/ajax/'.$Action.'.php';

}else if( file_exists(Config::_getDir('admin').'/includes/core/modules/ajax/'.$Action.'.php') ){

	//Including the appropriate file from the core modules if file doesnot exists
    include Config::_getDir('admin').'/includes/core/modules/ajax/'.$Action.'.php';
	
}else{

	Plugins::_runAction('ajax_no_page_found',$Action);

}

$Admin->_displayDeveloperModeActions();
	
