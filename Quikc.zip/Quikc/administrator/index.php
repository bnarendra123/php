<?php

define('QC_VALID', true);
define('QC_ADMIN', true);
define('QC_NOTLOGGED', true);

require 'includes/core/application_top.php';

$Themes->_setCurrentAdminPage('login');

require Config::_getDir('admin').'/includes/core/modules/forms/login.php';

$forms = Plugins::_runAction('form_login_before_generate',$forms);

$loginForm = $Forms->_generateForm($forms,'');

$loginForm = Plugins::_runAction('form_login_after_generate',$loginForm);

require 'includes/core/application_bottom.php';

