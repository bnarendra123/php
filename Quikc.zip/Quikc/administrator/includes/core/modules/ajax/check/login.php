<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){
  
	$processedForm = $Forms->_processForm($forms,$_POST);
	extract($processedForm['formElements']);

	if( count($processedForm['error']) != 0 ){
		$Base->_convertError($processedForm['error'],false);
	}

	$returnMessage = $User->_doLogin($emailUser,$passwordUser);

	// If conditions satisfied means, the user login is failed.
	// displaying the error message
	if( $returnMessage != 'ok' ){
		$Base->_convertError($processedForm['error'],false);
	}

	// if the execution come here, means the user is logged in
	// but not we have to confirm weateher he has the access to the admin panel or not
	// this can be done usring $Admin->_isLogged(). If it returns false, means the user is not allowed to access the admin panel
	// so we have to display that error message to the user  
	
	if( $User -> _isLogged() && !$Admin->_isLogged() ){
		$User->_logout();
    	$errors[] = 'Access Restricted.';
        $Base->_convertError($errors,false);
	}

	die($returnMessage);
}

