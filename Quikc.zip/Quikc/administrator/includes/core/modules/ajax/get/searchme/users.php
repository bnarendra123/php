<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    return;
}

$q = str_replace(" ", "%", $q);

$query  = " select *,concat(nameFirstUser,' ',nameLastUser) as fullName from ".Config::_getTable('users')." 
			where 
			concat(nameFirstUser,' ',nameLastUser) like :fullName
			or concat(nameLastUser,' ',nameFirstUser) like :revFullName 
		    order by fullName asc";

$arrayBind[]= array("key" => ":fullName",      "value" =>  "%$q%" );
$arrayBind[]= array("key" => ":revFullName",   "value" =>  "%$q%" );

$dataSearch =   array(
	                'title'     => 'Users',
	                'key'		=> $Base->_getFileName(__FILE__),
	                'query'   	=> $query,
	                'arrayBind' => $arrayBind,
	
	                'options'   => array(
	                                'title'         => 'fullName',
	                                'primaryField'  => 'idUser',
	                                'statusField'   => 'statusUser',
	                                'imageField'    => 'imageUser',
	
	                                'actions'       => array("create","status","edit","delete"),
	                                'filename'      => $Base->_getFileName(__FILE__), 
	                                ),
                );
                            
