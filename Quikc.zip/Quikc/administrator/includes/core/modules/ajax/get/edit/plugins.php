<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
    die();
}

extract($_POST);

if($formPrimaryField != -1){
    $details = $Plugins->_getPluginDetailsById($formPrimaryField);
    $forms['name'] = "Editing Plugin : ".$details->namePlugin;
}else{
    $details = '';
}

$hook = Plugins::_runAction('form_plugins_before_generate',array($forms,$details));
$forms 	 = $hook[0];
$details = $hook[1];

echo $Forms->_generateForm($forms,$details);

