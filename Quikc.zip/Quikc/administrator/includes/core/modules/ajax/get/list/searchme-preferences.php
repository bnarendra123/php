<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

extract($_POST);

$idDefPref = $SearchMe->_getDefaultPreference();

if( !isset($idPref) || $idPref == '' ){
	$idPref = $idDefPref;
} 

$q = ''; 

$filtersSearch = array();

$listFiles = $SearchMe->_filesSearchMe();

$listPref = $User->_getUserPreference('/admin/searchme/preferences');

if( isset($listPref[$idPref]) ){
	$detaiilsPref = $listPref[$idPref];
}elseif( $idPref == -1 ){
	$detaiilsPref = array( 'title' => '', 'items' => array() );
}else{
	$idPref = $idDefPref;	
	$detaiilsPref = $listPref[$idPref];
}

foreach($listFiles as $fileSearch){

	$dataSearch = '';
	
    include_once $fileSearch;
	
	if( isset($dataSearch['key']) ){
		
		if( $idPref == -1 || !isset($detaiilsPref['items'][$dataSearch['key']]) ){
			
			$dataSearch['active'] = true;
			$dataSearch['rows'] = $SearchMe->_defaultLimit();
			$filtersSearch[$dataSearch['key']] = $dataSearch;
		}else{
			
			$dataSearch['active'] = $detaiilsPref['items'][$dataSearch['key']]['active'];
			$dataSearch['rows'] = $detaiilsPref['items'][$dataSearch['key']]['rows'];
			$filtersSearch[$dataSearch['key']] = $dataSearch;
		}
	}
}

include_once Config::_getDir('admin.temp') .'/elements/searchme-preferences.phtml';

die();


