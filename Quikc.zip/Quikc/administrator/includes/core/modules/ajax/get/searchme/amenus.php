<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    return;
}

$query  = "select * from ".Config::_getTable('admin_menus')." where titleMenu like :titleMenu or linkMenu = :linkMenu order by titleMenu asc";
$arrayBind[]= array("key" => ":titleMenu",  "value" =>  "%$q%" );
$arrayBind[]= array("key" => ":linkMenu",   "value" =>  "%$q%" );

$actions = array("create","status","edit","copy","delete");

$view = '<a href="'.Config::_getUrl('admin').'/home.php?page=primaryField" onclick="return loadAjaxMenus(event,\''.Config::_getUrl('admin').'/home.php?page=primaryField\')"><span class="actions view"></span></a>';

array_unshift($actions, $view);

$dataSearch =   array(
                    'title'     => 'Admin Menus',
                    'key'		=> $Base->_getFileName(__FILE__),
                    'query'   	=> $query,
                    'arrayBind' => $arrayBind,

                    'options'   => array(
                                    'title'         => 'titleMenu',
                                    'primaryField'  => 'idMenu',
                                    'statusField'   => 'statusMenu',
                                    'imageField'    => 'imageMenu',

                                    'actions'       => $actions,
                                    'filename'      => $Base->_getFileName(__FILE__), 
                                    ),
                    );
                            
