<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array("developermodeglobal" 				=>  Config::_get('developer.mode.global'),
									 "developermode" 					=>  Config::_get('developer.mode'),
	                               	 "developermodesuperadminsonly"		=>  Config::_get('developer.mode.super.admins.only'),
	                               	 "developermodeloginreset"			=>  Config::_get('developer.mode.login.reset'),
	                               	 "developermodecaching"				=>  Config::_get('developer.mode.caching'),
	                               	 "developermodedisplayhelper"		=>  Config::_get('developer.mode.display.helper')
                       );

$hook = Plugins::_runAction('form_settings_developer_before_generate',array($forms,$detailssystemconfig));
$forms 	 = $hook[0];
$detailssystemconfig = $hook[1];

echo $Forms->_generateForm($forms,$detailssystemconfig);


?>
<script>
function settingsDeveloperMode_<?php echo $Forms->_getFormId(); ?>(){
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	
	var fields = ['developermodeloginreset','developermodecaching','developermodedisplayhelper'];
	
	var developermodeglobal = getValueFromId("developermodeglobal_"+idForm,'');
	var developermode = getValueFromId("developermode_"+idForm,'');
	var developermodesuperadminsonly = getValueFromId("developermodesuperadminsonly_"+idForm,'');
	
	for(var i in fields){
		if( developermodeglobal == 1 || developermode == 1 || developermodesuperadminsonly == 1 ){
			$("#"+fields[i]+"_"+idForm).parent().parent().show();
		}else{
			$("#"+fields[i]+"_"+idForm).parent().parent().hide();			
		}
	}
	
	updateTableRows();
}
settingsDeveloperMode_<?php echo $Forms->_getFormId(); ?>();

</script>