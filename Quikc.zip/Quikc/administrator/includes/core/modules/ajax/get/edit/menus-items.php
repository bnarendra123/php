<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

extract($_POST);

if(isset($formPrimaryField) && $formPrimaryField != -1) {
	$idMenu = $formPrimaryField;
}elseif(isset($params->idMenu) && $params->idMenu != -1){
	$idMenu = $params->idMenu;
}

if( !isset($idMenu) || !$Menus->_getMenuDetails($idMenu) ) die('Invalid Menu');

include_once Config::_getDir('admin.temp') .'/elements/menus-items.phtml';
