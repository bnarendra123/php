<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){

    $Base->_accessRestricted();

}

if(!$_POST){

    die();

}

extract($_POST);

if($formPrimaryField != -1){

    $details = $Cms->_getPageDetails($formPrimaryField);
    $forms['name'] = "Editing Page : ".$details->namePage." (".$details->fullLinkPage.")";

}else{

    $details = '';

    $titlePage = '';
            
    if($idParentPage !='' && $idParentPage != 0){

        $titlePage = " in (".$Cms->_getPageLink($idParentPage).")";

    }

    $forms['name'] = "Creating New Page ".$titlePage."";

}

$hook = Plugins::_runAction('form_cms_pages_before_generate',array($forms,$details));
$forms 	 = $hook[0];
$details = $hook[1];


echo $Forms->_generateForm($forms,$details);

?>
<script>
function themeChanged_<?php echo $Forms->_getFormId(); ?>(){
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	var activeTheme = '<?php echo $Themes->_getActiveTheme()->pathTheme; ?>';
	<?php

	 $setsThemeTemplates = '';

	// $themesSet from the cmspages forms page	
	 foreach($selectedthemesSet as $key => $value){
	 	$setsThemeTemplates[$key] = $Themes->_getTemplates($key);
	 }
	
	?>

	var listThemeTemplates = <?php echo json_encode($setsThemeTemplates); ?>;
	var listPluginTemplates = <?php echo json_encode($setPluginTemplates); ?>;
	
	var parent = $("#templatePage_"+idForm).parent();

	var typePage = $("#typePage_"+idForm).val();
	var selectedTemplate = $("#templatePage_"+idForm).val();
	
	var listFields = new Array();
	
	if(typePage == 'plugins'){

        $("#pluginPage_"+idForm).parent().parent().show();
        $("#themePage_"+idForm).parent().parent().hide();

        if( listPluginTemplates.length == 0 ){

            listFields = false;
            
        }else{
            var selectedPlugin = $("#pluginPage_"+idForm).val();
            listFields = listPluginTemplates[selectedPlugin];
        }

	}else{

		$("#pluginPage_"+idForm).parent().parent().hide();
		$("#themePage_"+idForm).parent().parent().show();

		var selectedTheme = $("#themePage_"+idForm).val();
		
		if( selectedTheme == 'global' ){
			selectedTheme = activeTheme;
		} 
		
		listFields = listThemeTemplates[selectedTheme];
	}
	
	$("#templatePage_"+idForm).remove();
	
	var generatedhtml = '';
	
	if( listFields ){
	    listFields = generateSelectBox(listFields, -1, '', "templatePage_"+idForm, selectedTemplate, true);
	}else{
	    listFields = 'No Records Found<input type="hidden" id="templatePage_'+idForm+'" />';
	}
	jQuery(parent).html(listFields);
	
	updateTableRows();

}
themeChanged_<?php echo $Forms->_getFormId(); ?>();
</script>