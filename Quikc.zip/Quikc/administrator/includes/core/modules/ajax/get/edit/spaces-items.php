<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

extract($_POST);

$idRandomForm = $Base->_generateRandomString(4);    

if(isset($formPrimaryField) && $formPrimaryField != -1) {
	$idSpace = $formPrimaryField;
}elseif(isset($params->idSpace) && $params->idSpace != -1){
	$idSpace = $params->idSpace;
}

$idSpace = Plugins::_runAction('spaces_items_space_id',$idSpace,$idRandomForm);

$listWidgets 	= $Widgets->_getWidgets();
$listWidgetItems= $Widgets->_getWidgetItems($idSpace);

$listSpaceWidgetItems = Spaces::_getInstanceById($idSpace)->_generateWidgets();

$listSpaceWidgetItems = Plugins::_runAction('spaces_items_widget_items',$listSpaceWidgetItems,$idRandomForm);

include_once Config::_getDir('admin.temp') .'/elements/spaces-items.phtml';

Plugins::_runAction('spaces_items_completed',$listSpaceWidgetItems,$idSpace,$idRandomForm);