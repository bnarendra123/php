<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

if(!$_POST){
    die();
}

extract($_POST);

if($formPrimaryField != -1){
    $details = $Widgets->_getWidgetItem($formPrimaryField);
    $forms['name'] = "Editing Widget Item : ".$details->titleWidgetItem;

	// Converting the options in to form fields
	$options = unserialize($details->optionsWidgetItem);	
	
	if($options != ''){
		foreach($options as $key => $option){
			$details->{'options_'.$key} = $option;
		}
	}

}else{
    $details = '';
}

$hook = Plugins::_runAction('form_widgets_before_generate',array($forms,$details));
$forms 	 = $hook[0];
$details = $hook[1];

echo $Forms->_generateForm($forms,$details);

if(isset($idWidget)){
	
	$pathFile = Config::_getDir().'/'.$Widgets->_getWidgetDetails($idWidget)->pathWidget.'/form_generated.php';
	
	if( file_exists($pathFile) ){
		include $pathFile;	
	}
}
