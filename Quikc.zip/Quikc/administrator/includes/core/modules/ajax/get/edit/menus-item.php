<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

if(!$_POST){
    die();
}

extract($_POST);

if($formPrimaryField != -1){
    $details = $Menus->_getMenuItemDetails($formPrimaryField);
    $forms['name'] = "Editing Menu Item : ".$details->titleMenuItem;

}else{
    $details = '';
}

$hook = Plugins::_runAction('form_menu_item_before_generate',array($forms,$details));
$forms 	 = $hook[0];
$details = $hook[1];

echo $Forms->_generateForm($forms,$details);

?>
<script>
function menuItemUrl_<?php echo $Forms->_getFormId(); ?>(){
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	
	var linkTypeMenuItem = $("#linkTypeMenuItem_"+idForm).val();
	
	$("#idLinkTypeMenuItem_"+idForm).parent().parent().hide();
	$("#linkMenuItem_"+idForm).parent().parent().hide();
	
	if( linkTypeMenuItem == 1 ){
		$("#idLinkTypeMenuItem_"+idForm).parent().parent().show();
	}

	if( linkTypeMenuItem == 2 ){
		$("#linkMenuItem_"+idForm).parent().parent().show();
	}
	updateTableRows();
}
menuItemUrl_<?php echo $Forms->_getFormId(); ?>();
</script>