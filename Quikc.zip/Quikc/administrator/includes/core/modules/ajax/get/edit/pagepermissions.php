<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission('permissions','view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

// Details of the selected user
$detailsSelectedMenu = $Menus->_loadAdminMenu($formPrimaryField);

if(!$detailsSelectedMenu || $detailsSelectedMenu->linkMenu == '' || !$Permissions->_adminMenuPermissionAllowed($detailsSelectedMenu->linkMenu) ){
	die('Invalid Menu or Permissions Not allowed for this menu.');
}

$groupsAdmin = $User->_getUserGroups();
$permissionMenus = $Permissions->_prepareAdminMenusPermissions($Menus->_getAdminMenus(''));

$generatedForm['form_id'] = 'permiss';
$generatedForm['headding'] = 'Page Permissions : '.$permissionMenus[$detailsSelectedMenu->linkMenu]->titleMenu;

$settoPermissionsPage = "set/pagepermissions";
$successPermissionsPage = 'message_reporting("messageError",\'Permissions updated successfully.\',1);';

/* inserting global permissions into array starts here */
$tmpPermissions = $Permissions->_getAdminPageGlobalPermissions($detailsSelectedMenu->linkMenu);
$tmpPermissions->id 	= -1;
$tmpPermissions->title	= 'Global Permissions';
$arrayPermissions[] 	= $tmpPermissions;
/* inserting global permissions into array ends here */


// inserting admin groups permissions into array
foreach($groupsAdmin as $key => $tmpGroup ){
	
	$tmpPermissions = $Permissions->_getGroupPagePermissions($detailsSelectedMenu->linkMenu,$tmpGroup->idGroup);
	
	$tmpPermissions->id 	= $tmpGroup->idGroup;
	$tmpPermissions->title	= $tmpGroup->nameGroup;

	$arrayPermissions[] = $tmpPermissions;
}

include_once Config::_getDir('admin.temp') .'/elements/permissions.phtml';
include_once Config::_getDir('admin.temp') .'/elements/forms.phtml';

