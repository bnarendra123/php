<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(
                                        "websiteipsall"         =>	Config::_get('website.ips.all'),
                                        "websiteipsblock" 		=>	Config::_get('website.ips.block'),
                                        "websiteipsallow" 		=>	Config::_get('website.ips.allow'),

                                        "websiteipsblockmessageoffline"     =>  Config::_get('website.ips.block.message.offline'),
                                        "websiteipsblockmessage"            =>  Config::_get('website.ips.block.message'),
									);

$hook = Plugins::_runAction('form_settings_ips_before_generate',array($forms,$detailssystemconfig));
$forms 	 = $hook[0];
$detailssystemconfig = $hook[1];

echo $Forms->_generateForm($forms,$detailssystemconfig);

?>
<script>
function settingsIp_<?php echo $Forms->_getFormId();?>(){
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	
	var websiteipsall = getValueFromId("websiteipsall_"+idForm,'');
	
    $("#websiteipsallow_"+idForm).parent().parent().hide();
    $("#websiteipsblock_"+idForm).parent().parent().hide();         

	if( websiteipsall == 1 ){
		$("#websiteipsallow_"+idForm).parent().parent().show();
	}else{
		$("#websiteipsblock_"+idForm).parent().parent().show();			
	}

    var websiteipsblockmessageoffline = getValueFromId("websiteipsblockmessageoffline_"+idForm,'');
    $("#websiteipsblockmessage_"+idForm).parent().parent().hide();         

    if( !websiteipsblockmessageoffline ){
        $("#websiteipsblockmessage_"+idForm).parent().parent().show();
    }
    
	updateTableRows();
}
settingsIp_<?php echo $Forms->_getFormId();?>();

</script>
