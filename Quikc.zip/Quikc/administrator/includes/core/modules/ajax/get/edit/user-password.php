<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

if($formPrimaryField != -1){
	$detailsuser = $User->_getUserDetailsById($formPrimaryField);
}else{
	$detailsuser = '';
}

$hook = Plugins::_runAction('form_admin_password_before_generate',array($forms,$detailsuser));
$forms 		 = $hook[0];
$detailsuser = $hook[1];

echo $Forms->_generateForm($forms,$detailsuser);

