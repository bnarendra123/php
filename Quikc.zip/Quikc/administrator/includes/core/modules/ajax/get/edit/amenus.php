<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

if($formPrimaryField != -1){

	$detailsMenu   = $Menus->_loadAdminMenu($formPrimaryField);

	if($formType == 'copy'){
		$forms['name'] = "Copying Admin Menu : ".$detailsMenu->titleMenu;
		$detailsMenu->$forms['primaryFiled'] = -1;
	}else{
		$forms['name'] = "Edit Admin Menu : ".$detailsMenu->titleMenu;
	}

}else{
	$detailsMenu = '';
}

$hook = Plugins::_runAction('form_admin_menu_before__generate',array($forms,$detailsMenu));
$forms 		 = $hook[0];
$detailsMenu = $hook[1];

echo $Forms->_generateForm($forms,$detailsMenu);

