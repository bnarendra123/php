<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(

                                       "allownewusers" 	                =>  Config::_get('registration.allow.new.users'),

                                       "requirmailconfirmation"        =>  Config::_get('registration.require.mail.confirmation'),
                                       "mailconfirmationcontent"       =>  Config::_get('registration.mail.confirmation.content'),

                                       "mailalert"                      =>  Config::_get('registration.mail.alert'),
                                       "mailalertcontent"               =>  Config::_get('registration.mail.alert.content'),

                                       "requireadminapproval"           =>  Config::_get('registration.require.admin.approval'),
                                       "adminapprovalmailalert"         =>  Config::_get('registration.admin.approval.mail.alert'),
                                       "adminapprovalmailalertcontent"  =>  Config::_get('registration.admin.approval.mail.alert.content'),

                                       "usecaptcha"                     =>  Config::_get('registration.use.captcha'),

									   "defaultadminuser" 		        =>  Config::_get('registration.default.admin.user'),
                                       "defaultadmingroups"             =>  Config::_get('registration.default.admin.groups'),

									);

$hook = Plugins::_runAction('form_settings_registration_before_generate',array($forms,$detailssystemconfig));
$forms 	 = $hook[0];
$detailssystemconfig = $hook[1];

echo $Forms->_generateForm($forms,$detailssystemconfig);

?>
<script>
function settingsRegistration_<?php echo $Forms->_getFormId(); ?>(){
    var idForm = '<?php echo $Forms->_getFormId(); ?>';
    
    var fields = ['requirmailconfirmation','mailconfirmationcontent','mailalert','mailalertcontent','requireadminapproval','adminapprovalmailalert','adminapprovalmailalertcontent','usecaptcha','deafultadminuser','deafultadmingroups'];
    var allownewusers = getValueFromId("allownewusers_"+idForm,'');
    
    for(var i in fields){
        if( allownewusers == 1 ){
            $("#"+fields[i]+"_"+idForm).parent().parent().show();
        }else{
            $("#"+fields[i]+"_"+idForm).parent().parent().hide();           
        }
    }

    var requirmailconfirmationfields = ['mailconfirmationcontent'];
    var requirmailconfirmation = getValueFromId("requirmailconfirmation_"+idForm,'');
    
    for(var i in requirmailconfirmationfields){
        if( requirmailconfirmation == 1 ){
            $("#"+requirmailconfirmationfields[i]+"_"+idForm).parent().parent().show();
        }else{
            $("#"+requirmailconfirmationfields[i]+"_"+idForm).parent().parent().hide();           
        }
    }

    var mailalertfields = ['mailalertcontent'];
    var mailalert = getValueFromId("mailalert_"+idForm,'');
    
    for(var i in requirmailconfirmationfields){
        if( mailalert == 1 ){
            $("#"+mailalertfields[i]+"_"+idForm).parent().parent().show();
        }else{
            $("#"+mailalertfields[i]+"_"+idForm).parent().parent().hide();           
        }
    }

    var requireadminapprovalfields = ['adminapprovalmailalert','adminapprovalmailalertcontent'];
    var requireadminapproval = getValueFromId("requireadminapproval_"+idForm,'');
    
    for(var i in requireadminapprovalfields){
        if( requireadminapproval == 1 ){
            $("#"+requireadminapprovalfields[i]+"_"+idForm).parent().parent().show();
        }else{
            $("#"+requireadminapprovalfields[i]+"_"+idForm).parent().parent().hide();           
        }
    }

    var adminapprovalmailalertfields = ['adminapprovalmailalertcontent'];
    var adminapprovalmailalert = getValueFromId("adminapprovalmailalert_"+idForm,'');
    
    for(var i in requireadminapprovalfields){
        if( adminapprovalmailalert == 1 ){
            $("#"+adminapprovalmailalertfields[i]+"_"+idForm).parent().parent().show();
        }else{
            $("#"+adminapprovalmailalertfields[i]+"_"+idForm).parent().parent().hide();           
        }
    }
    
    updateTableRows();
}
settingsRegistration_<?php echo $Forms->_getFormId(); ?>();

</script>

