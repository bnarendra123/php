<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(  "loginallowonlysuperadmins" 	=>  Config::_get('login.allow.only.super.admins'),
									   "loginsessiontimeout" 		=>  Config::_get('login.session.timeout'),
									   "logininvalidattempts" 		=>  Config::_get('login.invalid.attempts'),
									   "logininvalidshowcaptcha" 	=>  Config::_get('login.invalid.show.captcha'),
									   "logininvalidsendmail" 		=>  Config::_get('login.invalid.send.mail')
									);

$hook = Plugins::_runAction('form_settings_login_before_generate',array($forms,$detailssystemconfig));
$forms 	 = $hook[0];
$detailssystemconfig = $hook[1];

echo $Forms->_generateForm($forms,$detailssystemconfig);


