<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(  "websitetitle"    		=>  Config::_get('website.title'),
									   "websitelogo"     		=>  Config::_get('website.logo'),
									   "websitefavicon"  		=>  Config::_get('website.fav.icon'),
									   "websiteoffline"  		=>  Config::_get('website.offline'),
									   "websiteofflinemessage"  =>  Config::_get('website.offline.message'),
									   "websiteofflineimage"	=>  Config::_get('website.offline.image'),
									   "websitetimezone"		=>  Config::_get('website.timezone'),
									   "websiteurlrewrite"		=>  Config::_get('website.url.rewrite'),
									);

$hook = Plugins::_runAction('form_settings_general_before_generate',array($forms,$detailssystemconfig));
$forms 	 = $hook[0];
$detailssystemconfig = $hook[1];

echo $Forms->_generateForm($forms,$detailssystemconfig);


?>
<script>
function settingsGeneral_<?php echo $Forms->_getFormId();?>(){
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	
	var fields = ['websiteofflinemessage','websiteofflineimage'];
	
	var websiteoffline = getValueFromId("websiteoffline_"+idForm,'');
	
	for(var i in fields){
		if( websiteoffline == 1 ){
			$("#"+fields[i]+"_"+idForm).parent().parent().show();
		}else{
			$("#"+fields[i]+"_"+idForm).parent().parent().hide();			
		}
	}
	
	updateTableRows();
}
settingsGeneral_<?php echo $Forms->_getFormId(); ?>();

</script>