<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(  
                               "fromemail"           		=>	Config::_get('mail.from.address'),
							   "fromname" 		   			=>	Config::_get('mail.from.name'),
                               "sendserver"                 =>  Config::_get('mail.send.server'),
							   "smtpauthentication"  		=>	Config::_get('mail.smtp.authentication'),
							   "smtpsecurity" 	    		=>	Config::_get('mail.smtp.security'),
							   "smtphost" 	        		=>	Config::_get('mail.smtp.host'),
							   "smtpusername" 	    		=>	Config::_get('mail.smtp.username'),
							   "smtppassword" 	            =>	Config::_get('mail.smtp.password'),
							   "smtpport" 	                =>	Config::_get('mail.smtp.port'),									   
							);

$hook = Plugins::_runAction('form_settings_mail_before_generate',array($forms,$detailssystemconfig));
$forms 	 = $hook[0];
$detailssystemconfig = $hook[1];

echo $Forms->_generateForm($forms,$detailssystemconfig);


?>
<script>
function settingsMail_<?php echo $Forms->_getFormId(); ?>(){
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	
	var fields = ['smtpsecurity','smtphost','smtpusername','smtppassword','smtpport'];
	
	var smtpauthentication = getValueFromId("smtpauthentication_"+idForm,'');
	
	for(var i in fields){
		if( smtpauthentication == 1 ){
			$("#"+fields[i]+"_"+idForm).parent().parent().show();
		}else{
			$("#"+fields[i]+"_"+idForm).parent().parent().hide();			
		}
	}
	
	updateTableRows();
}
settingsMail_<?php echo $Forms->_getFormId(); ?>();

</script>
