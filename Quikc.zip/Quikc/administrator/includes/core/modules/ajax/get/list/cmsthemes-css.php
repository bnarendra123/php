<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

$permissionsPage = __FILE__;

$whereQuery = " tf.typeFile = :typeFile ";
$arrayBind[] = array('key' => ':typeFile', 'value' => 'css');

include Config::_getDir('admin').'/includes/core/modules/lists/cmsthemes-files.php';

echo $Lists->_generateList($listData);

