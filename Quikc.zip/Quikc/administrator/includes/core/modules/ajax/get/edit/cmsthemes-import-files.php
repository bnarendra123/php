<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$generatedForm['form_id'] = 'themefilesimport';
$generatedForm['headding'] = 'Import Files to Theme : ';

$lableFile = 'Select Files Zip : ';
$settoZipPage = "set/cmsthemes-import-files";

$generatedForm = Plugins::_runAction('form_cms_themes_import_files_before_generate',$generatedForm);

include_once Config::_getDir('admin.temp') .'/elements/zipuploader.phtml';
include_once Config::_getDir('admin.temp') .'/elements/forms.phtml';
