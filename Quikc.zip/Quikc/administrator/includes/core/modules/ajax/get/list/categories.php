<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission('categories','view') ){
    $Base->_accessRestricted();
}

echo $Lists->_generateList($listData);
		
