<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

if(!$_POST){
    die();
}

extract($_POST);

$permissionsPage = __FILE__;
$fileType = 'css';

include Config::_getDir('admin').'/includes/core/modules/forms/cmsthemes-files.php';

if($formPrimaryField != -1){
	
    $details = $Themes->_getThemeFileDetails($formPrimaryField);
	$details->fileContent = $Themes->_getThemeFileContent($details->pathFile);
	
    $forms['name'] = "Editing Theme File : ".$details->nameFile;

}else{
    $details = '';
}

$hook = Plugins::_runAction('form_cms_themes_files_before_generate',array($forms,$details));
$forms 	 = $hook[0];
$details = $hook[1];

echo $Forms->_generateForm($forms,$details);

?>
<style>.generatedEditor{width:95% !important}</style>