<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    return;
}

$query  = "select * from ".Config::_getTable('cms_pages')." where 
			namePage like :namePage 
			or linkPage = :linkPage 
			or themePage = :themePage 
			or templatePage = :templatePage 
			or descriptionPage = :descriptionPage 
			order by namePage asc";

$arrayBind[]= array("key" => ":namePage",  "value" =>  "%$q%" );
$arrayBind[]= array("key" => ":linkPage",   "value" =>  "%$q%" );
$arrayBind[]= array("key" => ":themePage",   "value" =>  "%$q%" );
$arrayBind[]= array("key" => ":templatePage",   "value" =>  "%$q%" );
$arrayBind[]= array("key" => ":descriptionPage",   "value" =>  "%$q%" );

$actions = array("create","status","edit","delete");

$dataSearch =   array(
                    'title'     => 'Pages',
                    'key'		=> $Base->_getFileName(__FILE__),
                    'query'   	=> $query,
                    'arrayBind' => $arrayBind,

                    'options'   => array(
                                    'title'         => 'namePage',
                                    'primaryField'  => 'idPage',
                                    'statusField'   => 'statusPage',
                                    'imageField'    => '',

                                    'actions'       => $actions,
                                    'filename'      => $Base->_getFileName(__FILE__), 
                                    ),
                    );
                            
