<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

extract($_POST);

if( empty($q) ){
    die();
}

if( empty($items) ){
    die('Not Allowed to View Search Results.');
}

$sortedItems = $SearchMe->_processPreferences($items);

$resultsSearch = array();

$listFiles = $SearchMe->_filesSearchMe();

foreach($listFiles as $fileSearch){

	$dataSearch = $query = '';
	$arrayBind = array();
	
    include_once $fileSearch;
	
	if( isset($dataSearch['key']) && ( !isset($sortedItems[$dataSearch['key']]) || $sortedItems[$dataSearch['key']]['active'] == 'true' ) ){
	
		if( isset($dataSearch['query']) && $dataSearch['query'] != '' ){
			
			if( isset($dataSearch['arrayBind']) ) $arrayBind = $dataSearch['arrayBind'];
			
			$dataSearch['results'] = $SearchMe->_processQuery($query, $arrayBind, $sortedItems[$dataSearch['key']]['rows']);
		}
		
		if( $dataSearch['results'] )
		$resultsSearch[$dataSearch['key']] = $dataSearch;
	}	
}

include_once Config::_getDir('admin.temp') .'/elements/searchme.phtml';



