<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

if($formPrimaryField != -1){

	$detailsUser = $User->_getuserDetailsById($formPrimaryField);
	$detailsUser->groupsUser = explode(',',$detailsUser->groupsUser);

	if($formType == 'copy'){
		$forms['name'] = "Copying Admin User : ".$detailsUser->nameFirstUser.' '.$detailsUser->nameLastUser;
		$detailsUser->$forms['primaryFiled'] = -1;
	}else{
		$forms['name'] = "Editing Admin User : ".$detailsUser->nameFirstUser.' '.$detailsUser->nameLastUser;
	}
}else{
	$detailsUser = '';
}

$hook = Plugins::_runAction('form_users_before_generate',array($forms,$detailsUser));
$forms 		 = $hook[0];
$detailsUser = $hook[1];

echo $Forms->_generateForm($forms,$detailsUser);

?>
<script>
function usersAdminCheckbox_<?php echo $Forms->_getFormId()?>(){
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	
	var fields = ['superUser'];
	
	var adminUser = getValueFromId("adminUser_"+idForm,'');
	
	if( adminUser == 1 ){
		$("#groupsUser_"+idForm).parent().parent().show();
		$("#superUser_"+idForm).parent().parent().show();
	}else{
		$("#groupsUser_"+idForm).parent().parent().hide();
		$("#superUser_"+idForm).parent().parent().hide();
		$("#superUser_"+idForm).attr("checked",false);
	}
	
	updateTableRows();
}
usersAdminCheckbox_<?php echo $Forms->_getFormId(); ?>();

</script>
