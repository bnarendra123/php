<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(  "websitemetadescription" =>  Config::_get('website.meta.description'),
									   "websitemetakeywords"    =>  Config::_get('website.meta.keywords'),
									   "websiterobots"  		=>  Config::_get('website.robots'),
									);

$hook = Plugins::_runAction('form_settings_general_before_generate',array($forms,$detailssystemconfig));
$forms 	 = $hook[0];
$detailssystemconfig = $hook[1];

echo $Forms->_generateForm($forms,$detailssystemconfig);


