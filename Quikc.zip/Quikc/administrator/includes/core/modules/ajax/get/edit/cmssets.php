<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if(!$_POST){
    die();
}

extract($_POST);

if( isset($formPrimaryField) && $formPrimaryField != -1 ){
    $detailsSet = $Cms->_getSetDetails($formPrimaryField);    

	$generatedForm['headding'] = 'Editing Set : '.$detailsSet->nameSet;

}else{
    $formPrimaryField = -1;
    $detailsSet = new stdClass();
    $detailsSet->idSet = $formPrimaryField;

    $fieldsDefault = array('nameSet','linkSet','databaseSet','whereSet','keyFieldSet','displayFieldSet','sortFieldSet','sortOrderFieldSet','nestedFieldSet','nestedStartSet','groupbyFieldSet');
    foreach($fieldsDefault as $field){
        $detailsSet->$field = '';
    }
	
	$generatedForm['headding'] = 'Createing New Set : ';
}

$generatedForm['form_id'] = 'cmssets';

$generatedForm = Plugins::_runAction('form_cms_sets_before_generate',$generatedForm);

include_once Config::_getDir('admin.temp') .'/elements/cmssets.phtml';
include_once Config::_getDir('admin.temp') .'/elements/forms.phtml';

