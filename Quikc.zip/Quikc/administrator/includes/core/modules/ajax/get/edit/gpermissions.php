<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$menusAdmin = $Permissions->_prepareAdminMenusPermissions($Menus->_getAdminMenus(''));

$generatedForm['form_id'] = 'permiss';
$generatedForm['headding'] = 'Global Permissions : ';

$settoPermissionsPage = "set/gpermissions";
$successPermissionsPage = 'message_reporting("messageError",\'Permissions updated successfully.\',1);';

foreach($menusAdmin as $key => $menu){
	$tmpPermissions = $Permissions->_getAdminPageGlobalPermissions($menu->linkMenu);
	
	$tmpPermissions->id 	= $menu->idMenu;
	$tmpPermissions->title	= $menu->titleMenu;

	$arrayPermissions[] = $tmpPermissions;
}

$generatedForm = Plugins::_runAction('form_cms_sets_before_generate',$generatedForm);

include_once Config::_getDir('admin.temp') .'/elements/permissions.phtml';
include_once Config::_getDir('admin.temp') .'/elements/forms.phtml';
