<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(  "cacheenable"          =>	Config::_get('cache.enabled'),
									   "cacheserver" 		  =>	Config::_get('cache.server'),
									   "cachefolder" 		  =>	Config::_get('cache.path'),
									   "cachefileextension"	  =>	Config::_get('cache.file.extension'),
									   "cachetimelimit" 	  =>	Config::_get('cache.time.limit')
									);

$hook = Plugins::_runAction('form_settings_cache_before_generate',array($forms,$detailssystemconfig));
$forms 	 = $hook[0];
$detailssystemconfig = $hook[1];

echo $Forms->_generateForm($forms,$detailssystemconfig);


?>
<script>
function settingsCache_<?php echo $Forms->_getFormId(); ?>(){
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	
	var fields = ['cacheserver','cachefolder','cachefileextension','cachetimelimit'];
	
	var cacheenable = getValueFromId("cacheenable_"+idForm,'');
	
	for(var i in fields){
		if( cacheenable == 1 ){
			$("#"+fields[i]+"_"+idForm).parent().parent().show();
		}else{
			$("#"+fields[i]+"_"+idForm).parent().parent().hide();			
		}
	}
	
	updateTableRows();
}
settingsCache_<?php echo $Forms->_getFormId(); ?>();

</script>
