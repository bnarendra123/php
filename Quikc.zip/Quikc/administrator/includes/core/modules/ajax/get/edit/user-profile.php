<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

if($formPrimaryField != -1){
	$detailsUser = $User->_userDetails();
}else{
	$detailsUser = '';
}

$hook = Plugins::_runAction('form_admin_profile_before_generate',array($forms,$detailsUser));
$forms 		 = $hook[0];
$detailsUser = $hook[1];

echo $Forms->_generateForm($forms,$detailsUser);

