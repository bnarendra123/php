<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$generatedForm['form_id'] = 'newplugin';
$generatedForm['headding'] = 'Add New Plugin : ';

$lableFile = 'Select Plugin Zip : ';
$settoZipPage = "set/pluginsnew";

$generatedForm = Plugins::_runAction('form_plugins_new_before_generate',$generatedForm);

include_once Config::_getDir('admin.temp') .'/elements/zipuploader.phtml';
include_once Config::_getDir('admin.temp') .'/elements/forms.phtml';
