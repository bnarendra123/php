<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'edit') || !$Permissions->_checkPagePermission(__FILE__,'delete') ){
    $Base->_accessRestricted();
}

if(!$_POST){
    die();
}

extract($_POST);

//$listMenus = $Menus->_prepareAdminMenuSet(false);
$listMenus = $Cms -> _prepareTreeView('admin_menus','idMenu','parentMenu','titleMenu',array("statusMenu" => '1'),array("titleMenu"=>'asc'),false,0,'----|&nbsp;');

// Deleting dashboard menu
foreach($listMenus as $key => $tmpMenu){    
    if( $tmpMenu->linkMenu == 'dashboard' ){
        unset($listMenus[$key]);
    }
}

$generatedForm['form_id'] = 'dashboard';
$generatedForm['headding'] = 'Dashboard Icons : ';

$settoPermissionsPage = "set/dashboard";
$successPermissionsPage = 'message_reporting("message_db_report",\'Settings updated successfully.\',1);';

$generatedForm = Plugins::_runAction('form_cms_sets_before_generate',$generatedForm);

include_once Config::_getDir('admin.temp') .'/elements/dashboard.phtml';
include_once Config::_getDir('admin.temp') .'/elements/forms.phtml';
