<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

// Details of the selected group
$detailsGroup = $User->_getUserGroupDetailsById($formPrimaryField);

if(!$detailsGroup){
	die();
}

$arrayPermissions = array(); 
$menusAdmin = $Permissions->_prepareAdminMenusPermissions($Menus->_getAdminMenus(''));

foreach($menusAdmin as $key => $menu){
	$tmpPermissions = $Permissions->_getGroupPagePermissions($menu->linkMenu,$detailsGroup->idGroup);
	
	$tmpPermissions->id 	= $menu->idMenu;
	$tmpPermissions->title	= $menu->titleMenu;
	
	if($menu->systemItem == 0){
		$arrayPermissions[] = $tmpPermissions;	
	}
	
}

$generatedForm['form_id'] = 'permiss';
$generatedForm['headding'] = 'Admin Permissions : '.$detailsGroup->nameGroup;

$settoPermissionsPage = "set/permissions";
$successPermissionsPage = "pageLoad('get/list/agroups');";

include_once Config::_getDir('admin.temp') .'/elements/permissions.phtml';
include_once Config::_getDir('admin.temp') .'/elements/forms.phtml';

