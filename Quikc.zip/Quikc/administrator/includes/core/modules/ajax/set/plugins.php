<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

	$do = $_POST['do'];
	
	if($do == 'edit'){
		$processedForm = $Forms->_processForm($forms,$_POST);
	
		extract($processedForm['formElements']);
        
        $fields = array('namePlugin','autoLoadPlugin','statusPlugin');
                    
		if( count($processedForm['error']) != 0 ){		
			$Base->_convertError($processedForm['error'],false);
		}		
		
		if( $formPrimaryField == -1 ){
		}else{
		
			if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
				$Base->_accessRestricted();
			}

			$setpPart = array();
	
			foreach($fields as $field){
				$setpPart[] = "`$field`=:$field";
				$arrayBind[]= array("key" => ":$field",	"value" =>  $$field );
			}
			$query	= "update ".Config::_getTable('plugins')." set ".implode(",",$setpPart)." where idPlugin = :idPlugin";
			$arrayBind[]= array("key" => ":idPlugin", "value" =>  $formPrimaryField );
	
			if(Core::_runQuery($query,$arrayBind)){

	            $User->_addUserLogActivity($User -> idUser(),46,$namePlugin);
				
				// Updating the cache
				$detailsPlugin = $Plugins->_getPluginDetailsById($formPrimaryField);
	            Cache::_getInstance()->_setCache('plugin_details_'.$detailsPlugin->identifierPlugin,$detailsPlugin);
				
				Plugins::_runAction('plugin_edit',$formPrimaryField);
			}
		}
	}else if($do == 'status'){
			
		if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        $idArray = explode(",",$id);

        $query  = "update ".Config::_getTable('plugins')." set statusPlugin = !statusPlugin where idPlugin = :idPlugin";
        
		foreach($idArray as $tmpId){
            unset($arrayBind);
			$arrayBind[]= array("key" => ":idPlugin", "value" =>  $tmpId);
			Core::_runQuery($query,$arrayBind);

            $detailsPlugin = $Plugins->_getPluginDetailsById($tmpId);
            
			if($detailsPlugin->statusPlugin == 1)
			$idLog = 44;
            else 
            $idLog = 45;
                            
			$User->_addUserLogActivity($User -> idUser(),$idLog,$detailsPlugin->namePlugin);
			
			// Updating the cache
			$detailsPlugin = $Plugins->_getPluginDetailsById($tmpId);
	        Cache::_getInstance()->_setCache('plugin_details_'.$detailsPlugin->identifierPlugin,$detailsPlugin);
		 }

	}else if($do == 'delete'){

		if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
			$Base->_accessRestricted();
		}
        
		$id = $_POST['id'];
		$idArray = explode(",",$id);
        
		foreach($idArray as $tmpId){
				
			$tmpId = Plugins::_runAction('plugin_delete',$tmpId);
			
			$detailsPlugin = $Plugins->_getPluginDetailsById($tmpId);

			if($detailsPlugin){
	            $Plugins->_removePlugin($detailsPlugin->identifierPlugin);

				if(Cache::_getInstance()->_isCached('plugin_details_'.$detailsPlugin->identifierPlugin)){
			        Cache::_getInstance()->_removeCache('plugin_details_'.$detailsPlugin->identifierPlugin);
				}
			}
		}
	}	
	die($messageDie);
}

