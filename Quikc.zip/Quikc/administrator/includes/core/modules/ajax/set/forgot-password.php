<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){
  
	$processedForm = $Forms->_processForm($forms,$_POST);
	extract($processedForm['formElements']);

	if( count($processedForm['error']) == 0 && $User->_checkEmailExistance($email) == false ){
		$processedForm['error'][] = 'Invalid Email';
	}
	
	if( count($processedForm['error']) != 0 ){
		$Base->_convertError($processedForm['error'],false);
	}

	$detailsUser = $User->_getUserDetailsByEmail($email);
	
    if( $detailsUser->statusUser != 1 ){
    	$processedForm['error'][] = Config::_getMessage('forms.validate.account.disabled');
        $Base->_convertError($processedForm['error'],false);
    }

    $randomNumber = $Base->_generateRandomString(10);

    $Mail = new Mail;
    $variables = array(
                        '[:User:]' => $detailsUser->nameFirstUser,
                        '[:Link:]' => $randomNumber,
                    );

    $Mail->_setVariables($variables);
    
    $Mail->_setDbMail('forgot_email');
    
    $Mail->_setTo($detailsUser->emailUser);
    
    $result = $Mail->_send();
    unset($Mail);
	
	die($messageDie);
}

