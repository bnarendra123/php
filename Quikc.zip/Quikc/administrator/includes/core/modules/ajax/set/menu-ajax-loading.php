<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

	extract($_POST);
	
	$User->_setUserPreference('/admin/ajax-menu',$menuAjaxLoading);

	die($messageDie);
}
