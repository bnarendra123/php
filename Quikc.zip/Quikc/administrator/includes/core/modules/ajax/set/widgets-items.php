<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    $do = $_POST['do'];
    
    if($do == 'edit'){
    
        $processedForm = $Forms->_processForm($forms,$_POST);
        extract($processedForm['formElements']);

		if( $formPrimaryField == -1 && !Spaces::_getInstanceById($idSpace)){
			$processedForm['error'][] = 'Invalid Space';
		}

        if( count($processedForm['error']) != 0 ){      
            $error_string = $Base->_convertError($processedForm['error'],false);
        }
		
    	$fields = $processedForm['fields'];
		
		$primaryFields = array('titleWidgetItem','optionsWidgetItem','globalWidgetItem');
		
		$optionField = new stdClass;
		
		if(isset($optionFields) && is_array($optionFields) && count($optionFields) > 0){
			foreach($optionFields as $field){
				$optionField->$field['id'] = ${'options_'.$field['id']};
			}			
		}
		
		$optionsWidgetItem = serialize($optionField);
    
        if($formPrimaryField == -1){
        	
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

			//Preparing the created by fields
			$primaryFields[] = 'idWidget';
			$primaryFields[] = 'idSpace';
			$primaryFields[] = 'createdById';
			$primaryFields[] = 'createdByType';
			
			$createdById = $User -> idUser();
			$createdByType = 'user';

			//Preparing the created by fields

			$insertKeys  = array();
			$insertValues= array();
			
	
			foreach($primaryFields as $field){
				$insertKeys[]  = "`$field`";
				$insertValues[]= ":$field";
				$arrayBind[]= array("key" => ":$field",	"value" => $$field);
			}
			$query = "insert into ".Config::_getTable('widget_items')." (".implode(",",$insertKeys).",dateAdditionWidgetItem) values (".implode(",",$insertValues).",NOW())";

			if(Core::_runQuery($query, $arrayBind)){

	            $formPrimaryField = Core::_getLastInsertId();
	
	            $messageDie = $messageDie."_ID_SPLITTER_".$formPrimaryField;	
				
				Plugins::_runAction('widgets_item_create',$formPrimaryField);
			}else{
				$messageDie = 'Creation Failed';
			}

        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($primaryFields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('widget_items')." set ".implode(",",$setpPart)." where idWidgetItem = :idWidgetItem";
            $arrayBind[]= array("key" => ":idWidgetItem", "value" =>  $formPrimaryField);
    
            if(Core::_runQuery($query, $arrayBind)){
            	Cache::_getInstance() -> _removeCache('widget_item_' . $formPrimaryField);
				
				Plugins::_runAction('widgets_item_edit',$formPrimaryField);
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }
		// Removing the cache
		Cache::_getInstance() -> _removeCache('widgets_item_' . $formPrimaryField);
		
    }else if($do == 'status'){
            
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusWidgetItem";
        }

        // Status change query
        $query  = "update ".Config::_getTable('widget_items')." set statusWidgetItem = ".$changeToField." where idWidgetItem = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
			
			// Removing the cache
			Cache::_getInstance() -> _removeCache('widgets_item_' . $tmpId);
        }
    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        
        // Exploding to get the ids
        $idArray = explode(",",$id);
        
        foreach($idArray as $tmpId){
			$Widgets->_deleteWidgetItem($tmpId);
        }
    }
    die($messageDie);
}

