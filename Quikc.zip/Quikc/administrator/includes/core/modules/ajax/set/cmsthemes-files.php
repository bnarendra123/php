<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if (!isset($permissionsPage))
	die("Missing Variable $permissionsPage");

include Config::_getDir('admin') . '/includes/core/modules/forms/cmsthemes-files.php';

$messageDie = 'ok';

if ($_POST) {

	extract($_POST);

	if ($do == 'edit') {

		$processedForm = $Forms -> _processForm($forms, $_POST);
		extract($processedForm['formElements']);

		if (count($processedForm['error']) != 0) {
			$Base -> _convertError($processedForm['error'], false);
		}

		$fields = $processedForm['fields'];

		if ($formPrimaryField == -1) {

		} else {

			if (!$Permissions -> _checkPagePermission(__FILE__, 'edit')) {
				$Base -> _accessRestricted();
			}

			$detailsFile = $Themes->_getThemeFileDetails($formPrimaryField);
			
			$detailsTheme = $Themes -> _getThemeDetails($detailsFile->idTheme);
			$pathTheme = dirname(Config::_getDir('temp')) . '/' . $detailsTheme -> pathTheme;
  
			$Base->_createFile($pathTheme.'/'.$detailsFile->pathFile,$fileContent);
			
			Plugins::_runAction('cms_themes_file_edit', $formPrimaryField);
		}

	} else if ($do == 'status') {
	} else if ($do == 'delete') {
	}
	die($messageDie);
}
