<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_FILES){
	die('Please Select File.');
}

// Define a destination
$tempDir = Config::_getDir('themes.store').'/working';

if(!isset($_FILES) || !isset($_FILES['zipFile']) || !isset($_FILES['zipFile']['name']) || !isset($_FILES['zipFile']['tmp_name']) || !isset($_FILES['zipFile']['size'])){
    $Base->_convertError(array("Please Select files to upload"),false);
}

$name    = $_FILES['zipFile']['name'];
$tmppath = $_FILES['zipFile']['tmp_name'];
$size    = $_FILES['zipFile']['size'];

$totalfiles  = count($name);
$extension   = array("zip");

$messages = array();

$fileParts = pathinfo($name);
if (in_array(strtolower($fileParts['extension']),$extension)) {

    move_uploaded_file($tmppath,$tempDir.'/'.$name);

    $messages[] = $name.' file of size '.$Base->_convertByes($size).' uploaded Successfully.';
    $messages = array_merge($messages, $Themes->_importFiles($Themes->_getDevelopingTheme()->idTheme,$tempDir.'/'.$name));
}else{
    $messages[] = "Invalid File Format ".$fileParts['extension'] .' for '.$name;
}   
	
$Base->_convertError($messages,false);

