<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if( !$Permissions->_checkPagePermission('settings-cache','edit') ){
	$Base->_accessRestricted();
}

Cache::_getInstance()->_removeAllCache();

Plugins::_runAction('clear_cache');

die('ok');
