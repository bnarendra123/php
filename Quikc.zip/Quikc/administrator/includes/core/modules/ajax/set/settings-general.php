<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$processedForm = $Forms->_processForm($forms,$_POST);

	extract($processedForm['formElements']);
	
	if( count($processedForm['error']) != 0 ){		
		$Base->_convertError($processedForm['error'],false);
	}
	
	$fields = array('websitetitle'	 		=> "website.title",
					'websitelogo' 	 		=> "website.logo",
					'websitefavicon' 		=> "website.fav.icon",
					'websiteoffline' 		=> "website.offline",
					'websiteofflinemessage' => "website.offline.message",
					'websiteofflineimage' 	=> "website.offline.image",
				    'websitetimezone'		=> 'website.timezone',
				    'websiteurlrewrite'		=> 'website.url.rewrite',
					);
	
	if( !$Permissions->_checkPagePermission($Base->_getFileName(__FILE__),'edit') ){
		$Base->_accessRestricted();
	}

	$setpPart = array();
	
	foreach($fields as $keyField => $keyValue){
		if(in_array($keyField, $processedForm['fields'])){
		    Config::_updateDbConfigEntry($keyValue,$$keyField);
		}
	}
	
	if(in_array('websiteurlrewrite', $processedForm['fields'])){
		if($websiteurlrewrite && file_exists(Config::_getDir().'/htaccess.txt') && !file_exists(Config::_getDir().'/.htaccess') ){
			rename(Config::_getDir().'/htaccess.txt', Config::_getDir().'/.htaccess');
		}
	
		if(!$websiteurlrewrite && !file_exists(Config::_getDir().'/htaccess.txt') && file_exists(Config::_getDir().'/.htaccess') ){
			rename(Config::_getDir().'/.htaccess', Config::_getDir().'/htaccess.txt');
		}

	}	
	die('ok');
}

