<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$processedForm = $Forms->_processForm($forms,$_POST);

	extract($processedForm['formElements']);

	if(in_array('cachefolder', $processedForm['fields'])){
		if(!is_dir(Config::_getDir().$cachefolder)){
			$processedForm['error'][] = 'The folder \''.$cachefolder.'\' doesn\'t exist.';
		}
		
		if(!is_writable(Config::_getDir().$cachefolder)){
			$processedForm['error'][] = 'The folder \''.$cachefolder.'\' is not writable.';
		}
	}
	
	if(in_array('cachetimelimit', $processedForm['fields'])){
		if( (int)$cachetimelimit <= 0 ){
			$processedForm['error'][] = 'Cache Time Limit should be an integer and greater than 0';
		}
	}
	
	if( count($processedForm['error']) != 0 ){		
		$Base->_convertError($processedForm['error'],false);
	}
	
	if(!$cacheenable || Config::_get('cache.file.extension') != $cachefileextension ){
		Cache::_getInstance()->_removeAllCache();
	}
	
	$fields = array(
                "cacheenable"         =>	"cache.enabled",
			    "cacheserver" 		  =>	"cache.server",
			    "cachefolder" 		  =>	"cache.path",
			    "cachefileextension"  =>	"cache.file.extension",
			    "cachetimelimit" 	  =>	"cache.time.limit",
			  );
					
	
	if( !$Permissions->_checkPagePermission($Base->_getFileName(__FILE__),'edit') ){
		$Base->_accessRestricted();
	}

	$setpPart = array();
	
	foreach($fields as $keyField => $keyValue){
		if(in_array($keyField, $processedForm['fields'])){
		    Config::_updateDbConfigEntry($keyValue,$$keyField);
		}
	}
	
	die('ok');
}

