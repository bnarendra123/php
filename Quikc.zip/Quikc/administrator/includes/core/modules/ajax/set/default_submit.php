<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$do = $_POST['do'];
	
	if($do == 'edit'){
	
		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);

		if( count($processedForm['error']) != 0 ){		
			$error_string = $Base->_convertError($processedForm['error'],true);
			die($error_string);
		}
		
		$fields = array('nameLanguage','codeLanguage','defaultLanguage','statusLanguage');
	
		if($formPrimaryField == -1){
	
			if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
				$Base->_accessRestricted();
			}

			$insertKeys  = array();
			$insertValues= array();
			
			foreach($fields as $field){
				$insertKeys[]  = "`$field`";
				$insertValues[]= ":$field";
				$arrayBind[]= array("key" => ":$field",	"value" => $$field);
			}
			$query = "insert into ".Config::_getTable('languages')." (".implode(",",$insertKeys).") values (".implode(",",$insertValues).")";
			$statusQuery= Core::_runQuery($query, $arrayBind);
			
		}else{
	
			if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
				$Base->_accessRestricted();
			}

			$setpPart = array();
	
			foreach($fields as $field){
				$setpPart[] = "`$field`=:$field";
				$arrayBind[]= array("key" => ":$field",	"value" =>  $$field );
			}
			$query	= "update ".Config::_getTable('languages')." set ".implode(",",$setpPart)." where idLanguage = :idLanguage";
			$arrayBind[]= array("key" => ":idLanguage", "value" =>  $formPrimaryField);
	
			$statusQuery= Core::_runQuery($query,$arrayBind);
		}
	}else if($do == 'status'){
			
		if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
			$Base->_accessRestricted();
		}

		$id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
		$query	= "update ".Config::_getTable('languages')." set statusLanguage = !statusLanguage where idLanguage = :idLanguage";
		$arrayBind[]= array("key" => ":idLanguage", "value" =>  $id);

		$statusQuery= Core::_runQuery($query,$arrayBind);
	}else if($do == 'delete'){

		if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
			$Base->_accessRestricted();
		}

		$id = $_POST['id'];
		$query	= "delete from ".Config::_getTable('languages')." where idLanguage = :idLanguage";
		$arrayBind[]= array("key" => ":idLanguage", "value" =>  $id);

		$statusQuery= Core::_runQuery($query,$arrayBind);
	}
	die('ok');
}

?>
