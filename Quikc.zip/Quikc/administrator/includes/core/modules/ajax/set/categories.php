<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    $do = $_POST['do'];
	
	if($do == 'edit'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// Form edit action starts here

		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);
		
        if( count($processedForm['error']) != 0 ){      
            $Base->_convertError($processedForm['error'],false);
        }

        $fields = $processedForm['fields'];

        unset($arrayBind);
		
        if($formPrimaryField == -1){
    
            if( !$Permissions->_checkPagePermission('categories','create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fields as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('categories')." (".implode(",",$insertKeys).",dateAdditionCategory) values (".implode(",",$insertValues).",NOW())";

           if(Core::_runQuery($query, $arrayBind)){
				$formPrimaryField = Core::_getLastInsertId();
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }else{
    
            if( !$Permissions->_checkPagePermission('categories','edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('categories')." set ".implode(",",$setpPart)." where idCategory = :formPrimaryField";
            $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
    
           if(!Core::_runQuery($query, $arrayBind)){
				$Base->_convertError(array("Save Filed"),false);  
            }
        }

		// Form edit action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }else if($do == 'status'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// List status action starts here

		if( !$Permissions->_checkPagePermission('categories','edit') ){
			$Base->_accessRestricted();
		}
        
        extract($_POST);
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusCategory";
        }

        // Status change query
        $query  = "update ".Config::_getTable('categories')." set statusCategory = ".$changeToField." where `idCategory` = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
        }
        
		// List status action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }else if($do == 'delete'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// List delete action starts here

		if( !$Permissions->_checkPagePermission('categories','delete') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
		
        // Exploding to get the ids
        $idArray = explode(",",$id);

        foreach($idArray as $tmpId){

            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);

            $query  = "delete from ".Config::_getTable('categories')." where `idCategory` = :primaryField";
            Core::_runQuery($query,$arrayBind);
	        
        }

		// List delete action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }
    die($messageDie);
}
		