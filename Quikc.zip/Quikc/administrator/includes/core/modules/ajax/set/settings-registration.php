<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$processedForm = $Forms->_processForm($forms,$_POST);

	extract($processedForm['formElements']);
	
	if( count($processedForm['error']) != 0 ){		
		$Base->_convertError($processedForm['error'],false);
	}
	
	$fields = array(
                   "allownewusers"                  =>  'registration.allow.new.users',
                   "requirmailconfirmation"         =>  'registration.require.mail.confirmation',
                   "mailconfirmationcontent"        =>  'registration.mail.confirmation.content',
                   "mailalert"                      =>  'registration.mail.alert',
                   "mailalertcontent"               =>  'registration.mail.alert.content',
                   "requireadminapproval"           =>  'registration.require.admin.approval',
                   "adminapprovalmailalert"         =>  'registration.admin.approval.mail.alert',
                   "adminapprovalmailalertcontent"  =>  'registration.admin.approval.mail.alert.content',
                   "usecaptcha"                     =>  'registration.use.captcha',
                   "defaultadminuser"               =>  'registration.default.admin.user',
                   "defaultadmingroups"             =>  'registration.default.admin.groups',
			  );


	$setpPart = array();
	
	foreach($fields as $keyField => $keyValue){
		if(in_array($keyField, $processedForm['fields'])){
		    Config::_updateDbConfigEntry($keyValue,$$keyField);
		}
	}
	
	die('ok');
}

