<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$processedForm = $Forms->_processForm($forms,$_POST);

	extract($processedForm['formElements']);

    // Condition 1. Checking if Block All Ips except allowed is in fields
    // Condition 2. Checking if Block All Ips except allowed is checked
    // Condition 3. Checking if Website Allow Ips is in fields
    if( in_array('websiteipsallow', $processedForm['fields']) && $websiteipsall && in_array('websiteipsallow', $processedForm['fields'])){

        $oneValidIp = false;            

        if( $websiteipsallow  != ''){

            $arrayAllowIps = explode(',',$websiteipsallow);

            foreach($arrayAllowIps as $ip){
                if( filter_var($ip, FILTER_VALIDATE_IP) ) {
                    $oneValidIp = true;
                    break;
                }
            }
        }
            
        if( !$oneValidIp ){
            $processedForm['error'][] = 'Please Enter Atleast one Valid Ip.';
        }

    }

	if( count($processedForm['error']) != 0 ){		
		$Base->_convertError($processedForm['error'],false);
	}
	
	$fields = array(
                "websiteipsall"         =>	"website.ips.all",
			    "websiteipsblock" 		=>	"website.ips.block",
			    "websiteipsallow" 		=>	"website.ips.allow",

                "websiteipsblockmessageoffline"      =>  "website.ips.block.message.offline",
                "websiteipsblockmessage"             =>  "website.ips.block.message",
			  );

	if( !$Permissions->_checkPagePermission($Base->_getFileName(__FILE__),'edit') ){
		$Base->_accessRestricted();
	}

	$setpPart = array();
	
	foreach($fields as $keyField => $keyValue){
		if(in_array($keyField, $processedForm['fields'])){
		    Config::_updateDbConfigEntry($keyValue,$$keyField);
		}
	}
	
	die('ok');
}

