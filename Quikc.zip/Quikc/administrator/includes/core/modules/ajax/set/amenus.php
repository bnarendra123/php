<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){
	
	$do = $_POST['do'];
	
	if($do == 'edit'){
	
		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);

        if($formPrimaryField != -1 && $statusMenu == '0' && $Admin->_checkAdminSystemMenu($formPrimaryField)){
            $processedForm['error'][]  = Config::_prepareMessage('forms.amenus.disable.system.menu',array(":MENU_TITLE" => $Menus->_loadAdminMenu($formPrimaryField)->titleMenu));
        }
		
		if( count($processedForm['error']) != 0 ){		
			$Base->_convertError($processedForm['error'],false);
		}
		
		$linkMenu = $Base->_prepareLink($linkMenu);
		
		$fields = $processedForm['fields'];

        /*if( !isset($formPrimaryField) || $formPrimaryField == -1 || $Menus->_loadAdminMenu($formPrimaryField)->systemItem != 1 || $Admin->_isDeveloperMode() ){
            $fields[] = 'linkMenu';
        }*/
        
		if($formPrimaryField == -1){
	
			if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
				$Base->_accessRestricted();
			}

			//Preparing the created by fields
			$fields[] = 'createdById';
			$fields[] = 'createdByType';
			
			$createdById = $User -> idUser();
			$createdByType = 'user';
			//Preparing the created by fields

			$insertKeys  = array();
			$insertValues= array();
			
	
			foreach($fields as $field){
				$insertKeys[]  = "`$field`";
				$insertValues[]= ":$field";
				$arrayBind[]= array("key" => ":$field",	"value" => $$field);
			}
			$query = "insert into ".Config::_getTable('admin_menus')." (".implode(",",$insertKeys).",dateAdditionAdminMenu) values (".implode(",",$insertValues).",NOW())";

			if(Core::_runQuery($query, $arrayBind)){

	            $formPrimaryField = Core::_getLastInsertId();
	
	            $messageDie = $messageDie."_ID_SPLITTER_".$formPrimaryField;	
	            $User->_addUserLogActivity($User -> idUser(),5,$titleMenu);
				
				Plugins::_runAction('admin_menu_create',$formPrimaryField);
			}else{
				$messageDie = 'Creation Failed';
			}

		}else{
	
			if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
				$Base->_accessRestricted();
			}

			$setpPart = array();
	
			foreach($fields as $field){
				$setpPart[] = "`$field`=:$field";
				$arrayBind[]= array("key" => ":$field",	"value" =>  $$field );
			}
			$query	= "update ".Config::_getTable('admin_menus')." set ".implode(",",$setpPart)." where idMenu = :idMenu";
			$arrayBind[]= array("key" => ":idMenu", "value" =>  $formPrimaryField);
	
			if(Core::_runQuery($query,$arrayBind)){
				$User->_addUserLogActivity($User -> idUser(),6,$titleMenu);
				Plugins::_runAction('admin_menu_edit',$formPrimaryField);
			}else{
				$messageDie = 'Save Failed';
			}
		}
	}else if($do == 'status'){
			
		if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        $systeMenus = array();
        foreach($idArray as $tmpId){
            if($Menus->_checkAdminSystemMenu($tmpId)){
                $systeMenus[] = $Menus->_loadAdminMenu($tmpId)->titleMenu.'('.$tmpId.')';
            }
        }
        if( count($systeMenus) > 0){
            $error  = Config::_prepareMessage('forms.amenus.disable.system.menu',array(":MENU_TITLE" => implode($systeMenus,',')));
            die($error);
        }

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
            $idLog = 27;
        }else if($changeTo == '0'){
            $changeToField = 0;
            $idLog = 28;
        }else{
            $idLog = 26;
            $changeToField = "!statusMenu";
        }

        // Status change query
        $query  = "update ".Config::_getTable('admin_menus')." set statusMenu = ".$changeToField." where idMenu = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
            $User->_addUserLogActivity($User -> idUser(),$idLog,$Menus->_loadAdminMenu($tmpId)->titleMenu);
        }
        
	}else if($do == 'delete'){

		if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
		
        // Exploding to get the ids
        $idArray = explode(",",$id);

        $systeMenus = array();
        foreach($idArray as $tmpId){
            if($Menus->_checkAdminSystemMenu($tmpId)){
                $systeMenus[] = $Menus->_loadAdminMenu($tmpId)->titleMenu.'('.$tmpId.')';
            }
        }
        if( count($systeMenus) > 0){
			$error  = Config::_prepareMessage('forms.amenus.disable.system.menu',array(":MENU_TITLE" => implode($systeMenus,',')));
            die($error);
            //die("Can't delete System Menus '".implode($systeMenus,',')."'.");
        }
		
        // delete query
        $query  = "delete from ".Config::_getTable('admin_menus')." where idMenu = :primaryField";
        foreach($idArray as $tmpId){

			$tmpId = Plugins::_runAction('admin_menu_delete',$tmpId);

            $titleMenu = $Menus->_loadAdminMenu($tmpId)->titleMenu;
			
			if($titleMenu){
	            unset($arrayBind);
	            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
	            Core::_runQuery($query,$arrayBind);
	            $User->_addUserLogActivity($User -> idUser(),29,$titleMenu);
			}
        }
	}

    Cache::_getInstance()->_removeCache('admin_menus_list');
	die($messageDie);
}

