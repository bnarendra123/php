<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    $do = $_POST['do'];
	
	if($do == 'edit'){
    
        $processedForm = $Forms->_processForm($forms,$_POST);
        extract($processedForm['formElements']);
		
        if( count($processedForm['error']) != 0 ){      
            $error_string = $Base->_convertError($processedForm['error'],true);
            die($error_string);
        }
                  
        
        $fields = array('keyConfig','valueConfig');
    
        if($formPrimaryField == -1){
    
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

			//Preparing the created by fields

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fields as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('configuration')." (".implode(",",$insertKeys).",dateAdditionConfig) values (".implode(",",$insertValues).",NOW())";

            if( Core::_runQuery($query, $arrayBind) ){
				$formPrimaryField = Core::_getLastInsertId();
	    		Plugins::_runAction('configuration_key_create',$keyConfig);
            }else{
				$messageDie = 'Creation Failed';
            }
            
        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('configuration')." set ".implode(",",$setpPart)." where idConfig = :idConfig";
            $arrayBind[]= array("key" => ":idConfig", "value" =>  $formPrimaryField);
    
            if(Core::_runQuery($query,$arrayBind)){
            	Plugins::_runAction('configuration_key_edit',$keyConfig);
            }else{
				$messageDie = 'Save Failed';
            }
			
        }
    }else if($do == 'status'){
            
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusConfig";
        }

        // Status change query
        $query  = "update ".Config::_getTable('configuration')." set statusConfig = ".$changeToField." where idConfig = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);                
        }
    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        
        // Exploding to get the ids
        $idArray = explode(",",$id);
        
        $query  = "delete from ".Config::_getTable('configuration')." where idConfig = :primaryField";
        foreach($idArray as $tmpId){
        	
        	$tmpId = Plugins::_runAction('configuration_key_delete',$tmpId);

            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
        }        
    }
    die($messageDie);
}

