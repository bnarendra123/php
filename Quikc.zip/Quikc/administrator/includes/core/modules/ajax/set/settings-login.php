<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$processedForm = $Forms->_processForm($forms,$_POST);

	extract($processedForm['formElements']);
	
	if(in_array('loginsessiontimeout', $processedForm['fields'])){
		if( (int)$loginsessiontimeout <= 0 ){
			$processedForm['error'][] = 'Login session timeout should be an integer and greater than 0';
		}
	}

	if(in_array('logininvalidattempts', $processedForm['fields'])){
		if( (int)$logininvalidattempts <= 0 ){
			$processedForm['error'][] = 'Invalid Login Attempts should be an integer and greater than 0';
		}
	}
	
	if( count($processedForm['error']) != 0 ){		
		$Base->_convertError($processedForm['error'],false);
	}
	
	$fields = array('loginallowonlysuperadmins' =>	"login.allow.only.super.admins",
					'loginsessiontimeout' 		=>	"login.session.timeout",
					'logininvalidattempts' 		=>	"login.invalid.attempts",
					'logininvalidshowcaptcha' 	=>	"login.invalid.show.captcha",
					'logininvalidsendmail' 		=>	"login.invalid.send.mail"
					);
	
	if( !$Permissions->_checkPagePermission($Base->_getFileName(__FILE__),'edit') ){
		$Base->_accessRestricted();
	}

	$setpPart = array();
	
	foreach($fields as $keyField => $keyValue){
		if(in_array($keyField, $processedForm['fields'])){
		    Config::_updateDbConfigEntry($keyValue,$$keyField);
		}
	}
	die('ok');
}

