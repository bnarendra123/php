<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
        $Base->_accessRestricted();
    }

	extract($_POST);
	
	$Relations->_deleteRalations('space_to_widget',$idSpace);

	//_generateRalation($typeRelation,$idFrom,$idTo,$fieldAdditional1='',$fieldAdditional2='',$fieldAdditional3='')
	
	$arrayWidgetItems = explode(",",$widgetItems);

	$i = 1;
	foreach($arrayWidgetItems as $item){
		$Relations->_generateRalation('space_to_widget',$idSpace,$item,$i);
		$i++;
	}	
		
    die($messageDie);
}

