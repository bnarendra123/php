<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    $do = $_POST['do'];
	
	if($do == 'edit'){
    
        $processedForm = $Forms->_processForm($forms,$_POST);
        extract($processedForm['formElements']);
		
		if(in_array('linkPage', $processedForm['fields'])){
			
			if( $linkPage == '') $linkPage = $namePage;
			
	        $linkPage = $Base->_prepareLink($linkPage);
			
			$detailsLink = $Cms->_getPageDetailsByLink($linkPage);
			
	        if( $detailsLink && $detailsLink->idParentPage == $idParentPage && $detailsLink->idPage != $formPrimaryField){      
	            $processedForm['error'][] = 'Page Link already exists';
	        }
		}
		
		if( in_array('typePage',$processedForm['fields']) ){
		    
            if( $typePage == 'plugins'){
			
	    		$themePage = '';
			
    		}else if( $typePage == 'themes'){
			
			$pluginPage = '';

			}
			
		}

        if( count($processedForm['error']) != 0 ){      
            $error_string = $Base->_convertError($processedForm['error'],true);
            die($error_string);
        }
        
        if( in_array('linkPage',$processedForm['fields']) ){
            
            $processedForm['fields'][] = 'fullLinkPage';

            $fullLinkPage = $Cms->_getPageLink($idParentPage).$linkPage."/";

        }

        $fields = $processedForm['fields'];
		
        if($formPrimaryField == -1){
    
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fields as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('pages')." (".implode(",",$insertKeys).", dateAdditionPage) values (".implode(",",$insertValues).", NOW())";

           if(Core::_runQuery($query, $arrayBind)){
				$formPrimaryField = Core::_getLastInsertId();
				Plugins::_runAction('page_create',$formPrimaryField);
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('pages')." set ".implode(",",$setpPart)." where idPage = :idPage";
            $arrayBind[]= array("key" => ":idPage", "value" =>  $formPrimaryField);
    
           if(Core::_runQuery($query, $arrayBind)){
				Plugins::_runAction('page_edit',$formPrimaryField);
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }

		//Updating the cache
		$detailsPage = $Cms->_getPageDetails($formPrimaryField);
        
        // Making the other pages as non default if the currnet page is the default page
		if(in_array('defaultPage', $fields) && $defaultPage){
			unset($arrayBind);
            $query  = "update ".Config::_getTable('pages')." set defaultPage = 0 where idPage != :idPage";
            $arrayBind[]= array("key" => ":idPage", "value" =>  $formPrimaryField);
            Core::_runQuery($query,$arrayBind);
			
	        Cache::_getInstance()->_setCache('cms_pages_default_page',$detailsPage -> linkPage);
		}else{
	        Cache::_getInstance()->_removeCache('cms_pages_default_page');
		}
		
    }else if($do == 'status'){
            
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }

        extract($_POST);
        // Exploding to get the ids
        $idArray = explode(",",$id);

		$detailsDefaultPage = $Cms -> _getPageDetailsByLink( $Cms->_getDefaultPage() );

		// Condition1 : If default page is selected
		// Condition2 : If its status is going to change to disable ( $changeTo == 0 will identify disabling through multiple actions)
		// Condition3 : If the stauts is inverting and current status of the default page is enabled
		// Then throwing error message in these cases
		// Or if default language is not selected or we are enabling its status, then we will allow further actions
		if( in_array($detailsDefaultPage->idPage,$idArray) && ( $changeTo == '0' || ( $changeTo != 1 && $detailsDefaultPage -> statusPage )) ){
            die("Can't disable Defautl Page");
		}				

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusPage";
        }

        // Status change query
        $query  = "update ".Config::_getTable('pages')." set statusPage = ".$changeToField." where idPage = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
			
			//Updating the cache
			$detailsPage = $Cms->_getPageDetails($tmpId);
        }
    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        
        // Exploding to get the ids
        $idArray = explode(",",$id);
        
        $query  = "delete from ".Config::_getTable('pages')." where idPage = :primaryField";
        foreach($idArray as $tmpId){
        	
			$tmpId = Plugins::_runAction('page_edit',$tmpId);
			
			//Getting the page details for the further user
			$detailsPage = $Cms->_getPageDetails($tmpId);

			if($detailsPage){
	            unset($arrayBind);
	            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
	            Core::_runQuery($query,$arrayBind);
				
	        	//Removing the cached page  entry
				Cache::_getInstance()->_removeCache('cms_pages_'.$detailsPage->linkPage);
			}			

        }        
    }
    die($messageDie);
}

