<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){
	
	$do = $_POST['do'];
	
	if($do == 'edit'){
	
		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);

		if( count($processedForm['error']) != 0 ){		
			$Base->_convertError($processedForm['error'],false);
		}
		
		$fields = $processedForm['fields'];
		//$fields = array('titleMenu','descriptionMenu','statusMenu');


		if($formPrimaryField == -1){
	
			if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
				$Base->_accessRestricted();
			}

			$insertKeys  = array();
			$insertValues= array();
	
			foreach($fields as $field){
				$insertKeys[]  = "`$field`";
				$insertValues[]= ":$field";
				$arrayBind[]= array("key" => ":$field",	"value" => $$field);
			}
			$query = "insert into ".Config::_getTable('menus')." (".implode(",",$insertKeys).",dateAdditionMenu) values (".implode(",",$insertValues).",NOW())";

			if(Core::_runQuery($query, $arrayBind)){

	            $formPrimaryField = Core::_getLastInsertId();
	
	            $messageDie = $messageDie."_ID_SPLITTER_".$formPrimaryField;	
				
				Plugins::_runAction('menu_create',$formPrimaryField);
			}else{
				$messageDie = 'Creation Failed';
			}

		}else{
	
			if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
				$Base->_accessRestricted();
			}

			$setpPart = array();
	
			foreach($fields as $field){
				$setpPart[] = "`$field`=:$field";
				$arrayBind[]= array("key" => ":$field",	"value" =>  $$field );
			}
			$query	= "update ".Config::_getTable('menus')." set ".implode(",",$setpPart)." where idMenu = :idMenu";
			$arrayBind[]= array("key" => ":idMenu", "value" =>  $formPrimaryField);
	
			if(Core::_runQuery($query,$arrayBind)){
				Plugins::_runAction('menu_edit',$formPrimaryField);
				Cache::_getInstance() -> _removeCache('cms_menus_' . $formPrimaryField);
			}else{
				$messageDie = 'Save Failed';
			}
		}
	}else if($do == 'status'){
			
		if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        // Exploding to get the ids
        $idArray = explode(",",$id);


        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
            $idLog = 27;
        }else if($changeTo == '0'){
            $changeToField = 0;
            $idLog = 28;
        }else{
            $idLog = 26;
            $changeToField = "!statusMenu";
        }

        // Status change query
        $query  = "update ".Config::_getTable('menus')." set statusMenu = ".$changeToField." where idMenu = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
        }
        
	}else if($do == 'delete'){

		if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
		
		
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Status change query
        $query  = "delete from ".Config::_getTable('menus')." where idMenu = :primaryField";
        foreach($idArray as $tmpId){

			$tmpId = Plugins::_runAction('menu_delete',$tmpId);

            $titleMenu = $Menus->_loadAdminMenu($tmpId)->titleMenu;
			
			if($titleMenu){
	            unset($arrayBind);
	            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
	            Core::_runQuery($query,$arrayBind);
	            $User->_addUserLogActivity($User -> idUser(),29,$titleMenu);
			}
        }
	}

    Cache::_getInstance()->_removeCache('admin_menus_list');
	die($messageDie);
}


