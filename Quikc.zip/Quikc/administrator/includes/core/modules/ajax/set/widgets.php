<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    $do = $_POST['do'];
    
    if($do == 'edit'){
    
        $processedForm = $Forms->_processForm($forms,$_POST);
        extract($processedForm['formElements']);

		if( $formPrimaryField == -1){

			if( $Widgets->_getWidgetDetailsByPath($pathWidget) ){
				$processedForm['error'] = 'Widget Already Exists with the path '.$pathWidget;
			}elseif( !file_exists(Config::_getDir().'/'.$pathWidget) || !is_dir(Config::_getDir().'/'.$pathWidget) ){
				$processedForm['error'] = 'Invalid Widget Directory '.Config::_getDir().'/'.$pathWidget;
			}
		}

        if( count($processedForm['error']) != 0 ){      
            $error_string = $Base->_convertError($processedForm['error'],true);
            die($error_string);
        }
		
    	$fields = $processedForm['fields'];
    
        if($formPrimaryField == -1){
        	
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

			//Preparing the created by fields
			$fields[] = 'createdById';
			$fields[] = 'createdByType';
			
			$createdById = $User -> idUser();
			$createdByType = 'user';

			//Preparing the created by fields
			$insertKeys  = array();
			$insertValues= array();
			$arrayBind	 = array();
	
			foreach($fields as $field){
				$insertKeys[]  = "`$field`";
				$insertValues[]= ":$field";
				$arrayBind[]= array("key" => ":$field",	"value" => $$field);
			}
			$query = "insert into ".Config::_getTable('widgets')." (".implode(",",$insertKeys).",dateAdditionWidget) values (".implode(",",$insertValues).",NOW())";

			if(Core::_runQuery($query, $arrayBind)){

	            $formPrimaryField = Core::_getLastInsertId();
	
	            $messageDie = $messageDie."_ID_SPLITTER_".$formPrimaryField;	
				
				Plugins::_runAction('widget_create',$formPrimaryField);
			}else{
				$messageDie = 'Creation Failed';
			}
        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('widgets')." set ".implode(",",$setpPart)." where idWidget = :idWidget";
            $arrayBind[]= array("key" => ":idWidget", "value" =>  $formPrimaryField);
    
            if(Core::_runQuery($query, $arrayBind)){
				Cache::_getInstance() -> _removeCache('widgets_' . $formPrimaryField);
				Plugins::_runAction('widgets_edit',$formPrimaryField);
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }
		// Removing the cache
		Cache::_getInstance() -> _removeCache('widgets_' . $formPrimaryField);
		
    }else if($do == 'status'){
            
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusWidget";
        }

        // Status change query
        $query  = "update ".Config::_getTable('widgets')." set statusWidget = ".$changeToField." where idWidget = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
			
			// Removing the cache
			Cache::_getInstance() -> _removeCache('widgets_' . $tmpId);
        }
    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        
        // Exploding to get the ids
        $idArray = explode(",",$id);
        
        $query  = "delete from ".Config::_getTable('widgets')." where idWidget = :primaryField";
        foreach($idArray as $tmpId){

			$tmpId = Plugins::_runAction('widgets_delete',$tmpId);
			
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
            
			// Removing the cache
			Cache::_getInstance() -> _removeCache('widgets_' . $tmpId);
			
			// Removing widget Items 
			$listItems = $Widgets->_getWidgetItemsByWidget($tmpId);
		
			foreach($listItems as $item){
				$Widgets->_deleteWidgetItem($item->idWidgetItem);
			}

        }
    }
    die($messageDie);
}

