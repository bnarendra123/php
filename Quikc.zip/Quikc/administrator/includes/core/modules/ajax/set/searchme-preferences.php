<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	extract($_POST);

	$errors = array();
	
	if( !in_array($do, array('save','delete')) ){
		$errors[] = 'Invalid Action';
	}
	
	if( ( !isset($title) || $title == '' ) && $do == 'save' ){
		$errors[] = 'Please Enter Title';
	}
	
	if( isset($title) && strlen($title) > 10 ){
		$title = substr($title, 0, 10);
	}

    if( count($errors) != 0 ){      
        $Base->_convertError($errors,false);
    }

	$sortedItems = $SearchMe->_processPreferences($items);
	
	$prefCurr	= array(	
					'title' => $title,
					'items' => $sortedItems,
					);

	$prefList = $User->_getUserPreference('/admin/searchme/preferences');

	if( $do == 'save' ){
		if( $formPrimaryField == -1 ){
			$prefList[] = $prefCurr;
			
			end($prefList);
			$idPref = key($prefList);
		}else{
			$prefList[$formPrimaryField] = $prefCurr;
			$idPref = $formPrimaryField;
		}

		if( $defaultLoad ){
			$User->_setUserPreference('/admin/searchme/preferences/default',$idPref);
		}elseif( !$defaultLoad && $SearchMe->_getDefaultPreference() == $idPref ){
			$User->_setUserPreference('/admin/searchme/preferences/default',-1);
		}
	}else if( $do == 'delete' ){
		unset($prefList[$formPrimaryField]);
	}

	$User->_setUserPreference('/admin/searchme/preferences',$prefList);
	
	if( $formPrimaryField == -1 || $do == 'delete' ){
		include Config::_getDir('admin').'/includes/core/modules/ajax/get/list/searchme-preferences.php';
		die();
	}	
}

die('ok');
