<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$processedForm = $Forms->_processForm($forms,$_POST);

	extract($processedForm['formElements']);
	
	if( $User->_checkEmailExistance($emailUser) && $formPrimaryField != $User->_getUserDetailsByEmail($emailUser)->idUser ){
		//$processedForm['error'][] = "Email already Exists.";
		$processedForm['error'][] = Config::_getMessage('forms.validation.email.exists');
	}
	
	if( count($processedForm['error']) != 0 ){		
		$Base->_convertError($processedForm['error'],false);
	}
	
	$fields = $processedForm['fields'];	
	
	if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
		$Base->_accessRestricted();
	}

	$setpPart = array();

	foreach($fields as $field){
		$setpPart[] = "`$field`=:$field";
		$arrayBind[]= array("key" => ":$field",	"value" =>  $$field );
	}
	
	$query	= "update ".Config::_getTable('users')." set ".implode(",",$setpPart)." where idUser = :idUser";
	$arrayBind[]= array("key" => ":idUser", "value" =>  $formPrimaryField );
	
	if(Core::_runQuery($query,$arrayBind)){
		Plugins::_runAction('user_profile_edit',$formPrimaryField);
	}else{
		$Base->_convertError(array("Save Filed"),false);  
    }
	
	die('ok');
}

