<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');


$messageDie = 'ok';

if($_POST){

    if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
        $Base->_accessRestricted();
    }

	extract($_POST);
	
	if( !isset($idMenu) || !$Menus->_getMenuDetails($idMenu) ) die('Invalid Menu');
	
	if( !isset($dataMenu) || $dataMenu  == '')  die('No Data Available');
	
	// This function is used to update the menu parent of all the current level of array elements and call the same function to update is children
	// Array(
	//    [0] => stdClass Object(
    //        [id] => 1
    //        [children] => Array(
    //                [0] => stdClass Object(
    //                        [id] => 2
    //                   )
    //            )
    //    )
	//    [1] => stdClass Object(
    //        [id] => 3
    //    )
	// )
	// Here in the first call, for the menu items with ids 1 and 3, it will update the parent item value as 0
	// Now look if these further have any sub children elements, and if they have any, then again calls the same function for the childer elements
	function updateMenuItems($dataMenu,$idParent = 0){

        // query to update the menu item parent menu item
        $query  = "update ".Config::_getTable('menu_items')." set parentMenuItem = :parentMenuItem, orderMenuItem = :orderMenuItem where idMenuItem = :idMenuItem";
	
		foreach($dataMenu as $orderMenuItem => $itemMenu){

			global $Menus;
			// This contains the details of the menu item before editing it
			// This is used to delete the old parent menu cache in which this item belongs to  
			$detailsMenuItem = $Menus->_getMenuItemDetails($itemMenu->id);
			
            unset($arrayBind);
            $arrayBind[]= array("key" => ":idMenuItem", "value" =>  $itemMenu->id);
            $arrayBind[]= array("key" => ":orderMenuItem", "value" =>  $orderMenuItem);
            $arrayBind[]= array("key" => ":parentMenuItem", "value" =>  $idParent);
            Core::_runQuery($query,$arrayBind);
			
			// Clearing this menu item from cache
			Cache::_getInstance() -> _removeCache('cms_menus_item_'. $itemMenu->id);
			// Clearing the old menu to which this menu item belongs to from cache
			Cache::_getInstance() -> _removeCache('cms_menus_items_'. $detailsMenuItem->idMenu);
			// Clearing the new menu to which this menu item belongs to from cache
			Cache::_getInstance() -> _removeCache('cms_menus_items_'. $itemMenu->id);
			
			if( isset($itemMenu->children) && is_array($itemMenu->children) && count($itemMenu->children) > 0 ){
				updateMenuItems($itemMenu->children,$itemMenu->id);
			} 
		}	
	}

	$dataMenu = json_decode($dataMenu);
	
	updateMenuItems($dataMenu);
}

die($messageDie);
