<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
	$Base->_accessRestricted();
}

if(!$_FILES){
	die('Please Select Plugins Files');
}

// Define a destination
$tempFolder = Config::_getDir('plugins.store');


if(!isset($_FILES) || !isset($_FILES['zipFile']) || !isset($_FILES['zipFile']['name']) || !isset($_FILES['zipFile']['tmp_name']) || $_FILES['zipFile']['tmp_name'] == '' || !isset($_FILES['zipFile']['size'])){
    $Base->_convertError(array("Please Select files to upload"),false);
}

$name    = $_FILES['zipFile']['name'];
$tmppath = $_FILES['zipFile']['tmp_name'];
$size    = $_FILES['zipFile']['size'];

$totalfiles  = count($name);
$extension   = array("zip");

$messages = array();

$fileParts = pathinfo($name);
if (in_array(strtolower($fileParts['extension']),$extension)) {

    move_uploaded_file($tmppath,$tempFolder.'/'.$name);
    
    $messages[] = $name.' file of size '.$Base->_convertByes($size).' uploaded Successfully.';
    $messages[] = 'Checking for the config file..... ';
    $configFile = false;

    $messages = array_merge($messages, $Plugins->_checkPluginFiles($tempFolder.'/'.$name));
}else{
    $messages[] = "Invalid File Format ".$fileParts['extension'] .' for '.$name;
}   
	
$Base->_convertError($messages,false);

