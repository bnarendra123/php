<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'edit') || !$Permissions->_checkPagePermission(__FILE__,'delete') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die("Restricted Acess");
}

extract($_POST);

if( !isset($selectedMenus) ){
    die('No Input Given');
}

$arrayMenus = explode("_SPLITTER_",$selectedMenus);

$listMenus = $Menus->_prepareAdminMenuSet(false);

$query  = "update ".Config::_getTable('admin_menus')." set dashboardMenu = :dashboardMenu where idMenu = :idMenu ";
foreach($listMenus as $key => $menu){    

    if( $menu -> linkMenu != 'dashboard' ){

        $dbMenu = 0;
        
        if( in_array($menu -> idMenu, $arrayMenus) ){

            $dbMenu = 1;
        
        }

        $arrayBind = array();
        $arrayBind[]= array("key" => ":dashboardMenu",  "value" =>  $dbMenu);    
        $arrayBind[]= array("key" => ":idMenu",         "value" =>  $menu -> idMenu);    
        Core::_runQuery($query,$arrayBind);
    }
}

Cache::_getInstance()->_removeCache('admin_menus_list');

die('ok');

