<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	extract($_POST);

	$errors = array();
	
	if( !in_array($do, array('save','delete')) ){
		$errors[] = 'Invalid Action';
	}

	if( ( !isset($nameList) || $nameList == '' ) ){
		$errors[] = 'Something Wrong!';
	}else{
		
		if( ( !isset($title) || $title == '' ) && $do == 'save' ){
			$errors[] = 'Please Enter Title';
		}
		
		if( isset($title) && strlen($title) > 10 ){
			$title = substr($title, 0, 10);
		}
	}
	
    if( count($errors) != 0 ){      
        $Base->_convertError($errors,false);
    }

	$preferences = $_POST;
	
	unset($preferences['do'],$preferences['formPrimaryField'],$preferences['nameList'],$preferences['title'],$preferences['defaultLoad']);
	
	$prefCurr	= array(	
					'title' => $title,
					'urlList' => $preferences,
					);

	$prefList = $User->_getUserPreference('/admin/lists/'.$nameList.'/preferences');

	if( $do == 'save' ){
		
		if( $formPrimaryField == -1 ){
			$prefList[] = $prefCurr;
			
			end($prefList);
			$idPref = key($prefList);
		}else{
			$prefList[$formPrimaryField] = $prefCurr;
			$idPref = $formPrimaryField;
		}
		
		if( $defaultLoad ){
			$User->_setUserPreference('/admin/lists/'.$nameList.'/preferences/default',$idPref);
		}elseif( !$defaultLoad && $Lists->_getDefaultListTemplate($nameList) == $idPref ){
			$User->_setUserPreference('/admin/lists/'.$nameList.'/preferences/default',-1);
		}

 	}else if( $do == 'delete' ){

		unset($prefList[$formPrimaryField]);

        if( $Lists->_getDefaultListTemplate($nameList) ==  $formPrimaryField ){

            $User->_setUserPreference('/admin/lists/'.$nameList.'/preferences/default',-1);

        }

	}

	$User->_setUserPreference('/admin/lists/'.$nameList.'/preferences',$prefList);
	
}

die('ok');