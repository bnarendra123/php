<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'edit') || !$Permissions->_checkPagePermission(__FILE__,'delete') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die("Restricted Acess");
}

extract($_POST);

// Only Super Admins can access the permissions page
if( !$Admin->_isSuperUser() ){
	$messageError = "<script>message_reporting('divContainer','".$Base->_convertError(array("Access Restricted"),true)."',4);</script>";
	die($messageError);
}

// Details of the selected user
$detailsGroup = $User->_getUserGroupDetailsById($formPrimaryField);

$readCheckboxArray = $createCheckboxArray = $editCheckboxArray = $deleteCheckboxArray = array();

// Converting view Permissions
$readCheckboxArray = explode("_SPLITTER_",$readCheckbox);

// Converting create Permissions
$createCheckboxArray = explode("_SPLITTER_",$createCheckbox);

// Converting edit Permissions
$editCheckboxArray = explode("_SPLITTER_",$editCheckbox);

// Converting delete Permissions
$deleteCheckboxArray = explode("_SPLITTER_",$deleteCheckbox);

// Getting all admin menus
$menusPermissions = $Permissions->_filterPermissionsAllowed($Menus->_getAdminMenus(''));

foreach($menusPermissions as $PermissionMenu){
	// Preparing the admin menu permissions for the given user
	$Permissions->_preparePermissionsRow($PermissionMenu->idMenu,$detailsGroup->idGroup);

	// Converting selected permissions to array
	$adminPermissions['view'] 	= in_array($PermissionMenu->idMenu,$readCheckboxArray) ? 1:0;
	$adminPermissions['create'] = in_array($PermissionMenu->idMenu,$createCheckboxArray) ? 1:0;
	$adminPermissions['edit'] 	= in_array($PermissionMenu->idMenu,$editCheckboxArray) ? 1:0;
	$adminPermissions['delete']	= in_array($PermissionMenu->idMenu,$deleteCheckboxArray) ? 1:0;

	$Permissions->_updatePermissionsRow($PermissionMenu->idMenu,$detailsGroup->idGroup,$adminPermissions);
	
}
$User->_addUserLogActivity($User -> idUser(),40);

Plugins::_runAction('group_permissions_edit',$detailsGroup->idGroup);

die('ok');

?>
