<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    extract($_POST);
    
    if($do == 'edit'){
    
        $errors = array();
        $identifierTables = array();
        $Columns = array();
        $fieldsListTable = array('nameSet','linkSet','databaseSet','whereSet');
        if( $nameSet == ''){
             $errors[] = Config::_getMessage('forms.cms.sets.error.empty.set.name');
        }
        if( $linkSet == ''){
           
			$errors[] = Config::_getMessage('forms.cms.sets.error.empty.set.link');
        }else{
            $linkSet = $Base->_prepareLink($linkSet);
            if( $Cms->_checkLinkSet($linkSet) && $Cms->_getSetDetailsByLink($linkSet)->idSet != $idSet){
                
				$errors[] = Config::_prepareMessage('forms.validation.sets.link.exists',array(":LINK_SET" => $linkSet));            
            }
        }
        if($databaseSet == 1){
            if( $keyFieldSet == ''){
                 $errors[] = Config::_getMessage('forms.cms.sets.error.empty.key.field');
            }
            if( $displayFieldSet == ''){
                $errors[] = Config::_getMessage('forms.cms.sets.error.empty.display.field');
            }
            $fieldsListTable[] = 'keyFieldSet';
            $fieldsListTable[] = 'displayFieldSet';
			$fieldsListTable[] = 'sortFieldSet';
            $fieldsListTable[] = 'sortOrderFieldSet';
			

            $tables  = explode("_TABLES_",$tables);
            $checkTablesForm = array();                
            foreach($tables as $tmpTable){
                // exploding to individual elements 
                $tmp = explode("_IDENTIFIER_",$tmpTable);
                // checking the tables in database
                if( !Core::_checkTable($tmp[0]) ){
                   // $errors[] = "Table ".$tmp[0]." doesnot exist in the database.";
                    $errors[] = Config::_prepareMessage('forms.validation.lists.databasetable.exists',array(":TABLE_NAME " => $tmp[0]));                     
                }
                // checking for multiple Entries for Tables 
                if( in_array($tmp[0],$checkTablesForm) ){
                   // $errors[] = "Table ".$tmp[0]." entered multiple times";
                   $errors[] = Config::_prepareMessage('forms.validation.lists.multiple.table.entry',array(":MULTIPLE_TABLE  " => $tmp[0]));                     
                }
                // checking for multiple Entries for Table Identifier
                if( isset($identifierTables[$tmp[1]]) ){
                   // $errors[] = "Table identifier ".$tmp[1]." entered multiple times";
                    $errors[] = Config::_prepareMessage('forms.validation.lists.multiple.identifier.entry',array(":MULTIPLE_IDENTIFIER   " => $tmp[1]));                    
                }
    
                // checking for multiple language field id for the table
                if( $tmp[4] != '' ){
                    $Columns[] = $tmp[4];                    
                }
    
                $identifierTables[$tmp[1]] = $tmp;
                $checkTablesForm[] = $tmp[0];
            }
            unset($checkTablesForm);
            
            foreach(array($keyFieldSet,$displayFieldSet) as $tmp){
                if($tmp != '' ){
                    $Columns[]  = $tmp;
                }
            }
            foreach($Columns as $tmpColumn){
                if( !isset($identifierTables[Core::_getFieldPrefix($tmpColumn)][0]) ){
                   // $errors[] = "Please add valid table identifier for the Column ".$tmpColumn;
                   $errors[] =Config::_prepareMessage('forms.validation.lists.valid.identifier',array(":IDENTIFIER_TITLE" => $tmpColumn));
                }else if( !Core::_checkColumn($identifierTables[Core::_getFieldPrefix($tmpColumn)][0],Core::_getField($tmpColumn)) ){
                   // $errors[] = "Column ".Core::_getField($tmpColumn)." doesnot exist in the Table ".$identifierTables[Core::_getFieldPrefix($tmpColumn)][0];
                    $errors[] =Config::_prepareMessage('forms.validation.lists.column.exist.table',array(":COLUMN_NAME " => Core::_getField($tmpColumn),":COLUMN_TABLE"=>$identifierTables[Core::_getFieldPrefix($tmpColumn)][0]));
                }            
            }

        }else{
            $databaseSet = 0;
            if( $options == ''){
               $errors[] = Config::_getMessage('forms.cms.sets.error.empty.option');
            }
            $options = explode("_OPTIONS_",$options);
    
            $optionsSets = array();
            foreach($options as $tmpOption){
                // exploding to individual elements 
                $tmp = explode("_SPLITTER_",$tmpOption);
    
                // checking for the valid key
                if( $tmp[0] != '' ){
                    $optionsSets[] = $tmp;
                }
            }
        }

        if( count($errors) != 0 ){      
            $Base->_convertError($errors,false);
        }
        
        if( !isset($idSet) || $idSet == -1){
    
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fieldsListTable as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('sets')." (".implode(",",$insertKeys).",dateAdditionSet) values (".implode(",",$insertValues).",NOW())";

            if(Core::_runQuery($query, $arrayBind)){
	            $idSet = Core::_getLastInsertId();
				Plugins::_runAction('cms_set_create',$idSet);
            }else{
				$messageDie = 'Creation Failed';
            }

        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            // Clearing the cache with older select name if exists
            $detailsSetCache = $Cms->_getSetDetails($idSet);
            if(Cache::_getInstance()->_isCached('select_'.$detailsSetCache->linkSet)){
                Cache::_getInstance()->_removeCache('select_'.$detailsSetCache->linkSet); 
            }

            $setpPart = array();
    
            foreach($fieldsListTable as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('sets')." set ".implode(",",$setpPart)." where idSet = :idSet";
            $arrayBind[]= array("key" => ":idSet", "value" =>  $idSet);    
            Core::_runQuery($query,$arrayBind);
            
            unset($arrayBind);
            $arrayBind[]= array("key" => ":idSet", "value" =>  $idSet);    

            $query  = "delete from ".Config::_getTable('sets_tables')." where idSet = :idSet";
            Core::_runQuery($query,$arrayBind);
                        
            $query  = "delete from ".Config::_getTable('sets_options')." where idSet = :idSet";
            Core::_runQuery($query,$arrayBind);

			Plugins::_runAction('cms_set_edit',$idSet);
        }

         if($databaseSet == 1){
            foreach($identifierTables as $identifier => $tmpTable){
                unset($arrayBind);
                $arrayBind[]= array("key" => ":idSet",             "value" => $idSet);
                $arrayBind[]= array("key" => ":tableSet",          "value" => $tmpTable[0]);
                $arrayBind[]= array("key" => ":identifierTableSet","value" => $identifier);
                $arrayBind[]= array("key" => ":joinTypeTable",     "value" => $tmpTable[2]);
                $arrayBind[]= array("key" => ":joinOnTable",       "value" => $tmpTable[3]);
                $arrayBind[]= array("key" => ":multiLanguageField","value" => $tmpTable[4]);
                            
                $query = "insert into ".Config::_getTable('sets_tables')." (`idSet`,`tableSet`,`identifierTableSet`,`joinTypeTable`,`joinOnTable`,`multiLanguageField`) 
                values (:idSet,:tableSet,:identifierTableSet,:joinTypeTable,:joinOnTable,:multiLanguageField)";
                Core::_runQuery($query, $arrayBind);
            }
        }else{
            foreach($optionsSets as $tmpOption){
    
                unset($arrayBind);
                $arrayBind[]= array("key" => ":idSet",       "value" => $idSet);
                $arrayBind[]= array("key" => ":keyOption",   "value" => $tmpOption[0]);
                $arrayBind[]= array("key" => ":titleOption", "value" => $tmpOption[1]);
                $arrayBind[]= array("key" => ":orderOption", "value" => $tmpOption[2]);
                $arrayBind[]= array("key" => ":statusOption","value" => $tmpOption[3]);
                            
                $query = "insert into ".Config::_getTable('sets_options')." (`idSet`,`keyOption`,`titleOption`,`orderOption`,`statusOption`) 
                values (:idSet,:keyOption,:titleOption,:orderOption,:statusOption)";
                Core::_runQuery($query, $arrayBind);
            }
        }
    }else if($do == 'status'){
            
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }
        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusSet";
        }

        // Status change query
        $query  = "update ".Config::_getTable('sets')." set statusSet = ".$changeToField." where idSet = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
            Cache::_getInstance()->_removeCache('select_'.$Cms->_getSetDetails($tmpId)->linkSet); 
        }
    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        
        // Exploding to get the ids
        $idArray = explode(",",$id);
        
        $query1  = "delete from ".Config::_getTable('sets')." where idSet = :primaryField";
        $query2  = "delete from ".Config::_getTable('sets_options')." where idSet = :primaryField";
        $query3  = "delete from ".Config::_getTable('sets_tables')." where idSet = :primaryField";
        foreach($idArray as $tmpId){
        		
			$tmpId = Plugins::_runAction('cms_set_delete',$tmpId);
        				
            $detailsSet = $Cms->_getSetDetails($tmpId);
			
			if($detailsSet){
	            unset($arrayBind);
	            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
	
	            Core::_runQuery($query1,$arrayBind);
	            Core::_runQuery($query2,$arrayBind);
	            Core::_runQuery($query3,$arrayBind);
	            
	            Cache::_getInstance()->_removeCache('select_'.$detailsSet->linkSet);            
			}
        }                
    }
    die($messageDie);
}

