<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
	$Base->_accessRestricted();
}

if($_POST){

	$do = $_POST['do'];
	
	if($do == 'edit'){

		$processedForm = $Forms->_processForm($forms,$_POST);
	
		extract($processedForm['formElements']);
		
		if( $passwordnew1 !=  $passwordnew2 ){
			$processedForm['error'][] = Config::_getMessage('forms.settings.lists.validate.new.password.match');
		}
		
		if( count($processedForm['error']) != 0 ){		
			$error_string = $Base->_convertError($processedForm['error'],true);
			die($error_string);
		}

		$passwordhash = md5($passwordold);

		if( $passwordhash !=  $User -> passwordUser() ){
			$processedForm['error'][] = Config::_getMessage('forms.settings.lists.validate.old.password.match');
			$error_string = $Base->_convertError($processedForm['error'],true);
			die($error_string);
			
		}else{

			$newpasswordhash = md5($passwordnew1);
			
			$query	= "update ".Config::_getTable('users')." set passwordUser = :passwordUser where idUser = :idUser ";
			$arrayBind[]= array("key" => ":passwordUser","value" =>  $newpasswordhash);
			$arrayBind[]= array("key" => ":idUser", 	"value" =>  $formPrimaryField);
	
			$statusQuery= Core::_runQuery($query,$arrayBind);
			
			Plugins::_runAction('user_password_change',$formPrimaryField);
		}
	}
	die('ok');
}
