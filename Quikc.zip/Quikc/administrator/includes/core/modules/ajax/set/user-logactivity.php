<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$do = $_POST['do'];
	
	if($do == 'edit'){	
	}else if($do == 'status'){
	}else if($do == 'delete'){

		if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Status change query
        $query  = "delete from ".Config::_getTable('user_log_activity')." where idLog = :primaryField";
        foreach($idArray as $tmpId){

			$tmpId = Plugins::_runAction('user_log_activity_delete',$tmpId);

            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);                
        }
	}
	die('ok');
}

