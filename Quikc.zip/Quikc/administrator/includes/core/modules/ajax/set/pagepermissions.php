<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if( !$Permissions->_checkPagePermission('permissions','edit') || !$Permissions->_checkPagePermission('permissions','delete') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die("Restricted Acess");
}

extract($_POST);

// Only Super Admins can access the permissions page
if( !$Admin->_isSuperUser() ){
	$messageError = "<script>message_reporting('divContainer','".$Base->_convertError(array("Access Restricted"),true)."',4);</script>";
	die($messageError);
}

// Details of the selected user
$detailsSelectedMenu = $Menus->_loadAdminMenu($formPrimaryField);


$readCheckboxArray = $createCheckboxArray = $editCheckboxArray = $deleteCheckboxArray = array();

// Converting view Permissions
$readCheckboxArray = explode("_SPLITTER_",$readCheckbox);

// Converting create Permissions
$createCheckboxArray = explode("_SPLITTER_",$createCheckbox);

// Converting edit Permissions
$editCheckboxArray = explode("_SPLITTER_",$editCheckbox);

// Converting delete Permissions
$deleteCheckboxArray = explode("_SPLITTER_",$deleteCheckbox);


/* Updaging global permissions starts here */

// Preparing the admin menu permissions for the given user
$Permissions->_prepareGlobalPermissionsRow($detailsSelectedMenu->idMenu);

// Converting selected permissions to array
$userPermissions['view'] 	= in_array(-1,$readCheckboxArray) ? 1:0;
$userPermissions['create'] 	= in_array(-1,$createCheckboxArray) ? 1:0;
$userPermissions['edit'] 	= in_array(-1,$editCheckboxArray) ? 1:0;
$userPermissions['delete']	= in_array(-1,$deleteCheckboxArray) ? 1:0;

$Permissions->_updateGlobalPermissionsRow($detailsSelectedMenu->idMenu,$userPermissions);
/* Updaging global permissions ends here */


// Getting all user groups
$groupsUser = $User->_getUserGroups();

foreach($groupsUser as $tmpGroup){
	// Preparing the admin menu permissions for the given user
	$Permissions->_preparePermissionsRow($detailsSelectedMenu->idMenu,$tmpGroup->idGroup);

	// Converting selected permissions to array
	$userPermissions['view'] 	= in_array($tmpGroup->idGroup,$readCheckboxArray) ? 1:0;
	$userPermissions['create']	= in_array($tmpGroup->idGroup,$createCheckboxArray) ? 1:0;
	$userPermissions['edit'] 	= in_array($tmpGroup->idGroup,$editCheckboxArray) ? 1:0;
	$userPermissions['delete']	= in_array($tmpGroup->idGroup,$deleteCheckboxArray) ? 1:0;

	$Permissions->_updatePermissionsRow($detailsSelectedMenu->idMenu,$tmpGroup->idGroup,$userPermissions);
	
}
$User->_addUserLogActivity($User -> idUser(),40);

Plugins::_runAction('page_permissions_edit',$detailsSelectedMenu->idMenu);

die('ok');

