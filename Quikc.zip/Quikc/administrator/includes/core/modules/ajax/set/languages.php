<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie='ok';

if($_POST){

	$do = $_POST['do'];
	
	if($do == 'edit'){
	
		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);

		if( $defaultLanguage == 0 && Languages::_getdefaultLanguage() == $formPrimaryField ){
			//$processedForm['error'][] = "You can't desclect the default language. Please set another Language as your default language and current default language 
			//will automatically removed. ";
			$processedForm['error'][]= Config::_getMessage('forms.validation.languages.actvation');
                
		}

		if( count($processedForm['error']) != 0 ){		
			$error_string = $Base->_convertError($processedForm['error'],true);
			die($error_string);
		}
		
		$fields = array('nameLanguage','codeLanguage','defaultLanguage','statusLanguage');
	
		if($defaultLanguage == 1){
			$query = "update ".Config::_getTable('languages')." set defaultLanguage = 0 ";
			Core::_runQuery($query, array());
		}

		if($formPrimaryField == -1){
	
			if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
				$Base->_accessRestricted();
			}

			$insertKeys  = array();
			$insertValues= array();
			
			foreach($fields as $field){
				$insertKeys[]  = "`$field`";
				$insertValues[]= ":$field";
				$arrayBind[]= array("key" => ":$field",	"value" => $$field);
			}
			
			$query = "insert into ".Config::_getTable('languages')." (".implode(",",$insertKeys).",dateAdditionLanguage) values (".implode(",",$insertValues).",NOW())";
			
			if(Core::_runQuery($query, $arrayBind)){
			
				$formPrimaryField = Core::_getLastInsertId();
	            $messageDie 	  = $messageDie."_ID_SPLITTER_".$formPrimaryField;
	
	            $User->_addUserLogActivity($User -> idUser(),34,$nameLanguage);
	
	            Plugins::_runAction('language_create',$formPrimaryField);
			}else{
				$messageDie = 'Creation Failed';
			}
						
		}else{
	
			if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
				$Base->_accessRestricted();
			}

			$setpPart = array();
	
			foreach($fields as $field){
				$setpPart[] = "`$field`=:$field";
				$arrayBind[]= array("key" => ":$field",	"value" =>  $$field );
			}
			$query	= "update ".Config::_getTable('languages')." set ".implode(",",$setpPart)." where idLanguage = :idLanguage";
			$arrayBind[]= array("key" => ":idLanguage", "value" =>  $formPrimaryField);
	
			if(Core::_runQuery($query,$arrayBind)){
				
				$nameLanguage = $Languages->_loadLanguage($formPrimaryField)->nameLanguage;
				$User->_addUserLogActivity($User -> idUser(),35,$nameLanguage);

	            Plugins::_runAction('language_edit',$formPrimaryField);
				
			}else{
				$messageDie = 'Save Failed';
			}
			
		}
	}else if($do == 'status'){
			
		if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        foreach($idArray as $tmpId){
            if( Languages::_getdefaultLanguage() == $tmpId ){
                die("Can't change the status of Defautl Language");
            }
        }

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        /*
        if($changeTo == '1'){
                    $changeToField = 1;
                }else if($changeTo == '0'){
                    $changeToField = 0;
                }else{
                    $changeToField = "!statusLanguage";
                }*/
        
         if($changeTo == '1'){
            $changeToField = 1;
            $idLog = 39;
        }else if($changeTo == '0'){
            $changeToField = 0;
            $idLog = 38;
        }else{
            $idLog = 37;
            $changeToField = "!statusLanguage";
        }

        // Status change query
        $query  = "update ".Config::_getTable('languages')." set statusLanguage = ".$changeToField." where idLanguage = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind); 
			$User->_addUserLogActivity($User -> idUser(),$idLog,$Languages->_loadLanguage($tmpId)->nameLanguage);               
        }

	}else if($do == 'delete'){

		if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
			$Base->_accessRestricted();
		}
        
        $id = $_POST['id'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        foreach($idArray as $tmpId){
            if( Languages::_getdefaultLanguage() == $tmpId ){
                die("Can't delete your Defautl Language");
            }
        }

        $query  = "delete from ".Config::_getTable('languages')." where idLanguage = :primaryField";
        foreach($idArray as $tmpId){
        		
	        $tmpId = Plugins::_runAction('language_delete',$tmpId);
			
            unset($arrayBind);
			
			$nameLanguage = $Languages->_loadLanguage($tmpId)->nameLanguage;

			if($nameLanguage){
	            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
	            Core::_runQuery($query,$arrayBind); 
				$User->_addUserLogActivity($User -> idUser(),36,$nameLanguage);               
			}
        }
	}
	die($messageDie);
}

?>
