<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    $do = $_POST['do'];
	
	if($do == 'edit'){
    
        $processedForm = $Forms->_processForm($forms,$_POST);
        extract($processedForm['formElements']);

        if( count($processedForm['error']) != 0 ){      
            $error_string = $Base->_convertError($processedForm['error'],true);
            die($error_string);
        }

        $fields = $processedForm['fields'];
		
        if($formPrimaryField == -1){
    
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fields as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('menu_items')." (".implode(",",$insertKeys).", dateAdditionMenuItem) values (".implode(",",$insertValues).", NOW())";

           if(Core::_runQuery($query, $arrayBind)){
				$formPrimaryField = Core::_getLastInsertId();
				Plugins::_runAction('menu_item_create',$formPrimaryField);
				Cache::_getInstance() -> _removeCache('cms_menus_items_'. $idMenu);
				
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('menu_items')." set ".implode(",",$setpPart)." where idMenuItem = :idMenuItem ";
            $arrayBind[]= array("key" => ":idMenuItem", "value" =>  $formPrimaryField);
    
           if(Core::_runQuery($query, $arrayBind)){
				Plugins::_runAction('menu_item_edit',$formPrimaryField);
			   
				Cache::_getInstance() -> _removeCache('cms_menus_item_'. $formPrimaryField);
				Cache::_getInstance() -> _removeCache('cms_menus_items_'. $Menus->_getMenuItemDetails($formPrimaryField)->idMenu);
			   			   
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }

    }else if($do == 'status'){
            
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusMenuItem";
        }

        // Status change query
        $query  = "update ".Config::_getTable('menu_items')." set statusMenuItem = ".$changeToField." where idMenuItem = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
			
			Cache::_getInstance() -> _removeCache('cms_menus_item_'. $tmpId);
			Cache::_getInstance() -> _removeCache('cms_menus_items_'. $Menus->_getMenuItemDetails($tmpId)->idMenu);
        }
    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        
        // Exploding to get the ids
        $idArray = explode(",",$id);
        
        $query  = "delete from ".Config::_getTable('menu_items')." where idMenuItem = :primaryField";
        foreach($idArray as $tmpId){
        	
			$tmpId = Plugins::_runAction('menu_item_delete',$tmpId);
			
            $detailsMenu = $Menus->_getMenuItemDetails($tmpId);

			if($detailsMenu){
			    
	            unset($arrayBind);
                
	            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
	            Core::_runQuery($query,$arrayBind);
				
				Cache::_getInstance() -> _removeCache('cms_menus_item_'. $tmpId);
				Cache::_getInstance() -> _removeCache('cms_menus_items_'.$detailsMenu->idMenu);
			}			

        }        

    }

    die($messageDie);

}


