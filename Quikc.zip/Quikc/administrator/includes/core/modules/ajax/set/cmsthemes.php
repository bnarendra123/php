<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if ($_POST) {

	$do = $_POST['do'];

	extract($_POST);

	if ($do == 'edit') {

		$processedForm = $Forms -> _processForm($forms, $_POST);
		extract($processedForm['formElements']);

		if ($Themes -> _getActiveTheme() -> idTheme == $formPrimaryField && $statusTheme == 0 ) {
			$processedForm['error'][] = Config::_getMessage('forms.validation.themes.status');
		}

		if (count($processedForm['error']) != 0) {
			$Base -> _convertError($processedForm['error'], false);
		}

		$fields = array('nameTheme', 'statusTheme');

		if ($formPrimaryField == -1) {

			if (!$Permissions -> _checkPagePermission(__FILE__, 'create')) {
				$Base -> _accessRestricted();
			}
		
			$Themes -> _createTheme($nameTheme,$statusTheme);
			Plugins::_runAction('cms_themes_create', $formPrimaryField);

		} else {

			if (!$Permissions -> _checkPagePermission(__FILE__, 'edit')) {
				$Base -> _accessRestricted();
			}

			$setpPart = array();

			foreach ($fields as $field) {
				$setpPart[] = "`$field`=:$field";
				$arrayBind[] = array("key" => ":$field", "value" => $$field);
			}
			
			$query = "update " . Config::_getTable('cms_themes') . " set " . implode(",", $setpPart) . " where idTheme = :idTheme";
			$arrayBind[] = array("key" => ":idTheme", "value" => $formPrimaryField);

			if (Core::_runQuery($query, $arrayBind)) {
				
				if($statusTheme == 1){
					unset($arrayBind);
					$query = "update " . Config::_getTable('cms_themes') . " set statusTheme = 0 where idTheme != :idTheme ";
					$arrayBind[] = array("key" => ":idTheme", "value" => $formPrimaryField);
					Core::_runQuery($query, $arrayBind);					
				}
				
				Plugins::_runAction('cms_themes_edit', $formPrimaryField);
			} else {
				$Base -> _convertError(array("Save Filed"), false);
			}
		}
	} else if ($do == 'copy') {

		if (!$Permissions -> _checkPagePermission($Base -> _getFileName(__FILE__), 'view') || !$Permissions -> _checkPagePermission($Base -> _getFileName(__FILE__), 'edit')) {
			$Base -> _accessRestricted();
		}

		$Themes -> _copyTheme($id);

	} else if ($do == 'status') {

		if (!$Permissions -> _checkPagePermission($Base -> _getFileName(__FILE__), 'edit')) {
			$Base -> _accessRestricted();
		}

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];

		if ($Themes -> _getActiveTheme() -> idTheme == $id) {
			$error_string = Config::_getMessage('forms.validation.themes.status');
			die($error_string);
		}

		$arrayBind[] = array("key" => ":idTheme", "value" => $id);

		$query = "update " . Config::_getTable('cms_themes') . " set statusTheme = 0 ";
		Core::_runQuery($query, $arrayBind);

		$query = "update " . Config::_getTable('cms_themes') . " set statusTheme = :statusTheme where idTheme = :idTheme";
		$arrayBind[] = array("key" => ":statusTheme", "value" => 1);
		Core::_runQuery($query, $arrayBind);

	} else if ($do == 'delete') {

		if (!$Permissions -> _checkPagePermission($Base -> _getFileName(__FILE__), 'delete')) {
			$Base -> _accessRestricted();
		}
		
        $id = $_POST['id'];

		$Themes -> _deleteTheme($id);
	}
	die('ok');
}
?>
