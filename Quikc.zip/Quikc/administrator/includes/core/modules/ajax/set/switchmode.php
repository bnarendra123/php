<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if(!$_POST){
	die('Access Restricted');
}

$Mode = '';

extract($_POST);

$loginModes = $Base->_generateSelect('adminmodes');

if( !isset($loginModes[$Mode]) ){
	die('Invalid Mode');
}

unset($arrayBind);
$query  = " update ".Config::_getTable('users')." set loginModeUser = :loginModeUser where idUser = :idUser ";
$arrayBind[]= array("key" => ":loginModeUser", "value" => $Mode);
$arrayBind[]= array("key" => ":idUser"	 , "value" => $User -> idUser());

if(Core::_runQuery($query,$arrayBind)){
	Plugins::_runAction('login_mode_switch',$Mode);
}else{
	$messageDie = 'Switching Falied';
}


die($messageDie);
