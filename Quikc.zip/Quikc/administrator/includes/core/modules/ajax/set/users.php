<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    $do = $_POST['do'];
    
    if($do == 'edit'){
        
        $processedForm = $Forms->_processForm($forms,$_POST);
    
        extract($processedForm['formElements']);

        if( $User->_checkEmailExistance($emailUser) && $formPrimaryField != $User->_getUserDetailsByEmail($emailUser)->idUser ){
            
            $processedForm['error'][] = "Email already Exists.";
            
        }

        // We have to make sure that we have atleaset one active super admin
        // step 1: $formPrimaryField != -1 Checking weather we are editing old user or creating new user
        //         If we are editing user, then we have to make sure that we have atleaste one active super admin
        // step 2: $Admin->_getActiveSuperAdminCount() checking the count of the super users
        
        if( $formPrimaryField != -1 && $Admin->_getActiveSuperUsersCount() <= 1 && $statusUser == 0 ){
            $processedForm['error'][] = '';
        }

        if( $formPrimaryField != -1 && $User -> idUser() == $formPrimaryField && $statusUser == 0  ){
            $processedForm['error'][] = "Your can't deactivate your account.";
        }
        
        $fields = $processedForm['fields'];

		// If we don't want to change the password then we can leave password field as blank
		// If the password field is blank then we don't update that field
		// First checking weather we have passwordUser field in the submitted fields list or not
		// If we found it, then checking weather the field is empty or not
		// If it is not empty then we have to get the md5 hash of the password
		// If the password is empty then we have to delete the password field from the existing frields, so that it won't get updated in the succeding steps		
        if( in_array('passwordUser',$fields) ){
            
			if( $passwordUser != '' ){
			    
				$passwordUser = md5($passwordUser);
                
			}else{
			    
				unset($fields[array_search('passwordUser', $fields)]);
                
			}

        }
		
		//These already comes verified from the processed fields.
		
/*    
        if( $User -> idUser() == 1){
            
            if( !$Permissions->_checkSuperUserReplacement($formPrimaryField) && $superadmin != 1 ){
 * 
                //$processedForm['error'][] = 'Atleast one super admin should present.';
                $processedForm['error'][] = Config::_getMessage('forms.validation.superadmin.email');
 * 
            }else{
 * 
               $fields[] = 'superadmin'; 
 * 
            }
 * 
        }
 * 
*/
        if( count($processedForm['error']) != 0 ){
                  
            $Base->_convertError($processedForm['error'],false);
            
        }       
        
        if( $formPrimaryField == -1 ){
    
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                
                $Base->_accessRestricted();
                
            }

            $insertKeys  = array();
            $insertValues= array();
    
            foreach($fields as $field){
                
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field );
                
            }
            $query = "insert into ".Config::_getTable('users')." (".implode(",",$insertKeys).",dateAdditionUser) values (".implode(",",$insertValues).",NOW())";
            
            if(Core::_runQuery( $query, $arrayBind )){

	            $formPrimaryField = Core::_getLastInsertId();	
				$messageDie 	  = $messageDie."_ID_SPLITTER_".$formPrimaryField;	

				Plugins::_runAction('user_create',$formPrimaryField);

            }else{
                
            	$messageDie = 'Creation Failed'; 
                
            }
            
        }else{
        
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                
                $Base->_accessRestricted();
                
            }

            $setpPart = array();
    
            foreach($fields as $field){
                
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
                
            }
            
            $query  = "update ".Config::_getTable('users')." set ".implode(",",$setpPart)." where idUser = :idUser";
            $arrayBind[]= array("key" => ":idUser", "value" =>  $formPrimaryField );
    
            if(Core::_runQuery($query,$arrayBind)){

				Plugins::_runAction('user_edit',$formPrimaryField);

            }else{

            	$messageDie = 'Save Failed'; 

            }

        }

    }else if($do == 'status'){

        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            
            $Base->_accessRestricted();
            
        }

        if( $User -> idUser() == $id ){
            
            die(Config::_getMessage('forms.validation.loginuser.status'));
            
        }

        if( !$Admin->_isSuperUser() || !$Permissions->_checkSuperUserReplacement($id) ){
            
            $Base->_convertError(Config::_getMessage('forms.validation.superadmin.permissions'),false);
           // die("You don't have enough Permissions or Atleast one active super admin should present");
           
        }

        $id = $_POST['id'];
        $changeTo = $_POST['changeTo'];
        $idArray = explode(",",$id);

        $query  = "update ".Config::_getTable('users')." set statusUser = !statusUser where idUser = :idUser";
        foreach($idArray as $tmpId){

            unset($arrayBind);
            $arrayBind[]= array("key" => ":idUser", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);

			Plugins::_runAction('user_status',$formPrimaryField);

         }

    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            
            $Base->_accessRestricted();
            
        }
        
        $id = $_POST['id'];
        $idArray = explode(",",$id);
         
        $query  = "delete from ".Config::_getTable('users')." where idUser = :idUser";
        
        foreach($idArray as $tmpId){
        	
			$tmpId = Plugins::_runAction('user_delete',$tmpId);

			if( $User->_getUserDetailsById($tmpId) ){

                if( $User -> idUser() == $tmpId ){

                    die(Config::_getMessage('forms.validation.loginuser.delete'));
                    
                }
                
                if( $User->_getUserDetailsById($tmpId)->superUser == 1 ){
                    
                    die("Can't delete super admins.");
                    
                }

	            unset($arrayBind);
	            $arrayBind[]= array("key" => ":idUser", "value" =>  $tmpId);
	            Core::_runQuery($query,$arrayBind);

			}

        }

    }

    die($messageDie);

}

