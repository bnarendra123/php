<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){
	
	$do = $_POST['do'];
	
	if($do == 'edit'){
	
		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);

		if( count($processedForm['error']) != 0 ){		
			$Base->_convertError($processedForm['error'],false);
		}
		
		$fields = array('nameGroup','statusGroup');

		if($formPrimaryField == -1){
	
			if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
				$Base->_accessRestricted();
			}

			$insertKeys  = array();
			$insertValues= array();			
	
			foreach($fields as $field){
				$insertKeys[]  = "`$field`";
				$insertValues[]= ":$field";
				$arrayBind[]= array("key" => ":$field",	"value" => $$field);
			}
			$query = "insert into ".Config::_getTable('user_groups')." (".implode(",",$insertKeys).",dateAdditionGroup) values (".implode(",",$insertValues).",NOW())";

			if(Core::_runQuery($query, $arrayBind)){
				
	            $formPrimaryField = Core::_getLastInsertId();
	
	            $messageDie = $messageDie."_ID_SPLITTER_".$formPrimaryField;
	            $User->_addUserLogActivity($User -> idUser(),49,$nameGroup);
	
				Plugins::_runAction('user_group_create',$formPrimaryField);
			}else{
				$messageDie = 'Creation Filed';
			}
			
		}else{
	
			if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
				$Base->_accessRestricted();
			}

			$setpPart = array();
	
			foreach($fields as $field){
				$setpPart[] = "`$field`=:$field";
				$arrayBind[]= array("key" => ":$field",	"value" =>  $$field );
			}
			$query	= "update ".Config::_getTable('user_groups')." set ".implode(",",$setpPart)." where idGroup = :idGroup";
			$arrayBind[]= array("key" => ":idGroup", "value" =>  $formPrimaryField);
	
			if(Core::_runQuery($query,$arrayBind)){
			
	            $User->_addUserLogActivity($User -> idUser(),50,$nameGroup);
	
				Plugins::_runAction('user_group_edit',$formPrimaryField);
			}else{
				$messageDie = "Save Filed"; 
			}
			
		}
	}else if($do == 'status'){
			
		if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
            $idLog = 51;
        }else if($changeTo == '0'){
            $changeToField = 0;
            $idLog = 52;
        }else{
            $changeToField = "!statusGroup";
            $idLog = 53;
        }

        // Status change query
        $query  = "update ".Config::_getTable('user_groups')." set statusGroup = ".$changeToField." where idGroup = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
            $User->_addUserLogActivity($User -> idUser(),$idLog,$User->_getUserGroupDetailsById($tmpId)->nameGroup);
        }
        
	}else if($do == 'delete'){

		if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
		
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Status change query
        $query  = "delete from ".Config::_getTable('user_groups')." where idGroup = :primaryField";
        foreach($idArray as $tmpId){

			$tmpId = Plugins::_runAction('admin_group_delete',$tmpId);

            $nameGroup = $User->_getUserGroupDetailsById($tmpId)->nameGroup;
			if($nameGroup){
	            unset($arrayBind);
	            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
	            Core::_runQuery($query,$arrayBind);
				
	            $User->_addUserLogActivity($User -> idUser(),54,$nameGroup);
			}
			
        }
	}
	die($messageDie);
}

?>
