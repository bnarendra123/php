<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "emailUser",	   "type" => "Email",	 "label" => "Email",	"req" => true ,"validate" => false , "value" => "", 	   "additional" => '' );
$formFields[] = array("id" => "passwordUser",  "type" => "Password", "label" => "Password", "req" => true ,"validate" => false , "value" => "", 	   "additional" => '' );

$formFields[] = array("id" => "",			"type" => "Button",	"label" => "",		   "req" => false, "value" => "Login", "additional" => 'class="submit-btn"',
                "postFieldLable"=>'');

if(isset($_GET['page'])){
    $page = "?page=".$_GET['page'];
}else{
    $page = ''; 
}

$forms = array( 
	"identifier" 	 => "loginForm", 
	"name" 		     => Config::_getMessage('forms.administrator.login.title'), 
	"primaryFiled"   => "", 
	"url" 			 => "check/".$Base->_getFileName(__FILE__), 
	"success" 		 => "pageRedirect('home.php".$page."',0);", 
	"closeLink" 	 => "",
	"filename" 	     => $Base->_getFileName(__FILE__), 
	"fields" 		 => $formFields
);


$forms = Plugins::_runAction('form_login',$forms);
