<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "email",	  "type" => "Email", "label" => "Email","req" => true ,"validate" => false , "value" => "", 	   "additional" => '' );
$formFields[] = array("id" => "",		"type" => "Button",	"label" => "",		"req" => false,"value" => "Rest Password", "additional" => 'class="submit-btn"',);

$forms = array( 
	"identifier" 	 => "resetPasswordForm", 
	"name" 		     => 'Reset Password', 
	"primaryFiled"   => "", 
	"url" 			 => "set/".$Base->_getFileName(__FILE__), 
    "success"        => "message_reporting('message_:FORM_ID','Reset Link has been sent to your mail. Please check your mail. If you don\'t find in inbox, please check junk folder.',1);", 
	"filename" 	     => $Base->_getFileName(__FILE__), 
	"fields" 		 => $formFields
);

$forms = Plugins::_runAction('form_forgot_password',$forms);
