<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$formFields[] = array("id" => "keyMessage",    "type" => "Text",    "label" => "key",    "req" => true ,"value" => "", "additional" => 'style="width: 90%;"' );
$formFields[] = array("id" => "contentMessage",    "type" => "Text",    "label" => "Message",    "req" => true,"value" => "", "additional" => 'style="width: 90%;"' );


$formFields[] = array("id" => "statusMessage",    "type" => "Select",  "label" => "Status",        "req" => true ,"value" => "1", "additional" => '' ,"set" => "status");
$formFields[] = array("id" => "",              "type" => "Button",  "label" => "",              "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
    "identifier"    => "pageForm",
    "name"          => Config::_getMessage('forms.cms.messagelogs.title') , 
    "primaryFiled"  => "idMessage", 
    "url"           => "set/".$Base->_getFileName(__FILE__), 
  //  "success"       => "message_reporting('message_:FORM_ID','Message updated successfully.',1)",
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);

$forms = Plugins::_runAction('form_cms_messages',$forms);
