<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "loginallowonlysuperadmins",  "type" => "checkbox",	"label" => "Disable Admin Panel access to Admin Users(Only super admin users can have the access)","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="Allow only Super Admins to login" />');

$formFields[] = array("id" => "loginsessiontimeout",  "type" => "text",	"label" => "Login Session Time Out","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'Minutes<span class="fieldhelp" title="The no of minutes an user session will exists after login" />');

$formFields[] = array("id" => "logininvalidattempts",  "type" => "text",	"label" => "Invalid Login Attempts","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="The no of invalid login attempts after which we have to perform the following invalid actions" />');

$formFields[] = array("id" => "logininvalidshowcaptcha",  "type" => "checkbox",	"label" => "Show Captcha for Invalid Attepts","req" => false ,"value" => "", "additional" => '', 
"postFieldLable"=>'<span class="fieldhelp" title="This will display and ask the user to enter the captcha once invalid attempts reached the threshold limit mentioned above" />');

$formFields[] = array("id" => "logininvalidsendmail",  "type" => "checkbox",	"label" => "Send Mail for Invalid Attempts","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="This will send a mail to the user regarding the invalid attempts once invalid attempts reached the threshold limit mentioned above" />');


$formFields[] = array("id" => "",		 "type" => "Button","label" => "",			"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "loginSettignsForm", 
	"name" 			=> "Login Settings", 
	"primaryFiled" 	=> "idSystemconfig", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__), 
	"success" 		=> "message_reporting('message_:FORM_ID','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 


$forms = Plugins::_runAction('form_settings_login',$forms);
