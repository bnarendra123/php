<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "fromemail",  "type" => "text",	"label" => "From Address","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="The email address used by CMS to send site email." />');

$formFields[] = array("id" => "fromname",  "type" => "text",	"label" => "From Name","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="This will be used when sending site emails. By default, site name will be used during the initial setup." />');

$formFields[] = array("id" => "sendserver","type" => "select",  "label" => "Mail Server","req" => true ,"value" => "", "additional" => '',"set" => "mailservers",
"postFieldLable"=>'<span class="fieldhelp" title=" List of mail servers available." />');

$formFields[] = array("id" => "smtpauthentication",  "type" => "checkbox",	"label" => "Authenticate SMTP","req" => false ,"value" => "", "additional" => 'onclick="return settingsMail_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title=" If the SMTP server requires authentication to send mail, Please chekc this. Otherwise leave it." />');

$formFields[] = array("id" => "smtpsecurity",  "type" => "checkbox",	"label" => "SMTP Security","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" Select the security model your SMTP server uses." />');

$formFields[] = array("id" => "smtphost",  "type" => "text",	"label" => "SMTP Host","req" => false ,"value" => "", "additional" => '', "set" => "yesno",
"postFieldLable"=>'<span class="fieldhelp" title="The SMTP address to use when sending mail." >');

$formFields[] = array("id" => "smtpusername",  "type" => "text",	"label" => "SMTP Username","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="The username to use for access to the SMTP host." >');

$formFields[] = array("id" => "smtppassword",  "type" => "password",	"label" => "SMTP Password","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="The password to use for access to the SMTP host." >');

$formFields[] = array("id" => "smtpport",  "type" => "text",	"label" => "SMTP Port","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span title="Most unsecure servers use port 25 and most secure servers use port 465." />');

$formFields[] = array("id" => "", "type" => "Button", "label" => "", "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "mailSettingsForm", 
	"name" 		  => "Mail Settings", 
	"primaryFiled"  => "idSystemconfig", 
	"url" 		   => "set/".$Base->_getFileName(__FILE__), 
	"success" 	   => "message_reporting('message_".$Forms->_getFormId()."','Your details saved successfully.',1);", 
	"closeLink" 	 => "",
	"filename" 	  => $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 

$forms = Plugins::_runAction('form_settings_mail',$forms);
