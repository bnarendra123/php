<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "websiteipsall",  "type" => "checkbox",  "label" => "Block All Ips Except Allowed Ips","req" => false ,"value" => "", "additional" => 'onclick="return settingsIp_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this option will block all the ips except Allowed Ips below." >');

$formFields[] = array("id" => "websiteipsblock",  "type" => "textarea",   "label" => "Blocked Ips","req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"',
"postFieldLable"=>'<span class="fieldhelp" title="This contains the list of Ips to be Blocked. Use , to seperate Multiple Ips." >');

$formFields[] = array("id" => "websiteipsallow",  "type" => "textarea",	"label" => "Allowed Ips","req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"',
"postFieldLable"=>'<span class="fieldhelp" title="This contains the lsit of Ips to be Allowed. Use , to seperate Multiple Ips." >');

$formFields[] = array("id" => "websiteipsblockmessageoffline",  "type" => "checkbox",  "label" => "Display Website Offline Message for Blocked Ips","req" => false ,"value" => "", "additional" => 'onclick="return settingsIp_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this option will show website offline message for blocked ips." >');

$formFields[] = array("id" => "websiteipsblockmessage",  "type" => "textarea", "label" => "Message for Blocked Ips","req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"',
"postFieldLable"=>'<span class="fieldhelp" title="This message will be show for the blocked ips." >');

$formFields[] = array("id" => "",		 "type" => "Button","label" => "",			"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "gSettignsForm", 
	"name" 			=> "Ip Settings", 
	"primaryFiled" 	=> "idSystemconfig", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__), 
	"success" 		=> "message_reporting('message_:FORM_ID','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 

$forms = Plugins::_runAction('form_settings_ip',$forms);
