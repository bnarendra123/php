<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "cacheenable",  "type" => "checkbox",	"label" => "Enable Cache","req" => false ,"value" => "", "additional" => 'onclick="return settingsCache_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<a href="javascript:clearCache();">Clear Cache</a>&nbsp;<span  class="fieldhelp" title="Enable/disables the cache" />');

$formFields[] = array("id" => "cacheserver","type" => "select",  "label" => "Cache Server","req" => true ,"value" => "", "additional" => '',"set" => "cacheservers",
"postFieldLable"=>'<span class="fieldhelp" title=" List of mail servers available." />');

$formFields[] = array("id" => "cachefolder",  "type" => "text",	"label" => "Cache Folder","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span  class="fieldhelp" title="This will be used to store Cached files. Folder must be writable." />');

$formFields[] = array("id" => "cachefileextension",  "type" => "text",	"label" => "Cache File Extension","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span  class="fieldhelp" title="This extension will be used to save the cache files." />');

$formFields[] = array("id" => "cachetimelimit",  "type" => "text",	"label" => "Cache Time Limit","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'seconds <span class="fieldhelp" title=" Sets the time limit for cache storing." />');

$formFields[] = array("id" => "", "type" => "Button", "label" => "", "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "cacheSettingsForm", 
	"name" 		  => "Cache Settings", 
	"primaryFiled"  => "idSystemconfig", 
	"url" 		   => "set/".$Base->_getFileName(__FILE__), 
	"success" 	   => "message_reporting('message_".$Forms->_getFormId()."','Your details saved successfully.',1);", 
	"closeLink" 	 => "",
	"filename" 	  => $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 

$forms = Plugins::_runAction('form_settings_cache',$forms);
