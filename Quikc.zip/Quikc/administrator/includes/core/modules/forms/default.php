<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

 //* Datafileter. Useful to sort the data after save or closing of the editor*/
if( !isset($dataFilter) ) $dataFilter = '';

if( !isset($_POST['formPrimaryField']) || $_POST['formPrimaryField'] == 'undefined') $_POST['formPrimaryField'] = -1;

$formFields  = array();
$forms       = array();

if( isset($_POST['id']) && $_POST['id'] != '' && $_POST['formPrimaryField'] == -1 ){
    $_POST['formPrimaryField'] = $_POST['id'];
}

$forms = Plugins::_runAction('form_default',$forms);
