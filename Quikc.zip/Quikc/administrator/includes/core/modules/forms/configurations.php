<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$formFields[] = array("id" => "keyConfig",    "type" => "Text",    "label" => "Configuration Key",    "req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "valueConfig",    "type" => "Text",    "label" => "Configuration Value",    "req" => true,"value" => "", "additional" => '' );

$formFields[] = array("id" => "",              "type" => "Button",  "label" => "",              "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
    "identifier"    => "pageForm",
    "name"          => Config::_getMessage('forms.superadministrator.config.title') , 
    "primaryFiled"  => "idConfig", 
    "url"           => "set/".$Base->_getFileName(__FILE__), 
  //  "success"       => "message_reporting('message_:FORM_ID','Message updated successfully.',1)",
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);

$forms = Plugins::_runAction('form_configurations',$forms);
