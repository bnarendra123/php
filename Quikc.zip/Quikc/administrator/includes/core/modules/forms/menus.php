<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$formFields[] = array("id" => "titleMenu",	 	"type" => "Text",		"label" => "Menu Title", 		"req" => true,	"value" => "", "additional" => '' );
$formFields[] = array("id" => "classMenu",	 	"type" => "Text",		"label" => "Menu Class", 		"req" => false,	"value" => "", "additional" => '' );
$formFields[] = array("id" => "descriptionMenu","type" => "Textarea",	"label" => "Menu Description",  "req" => false,	"value" => "", "additional" => 'class="no-editor"' );
$formFields[] = array("id" => "statusMenu", 	"type" => "checkbox",	"label" => "Menu Status",	  	"req" => false,	"value" => "1","additional" => '');

$formFields[] = array("id" => "",			 	"type" => "Button",		"label" => "",				  	"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"');

$forms = array(
	"identifier" 	=> "menuForm", 
	"name" 			=> 'Create New Menu', 
    "primaryFiled"  => "idMenu", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> $Base->_getFileName(__FILE__),
    "fields"        => $formFields,
);


$forms = Plugins::_runAction('form_menus',$forms);
