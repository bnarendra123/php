<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$formFields[] = array("id" => "nameTheme",	 	"type" => "Text",		"label" => "Theme Name", 		"req" => true ,	"value" => "", "additional" => '' );
$formFields[] = array("id" => "statusTheme",	"type" => "Select",		"label" => "Active Theme",  	"req" => true ,	"value" => "0","additional" => '' ,"set" => "yesno");

$formFields[] = array("id" => "", 				"type" => "Button",		"label" => "",  				"req" => false,	"value" => "Proceed","additional" => 'class="submit-btn"');

$forms = array(
	"identifier" 	=> "cmsthemes", 
	"name" 			=> 'Create New Theme', 
    "primaryFiled"  => "idTheme", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> $Base->_getFileName(__FILE__),
    "fields"        => $formFields,
);

$forms = Plugins::_runAction('form_cms_themes',$forms);
