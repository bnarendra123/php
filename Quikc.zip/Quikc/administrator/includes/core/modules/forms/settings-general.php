<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "websitetitle",  "type" => "text",	"label" => "Website Title","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="Website title to be displayed in the Admin Panel"/>');

$formFields[] = array("id" => "websitelogo",  "type" => "media",	"label" => "Website Logo","req" => false ,"value" => "", "additional" => '',"set"=>"img",
"postFieldLable"=>'<span class="fieldhelp" title="This image will set logo for your website." />');

$formFields[] = array("id" => "websitefavicon",  "type" => "media",	"label" => "Website Favicon","req" => false ,"value" => "", "additional" => '',"set"=>"img",
"postFieldLable"=>'<span class="fieldhelp" title="This image will set favicon for your website." />');

$formFields[] = array("id" => "websiteoffline",  "type" => "checkbox",	"label" => "Website Offline","req" => false ,"value" => "", "additional" => 'onclick="return settingsGeneral_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="If yes then the site will go to offline." >');

$formFields[] = array("id" => "websiteofflinemessage",  "type" => "text",	"label" => "Website Offline Message","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="This message will be shown when website goes to offline." >');

$formFields[] = array("id" => "websiteofflineimage",  "type" => "media",	"label" => "Website Offline Image","req" => false ,"value" => "", "additional" => '',"set"=>"img",
"postFieldLable"=>'<span class="fieldhelp" title="This message will be shown when website goes to offline." >');

$formFields[] = array("id" => "websitetimezone",  "type" => "select",	"label" => "Website TimeZone","req" => true ,"value" => "", "additional" => '',"set"=>"timezones",
"postFieldLable"=>'<span class="fieldhelp" title="This will be marked as server and database timezon. Donot change unless you are sure about it." >');

$formFields[] = array("id" => "websiteurlrewrite",  "type" => "checkbox",	"label" => "Allow Url Rewrite","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="This will be marked as server and database timezon. Donot change unless you are sure about it." >');

$formFields[] = array("id" => "",		 "type" => "Button","label" => "",			"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "gSettignsForm", 
	"name" 			=> "General Settings", 
	"primaryFiled" 	=> "idSystemconfig", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__), 
	"success" 		=> "message_reporting('message_".$Forms->_getFormId()."','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 

$forms = Plugins::_runAction('form_settings_general',$forms);

