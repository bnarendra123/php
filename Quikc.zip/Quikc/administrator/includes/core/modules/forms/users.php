<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$query		= "select * from ".Config::_getTable('user_groups')." where statusGroup = 1 ";
$listGroups	= Core::_getAllRows($query, '');

$formFields[] = array("id" => "nameFirstUser", "type" => "Text",    "label" => "First Name","req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "nameLastUser",  "type" => "Text",    "label" => "Last Name", "req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "emailUser",     "type" => "Email",   "label" => "Email",     "req" => true ,"value" => "", "additional" => '' );

// If we are creating a new user then the password must be given
if( $formPrimaryField == -1 ){
     $preq = true;
}else{
     $preq = false; 
}

// Condition 1: If create new user then the password field will be visible $formPrimaryField = 1
// Condition 2: If currently logged in user is a suprt user then also the password field visible
// Condition 3: If currently editing user is not a suprt user then also the password field visible

// Any user can access the password field, 
// unless the user he is editing is a super user and he is not a super admin

if( $formPrimaryField == -1 || ( $Admin-> isSuperUser() || $User->_getUserDetailsById($formPrimaryField)->superUser != 1) )
$formFields[] = array("id" => "passwordUser",   "type" => "Password","label" => "Password",  "req" =>$preq,"value" => "", "additional" => '' );

$formFields[] = array("id" => "imageUser",  	"type" => "Media",   "label" => "User Image","req" => false,"value" => "", "additional" => '' ,"set" => 'img');
$formFields[] = array("id" => "countryUser",    "type" => "Select",  "label" => "Country",   "req" => true ,"value" => "", "additional" => '' ,"set" => "countries" );
$formFields[] = array("id" => "timezoneUser",   "type" => "Select",  "label" => "Time Zone", "req" => false ,"value" => "", "additional" => '' ,"set" => "timezones" );
$formFields[] = array("id" => "genderUser",     "type" => "Select",  "label" => "Gender",    "req" => true, "value" => "", "additional" => '' ,"set" => "gender");

$formFields[] = array("id" => "adminUser", "type" => "Checkbox","label" =>"Admin User","req" => false, "value" => "0","additional" => 'onclick="return usersAdminCheckbox_'.$Forms->_getFormId().'()"') ;

if( $Admin -> _isSuperUser() )
$formFields[] = array("id" => "superUser", "type" => "Checkbox","label" =>"Super User","req" => false, "value" => "0","additional" => '') ;

$formFields[] = array("id" => "groupsUser","type" => "selectmulti","label"=>"User Groups","req" => false, "value" => "0","additional" => '' ,"set" => 'usergroups');

$formFields[] = array("id" => "statusUser",     "type" => "Checkbox","label" => "Status",   "req" => false ,"value" => "1","additional" => '');
$formFields[] = array("id" => "mobilenoUser",   "type" => "Text",  	"label" => "Mobile No" ,"req" => false,"value" => "", "additional" => '' );
$formFields[] = array("id" => "",           "type" => "Button","label" => "",          		"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
    "identifier"    => "userForm", 
    "name"          => "User", 
    "primaryFiled"  => "idUser", 
    "url"           => "set/".$Base->_getFileName(__FILE__), 
    "success"       => "javascript:message_reporting('message_".$Forms->_getFormId()."','Your details saved successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);

$forms = Plugins::_runAction('form_users',$forms);

