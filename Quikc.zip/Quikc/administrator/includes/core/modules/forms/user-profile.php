<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "nameFirstUser",	"type" => "Text",	"label" => "First Name","req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "nameLastUser",	"type" => "Text",	"label" => "Last Name", "req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "emailUser",		"type" => "Email",	"label" => "Email", 	"req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "imageUser",		"type" => "Media",	"label" => "User Image","req" => false,"value" => "", "additional" => '' ,"set" => 'img' );
$formFields[] = array("id" => "countryUser", 	"type" => "Select",	"label" => "Country",	"req" => true ,"value" => "", "additional" => '' ,"set" => "countries" );
$formFields[] = array("id" => "timezoneUser",   "type" => "Select", "label" => "Time Zone", "req" => true ,"value" => "", "additional" => '' ,"set" => "timezones" );
$formFields[] = array("id" => "genderUser", 	"type" => "Select",	"label" => "Gender",	"req" => true, "value" => "", "additional" => '' ,"set" => "gender");

if( $Admin -> _isSuperUser() )
$formFields[] = array("id" => "superUser", "type" => "Checkbox","label" =>"Super User","req" => false, "value" => "0","additional" => '' ,"set" => "yesno") ;

$formFields[] = array("id" => "mobilenoUser","type" => "Text",	"label" => "Mobile No" ,"req" => false,"value" => "", "additional" => '' );
$formFields[] = array("id" => "",		 "type" => "Button","label" => "",			"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "userForm", 
	"name" 			=> Config::_getMessage('forms.settings.profile.title'), 
	"primaryFiled" 	=> "idUser", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__), 
	"success" 		=> "message_reporting('message_:FORM_ID','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 

$forms = Plugins::_runAction('form_user_profile',$forms);
