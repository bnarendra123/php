<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$formFields[] = array("id" => "titleWidget",   "type" => "Text",    "label" => "Widget Title",	"req" => true ,"value" => "", "additional" => '' );

if( $formPrimaryField == -1 ){
	$formFields[] = array("id" => "pathWidget",    "type" => "Text",  	"label" => "Widget path",   "req" => true,"value" => "", "additional" => '');
}

$formFields[] = array("id" => "statusWidget",  "type" => "Checkbox","label" => "Status",      	"req" => false,"value" => "1", "additional" => '');
$formFields[] = array("id" => "systemItem",    "type" => "Checkbox","label" => "System Item",   "req" => false,"value" => "0", "additional" => '');
$formFields[] = array("id" => "",              "type" => "Button",  "label" => "",              "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
    "identifier"    => "widgetForm", 
    "name"          => 'Creating New Widet', 
    "primaryFiled"  => "idWidget", 
    "url"           => "set/".$Base->_getFileName(__FILE__), 
    "success"       => "javascript:message_reporting('message_".$Forms->_getFormId()."','Your details saved successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);


$forms = Plugins::_runAction('form_widgets',$forms);
