<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$formFields[] = array("id" => "namePlugin",     "type" => "Text",    "label" => "Plugin Name",    "req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "autoLoadPlugin", "type" => "Select",  "label" => "Auto Load Plugin","req" => true ,"value" => "", "additional" => '',"set" => "yesno" );
$formFields[] = array("id" => "statusPlugin",   "type" => "Select",  "label" => "Plugin Status",  "req" => true ,"value" => "", "additional" => '' ,"set" => "status");
$formFields[] = array("id" => "",              "type" => "Button",  "label" => "",              "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
    "identifier"    => "pluginsForm", 
    "name"          => '', 
    "primaryFiled"  => "idPlugin", 
    "url"           => "set/".$Base->_getFileName(__FILE__), 
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);

$forms = Plugins::_runAction('form_plugins',$forms);

