<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$listMenus = $Menus->_prepareAdminMenuSet(false);

extract($_POST);

if( !isset($formPrimaryField) ){
    $formPrimaryField = -1;
}

// Deleting the same menu as the non top menu and also the dashboard menu
foreach($listMenus as $key => $tmpMenu){    
    if( $tmpMenu->idMenu == $formPrimaryField || $tmpMenu->linkMenu == 'dashboard' ){
        unset($listMenus[$key]);
    }
}


$formFields[] = array("id" => "titleMenu",	 "type" => "Text",	"label" => "Menu Title", "req" => true ,"value" => "", "additional" => '' );

$additional = '';

if( isset($formPrimaryField) && $formPrimaryField != -1){
    if($Menus->_loadAdminMenu($formPrimaryField)->systemItem == 1 && !$Admin->_isDeveloperMode())
    $additional = 'disabled="disabled"';
}

$formFields[] = array("id" => "linkMenu",   	"type" => "Text",	"label" => "Menu Link" ,		"req" => false,	"value" => "", "additional" => $additional );
$formFields[] = array("id" => "imageMenu",	 	"type" => "Media",	"label" => "Menu Image",		"req" => false,	"value" => "0","additional" => '',"set" => 'img');
$formFields[] = array("id" => "parentMenu", 	"type" => "Select",	"label" => "Parent Menu",		"req" => false,	"value" => "", "additional" => '' ,"set" => array($listMenus,'idMenu','titleMenu'));
$formFields[] = array("id" => "dashboardMenu",	"type"=>"Checkbox",	"label" => "Show in Dashboard",	"req" => false,	"value" => "1","additional" => '');
$formFields[] = array("id" => "topMenu",	 	"type" => "Checkbox","label" => "Show in Top Menu",	"req" => false,	"value" => "1","additional" => '');
$formFields[] = array("id" => "showSubMenus",	"type" => "Checkbox","label" => "Show Sub Menus",	"req" => false,	"value" => "1","additional" => '');
$formFields[] = array("id" => "statusMenu",		"type" => "Checkbox","label" => "Menu Status",	  	"req" => false,	"value" => "1","additional" => '' );
$formFields[] = array("id" => "orderMenu",		"type" => "Text",	"label" => "Menu Order" ,	  	"req" => false,	"value" => "", "additional" => '' );
$formFields[] = array("id" => "",				"type" => "Button",	"label" => "",				  	"req" => false,	"value" => "Proceed","additional" => 'class="submit-btn"');

$forms = array(
	"identifier" 	=> "amenuForm", 
	"name" 			=> Config::_getMessage('forms.superadministrator.adminmenus.title'), 
    "primaryFiled"  => "idMenu", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> $Base->_getFileName(__FILE__),
    "fields"        => $formFields,
);

$forms = Plugins::_runAction('form_admin_menu',$forms);
