<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$idParentPage= 0;
// value will be updated when getting the create/edit forms
if(isset($params->idParentPage)){
    $idParentPage = $params->idParentPage;
}


$formFields[] = array("id" => "namePage",    "type" => "Text",    "label" => "Page Name",    "req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "linkPage",    "type" => "Text",    "label" => "Page Link",    "req" => false,"value" => "", "additional" => '' );

// List of Pages ready for parent page
$listParentPages = $Cms->_preparePageSet();

// When editing removing current page from parent page list
foreach( $listParentPages[0] as $key => $page ){
    
    if( $page -> idPage == $formPrimaryField || in_array($formPrimaryField, $page -> idsParent) ){

        unset($listParentPages[0][$key]);

    }

}

$formFields[] = array( "id" => "idParentPage"	,"label" => "Id Parent Page" ,"type" => "select"	,"value" => $idParentPage,"additional" => ""	,"set" => $listParentPages ,"dbfield" => "1"	,"req" => false	,"unique" => "");

$formFields[] = array("id" => "descriptionPage" ,"type" => "Textarea", "label" => "Page Description",	  "req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"' );
$formFields[] = array("id" => "keywordsPage"    ,"type" => "text"    , "label" => "Page Keywords",        "req" => false ,"value" => "", "additional" => '' ,"postFieldLable"=>'<br/>seperate multiple with comma');

$themesSet = array('themes' => 'Select From Themes', 'plugins' => 'Select From Plugins');

$formFields[] = array("id" => "typePage", "type" => "Select",   "label" => "Page Theme",   "req" => true ,"value" => "", "additional" => 'onchange="return themeChanged_'.$Forms->_getFormId().'()"', 'set' => $themesSet );

$selectedthemesSet = array_merge(array('global' => 'Use Active Theme'),$Base->_generateSelect('themes'));

$formFields[] = array("id" => "themePage", "type" => "Select",   "label" => "Select Page",   "req" => true ,"value" => "", "additional" => 'onchange="return themeChanged_'.$Forms->_getFormId().'()"', 'set' => $selectedthemesSet);

$themeTemplatesSet = $Themes->_getTemplates();

$listPlugins = $Plugins->_getActivePlugins();

$setPluginTemplates = array();

foreach($listPlugins as $key => $plugin){
	
	$listtemplates = $Themes->_getTemplates(false,$plugin->identifierPlugin);
	
	if($listtemplates && count($listtemplates) > 0){
	    
		$setPluginTemplates[$plugin->identifierPlugin] = $listtemplates;
        
	}else{
	    
		//unset($listPlugins[$key]);
		
	}
}

$setPlugins = array($listPlugins,'identifierPlugin','namePlugin');

$formFields[] = array("id" => "pluginPage","type" =>"Select",  "label" => "Select Plugin","req" => true ,"value" => "", "additional" => 'onchange="return themeChanged_'.$Forms->_getFormId().'()"', 'set' => $setPlugins );

$formFields[] = array("id" => "templatePage","type" =>"Text",  "label" => "Page Template","req" => true ,"value" => "", "additional" => ''  );

$robotsSet = array_merge(array('global' => 'Use Global'),$Base->_generateSelect('robots'));

$formFields[] = array("id" => "robotsPage", "type" => "Select",  "label" => "Page Robots",  "req" => true ,"value" => "",  "additional" => '', 'set' => $robotsSet );

$formFields[] = array("id" => "requireLogin","type" => "checkbox","label"=> "Require Login to Access", "req" => false ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "defaultPage","type" => "Checkbox","label" => "Default Page", "req" => false,"value" => "0", "additional" => '' );
$formFields[] = array("id" => "statusPage", "type" => "Checkbox","label" => "Page Status",  "req" => false,"value" => "1", "additional" => '' ,"set" => "status");
$formFields[] = array("id" => "",           "type" => "Button",  "label" => "",             "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
    "identifier"    => "pageForm",
    "name"          => "", 
    "primaryFiled"  => "idPage", 
    "url"           => "set/".$Base->_getFileName(__FILE__), 
    "success"       => "message_reporting('message_:FORM_ID','Page updated successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);

$forms = Plugins::_runAction('form_cms_pages',$forms);


