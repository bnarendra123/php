<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "allownewusers",  "type" => "checkbox",	"label" => "Allow New Users to Register","req" => false ,"value" => "", "additional" => 'onclick="return settingsRegistration_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this will allow new users to register to the website" />');

$formFields[] = array("id" => "requirmailconfirmation",  "type" => "checkbox",   "label" => "Require Email Confirmation","req" => false ,"value" => "", "additional" => 'onclick="return settingsRegistration_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this will ask newly registered users to confirm their email" />');
$formFields[] = array("id" => "mailconfirmationcontent",  "type" => "textarea",   "label" => "Email Confirmation Content","req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"',
"postFieldLable"=>'<span class="fieldhelp" title="This content will be used to send confirmation email to users" />');

$formFields[] = array("id" => "mailalert",  "type" => "checkbox",   "label" => "Send Email Alert","req" => false ,"value" => "", "additional" => 'onclick="return settingsRegistration_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this will send mail alter to users after completing theri registration" />');
$formFields[] = array("id" => "mailalertcontent",  "type" => "textarea",   "label" => "Send Email Alert Content","req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"',
"postFieldLable"=>'<span class="fieldhelp" title="This content will be used to send email to users" />');

$formFields[] = array("id" => "requireadminapproval",  "type" => "checkbox",   "label" => "Require Admin Approval","req" => false ,"value" => "", "additional" => 'onclick="return settingsRegistration_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this require admin to approve new users" />');
$formFields[] = array("id" => "adminapprovalmailalert",  "type" => "checkbox",   "label" => "Send Email Alert After Admin Approval/Disapproval","req" => false ,"value" => "", "additional" => 'onclick="return settingsRegistration_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this will send mail alter to users after admin approval/ disapproval" />');
$formFields[] = array("id" => "adminapprovalmailalertcontent",  "type" => "textarea",   "label" => "Send Email Alert Content","req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"',
"postFieldLable"=>'<span class="fieldhelp" title="This content will be used to send email to users after admin approval/disapproval" />');

$formFields[] = array("id" => "usecaptcha",  "type" => "checkbox",   "label" => "Use Captcha In Registration","req" => false ,"value" => "", "additional" => 'onclick="return settingsRegistration_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this will will use captcha in registration" />');

$formFields[] = array("id" => "defaultadminuser",    "type" => "checkbox",      "label" => "Admin User by default", "req" => false ,"value" => "", "additional" => 'onclick="return settingsRegistration_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="Checking this will make users as admin users by default" />');
$formFields[] = array("id" => "defaultadmingroups",  "type" => "selectmulti",   "label" => "Default Admin Groups",  "req" => false ,"value" => "0", "additional" => '', 'set' => 'usergroups',
"postFieldLable"=>'<span class="fieldhelp" title="The selected groups will be applied to the users by default." />');


$formFields[] = array("id" => "",		 "type" => "Button","label" => "",			"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "registrationSettignsForm", 
	"name" 			=> "registration Settings", 
	"primaryFiled" 	=> "idSystemconfig", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__), 
	"success" 		=> "message_reporting('message_:FORM_ID','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 


$forms = Plugins::_runAction('form_settings_registration',$forms);
