<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

// Updating space id and widget id when edit form is called
if(isset($params->idWidget)){

	$idWidget = $params->idWidget;

}
if(isset($params->idSpace)){

	$idSpace = $params->idSpace;

}

// Updating space id and widget id when set form is called(when saving the data to the databse)
if(isset($formId) && $formId != ''){

	$idWidget = ${'idWidget_'.$formId};	
	
	if(isset(${'idSpace_'.$formId})){

        $idSpace  = ${'idSpace_'.$formId};  
	    
	}

}


// updating the widget id from the database when editing the item
if($formPrimaryField != -1){
	$idWidget = $Widgets->_getWidgetItem($formPrimaryField)->idWidget;
}

// Checking the widget id except for the status and the deletion of the widget item
// When creating new widget we must have the widget id defined
if( ( !isset($do) || !in_array($do, array('status','delete' )) ) && ( !isset($idWidget) || !$Widgets->_getWidgetDetails($idWidget) ) ){
	die('Invalid Widget');
}

$formFields[] = array("id" => "titleWidgetItem",  "type" => "Text",    "label" => "Title",  	"req" => false ,"value" => "", 			"additional" => '' );


if(isset($idSpace)){
	$formFields[] = array("id" => "idSpace", "type" => "Hidden",  "label" => "Space Id",  "req" => true ,"value" => "$idSpace",	"additional" => '' );
}

// We don't have the $idWidget set for status and delete actions
// And we don't need widget fields for those two actions 
// Based on the $idWidget we are avoiding these for them 
if(isset($idWidget)){
	
	$formFields[] = array("id" => "idWidget",     	  "type" => "Hidden",  "label" => "Widget Id",  "req" => true ,"value" => "$idWidget",	"additional" => '' );

	$formPath = Config::_getDir().'/'.$Widgets->_getWidgetDetails($idWidget)->pathWidget.'/form.php';
	
    $widgetFields = array();
    
	if(file_exists($formPath)){
		include_once $formPath;
    }

    $widgetFields = Plugins::_runAction('form_widgets_items_include_widget_form_fields',$widgetFields, $formPath,$idWidget);
		
	if(is_array($widgetFields) && count($widgetFields) > 0){

		foreach($widgetFields as $field){

			// Used to save when saving the data in set/widget-items.php
			$optionFields[] = $field;

			$field['id'] = 'options_'.$field['id'];

			$formFields[] = $field;
		}
	}
}

$formFields[] = array("id" => "globalWidgetItem", "type" => "Checkbox",  "label" => "Allow Global Mode","req" => false,"value" => "0", "additional" => '');
$formFields[] = array("id" => "",			  "type" => "Button",  "label" => "",            	"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
    "identifier"    => "widgetItemForm", 
    "name"          => 'Creating New Widet Item: ', 
    "primaryFiled"  => "idWidgetItem", 
    "url"           => "set/".$Base->_getFileName(__FILE__), 
    "success"       => "javascript:message_reporting('message_".$Forms->_getFormId()."','Your details saved successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);

$forms = Plugins::_runAction('form_widgets_items',$forms);

