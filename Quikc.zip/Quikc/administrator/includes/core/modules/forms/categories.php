<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$idParentCategory = 0;
// value will be updated when getting the create/edit forms
if(isset($params->idParentCategory)){
    $idParentCategory = $params->idParentCategory;
}

$formFields[] = array( "id" => "nameCategory"		,"label" => "Name Category"	     ,"type" => "text"		,"value" => ""	,"additional" => ""	,"set" => ""	,"dbfield" => "1"	,"req" => true	,"unique" => "");
$formFields[] = array( "id" => "linkCategory"		,"label" => "Link Category"		 ,"type" => "text"		,"value" => ""	,"additional" => ""	,"set" => ""	,"dbfield" => "1"	,"req" => false	,"unique" => "");

$formFields[] = array( "id" => "idParentCategory"	,"label" => "Id Parent Category" ,"type" => "hidden"	,"value" => $idParentCategory  ,"additional" => ""	,"set" => ""	,"dbfield" => "1"	,"req" => false	,"unique" => "");

$formFields[] = array( "id" => "imageCategory"		,"label" => "Image Category"	 ,"type" => "media"		,"value" => ""	,"additional" => ""	,"set" => "img"	,"dbfield" => "1"	,"req" => false	,"unique" => "");
$formFields[] = array( "id" => "statusCategory"		,"label" => "Status Category"	 ,"type" => "checkbox"	,"value" => "1"	,"additional" => ""		                ,"dbfield" => "1"	,"req" => false	,"unique" => "");

$formFields[] = array( "id" => ""		,"label" => ""		,"type" => "button"		,"value" => "Proceed"		,"additional" => ""		,"set" => ""		,"dbfield" => ""		,"req" => false		,"unique" => "");

$forms = array( 
	"identifier" 	=> "dynamicForm", 
	"name" 			=> "Creating New categories", 
    "primaryFiled"  => "idCategory", 
	"url" 			=> "set/categories",
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> "categories",
    "fields"        => $formFields,
);
		
$forms = Plugins::_runAction('form_categories',$forms);
		