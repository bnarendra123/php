<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$fileTypes = array(
				'css' 	=> array('path' => '/css'	, 'extensions' => array('css') ),
				'phtml' => array('path' => '/images', 'extensions' => array('phtml') ),
			);

$formFields[] = array("id" => "fileContent",  	"type" => "Textarea",	"label" => "File Content" , 	"req" => true,	"value" => "", "additional" => 'class="no-editor file-editor"' );
$formFields[] = array("id" => "", 				"type" => "Button",		"label" => "",  				"req" => false,	"value" => "Proceed","additional" => 'class="submit-btn"');

$forms = array(
	"identifier" 	=> "cmsthemes-files", 
	"name" 			=> 'Create New File', 
    "primaryFiled"  => "idFile", 
	"url" 			=> "set/".$Base->_getFileName($permissionsPage),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> $Base->_getFileName($permissionsPage),
    "fields"        => $formFields,
);

$forms = Plugins::_runAction('form_cms_themes_files',$forms);

