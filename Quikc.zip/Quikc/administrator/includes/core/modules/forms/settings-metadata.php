<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "websitemetadescription",  "type" => "textarea",	"label" => "Website Description","req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"',
"postFieldLable"=>'<span class="fieldhelp" title="Website title to be displayed in the Admin Panel"/>');

$formFields[] = array("id" => "websitemetakeywords",  "type" => "textarea",	"label" => "Website Keywords","req" => false ,"value" => "", "additional" => 'class="no-editor textarea-small"',
"postFieldLable"=>'<span class="fieldhelp" title="This image will set logo for your website." />');

$formFields[] = array("id" => "websiterobots",  "type" => "select",	"label" => "Robots","req" => true ,"value" => "", "additional" => '',"set"=>"robots",
"postFieldLable"=>'<span class="fieldhelp" title="This image will set favicon for your website." />');

$formFields[] = array("id" => "",		 "type" => "Button","label" => "",			"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "mSettignsForm", 
	"name" 			=> "MetaData Settings", 
	"primaryFiled" 	=> "idSystemconfig", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__), 
	"success" 		=> "message_reporting('message_:FORM_ID','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 

$forms = Plugins::_runAction('form_settings_metadata',$forms);
