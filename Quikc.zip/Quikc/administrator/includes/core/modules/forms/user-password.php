<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "passwordold" ,"type" => "Password","label" => "Old password","req" => true ,"validate" => false , "value" => "", "additional" => '' );
$formFields[] = array("id" => "passwordnew1","type" => "Password","label" => "New password","req" => true ,"validate" => true ,  "value" => "", "additional" => '' );
$formFields[] = array("id" => "passwordnew2","type" => "Password","label" => "Enter New password again", "req" => true ,"validate" => false , "value" => "", "additional" => '' );
$formFields[] = array("id" => "",			"type" => "Button",	 "label" => "",	"req" => false, "value" => "Change Password", "additional" => 'class="submit-btn"');

$forms = array( 
	"identifier" 	=> "adminPassowrd", 
	"name" 		  	=> Config::_getMessage('forms.settings.password.title'), 
	"primaryFiled"  => "idUser", 
	"success" 	   	=> "passwordChanged(':FORM_ID');", 
	"closeLink" 	=> "",
	"url" 		  	=> "set/".$Base->_getFileName(__FILE__), 
	"filename" 	  	=> $Base->_getFileName(__FILE__) ,
	"fields" 		=> $formFields
);

$forms = Plugins::_runAction('form_user_password',$forms);
