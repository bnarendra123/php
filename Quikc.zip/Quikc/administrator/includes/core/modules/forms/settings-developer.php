<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "developermodeglobal",  "type" => "checkbox",	"label" => "Global Developer Mode","req" => false ,"value" => "", "additional" => 'onclick="return settingsDeveloperMode_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="If yes, then the entire website will run in developer mode. Irrespective of the admins or their login status" />');

$formFields[] = array("id" => "developermode",  "type" => "checkbox",	"label" => "Allow Admin Developer Modes","req" => false ,"value" => "", "additional" => 'onclick="return settingsDeveloperMode_'.$Forms->_getFormId().'()"',
"postFieldLable"=>'<span class="fieldhelp" title="If yes, then this option will allow the admins to use the website in Developer Mode. In developer mode admins will have the extended access to the system items and, no cache, errors will be directly displayed etc." />');

$formFields[] = array("id" => "developermodesuperadminsonly",  "type" => "checkbox",	"label" => "Allow Developer for Super Admins only","req" => false ,"value" => "", "additional" => 'onclick="return settingsDeveloperMode()"',
"postFieldLable"=>'<span class="fieldhelp" title="If yes, then only Super Admins are allowed to use the website in Developer Mode, otherwise, everyone can use the Developer Mode." />');

$formFields[] = array("id" => "developermodeloginreset",  "type" => "checkbox",	"label" => "Reset Developer Mode on Login","req" => false ,"value" => "", "additional" => '',"set"=>"yesno",
"postFieldLable"=>'<span class="fieldhelp" title="If yes, the each time the user logged in, he will be logged as normal Admin, Otherwise his previous modes will be used for the next sessions." />');

$formFields[] = array("id" => "developermodedisplayhelper",  "type" => "checkbox",	"label" => "Display Developer Mode Helper","req" => false ,"value" => "", "additional" => '',"set"=>"yesno",
"postFieldLable"=>'<span class="fieldhelp" title="If yes, then a helper will be displayed in all the pages." />');

$formFields[] = array("id" => "developermodecaching",  "type" => "checkbox",	"label" => "Allow Caching in Developer Mode","req" => false ,"value" => "", "additional" => '',"set"=>"yesno",
"postFieldLable"=>'<span class="fieldhelp" title="If yes, then caching will be enabled in developer mode as well." />');

$formFields[] = array("id" => "",		 "type" => "Button","label" => "",			"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "developerSettingsForm", 
	"name" 			=> "Developer Settings", 
	"primaryFiled" 	=> "idSystemconfig", 
	"url" 			=> "set/".$Base->_getFileName(__FILE__), 
	"success" 		=> "message_reporting('message_".$Forms->_getFormId()."','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 

$forms = Plugins::_runAction('form_settings_developer',$forms);
