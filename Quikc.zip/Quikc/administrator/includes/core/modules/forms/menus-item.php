<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

if(isset($formPrimaryField) && $formPrimaryField != -1) {

	$idMenu = $formPrimaryField;

}elseif(isset($params->idMenu) && $params->idMenu != -1){

	$idMenu = $params->idMenu;

}

// Updating menu id when set form is called(when saving the data to the database)
if(isset($formId) && $formId != '' && isset(${'idMenu_'.$formId}) ){

	$idMenu = ${'idMenu_'.$formId};	

}

// We need menu id if we are creating a new menu item
// If we are editing already existing menu item, then we don't need menu id
// $formPrimaryField == -1 checks weather we are creating a new menu item or editing existing one
// if creating new, then !isset($idMenu) || !$Menus->_getMenuDetails($idMenu) will confirms that we have a valid menu id
if( $formPrimaryField == -1 && ( !isset($idMenu) || !$Menus->_getMenuDetails($idMenu) ) ){

    die('Invalid Menu');

}

// We only need menu id when creating a new menu item
if( $formPrimaryField == -1 ){

	$formFields[] = array("id" => "idMenu", "type" => "hidden",   "label" => "Menu Id",   "req" => true ,"value" => "$idMenu", "additional" => '' );

}

$typeLinks = array('1' => 'Select Page','2' => 'External Link');

$formFields[] = array("id" => "linkTypeMenuItem",  	"type" => "select"	,"label"  => "Link Type",			"req" => false ,"value" => "", "additional" => 'onchange="return menuItemUrl_'.$Forms->_getFormId().'()"', "set" => $typeLinks );

$formFields[] = array("id" => "idLinkTypeMenuItem",  	"type" => "select"	,"label"  => "Select from Pages",	"req" => false ,"value" => "", "additional" => '', "set" => $Cms->_preparePageSet() );
$formFields[] = array("id" => "linkMenuItem",			"type" => "text"	,"label"  => "External Link",		"req" => false ,"value" => "", "additional" => '');

$formFields[] = array("id" => "titleMenuItem",    "type" => "Text",    "label" => "Menu Item Title",   "req" => true ,"value" => "", "additional" => '' );
$formFields[] = array("id" => "imageMenuItem",    "type" => "Media",    "label" => "Page Link",    "req" => false,"value" => "", "additional" => '', 'set' => 'img' );

$formFields[] = array("id" => "parentMenuItem","type" => "hidden",   "label" => "Parent",  "req" => false ,"value" => "0", "additional" => '');
$formFields[] = array("id" => "orderMenuItem", "type" => "hidden",   "label" => "Order",   "req" => false ,"value" => "1000", "additional" => '');

$formFields[] = array("id" => "statusMenuItem", "type" => "Checkbox","label" => "Menu Item Status",  "req" => false,"value" => "1", "additional" => '');

$formFields[] = array("id" => "",           "type" => "Button",  "label" => "",             "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
    "identifier"    => "menuitemForm",
    "name"          => 'New Menu Item' , 
    "primaryFiled"  => "idMenuItem", 
    "url"           => "set/".$Base->_getFileName(__FILE__), 
    "success"       => "message_reporting('message_:FORM_ID','Page updated successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);


$forms = Plugins::_runAction('form_menus_items',$forms);
