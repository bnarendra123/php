<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$actions = array("status","edit","delete");

$displayFields	= array( 
 array( "id" => "from",		"title" => 'From'		,"type" => 'text'   ,"dbField" => true ,"tpx" => 'm', "display" => ':data'),
 array( "id" => "replyTo",	"title" => 'Reply To'	,"type" => 'text'   ,"dbField" => true ,"tpx" => 'm', "display" => ':data'),
 array( "id" => "subject",	"title" => 'Subject'	,"type" => 'text'   ,"dbField" => true ,"tpx" => 'm', "display" => ':data'), 
 array( "id" => "link",		"title" => 'Link'		,"type" => 'text'   ,"dbField" => true ,"tpx" => '' , "display" => ':data'),
 array( "id" => "actions",	"title" => 'Actions'	,"type" => 'actions',"dbField" => false,"tpx" => ''  , "display" => '',"set" => $actions)
);

$listData = array( 
	"sql" 			=> " select * from ".Config::_getTable('mails')." m",
//	"where" 		=> "", 
//	"arrayBind" 	=> "",
	"sortby" 		=> "idMail", 
	"order" 		=> "asc", 
	"headding" 		=> Config::_getMessage('lists.cms.mails.title'), 
	"primaryField" 	=> "idMail", 
	"statusField" 	=> "statusMail",
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__) 
);

$listData = Plugins::_runAction('list_mails',$listData);

