<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');


$actions = array("status","edit","delete");

$displayFields	= array( 
 array( "id" =>"idMessage",		"title" => 'Id'		,"type" => 'text'   ,"dbField" => true ,"tpx" => 'cm', "display" => ':data'),
 array( "id" =>"keyMessage",	"title" => 'Key'	,"type" => 'text'   ,"dbField" => true ,"tpx" => 'cm', "display" => ':data'),
 array( "id" =>"contentMessage","title" => 'Message',"type" => 'text'   ,"dbField" => true ,"tpx" => 'cm', "display" => ':data'), 
 array( "id" =>"createdBy",     "title" => 'Created By',"type" => 'text'   ,"dbField" => true ,"tpx" => '', "display" => ':data'),

 array( "id" =>"dateAdditionMessage", "title" => 'Created On'	 ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'cm', "display" => ':data'),
 array( "id" =>"dateUpdationMessage", "title" => 'Updated On'	 ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'cm', "display" => ':data'),
 array( "id" =>"actions",             "title" => 'Actions'		 ,"type" => 'actions',"dbField" => false,"tpx" => ''  , "display" => '',"set" => $actions)
);

$listData = array( 
	"sql" 			=> " select *,if(cm.createdByType = 'user', concat(u.nameFirstUser,' ',u.nameLastUser,'(user)'), concat(p.namePlugin,'(plugin)') ) as createdBy from ".Config::_getTable('cms_messages_log')." cm left join ".Config::_getTable('users')." u on cm.createdById = u.idUser left join ".Config::_getTable('plugins')." p on cm.createdById = p.identifierPlugin",
//	"where" 		=> "", 
//	"arrayBind" 	=> "",
	"sortby" 		=> "dateUpdationMessage", 
	"order" 		=> "desc", 
	"headding" 		=> Config::_getMessage('lists.cms.messagelogs.title'), 
	"primaryField" 	=> "idMessage", 
	"statusField" 	=> "statusMessage",
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__) 
);

$listData = Plugins::_runAction('list_cms_messages',$listData);


