<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');


$actions = array("status","edit","delete","permissions");

$displayFields	= array( 
 array( "id" => "idLanguage",		"title" => 'Language Id'	,"type" => 'text'  ,"dbField" => true ,"tpx" => 'l',"display" => ':data'),
 array( "id" => "nameLanguage",		"title" => 'Language Name' 	,"type" => 'text'  ,"dbField" => true ,"tpx" => 'l',"display" => ':data'), 
 array( "id" => "codeLanguage",		"title" => 'Language Code' 	,"type" => 'text'  ,"dbField" => true ,"tpx" => 'l',"display" => ':data'), 
 array( "id" => "defaultLanguage",	"title" => 'Default Language',"type" => 'select',"dbField" => true ,"tpx" => 'l',"display" => ':data',"set" => "yesno"),
 array( "id" => "dateAdditionLanguage","title" => 'Created On' 	,"type" => 'date'  ,"dbField" => true ,"tpx" => 'l',"display" => ':data'),
 array( "id" => "dateUpdationLanguage","title" => 'Updated On' 	,"type" => 'date'  ,"dbField" => true ,"tpx" => 'l',"display" => ':data'),
 array( "id" => "actions",             "title" => 'Actions'		,"type" => 'actions',"dbField" =>false,"tpx" => ''  ,"display" => '',"set" => $actions	)
);

$listData = array( 
	"sql" 			=> " select * from ".Config::_getTable('languages')." l ",
	"where" 		=> "",
	"arrayBind" 	=> "",
	"sortby" 		=> "nameLanguage", 
	"order" 		=> "asc",
	"headding" 		=> Config::_getMessage('lists.superadministrator.languages.title'), 
	"primaryField" 	=> "idLanguage", 
	"statusField" 	=> "statusLanguage",
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields,
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__)
);

$listData = Plugins::_runAction('list_languages',$listData);


