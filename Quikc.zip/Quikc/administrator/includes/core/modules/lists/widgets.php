<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$actions = array("status","edit","delete");

//array_unshift($actions,array('display' => '<a href="javascript:manageWidgetsItems(\'primaryField\');">Manage Created Widgets</a>', 'permissions' => 'edit' ));
$itemsWidget = '<a href="javascript:manageWidgetsItems(\':data\');">Manage Widget Items</a>';

$displayFields  = array( 
 array( "id" =>"idWidget",      "title" => 'Widget Id'      ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'w', "display" => ':data'),
 array( "id" =>"titleWidget",   "title" => 'Widget Name'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'w', "display" => ':data'), 
 array( "id" =>"pathWidget",    "title" => 'Widget Path'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'w', "display" => ':data'), 
 array( "id" =>"statusWidget",  "title" => 'Widget Status'  ,"type" => 'select' ,"dbField" => true ,"tpx" => 'w', "display" => ':data',"set" => "status"),
 array( "id" =>"systemItem",    "title" => 'System Item'    ,"type" => 'select' ,"dbField" => true ,"tpx" => 'w', "display" => ':data',"set" => "yesno"),

 array( "id" =>"createdBy",     "title" => 'Created By'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => '', "display" => ':data'),

 array( "id" =>"dateAdditionWidget", "title" => 'Added On'   ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'w', "display" => ':data'),
 array( "id" =>"dateUpdationWidget", "title" => 'Update On'  ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'w', "display" =>':data'), 

 array( "id" =>"widgetItems", "title" => 'Widget Items'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => '', "display" => $itemsWidget),
 array( "id" =>"actions"    , "title" => 'Actions'       ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    )
);

$sql =	" select *,w.idWidget as widgetItems,if(w.createdByType = 'user', concat(u.nameFirstUser,' ',u.nameLastUser,'(user)'), concat(p.namePlugin,'(plugin)') ) as createdBy from 
		".Config::_getTable('widgets')." w 
		left join ".Config::_getTable('users')." u on w.createdById = u.idUser
		left join ".Config::_getTable('plugins')." p on w.createdById = p.identifierPlugin";
	
$listData = array( 
    "sql"           => $sql, 
    "where"         => "",
    "arrayBind"     => "",
    "sortby"        => "titleWidget", 
    "order"         => "asc", 
    "headding"      => 'Widgets', 
    "primaryField"  => "idWidget", 
    "statusField"   => "statusWidget", 
    "noCreate"      => true,
    //  Fields from here are same for all (in general)
    "multiActions"  => true, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

$listData = Plugins::_runAction('list_widgets',$listData);

