<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$idWidget = $params->idWidget;

if( !isset($idWidget) || !$Widgets->_getWidgetDetails($idWidget) ){

	die('Invalid Widget');

}

$actions = array("status","edit","delete");

$displayFields  = array( 
 array( "id" => "idWidgetItem",     "title" => 'Widget Item Id'  	,"type" => 'text'   ,"dbField" => true ,"tpx" => 'wi', "display" => ':data'),
 array( "id" => "titleWidgetItem",  "title" => 'Widget Item Title'	,"type" => 'text'   ,"dbField" => true ,"tpx" => 'wi', "display" => ':data'), 
 array( "id" => "statusWidgetItem", "title" => 'Widget Item Status'	,"type" => 'select' ,"dbField" => true ,"tpx" => 'wi', "display" => ':data',"set" => "status"),

 array( "id" => "idSpace",     "title" => 'Created Space'	,"type" => 'select'   ,"dbField" => true ,"tpx" => 's', "display" => ':data', 'set' => "spaces"),
 array( "id" => "idPage",      "title" => 'Created Page'	,"type" => 'select'   ,"dbField" => true ,"tpx" => 'p', "display" => ':data', 'set' => "pages"),

 array( "id" => "globalWidgetItem", "title" => 'Global Item'    	,"type" => 'select' ,"dbField" => true ,"tpx" => 'wi', "display" => ':data',"set" => "yesno"),
 array( "id" => "systemItem",       "title" => 'System Item'    	,"type" => 'select' ,"dbField" => true ,"tpx" => 'wi', "display" => ':data',"set" => "yesno"),

 array( "id" => "dateAdditionWidgetItem", "title" => 'Added On'   ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'wi', "display" => ':data'),
 array( "id" => "dateUpdationWidgetItem", "title" => 'Update On'  ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'wi', "display" =>':data'), 

 array( "id" => "actions",  "title" => 'Actions' ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    )
);

$sql =	" select * from 
		".Config::_getTable('widget_items')." wi 
		left join ".Config::_getTable('spaces')." s on wi.idSpace = s.idSpace ";

$where = "wi.idWidget = :idWidget";

unset($arrayBind);
$arrayBind[] = array("key" => ":idWidget", "value" => $idWidget);

$listData = array( 
    "sql"           => $sql, 
    "where"         => $where,
    "arrayBind"     => $arrayBind,
    "sortby"        => "titleWidgetItem", 
    "order"         => "asc", 
    "headding"      => 'Widget Items of '.$Widgets->_getWidgetDetails($idWidget)->titleWidget, 
    "primaryField"  => "idWidgetItem", 
    "statusField"   => "statusWidgetItem", 
    //  Fields from here are same for all (in general)
    "noCreate"  	=> true, 
    "multiActions"  => true, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

$listData = Plugins::_runAction('list_widgets_options',$listData);

