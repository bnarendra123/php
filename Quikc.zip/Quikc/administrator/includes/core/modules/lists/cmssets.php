<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');


$actions = array("status","edit","delete");

$displayFields  = array( 
array( "id" => "idSet",         "title" => 'Set Id'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 's', "display" => ':data'),
array( "id" => "nameSet",       "title" => 'Set Name'  ,"type" => 'text'   ,"dbField" => true ,"tpx" => 's', "display" => ':data'), 
array( "id" => "linkSet",       "title" => 'Set Link'  ,"type" => 'text'   ,"dbField" => true ,"tpx" => 's', "display" => ':data'),
array( "id" => "statusSet",     "title" => 'Set Status',"type" => 'select' ,"dbField" => true ,"tpx" => 's', "display" => ':data',"set" => "status"),
array( "id" => "dateAdditionSet","title" => 'Created On',"type" => 'date'   ,"dbField" => true ,"tpx" => 's', "display" => ':data'),
array( "id" => "dateUpdationSet","title" => 'Update On' ,"type" => 'date'   ,"dbField" => true ,"tpx" => 's', "display" => ':data'), 
array( "id" => "actions",        "title" => 'Actions'      ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    )
);

$listData = array( 
    "sql"           => "select * from ".Config::_getTable('sets')." s ", 
    "where"         => "",
    "arrayBind"     => "",
    "sortby"        => "nameSet", 
    "order"         => "asc", 
    "headding"      => Config::_getMessage('lists.cms.sets.title'), 
    "primaryField"  => "idSet", 
    "statusField"   => "statusSet", 
    //  Fields from here are same for all (in general)
    "multiActions"  => true, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

$listData = Plugins::_runAction('list_cms_sets',$listData);

