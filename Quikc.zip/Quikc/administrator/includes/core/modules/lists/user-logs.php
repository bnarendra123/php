<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$idUser = $User -> idUser();

$displayFields	= array( 
 array( "id" => "idLog",	  "title" => 'Log No'	   ,"type" => 'text'    ,"dbField" => true ,"tpx" => 'al', "display" => ':data'),
 array( "id" => "timeLog",	  "title" => 'Time'	       ,"type" => 'date'    ,"dbField" => true ,"tpx" => 'al', "display" => ':data'),
 array( "id" => "titleOption","title" => 'Activity'    ,"type" => 'text'    ,"dbField" => true ,"tpx" => 'cso',"display" => ':data'),
 array( "id" => "ipaddressLog","title" => 'Ip address' ,"type" => 'text'    ,"dbField" => true ,"tpx" => 'al', "display" => ':data')
);

$listData = array( 
	"sql" 			=> " select *,REPLACE(cso.titleOption,':data',al.replaceData) as titleOption from ".Config::_getTable('user_log_activity')."  al, ".Config::_getTable('cms_sets_options')." cso, 
	                   ".Config::_getTable('cms_sets')." cs ",
	"where" 		=> "cs.linkSet = 'logactivity' and cso.keyOption = al.statusLog and cs.idSet = cso.idSet and al.idUser = '".$idUser."' ", 
//	"arrayBind" 	=> "",
	"sortby" 		=> "timeLog", 
	"order" 		=> "desc", 
	"headding" 		=> Config::_getMessage('lists.superadministrator.alogactivity.title'), 
	"primaryField" 	=> "idLog", 
	"statusField" 	=> "statusLog",
	"noCreate"      => true,
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> 1, 
	"perpage" 		=> 50, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__) 
);

$listData = Plugins::_runAction('list_user_log_activity_user',$listData);

