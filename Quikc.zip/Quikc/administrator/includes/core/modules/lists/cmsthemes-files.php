<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$Themes->_updateFiles();

$actions = array("edit");

$displayFields  = array( 
 array( "id" => "idFile",             "title" => 'File Id'      ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'tf', "display" => ':data'),
 array( "id" => "nameFile",           "title" => 'File Name'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'tf', "display" => ':data'), 
 array( "id" => "pathFile",           "title" => 'File Path'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'tf', "display" => ':data'), 
 array( "id" => "typeFile",           "title" => 'File Type'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'tf', "display" => ':data'),
  
 array( "id" => "actions",      	  "title" => 'Actions'      ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    )
);

$whereQuery .= ' and tf.idTheme = :idTheme ';
$arrayBind[] = array('key' => ":idTheme", 'value' => $Themes->_getDevelopingTheme()->idTheme);

$listData = array( 
    "sql"           => "select * from ".Config::_getTable('cms_themes_files')." tf ", 
    "where"         => $whereQuery,
    "arrayBind"     => $arrayBind,
    "sortby"        => "nameFile", 
    "order"         => "asc", 
    "headding"      => $Themes->_getDevelopingTheme()->nameTheme. " Theme Files ", 
    "primaryField"  => "idFile",
    //  Fields from here are same for all (in general)
    "noCreate"  	=> true, 
    "multiActions"  => true, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1,
    "perpage"       => 10,
    "displaypages"  => 10,
    "filename"      => $Base->_getFileName($permissionsPage)
);

$listData = Plugins::_runAction('list_cms_files',$listData);

