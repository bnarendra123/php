<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$actions = array("status","edit","copy","delete");

$itemsMenu = '<a href="javascript:manageMenuItems(\':data\');">Manage Menu Items</a>';

$displayFields	= array( 
 array( "id" => "idMenu",			"title" => 'Menu Id'	 		,"type" => 'text'    ,"dbField" => true ,"tpx" => 'm', "display" => ':data'),
 array( "id" => "titleMenu",		"title" => 'Menu Title'	 		,"type" => 'text'    ,"dbField" => true ,"tpx" => 'm', "display" => ':data'),
 array( "id" => "classMenu",		"title" => 'Menu Class'	 		,"type" => 'text'    ,"dbField" => true ,"tpx" => 'm', "display" => ':data'),
 array( "id" => "descriptionMenu",	"title" => 'Menu Description'	,"type" => 'longtext',"dbField" => true ,"tpx" => 'm', "display" => ':data'), 
 array( "id" => "statusMenu", 		"title" => 'Menu Status'  		,"type" => 'select'  ,"dbField" => true ,"tpx" => 'm', "display" => ':data', 'set' => 'status'),

 array( "id" => "dateAdditionMenu","title" => 'Created On'	 		,"type" => 'date'   ,"dbField" => true ,"tpx" => 'm', "display" => ':data'),
 array( "id" => "dateUpdationMenu","title" => 'Updated On'	 		,"type" => 'date'   ,"dbField" => true ,"tpx" => 'm', "display" => ':data'),

 array( "id" =>"idMenu", "title" => 'Menus'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => '', "display" => $itemsMenu),

 array( "id" => "actions","title" => 'Actions'		 ,"type" => 'actions',"dbField" => false,"tpx" => ''  , "display" => '',"set" => $actions	)
);

$listData = array( 
	"sql" 			=> " select * from ".Config::_getTable('menus')." m ",
	"where" 		=> "", 
	"arrayBind" 	=> "",
	"sortby" 		=> "titleMenu", 
	"order" 		=> "asc", 
	"headding" 		=> 'Menus', 
	"primaryField" 	=> "idMenu", 
	"statusField" 	=> "statusMenu",
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__) 
);

$listData = Plugins::_runAction('list_menu',$listData);


