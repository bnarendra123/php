<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$actions = array("status","edit","copy");

if( $Admin->_isSuperUser() ){

	$actions[] = array('display' => '<a href="javascript:generateEditor(\'get/edit/permissions\',\'form_idList_primaryField\',\'edit\',\'primaryField\')">
						<img src="'.Config::_getUrl('admin.temp').'/images/permissions.gif" width="16" height="16" alt="permissions" title="permissions" />
					</a>', 'permissions' => 'view' );

}

$actions[] = "delete";

$displayFields	= array( 
 array( "id" => "idGroup"				,"title" => 'Moderator Id'		,"type" => 'text'   	,"dbField" => true ,"tpx" => 'ug', "display" => ':data'),
 array( "id" => "nameGroup"				,"title" => 'Moderator Name'	,"type" => 'text'   	,"dbField" => true ,"tpx" => 'ug', "display" => ':data'),
 array( "id" => "statusGroup"			,"title" => 'Status'			,"type" => 'select' 	,"dbField" => true ,"tpx" => 'ug', "display" => ':data', "set" => "status"), 
 array( "id" => "dateAdditionGroup"		,"title" => 'Created On'	 	,"type" => 'date'   	,"dbField" => true ,"tpx" => 'ug', "display" => ':data'),
 array( "id" => "dateUpdationGroup"		,"title" => 'Updated On'	 	,"type" => 'date'   	,"dbField" => true ,"tpx" => 'ug', "display" => ':data'),
 array( "id" => "actions"				,"title" => 'Actions' 			,"type" => 'actions'	,"dbField" => false,"tpx" => ''  , "display" => ''		,"set" => $actions	)
);

$listData = array( 
	"sql" 			=> " select * from ".Config::_getTable('user_groups')." ug ",
//	"where" 		=> "", 
//	"arrayBind" 	=> "",
	"sortby" 		=> "nameGroup", 
	"order" 		=> "asc", 
	"headding" 		=> "Moderators", 
	"primaryField" 	=> "idGroup", 
	"statusField" 	=> "statusGroup",
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__) 
);

$listData = Plugins::_runAction('list_user_groups',$listData);

