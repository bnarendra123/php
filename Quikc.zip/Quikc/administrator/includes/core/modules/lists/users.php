<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');


$actions = array("status","edit","copy","delete");

$displayFields	= array( 
 array( "id" =>"idUser",		"title" => 'User Id'		,"type" =>	'text'   ,"dbField" => true ,"tpx" => 'u', "display" => ':data',"show" =>	false),
 array( "id" =>"nameFirstUser",	"title" => 'First Name'	 	,"type" =>	'text'   ,"dbField" => true ,"tpx" => 'u', "display" => ':data'), 
 array( "id" =>"nameLastUser",  "title" => 'Last Name'	 	,"type" =>	'text'   ,"dbField" => true ,"tpx" => 'u', "display" => ':data'), 
 array( "id" =>"emailUser",		"title" => 'Email' 	 	 	,"type" =>	'text'   ,"dbField" => true ,"tpx" => 'u', "display" => ':data'),
 array( "id" =>"imageUser", 	"title" => 'Profile Picture',"type"	=>	'image'	 ,"dbField" => true ,"tpx" => 'u', "display"=>'<img src=":data" width="50"/>'), 
 array( "id" =>"countryUser",   "title" => 'Country'		,"type" =>	'select' ,"dbField" => true ,"tpx" => 'u', "display" => ':data',"set" => "countries"), 
 array( "id" =>"timezoneUser",  "title" => 'Time Zone'     	,"type" =>	'select' ,"dbField" => true ,"tpx" => 'u', "display" => ':data',"set" => "timezones", "show" =>	false ), 
 array( "id" =>"genderUser",	"title" => 'Gender'		 	,"type" =>	'select' ,"dbField" => true ,"tpx" => 'u', "display" => ':data',"set" => "gender"),
 array( "id" =>"adminUser",		"title" => 'Admin User'		,"type" =>	'select' ,"dbField" => true ,"tpx" => 'u', "display" => ':data',"set" => "yesno" ,"show" =>	false ),
 array( "id" =>"superUser",		"title" => 'Super User'		,"type" =>	'select' ,"dbField" => true ,"tpx" => 'u', "display" => ':data',"set" => "yesno" ,"show" =>	false ),
 array( "id" =>"dateAdditionUser","title" => 'Created On'	,"type"	=>	'date'   ,"dbField" => true ,"tpx" => 'u', "display" => ':data' ,"show" =>	false ),
 array( "id" =>"dateUpdationUser","title" => 'Updated On'	,"type"	=>	'date'   ,"dbField" => true ,"tpx" => 'u', "display" => ':data' ,"show" =>	false ), 
 array( "id" =>"actions",		"title" => 'Actions'		,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions	)
);

$where = "";

if( !User::_userDetails() -> superUser ){
    $where = 'u.superUser != 1';
}


$listData = array(
	"sql" 			=> "select * from ".Config::_getTable('users')." u ", 
	"where" 		=> $where,
	"arrayBind" 	=> "",
	"sortby" 		=> "nameFirstUser", 
	"order" 		=> "asc", 
	"headding" 		=> "Users", 
	"primaryField" 	=> "idUser", 
	"statusField" 	=> "statusUser", 
//  Fields from here are same for all (in general)
  	"multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields,																																														
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__)
);

$listData = Plugins::_runAction('list_users',$listData);


