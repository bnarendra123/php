<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$Themes->_updateThemes();

$actions = array("status","edit");

$actions[] = array('display' => '<a href="javascript:copyTheme(\'primaryField\')">
					<img src="'.Config::_getUrl('admin.temp').'/images/copy.png" width="16" height="16" alt="Copy Theme" title="Copy Theme" />
				</a>', 'permissions' => 'create' );

$actions[]= "delete";

$displayFields  = array( 
array( "id" => "idTheme",           "title" => 'Theme Id'      ,"type" => 'text'   ,"dbField" => true ,"tpx" => 't', "display" => ':data'),
array( "id" => "nameTheme",         "title" => 'Theme Name'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 't', "display" => ':data'), 
array( "id" => "pathTheme",         "title" => 'Theme Path '   ,"type" => 'text'   ,"dbField" => true ,"tpx" => 't', "display" => ':data'), 
array( "id" => "statusTheme",       "title" => 'Active Theme'  ,"type" => 'select' ,"dbField" => true ,"tpx" => 't', "display" => ':data',"set" => "yesno"),
array( "id" => "dateAdditionTheme", "title" => 'Created On'  ,"type" => 'text'   ,"dbField" => true ,"tpx" => 't', "display" =>':data'),
array( "id" => "dateUpdationTheme", "title" => 'Updated On'  ,"type" => 'text'   ,"dbField" => true ,"tpx" => 't', "display" =>':data'), 
array( "id" => "actions",           "title" => 'Actions'       ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    ),
);

$listData = array( 
    "sql"           => "select * from ".Config::_getTable('themes')." t ", 
    "where"         => "",
    "arrayBind"     => "",
    "sortby"        => "nameTheme", 
    "order"         => "asc", 
    "headding"      => Config::_getMessage('lists.cms.themes.title'), 
    "primaryField"  => "idTheme", 
    "statusField"   => "statusTheme", 
    //  Fields from here are same for all (in general)
    "multiActions"  => false, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

$listData = Plugins::_runAction('list_cms_themes',$listData);

