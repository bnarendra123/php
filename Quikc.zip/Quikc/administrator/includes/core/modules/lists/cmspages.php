<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$viewPage = '<a href="'.$Themes->_url(':data').'" target="_blank">View Page</a>';

$actions[] = array('display' => '<a href="javascript:LoadList_'.$Lists->_getListId().'(\'\',\'\',\'\',{\'idParentPage\':\'primaryField\'})">
                    <img src="'.Config::_getUrl('admin.temp').'/images/arrow-curve-000-left.gif" width="16" height="16" alt="View" title="View" />
                </a>', 'permissions' => 'view' );

$actions = array_merge($actions,array("status","edit","delete"));

$idParentPage= 0;

extract($_POST);

if( isset($params->idParentPage) ){
    $idParentPage = $params->idParentPage;
}

$themesSet = array_merge(array('' => 'No Theme','global' => 'Use Active Theme'),$Base->_generateSelect('themes'));

$typesPageSet = array('themes' => 'From Themes', 'plugins' => 'From Plugins');

$listPlugins = $Plugins->_getActivePlugins();
$setPlugins = array($listPlugins,'identifierPlugin','namePlugin');

$displayFields[] = array( "id" => "idPage",            "title" => 'Page Id'         ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'p', "display" => ':data');
$displayFields[] = array( "id" => "namePage",          "title" => 'Page Name'       ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'p', "display" => ':data');
$displayFields[] = array( "id" => "idParentPage",  	    "title" => 'Parent Page'     ,"type" => 'select',"dbField" => true ,"tpx" => 'p', "display" => ':data',"set" => "pages"); 
$displayFields[] = array( "id" => "linkPage",          "title" => 'Page Link'       ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'p', "display" => ':data');
$displayFields[] = array( "id" => "defaultPage",       "title" => 'Default Page'    ,"type" => 'select' ,"dbField" => true ,"tpx" => 'p', "display" => ':data',"set" => "yesno"); 
$displayFields[] = array( "id" => "requireLogin",      "title" => 'Require Login'   ,"type" => 'select' ,"dbField" => true ,"tpx" => 'p', "display" => ':data',"set" => "yesno"); 
$displayFields[] = array( "id" => "typePage",          "title" => 'Page Type'       ,"type" => 'select' ,"dbField" => true ,"tpx" => 'p', "display" => ':data',"set" => $typesPageSet); 
$displayFields[] = array( "id" => "themePage",         "title" => 'Page Theme'      ,"type" => 'select' ,"dbField" => true ,"tpx" => 'p', "display" => ':data',"set" => $themesSet);
$displayFields[] = array( "id" => "pluginPage",        "title" => 'Page Plugin'     ,"type" => 'select' ,"dbField" => true ,"tpx" => 'p', "display" => ':data',"set" => $setPlugins); 
$displayFields[] = array( "id" => "templatePage",      "title" => 'Page Template'	 ,"type" => 'text' 	 ,"dbField" => true ,"tpx" => 'p', "display" => ':data');
$displayFields[] = array( "id" => "dateAdditionPage",  "title" => 'Created On'      ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'p', "display" => ':data');
$displayFields[] = array( "id" => "dateUpdationPage",  "title" => 'Update On'       ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'p', "display" =>':data');
$displayFields[] = array( "id" => "fullLinkPage",          "title" => 'View Page'       ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'p', "display" => $viewPage); 
$displayFields[] = array( "id" => "actions",           "title" => 'Actions'         ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    );

$arrayBind = array();
$where = "p.idParentPage= :idParentPage";
$arrayBind[] = array( 'key' => ':idParentPage' , 'value' => $idParentPage);

function _headdingCategory($idPage){
    
    global $Lists;
    
    if($idPage == 0 ){
        
        $headingList = '<a href="javascript:LoadList_'.$Lists->_getListId().'(\'\',\'\',\'\',{\'idParentPage\':\'0\'})">Home</a>';

    }else{

        $query = "select * from cms_pages where idPage= :idPage";
        $arrayBind[] = array("key" => ":idPage", "value" => $idPage);
        
        $detailsPages = Core::_getRow($query,$arrayBind);
        
        $headingList = _headdingCategory($detailsPages->idParentPage) .' >> <a href="javascript:LoadList_'.$Lists->_getListId().'(\'\',\'\',\'\',{\'idParentPage\':\''.$idPage.'\'})">'.$detailsPages ->namePage.'</a>';
    }

    return $headingList;    
}

$headingList = _headdingCategory($idParentPage) . ' Pages';


$listData = array( 
    "sql"           => "select * from ".Config::_getTable('pages')." p ", 
    "where"         => $where,
    "arrayBind"     => $arrayBind,
    "sortby"        => "namePage", 
    "order"         => "asc", 
    "headding"      => $headingList, 
    "primaryField"  => "idPage", 
    "statusField"   => "statusPage",
    "params"        => "{'idParentPage':$idParentPage}", 
    //  Fields from here are same for all (in general)
    "multiActions"  => true,
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

$listData = Plugins::_runAction('list_cms_pages',$listData);


