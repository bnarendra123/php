<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$actions = array("status","edit","copy","delete");

$query      = "select * from ".Config::_getTable('admin_menus')." order by `titleMenu` asc";
$listMenus  = Core::_getAllRows($query, '');
$set = array($listMenus,"idMenu","titleMenu");

$displayFields	= array( 
 array( "id" => "idMenu",		"title" => 'Menu Id'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'am', "display" => ':data', "show" =>	false),
 array( "id" => "titleMenu",	"title" => 'Menu Title'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'am', "display" => ':data'),
 array( "id" => "linkMenu",		"title" => 'Menu Link'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'am', "display" => ':data'), 
 array( "id" => "parentMenu",   "title" => 'Parent Menu' ,"type" => 'select' ,"dbField" => true ,"tpx" => 'am',  "display" => ':data', 'set' => $set), 
 array( "id" => "imageMenu", 	"title" => 'Menu IMage'  ,"type" => 'image'  ,"dbField" => true ,"tpx" => 'am', "display" =>'<img src=":data" style="max-width:50px;max-height:50px;"/>'),
 array( "id" => "orderMenu",	"title" => 'Menu Order'	 ,"type" => 'text'	 ,"dbField" => true ,"tpx" => 'am', "display" => ':data', "show" =>	false), 
 array( "id" => "systemItem",   "title" => 'System Menu'   ,"type" => 'select' ,"dbField" => true ,"tpx" => 'am', "display" => ':data',"set" => "yesno", "show" =>	false),
 array( "id" => "dashboardMenu","title" => 'Dashboard Menu',"type" => 'select' ,"dbField" => true ,"tpx" => 'am', "display" => ':data',"set" => "yesno"),
 array( "id" => "topMenu",		"title" => 'Top Menu'	 ,"type" => 'select' ,"dbField" => true ,"tpx" => 'am', "display" => ':data',"set" => "yesno"),
 array( "id" => "showSubMenus",	"title" => 'Sub Menus'	 ,"type" => 'select' ,"dbField" => true ,"tpx" => 'am', "display" => ':data',"set" => "yesno", "show" =>	false),
 array( "id" => "createdBy",	"title" => 'Created By'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => '', "display" => ':data'),

 array( "id" => "dateAdditionAdminMenu","title" => 'Created On'	 ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'am', "display" => ':data', "show" =>	false),
 array( "id" => "dateUpdationAdminMenu","title" => 'Updated On'	 ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'am', "display" => ':data', "show" =>	false),
 array( "id" => "actions","title" => 'Actions'		 ,"type" => 'actions',"dbField" => false,"tpx" => ''  , "display" => '',"set" => $actions	)
);

$listData = array( 
	"sql" 			=> " select *,if(am.createdByType = 'user', concat(u.nameFirstUser,' ',u.nameLastUser,'(user)'), concat(p.namePlugin,'(plugin)') ) as createdBy from 
						".Config::_getTable('admin_menus')." am left join ".Config::_getTable('users')." u on am.createdById = u.idUser left join ".Config::_getTable('plugins')." p on am.createdById = p.identifierPlugin",
//	"where" 		=> "", 
//	"arrayBind" 	=> "",
	"sortby" 		=> "titleMenu", 
	"order" 		=> "asc", 
	"headding" 		=> Config::_getMessage('lists.superadministrator.amenus.title'), 
	"primaryField" 	=> "idMenu", 
	"statusField" 	=> "statusMenu",
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__) 
);

$listData = Plugins::_runAction('list_admin_menu',$listData);


