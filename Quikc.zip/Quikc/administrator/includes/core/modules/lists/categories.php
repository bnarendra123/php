<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

//<img src="'.Config::_getUrl('admin.temp').'/images/arrow-curve-000-left.gif" width="16" height="16" alt="View" title="View" />

$actions[] = array('display' => '<a href="javascript:LoadList_'.$Lists->_getListId().'(\'\',\'\',\'\',{\'idParentCategory\':\'primaryField\'})">
                    View Sub Categories
                </a>', 'permissions' => 'view' );

$actions = array_merge($actions,array("status","edit","delete"));

$idParentCategory = 0;

extract($_POST);

if( isset($params->idParentCategory) ){
    $idParentCategory = $params->idParentCategory;
}

$displayFields[] =  array( "id" => "idCategory"		    ,"title" => "Id Category"		,"type" => "text"		,"dbField" => true		,"tpx" => "c"		,"display" => ":data"		,"set" => ""		,"show" => true);
$displayFields[] =  array( "id" => "nameCategory"		,"title" => "Name Category"		,"type" => "text"		,"dbField" => true		,"tpx" => "c"		,"display" => ":data"		,"set" => ""		,"show" => true);
$displayFields[] = 	array( "id" => "linkCategory"		,"title" => "Link Category"		,"type" => "text"		,"dbField" => true		,"tpx" => "c"		,"display" => ":data"		,"set" => ""		,"show" => true);

if( $idParentCategory != 0){
    $displayFields[] =  array( "id" => "idParentCategory"   ,"title" => "Parent Category","type" => "select"        ,"dbField" => true      ,"tpx" => "c"       ,"display" => ":data"       ,"set" => "categories"      ,"show" => true);
}

$displayFields[] = 	array( "id" => "imageCategory"				,"title" => "Image Category"	,"type" => "image"		,"dbField" => true		,"tpx" => "c"		,"display" => "<img src=\":data\" width=\"50\" />"		,"set" => ""		,"show" => true);
$displayFields[] = 	array( "id" => "statusCategory"				,"title" => "Status Category"	,"type" => "select"		,"dbField" => true		,"tpx" => "c"		,"display" => ":data"		,"set" => "status"		,"show" => true);
$displayFields[] = 	array( "id" => "dateAdditionCategory"		,"title" => "Date Addition"		,"type" => "date"		,"dbField" => true		,"tpx" => "c"		,"display" => ":data"		,"set" => ""		,"show" => true);
$displayFields[] = 	array( "id" => "dateUpdationCategory"		,"title" => "Date Updation"		,"type" => "date"		,"dbField" => true		,"tpx" => "c"		,"display" => ":data"		,"set" => ""		,"show" => true);
$displayFields[] = 	array( "id" => "actions"					,"title" => "Actions"			,"type" => "actions"		,"dbField" => false		,"tpx" => ""		,"display" => ""		,"set" => $actions);

$arrayBind = array();
$where = "c.idParentCategory = :idParentCategory ";
$arrayBind[] = array( 'key' => ':idParentCategory' , 'value' => $idParentCategory);

function _headdingCategory($idCategory){
    
    global $Lists;
    
    if($idCategory == 0 ){
        
        $headingList = '<a href="javascript:LoadList_'.$Lists->_getListId().'(\'\',\'\',\'\',{\'idParentCategory\':\'0\'})">Home</a>';

    }else{

        $query = "select * from categories where idCategory = :idCategory";
        $arrayBind[] = array("key" => ":idCategory", "value" => $idCategory);
        
        $detailsCategory = Core::_getRow($query,$arrayBind);
        
        $headingList = _headdingCategory($detailsCategory->idParentCategory) .' >> <a href="javascript:LoadList_'.$Lists->_getListId().'(\'\',\'\',\'\',{\'idParentCategory\':\''.$idCategory.'\'})">'.$detailsCategory->nameCategory.'</a>';
    }

    return $headingList;    
}

$headingList = _headdingCategory($idParentCategory) . ' Categories ';

$listData = array( 
	"sql" 			=> "select * from categories c",
	"where" 		=> $where, 
	"arrayBind" 	=> $arrayBind,
	"sortby" 		=> "nameCategory", 
	"order" 		=> "asc", 
	"headding" 		=> $headingList, 
	"primaryField" 	=> "idCategory", 
	"statusField" 	=> "statusCategory",
    "params"        => "{'idParentCategory':$idParentCategory}", 
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> "0", 
	"perpage" 		=> "0", 
	"displaypages" 	=> "0", 
	"filename" 		=> $Base->_getFileName(__FILE__), 
);
		
