<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');


$actions = array("status");

$manageSpace = '<a href="javascript:manageSpace(\':data\');">Manage Space</a>';

$displayFields  = array( 
 array( "id" => "idSpace",      "title" => 'Space Id'      ,"type" => 'text'   ,"dbField" => true ,"tpx" => 's', "display" => ':data'),
 array( "id" => "titleSpace",   "title" => 'Space Title'   ,"type" => 'text'   ,"dbField" => true ,"tpx" => 's', "display" => ':data'),
 array( "id" => "statusSpace", 	"title" => 'Space Status'  ,"type" => 'select' ,"dbField" => true ,"tpx" => 's', "display" => ':data',"set" => "status"),

 array( "id" => "globalSpace",	"title" => 'Global Space'  ,"type" => 'select' ,"dbField" => true ,"tpx" => 's', "display" => ':data',"set" => "yesno"),
 array( "id" => "namePage",     "title" => 'Created Page'  ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'p', "display" => ':data'),

 array( "id" => "systemItem",	"title" => 'System Item'   ,"type" => 'select' ,"dbField" => true ,"tpx" => 's', "display" => ':data',"set" => "yesno"),

 array( "id" => "dateAdditionSpace","title" => 'Added On'   ,"type" => 'date'   ,"dbField" => true ,"tpx" => 's', "display" => ':data'),
 array( "id" => "dateUpdationSpace","title" => 'Update On'  ,"type" => 'date'   ,"dbField" => true ,"tpx" => 's', "display" =>':data'), 

 array( "id" => "idSpace"	 ,"title" => 'Manage Space'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => '', "display" => $manageSpace),
 array( "id" => "actions"    ,"title" => 'Actions'       ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    )
);

$sql =	" select * from 
		".Config::_getTable('spaces')." s 
		left join ".Config::_getTable('pages')." p on s.idPage = p.idPage ";
	
$listData = array( 
    "sql"           => $sql, 
    "where"         => "",
    "arrayBind"     => "",
    "sortby"        => "titleSpace", 
    "order"         => "asc", 
    "headding"      => 'Spaces', 
    "primaryField"  => "idSpace", 
    "statusField"   => "statusSpace", 
    //  Fields from here are same for all (in general)
    "noCreate"  	=> true, 
    "multiActions"  => true, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

$listData = Plugins::_runAction('list_spaces',$listData);

