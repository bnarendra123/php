<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');


$actions = array("status","edit","delete");

$displayFields	= array( 
 array( "id" => "namePlugin",   	"title" => 'Name'	   ,"type" => 'text'  ,"dbField" => true ,"tpx" => 'p', "display" => ':data'), 
 array( "id" => "identifierPlugin", "title" => 'Identifier',"type" => 'text'  ,"dbField" => true ,"tpx" => 'p', "display" => ':data'), 

 array( "id" => "versionPlugin", "title" => 'Version'   ,"type" => 'text'  ,"dbField" => true ,"tpx" => 'p', "display" => ':data'),
 array( "id" => "authorPlugin",  "title" => 'Author'    ,"type" => 'text'  ,"dbField" => true ,"tpx" => 'p', "display" => ':data'),
 array( "id" => "urlPlugin",     "title" => 'Url'       ,"type" => 'text'  ,"dbField" => true ,"tpx" => 'p', "display" => '<a href=":data" target="_blank">:data</a>'),
 array( "id" => "autoLoadPlugin","title" => 'Auto Load ',"type" => 'select',"dbField" => true ,"tpx" => 'p', "display" => ':data' ,"set" => "yesno"),

 array( "id" => "statusPlugin",  			"title" => 'Plugin Status'  ,"type" => 'select',"dbField" => true ,"tpx" => 'p', "display" => ':data' ,"set" => "status"), 
 array( "id" => "dateAdditionPlugin",		"title" => 'Uploaded On'    ,"type" => 'date'  ,"dbField" => true ,"tpx" => 'p', "display" => ':data'), 
 array( "id" => "dateInstallationPlugin",	"title" =>'Installed On'	,"type" => 'date'  ,"dbField" => true ,"tpx" => 'p', "display" => ':data'), 
 array( "id" => "dateUpdationPlugin",		"title" => 'Modified On'	,"type" => 'date'  ,"dbField" => true ,"tpx" => 'p', "display" => ':data'),
 array( "id" => "actions",					"title" => 'Actions'		,"type" => 'actions',"dbField" => false,"tpx" => ''  , "display" => '',"set" => $actions	),
);

$listData = array( 
	"sql" 			=> " select * from ".Config::_getTable('plugins')." p ", 
	"where" 		=> "", 
	"arrayBind" 	=> "",
	"sortby" 		=> "namePlugin", 
	"order" 		=> "asc", 
	"headding" 		=> Config::_getMessage('lists.plugins.title'), 
	"primaryField" 	=> "idPlugin", 
	"statusField" 	=> "statusPlugin",
    "noCreate"      => true,
    //  Fields from here are same for all (in general)
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__) 
);

$listData = Plugins::_runAction('list_plugins',$listData);

