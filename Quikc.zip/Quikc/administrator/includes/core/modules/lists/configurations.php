<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');


$actions = array("status","edit","delete");

$displayFields	= array( 
array( "id" => "idConfig",		    "title" => 'Configuration Id'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'cf', "display" => ':data'),
array( "id" => "keyConfig",	        "title" => 'Configuration Key'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'cf', "display" => ':data'),
array( "id" => "valueConfig",       "title" => 'Configuration Value' ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'cf', "display" => ':data'), 
array( "id" => "dateUpdationConfig","title" => 'Last Modified On'	 ,"type" => 'date'	 ,"dbField" => true ,"tpx" => 'cf', "display" => ':data'	), 
array( "id" => "actions",            "title" => 'Actions'		     ,"type" => 'actions',"dbField" => false,"tpx" => ''  , "display" => '',"set" => $actions	)
);

$listData = array( 
	"sql" 			=> " select * from ".Config::_getTable('configuration')." cf",
//	"where" 		=> "", 
//	"arrayBind" 	=> "",
	"sortby" 		=> "keyConfig", 
	"order" 		=> "asc", 
	"headding" 		=> Config::_getMessage('lists.superadministrator.config.title'), 
	"primaryField" 	=> "idConfig", 
	"statusField" 	=> "statusConfig",
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> 1, 
	"perpage" 		=> 10, 
	"displaypages" 	=> 10, 
	"filename" 		=> $Base->_getFileName(__FILE__) 
);

$listData = Plugins::_runAction('list_configurations',$listData);


