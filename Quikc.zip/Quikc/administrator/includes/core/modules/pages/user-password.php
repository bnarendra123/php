<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

// Initiates this ajax load upon loading
$loadPage = "generateEditor('get/edit/user-password','user-password','edit',".$User -> idUser().")";

