<?php

die('Restricted Access');
?>