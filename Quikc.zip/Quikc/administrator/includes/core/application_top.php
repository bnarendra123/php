<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

define('_START_TIME', microtime(true));
define('_START_MEMO', memory_get_usage());

// Including the config classs
require dirname(dirname(dirname(dirname(__FILE__)))) . '/includes/core/classes/config.php';

// Creating the instance for the config class
$Config = new Config;
// calling init to generate the base dir and base url paths
$Config -> init();

require Config::_getDir() . '/includes/core/classes/core.php';

// Now including config file, to configure all default config variables
if( file_exists(Config::_getDir() . '/includes/custom/lib/config.php') ) {

	// including config file from custom folder	
	require Config::_getDir() . '/includes/custom/lib/config.php';

}else{

	// Config file missing
	// going through the installer once again
	require Config::_getDir() . '/includes/core/classes/installer.php';

	$Installer = new Installer;
	$Installer->_runProcess();

}

// Loading the configuration values like developer mode, cache status etc
$Config -> _loadBasicConfigs();

// Updating the admin directory
Config::_set('admin', '/' . basename(dirname(dirname(dirname(__FILE__)))));

require Config::_getDir() . '/includes/core/lib/sessions.php';
require Config::_getDir() . '/includes/core/lib/database_tables.php';
require Config::_getDir() . '/includes/core/classes/validate.php';
require Config::_getDir() . '/includes/core/classes/user.php';

$Validate = new Validate;
$User = new User;

require Config::_getDir('admin') . '/includes/core/lib/database_tables.php';
require Config::_getDir('admin') . '/includes/core/classes/admin.php';
require Config::_getDir('admin') . '/includes/core/classes/permissions.php';

$Admin = new Admin;
$Permissions = new Permissions;

require Config::_getDir() . '/includes/core/classes/plugins.php';
$Plugins = new Plugins;

require Config::_getDir() . '/includes/core/classes/base.php';
$Base = new Base;

require Config::_getDir() . '/includes/core/classes/cache.php';

$Config -> _setSystem();

require Config::_getDir() . '/includes/core/lib/authenticate.php';

$Config -> _setLogs();

require Config::_getDir() . '/includes/core/classes/themes.php';
$Themes = new Themes;

if (isset($_GET['page']) && $_GET['page'] != '')
	$Page = $_GET['page'];
else
	$Page = '1';

if (!$Admin -> _isLogged() && defined('QC_LOGGED')) {

	$Base -> _pageRedirect(Config::_getUrl('admin') . "/index.php?page=" . $Page);

} else if ($Admin -> _isLogged() && defined('QC_NOTLOGGED')) {

	$Base -> _pageRedirect(Config::_getUrl('admin') . "/home.php");

}

require Config::_getDir('admin') . '/includes/core/classes/forms.php';
require Config::_getDir('admin') . '/includes/core/classes/lists.php';

$Forms = new Forms;
$Lists = new Lists;

require Config::_getDir() . '/includes/core/classes/mail.php';
require Config::_getDir() . '/includes/core/classes/cms.php';
require Config::_getDir() . '/includes/core/classes/menus.php';
require Config::_getDir() . '/includes/core/classes/languages.php';
require Config::_getDir() . '/includes/core/classes/relations.php';

$Cms = new Cms;
$Menus = new Menus;
$Languages = new Languages;
$Relations = new Relations;

require Config::_getDir() . '/includes/core/classes/editor.php';
$Editor = new Editor;

require Config::_getDir() . '/includes/core/classes/spaces.php';
require Config::_getDir() . '/includes/core/classes/widgets.php';
$Widgets = new Widgets;

require Config::_getDir() . '/includes/core/classes/ajax.php';
$Ajax = new Ajax;

require Config::_getDir() . '/includes/core/classes/searchme.php';
$SearchMe = new SearchMe;

$Plugins -> _loadAutoLoadPlugins();

if (isset($_GET['action'])){

    $Action = $_GET['action'];
    
}else{

    $Action = '';
    
}

$Menus -> _verifyPageNo($Page);
$Menus -> _setCurrentAdminMenu($Page);
$Themes->_setCurrentAdminPage($Menus -> _getCurrentAdminMenu() -> linkMenu);

// Check current instance access
//$Config -> _checkAccess();

if (file_exists(Config::_getDir('admin') . '/includes/custom/application_top.php')) {

	include_once Config::_getDir('admin') . '/includes/custom/application_top.php';

}
