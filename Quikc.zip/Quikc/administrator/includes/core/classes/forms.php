<?php

defined('QC_VALID') or die('Restricted Access!');

/**
* Forms class, used for generating forms( especially for the backend )
* This includes generating, php validating, javascript validating, submission of forms 
*
* @version 1.0
* @http://www.quikc.org/
*/

class Forms{

    /**
    * Id used to identify the form and form element
    *
    * @var string
    */
 	private $formId;

    /**
    * Complete list of form elements passed
    *
    * @var array of string
    */
 	private $formElements;

    /**
    * Primay field of a form. In general this will be the id like Menu Id, User Id etc
    *
    * @var string
    */
 	private $formPrimaryField;
 
    /** Constructur, performs default actions for the forms class like generating the Form id etc
    * 
    *
    * @param void
    * @var null
    */
    public function __construct(){

        $this->_setFormId();

    }

    /**
    * Creates or updates the $formId
    *
    * @param void
    * @return null
    */
    private function _setFormId(){

    	global $Base;
		// Generating a random string of length 4 and setting as form Id	
		$this->formId = $Base->_generateRandomString(4);

	}

    /**
    * Return the $formId
    *
    * @param void
    * @return string
    */
    public function _getFormId(){	

		return $this->formId;

	}
	
    /**
    * Updates the $formElements variable
    *
    * @param $formElements(array)
    * @return null
    */
    private function _setFormElements($formElements){	

		$this->formElements = $formElements;

	}

    /**
    * Returns $formElements
    *
    * @param void
    * @return array
    */
    private function _getFormElements(){

		return $this->formElements;

	}

    /**
    * Appends $formId to all fields in the form. And also updates form field values with the array values passed
    *
    * @param $detailsForm(array)
    * @return null
    */
    private function _updateFieldIds($detailsForm){
	
		$formId = $this->_getFormId();
		$formElements = $this->_getFormElements();
		
		foreach($formElements['fields'] as $key => $value){

			// Updating the value of the field with same field value from $detailsForm
			if(isset($detailsForm->$value['id'])){

                $formElements['fields'][$key]['value'] = $detailsForm->$value['id'];
                			    
			}

			// Appending the $formId to the field id 
			$formElements['fields'][$key]['id'] = $formElements['fields'][$key]['id'].'_'.$formId;

		}

		// Updating the modified $formElements
		$this->_setFormElements($formElements);

	}

    /**
    * Generates the form
    *
    * @param $formElements(array - Form Attribues from the forms pages), $detailsForm(array - values of form fields)
    * @return generated form(string)
    */
    public function _generateForm($formElements,$detailsForm){

		$hook = Plugins::_runAction('generate_form_start',array($formElements,$detailsForm)); 

		$formElements = $hook[0];
		$detailsForm  = $hook[1];
		
        if( !is_array($formElements) ){

        	return false;

        }

		$this->_setFormElements($formElements);

		// Updating form fields ids, and values
		$this->_updateFieldIds($detailsForm);

		// Updating $formElements
		$formElements = $this->_getFormElements();
		
		if(isset($detailsForm->$formElements['primaryFiled'])){

			// for edit form
			$this->formPrimaryField = $detailsForm->$formElements['primaryFiled'];

		}else{

			// for create form
			$this->formPrimaryField = -1;

		}
		
		$generatedForm = $hiddenFieldsForm = array();

		$generatedForm['form_id'] = $this->_getFormId();

		//if( $formElements['closeLink'] != '' )
		//$generatedForm['close_link'] = $formElements['closeLink'];
		
		$generatedForm['headding'] = $formElements['name'];

		// To generate the class of the rows
		$i = 1;
		foreach($formElements['fields'] as $value){

			// Creating function name with the field type
			$function = '_generate'.$value['type'].'Field';
			
			//Post Field Lable	
			if( isset($value['postFieldLable']) && $value['postFieldLable'] != '' ){

				$postFieldLable = $value['postFieldLable'];	

			}else{

				$postFieldLable = '';

			}
			
			// Creating row for the field
			$generatedForm['form_elements'][] = array( 
													'label' 	 => $value['label'].( ($value['req'])?"*":"" ),
													'field'		 => $this->$function($value),
													'post_field' => $postFieldLable,
													'type'		 => strtolower($value['type']),
												);
		}

		// HTML form generation completed
		
		// Appending the Javascript code to the generated form
		$generatedForm['form_js_elements'] = $this->_generateJavaScript();

		$generatedForm = Plugins::_runAction('generate_form_end',$generatedForm,$formElements,$detailsForm);
		
		ob_start();
		
		include_once Config::_getDir('admin.temp') .'/elements/forms.phtml';

		$generatedFormData = ob_get_clean();

		return $generatedFormData;

    }

	/*
	Fields Generation functions starts here
	<!-----------------------------------------------------------------------------------------------------------------------------------------
	*/

    /**
    * Returns Enter Submit Javascript
    *
    * @param void
    * @return Enter Submit Script(string)
    */
    
    public function _generateEnterSubmitScript(){

        $text = 'onkeypress="return Ajax_Submit(event,\'function_'.$this->_getFormId().'\');"';

        return $text;

    }

    /**
    * Generates Hidden Field
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */    
    public function _generateHiddenField($attributesField){

		$text = '<input type="hidden" name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" value="'.Validate::_prepareTextboxValue($attributesField['value']).'" '.$attributesField['additional'].' '.$this->_generateEnterSubmitScript().'/>';
		$text = Plugins::_runAction('generate_form_generate_hidden_field',$text,$attributesField);

		return $text;

	}

    /**
    * Generates Text Field
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */    
    public function _generateTextField($attributesField){

		$text = '<input type="text" name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" value="'.Validate::_prepareTextboxValue($attributesField['value']).'" '.$attributesField['additional'].' '.$this->_generateEnterSubmitScript().' placeholder="'.$attributesField['label'].'"/>';
		$text = Plugins::_runAction('generate_form_generate_text_field',$text,$attributesField);

		return $text;

	}

    /**
    * Generates Email Field
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateLabelField($attributesField){

        $email = '<span '.$attributesField['additional'].' id="'.$attributesField['id'].'" >'.$attributesField['value'].'" />';
		$email = Plugins::_runAction('generate_form_generate_label_field',$email,$attributesField);

        return $email;

    }

    /**
    * Generates Email Field
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateEmailField($attributesField){

        $email = '<input type="text" name="'.$attributesField['type'].'" id="'.$attributesField['id'].'" value="'.Validate::_prepareTextboxValue($attributesField['value']).'" '.$attributesField['additional'].' '.$this->_generateEnterSubmitScript().' placeholder="'.$attributesField['label'].'"/>';
		$email = Plugins::_runAction('generate_form_generate_email_field',$email,$attributesField);

        return $email;

    }

    /**
    * Generates Hidden Field
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */    
    public function _generateDateField($attributesField){

		$text = '<input type="text" name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" value="'.$attributesField['value'].'" '.$attributesField['additional'].' '.$this->_generateEnterSubmitScript().'/>';
		$text = Plugins::_runAction('generate_form_generate_date_field',$text,$attributesField);

		return $text;

	}

    /**
    * Generates Text Area
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateTextareaField($attributesField){

        $textarea = '<textarea name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" '.$attributesField['additional'].' >'.$attributesField['value'].'</textarea>';
		$textarea = Plugins::_runAction('generate_form_generate_textarea_field',$textarea,$attributesField);

        return $textarea;

    }

    /**
    * Generates Password Field
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generatePasswordField($attributesField){

		$password = '<input type="password" name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" value="" '.$attributesField['additional'].' '.$this->_generateEnterSubmitScript().'  placeholder="'.$attributesField['label'].'">';
		$password = Plugins::_runAction('generate_form_generate_password_field',$password,$attributesField);

		return $password;

	}

    /**
    * Generates Checkbox
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateCheckboxField($attributesField){

		$checked = ( $attributesField['value'] ) ? 'checked="checked"' : '';
		$checkbox = '<input type="checkbox" name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" '.$checked.' '.$attributesField['additional'].' >';
		$checkbox = Plugins::_runAction('generate_form_generate_checkbox_field',$checkbox,$attributesField);

		return $checkbox;

	}

    /**
    * Generates Select Box
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateSelectField($attributesField){

		global $Base;
        $listSelect = $Base->_generateSelect($attributesField['set']);
	
		// Starts generating select box
		$boxSelect = '<select name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" '.$attributesField['additional'].' >';

		// Adding Select option if the field is not required
		if(!$attributesField['req']){

            $boxSelect .= '<option value="" >Select</option>';
		    
		}

		// Generating the select box options
		if( isset($listSelect) && is_array($listSelect) && count($listSelect) ){

			foreach($listSelect as $key => $value){

				$selected = ($key == $attributesField['value'])?'selected="selected"' : '';		
				$boxSelect .= '<option value="'.$key.'" '.$selected.' >'.$value.'</option>';

			}

		}
        
		$boxSelect .= '</select>';
		
		$boxSelect = Plugins::_runAction('generate_form_generate_select_field',$boxSelect,$attributesField);
		// Select box generation completed
		
		return $boxSelect;

	}

    /**
    * Generates Select Box
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateSelectmultiField($attributesField){

		global $Base;
        $listSelect = $Base->_generateSelect($attributesField['set']);
	
		// Starts generating select box
		$boxSelect = '<select name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" '.$attributesField['additional'].' multiple>';
		
		if($attributesField['value'] == '' ){

			$attributesField['value'] = array();

		}

        if( !is_array($attributesField['value']) ){
            
            $attributesField['value'] = array($attributesField['value']);
            
        }
     
		// Generating the select box options
		if( isset($listSelect) && is_array($listSelect) && count($listSelect) ){

			foreach($listSelect as $key => $value){

				$selected = (in_array($key,$attributesField['value']))?'selected="selected"' : '';		
				$boxSelect .= '<option value="'.$key.'" '.$selected.' >'.$value.'</option>';

			}

		}

		$boxSelect .= '</select>';

		$boxSelect = Plugins::_runAction('generate_form_generate_selectmulti_field',$boxSelect,$attributesField);
		// Multi Select box generation completed
		
		return $boxSelect;

	}

    /**
    * Generates Button Field
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateButtonField($attributesField){

		$button = '';

		$formElements = $this->_getFormElements();

		$Permissions = new Permissions;

		if( $Permissions->_checkPagePermission($formElements['filename'],'edit') ){

			$button = '<input type="button" name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" value="'.$attributesField['value'].'"  
			'.$attributesField['additional'].' onclick="return function_'.$this->_getFormId().'();">';

		}else{

			$button = $Base->_convertError(array('Don\'t have enough permissions to perform this task.'),true);

		}

		$button = Plugins::_runAction('generate_form_generate_button_field',$button,$attributesField);
        
		return $button;

	}

    /**
    * Generates Media Field
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateMediaField($attributesField){

		// hidden variable used to store the id of the Media selected from the gallery
		$dataMedia = '<input type="hidden" name="'.$attributesField['id'].'" id="'.$attributesField['id'].'" value="'.$attributesField['value'].'" '.$attributesField['additional'].'>';

		if( is_array($attributesField['set']) ){

            $attributesField['set'] = implode(',',$attributesField['set']);
            		    
		}
        
		$dataMedia .= '<input type="hidden" name="'.$attributesField['id'].'_allowed_types" id="'.$attributesField['id'].'_allowed_types" value="'.$attributesField['set'].'">';

		global $Base;
		if($attributesField['value'] == ''){

			// No Media present. Select image
			$lable = '<img src="'.$Base->_displayPhpthumb('',50,50).'" id="'.$attributesField['id'].'_media" width="50" height="50" title="'.basename($Base->_displayPhpthumb('',50,50)).'"/> Select File';

		}else{

			// No Image present. Change image
			$lable = '<img src="'.$Base->_displayPhpthumb($attributesField['value'],50,50).'" id="'.$attributesField['id'].'_media" width="50" height="50" title="'.basename($Base->_displayPhpthumb('',50,50)).'"/> 
			Change File';
			
		}
		
		$link = Plugins::_runAction('media',$attributesField['id'],$lable);
		
		if($link == ''){

            $link = 'No Media Plugins Loaded!';
		    
		}else{

            $link .= '&nbsp;&nbsp;<a href="javascript:clearImage(\''.$attributesField['id'].'\');">Clear File</a>'; 
		    
		}

		$dataMedia .= $link;
		
		$dataMedia = Plugins::_runAction('generate_form_generate_media_field',$dataMedia,$attributesField);

		return $dataMedia;

	}

	/*
	Fields Generation functions ends here
	-----------------------------------------------------------------------------------------------------------------------------------------!>
	*/


    /**
    * Generates Error Message
    *
    * @param $attributesField(array - Field Attribues)
    * @return generated field(string)
    */
    public function _generateErrorMessage($attributesField){	

		if(strtolower($attributesField['type']) == 'email'){

            $error = Config::_prepareMessage('forms.validation.invalid.email',array(":FIELD_NAME" => $attributesField['label']) );

		}elseif(strtolower($attributesField['type']) == 'date'){

            $error = Config::_prepareMessage('forms.validation.invalid.date',array(":FIELD_NAME" => $attributesField['label']) );

		}else{

            $error = Config::_prepareMessage('forms.validation.empty.field',array(":FIELD_NAME" => $attributesField['label']) );

		}	

		$error = Plugins::_runAction('generate_form_generate_error_message',$error,$attributesField);

		return $error;	

	}

    /**
    * Generates Javascript for the forms. This code handles javascript validations, form submissions.
    *
    * @param void
    * @return generated javascript code(string)
    */
    public function _generateJavaScript(){

		// Loading all the form elements	
		$formElements = $this->_getFormElements();

		$formElements = Plugins::_runAction('generate_form_generate_js_start',$formElements);
		
		$passedData   = array();
		
		$Permissions = new Permissions;
		
		if( !$Permissions->_checkPagePermission($formElements['filename'],'edit') ){

			return false;

		}

		// Function starts on create / update  
		$js  = '
                var formPrimaryField_'.$this->_getFormId().' = '.$this->formPrimaryField.';
		        document.getElementById("'.$formElements['fields'][0]['id'].'").focus();
				function function_'.$this->_getFormId().'(){ ';

		// Clears the previous messages		
		$js  .= '	

        	        var formId 			 = "'.$this->_getFormId().'";
				
					message_reporting("message_'.$this->_getFormId().'","",0);
					var errors = new Array;
				    var pass_data = {};';
		
				$js = Plugins::_runAction('generate_form_generate_js_inside_function',$js,$formElements);
				
				foreach($formElements['fields'] as $field){
				
					// Identifying valid form fields 
					if(in_array(strtolower($field['type']),array("text","date","hidden","textarea","password","media","select","selectmulti","email","checkbox"))){
						// Gathers the field values 
						
						if( in_array(strtolower($field['type']),array("checkbox")) ){

							$js .= 'var '.$field['id'].' = document.getElementById("'.$field['id'].'").checked?1:""; ';

						}else if(in_array(strtolower($field['type']),array("email")) ){

                            $js .= 'var '.$field['id'].' = document.getElementById("'.$field['id'].'").value; ';
                        //}else if(in_array(strtolower($field['type']),array("textarea")) ){
                        //    $js .= 'var '.$field['id'].' = tinymce.EditorManager.get("'.$field['id'].'").getContent();';
                        
                        }else if( in_array(strtolower($field['type']),array("selectmulti")) ){

							$js .= 'var '.$field['id'].' = multiSelectBoxValue("'.$field['id'].'").join(",");';

						}else{

							$js .= 'var '.$field['id'].' = document.getElementById("'.$field['id'].'").value; ';
							
						}
						
						// Validates if the field is required
						if( $field["req"] ){

                            $js .= 'if( '.$field['id'].' == "" ) errors.push("'.$this->_generateErrorMessage($field).'");';

						    
						}

						// Validates email if there is any data in the field
						if( strtolower($field['type']) == "email" ){

	       					$js .= 'if( '.$field['id'].' != "" && ! /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test('.$field['id'].') ) errors.push("'.$this->_generateErrorMessage($field).' "+'.$field['id'].');';

						}

						// Preparing ajax passed data string
						$js  .= 'pass_data["'.$field['id'].'"] = '.$field['id'].';';

					}

				}

		// Javasciprt captured error and form processing		
		$js .= '	if( errors.length > 0 ){
						message_reporting("message_'.$this->_getFormId().'",Convert_Message(errors,2),4);
						return false;
					}
					var pass_url = "/ajax.php?action='.$formElements['url'].'";
					pass_data["do"]				  = "edit";
					pass_data["formId"] 		  = formId;
					pass_data["formPrimaryField"] = formPrimaryField_'.$this->_getFormId().';
					pass_data["formIdentifier"]   = "'.$formElements["identifier"].'";

					$.ajax({
						type        : "POST",
						beforeSend	: loadingStarts,
						url         : adminUrl+pass_url,
						data        : pass_data,
						success     : function(responseText){
										loadingEnds();
										if(formPrimaryField_'.$this->_getFormId().' == -1 ){
										    if( responseText.indexOf("_ID_SPLITTER_") !== -1 ){
										        var responseArray = responseText.split("_ID_SPLITTER_");
                                                
                                                if( responseArray[0] == "ok" ){
                                                    formPrimaryField_'.$this->_getFormId().' = responseArray[1];
                                                    '.str_replace(':FORM_ID',$this->_getFormId(),$formElements['success']).'
                                                }else{
                                                    message_reporting("message_'.$this->_getFormId().'",responseText,4);
                                                }
                                            }else if(responseText == "ok"){
                                                '.str_replace(':FORM_ID',$this->_getFormId(),$formElements['success']).'
                                            }else if(responseText == "reload"){
												pageReload();
											}else{
                                                message_reporting("message_'.$this->_getFormId().'",responseText,4);
                                            }
                                        }else if( responseText == "ok" ){
											'.str_replace(':FORM_ID',$this->_getFormId(),$formElements['success']).'
										}else if(responseText == "reload"){
											pageReload();
										}else{
											message_reporting("message_'.$this->_getFormId().'",responseText,4);
										}
									}
					});
				} 		
			  ';

		foreach($formElements['fields'] as $field){

			if(in_array(strtolower($field['type']),array("date"))){

				$js .= 'datepicker("'.$field['id'].'");';

			}

		}
		  
		// Javascript code generation ends here
		$js = Plugins::_runAction('generate_form_generate_js_end',$js);
				
		return $js;

	}

    /**
    * Processes form after submission. This handles php validations
    *
    * @param Posted form fields(array)
    * @return $processedForm(array)
    */
    public function _processForm($forms,$formElements){
    	
		$hook = Plugins::_runAction('generate_form_process_form_start',array($forms,$formElements)); 

		$forms = $hook[0];
		$formElements  = $hook[1];		
				
    	// Removes the formId from all the form fields
		$processedForm['formElements']	= $this->_removeFieldIds($formElements);
		// Validates the form in php. This validation handles empty fields, email.
		$processedForm['error']			= $this->_validateForm($forms,$processedForm['formElements']);
		// Generates the list of fields for furthur processing
		$processedForm['fields']		= $this->_generateFields($forms);

		$processedForm = Plugins::_runAction('generate_form_process_form_end',$processedForm);
		
		return $processedForm;

	}	

    /**
    * Removes the form id from field keys
    *
    * @param Posted form fields(array)
    * @return $processedForm(array)
    */
    public function _removeFieldIds($formElements){

		$formId = "_".$formElements['formId'];
		$modifiedFormElements = array();
		
		foreach($formElements as $key => $fieldValue){

			// Checking for the formid in all the keys
			$pos = strrpos($key, $formId);

			if($pos !== false){

				// $key = substr_replace(Search In, Replace With, $pos, strlen(Seach For));
				$key = substr_replace($key, "", $pos, strlen($formId));

			}
			
			// pushing the value into another arry with modified key
			$modifiedFormElements[$key] = $fieldValue;

		}

		return $modifiedFormElements;

	}

    /**
    * Validates for posted form elements
    *
    * @param form elements(array), Posted form fields(array)
    * @return $processedForm(array)
    */
    public function _validateForm($formElements,$formElementsVales){
	
		$arrayValidation = $emailErrors = $passwordErrors = $dateErrors = array();

		foreach($formElements['fields'] as $key => $field){

			if($field["req"]){

				// Collecting the elements to be validated. array[id] = array(value entered,error message)
				$arrayValidation[$field['id']] = array($formElementsVales[$field['id']],$this->_generateErrorMessage($field) );

			}

			// Checking the validate attribute for the field validateions.
			if( !isset($field["validate"]) || $field["validate"] == true ){
				
				// Validating the email elements. array[id] = array(value entered,error message)
				if( strtolower($field["type"]) == 'email' && !Validate::_validateEmail($formElementsVales[$field['id']]) ){

					$emailErrors[] = $this->_generateErrorMessage($field);

				}
	
	            // Validating the password. array[id] = array(value entered,error message)
	            if($field["type"] == 'Password' && !Validate::_validatePassword($formElementsVales[$field['id']]) ){

	                $passwordErrors[] = Config::_getMessage('forms.settings.lists.validate.password');

	            }

				// Validating the date elements. array[id] = array(value entered,error message)
				if( strtolower($field["type"]) == 'date' && !Validate::_validateDate($formElementsVales[$field['id']]) ){

					$dateErrors[] = $this->_generateErrorMessage($field);

				}

			}

		}

		// Sending the collected elements for validation
		$error = Validate::_validateInput($arrayValidation);

		// Merging the errors with the email errors
		$error = array_merge($error,$emailErrors,$passwordErrors,$dateErrors);

		return $error;

	}

    /**
    * Generates an array with the list of form fields
    *
    * @param form data(array)
    * @return $formFields(array)
    */
    public function _generateFields($forms){

		$formFields = array();
		
		if( isset($forms['fields']) && is_array($forms['fields']) ){

			foreach($forms['fields'] as $field){

				if($field['id'] != ''){

                    $formFields[] = $field['id'];   
				    
				}

			}

		}
		
		return $formFields;

	}

    /* Fields display functions ends here
    -----------------------------------------------------------------------------------------------------------------------------------------!>
    */
    
    /**
    * Check weather the forms page with the given page exists or not
    *
    * @param  string(page)
    * @return boolean
    */
    public function _checkFormsPage($Page){

		$return = false;
		
		if(file_exists(Config::_getDir('admin').'/includes/core/modules/ajax/get/edit/'.$Page.'.php') || file_exists(Config::_getDir('admin').'/includes/custom/modules/ajax/get/edit/'.$Page.'.php')){

		  $return = true;

		}

		$return = Plugins::_runAction('check_forms_page',$return,$Page);
		
		return $return;

	}
        
}

