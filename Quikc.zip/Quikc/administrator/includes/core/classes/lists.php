<?php

defined('QC_VALID') or die('Restricted Access!');

/**
 * List class, used for generating lists
 * This includes handling generating, searching, sorting, page generation of lists
 *
 * @version 1.0
 * @http://www.quikc.org/
 */

class Lists {

    /**
    * Id used to identify the list and list elements
    *
    * @var string
    */
    private $idList;

    /**
     * Complete list of elements passed
     *
     * @var array of string
     */
    private $listElements;

    /**
     * Contains valid fosition fields
     * Used to declare the search query position
     *
     * @var array of string
     */
    private $positionFiltersArray = array("" => "Any Where", "start" => "Starts With", "end" => "Ends With", "exactly" => "Exactly");

    /**
     * Contains valid sorting order fields
     * Used to sort the results
     *
     * @var array of string
     */
    private $OrderFiltersArray = array("asc" => "Ascending", "desc" => "Descending");

    /**
     * Contains list of permissions
     * Used to generate the actions
     *
     * @var array of string
     */
    private $actionsPermissionsArray = array("view", "create", "edit", "delete");

    /**
     * Contains list of permissions generated
     *
     *
     * @var array of string
     */
    private $generatedPermissios;

    /** Constructur, performs default actions for the lists class like generating the List id etc
    * 
    *
    * @param void
    * @var null
    */
    public function __construct(){

        $this->_setListId();

    }

    /**
    * Creates or updates $idList
    *
    * @param void
    * @return null
    */
    private function _setListId(){

        global $Base;
        // Generating a random string of length 4 and setting as form Id    
        $this->idList = $Base->_generateRandomString(4);

    }

    /**
    * Return $idList
    *
    * @param void
    * @return string
    */
    public function _getListId(){
          
        return $this->idList;

    }

    /**
     * updates list default values like load id and page load etc
     *
     * @param void
     * @return null
     */
    private function _setDefaultFields() {

        if ( isset($_POST['idLoad']) ){

            $this->idLoad = $_POST['idLoad'];

        } 

        if ( isset($_POST['pageLoad']) ){

            $this->pageLoad = $_POST['pageLoad'];
                        
        } 

        $this->params = '';

        if ( isset($_POST['params']) ){

            $this->params = $_POST['params'];
                        
        } 

    }

    /**
     * updates the $listElements variable
     *
     * @param $listElements
     * @return null
     */
    private function _setListElements($listElements) {

        $this -> listElements = $listElements;

    }

    /**
     * returns the $listElements variable
     *
     * @param void
     * @return $listElements
     */
    private function _getListElements() {

        return $this -> listElements;

    }
    
    /**
     * Validates the input list elements and sets the default values for null values
     *
     * @param void
     * @return $listElements
     */
    private function _validateListElements() {

        $listElements = $this -> _getListElements();

        // Updating the default languages values. Applies for the multi language
        if (!isset($listElements['defaultLanguage']) || $listElements['defaultLanguage'] == '') {

            $listElements['defaultLanguage'] = Languages::_getdefaultLanguage();

        }

        $listElements['where']     = isset($listElements['where']) ? $listElements['where'] : '';
        $listElements['arrayBind'] = isset($listElements['arrayBind']) ? $listElements['arrayBind'] : '';
        $listElements['params']    = isset($listElements['params']) ? $listElements['params'] : false;

        $listElements['primaryField']   = isset($listElements['primaryField']) ? $listElements['primaryField'] : $listElements['displayFields'][0]['id'];
        $listElements['statusField']    = isset($listElements['statusField']) ? $listElements['statusField'] : '';
        $listElements['statusField']    = ($listElements['statusField'] != '') ? $listElements['statusField'] : '-1';

        $listElements['multiActions']   = isset($listElements['multiActions']) ? $listElements['multiActions'] : false;
        $listElements['multiLanguages'] = isset($listElements['multiLanguages']) ? $listElements['multiLanguages'] : false;
        $listElements['defaultLanguage']= isset($listElements['defaultLanguage']) ? $listElements['defaultLanguage'] : Languages::_getdefaultLanguage();

        $listElements['allowExport'] = ( isset($listElements['allowExport']) && in_array($listElements['allowExport'], array(true,false)) ) ? $listElements['allowExport'] : true;


        $listElements['sortby']     = isset($listElements['sortby']) ? $listElements['sortby'] : '';
        $listElements['order']      = isset($listElements['order']) ? $listElements['order'] : 'asc';
 
        $listElements['textPageNo']     = isset($listElements['textPageNo']) ? $listElements['textPageNo'] : '';
        $listElements['textPageNo']     = ((int)$listElements['textPageNo'] > 0) ? $listElements['textPageNo'] : 1;
        $listElements['perpage']        = isset($listElements['perpage']) ? $listElements['perpage'] : '';
        $listElements['perpage']        = ((int)$listElements['perpage'] > 0) ? $listElements['perpage'] : 10;
        $listElements['displaypages']   = isset($listElements['displaypages']) ? $listElements['displaypages'] : '';
        $listElements['displaypages']   = ((int)$listElements['displaypages'] > 0) ? $listElements['displaypages'] : 5;
        $listElements['defaultLanguage']= isset($listElements['defaultLanguage']) ? $listElements['defaultLanguage'] : '';

        // inorder to echo these values to javascript we need to take them as strings instead of boolean
        $listElements['defaultTemplate'] = isset($listElements['defaultTemplate']) ? $listElements['defaultLanguage'] : 'false';

        $listElements = Plugins::_runAction('lists_validate_list_elements', $listElements);

        $this -> _setListElements($listElements);

    }

    /**
     * returns the $listElements variable
     *
     * @param void
     * @return $listElements
     */
    private function _getDefautlPostFields() {

        $listElements = $this -> _getListElements();

        $postFields = array(
                            "idLoad"                => '',
                            "pageLoad"              => '', 
                            "filterSort"            => $listElements['sortby'], 
                            "filterSortOrder"       => $listElements['order'], 
                            "textPageNo"            => $listElements['page'], 
                            "perPage"               => $listElements['perpage'], 
                            "filterLanguage"        => $listElements['defaultLanguage'],
                            "display_manage_fields" => false,
                            "display_template"      => false
                            );

        $postFields = Plugins::_runAction('lists_get_default_post_fields', $postFields, $listElements);

        return $postFields;

    }

    /**
     * returns the $listElements variable
     *
     * @param void
     * @return $listElements
     */
    private function _reArrangeDisplayFields() {

        $listElements = $this -> _getListElements();
        
        $displayFields = $listElements['displayFields'];
        $modifiedDisplayFields = array();

        foreach ($displayFields as $key => $ListField) {

            if( isset($_POST['display_field_'.$ListField['id']]) ){

                // checking if display_field key is set for the current element
                // and updating the vlaues from the post fields 
                $values = explode(',',$_POST['display_field_'.$ListField['id']]);

                $status = ($values[0]=='1')?true:false;
                $order = $values[1];
                
            }else{
                
                // if the key display_field key is not set in the post elements
                // then updating the order and show values from the attributes given by the user while generating list elements
                
                // $key-0.01 is to avoid the overriding problem when using different list elements depending on other values
                // like categories etc where the list loads firsts with some elements and the same list loads different elements once the user clicks on view
                $order = $key+0.01;
                $status = (isset($ListField['show']))?$ListField['show']:true;

            }

            $ListField['show'] = $status;
            
            $modifiedDisplayFields[$order] = $ListField;
            
        }

        // sorting the fields according to the keys
        ksort($modifiedDisplayFields);

        $modifiedDisplayFields = Plugins::_runAction('lists_rearrange_display_fields', $modifiedDisplayFields, $displayFields, $listElements);
        
        return $modifiedDisplayFields;

    }

    /**
     * updates the post variables to listElements
     *
     * @param void
     * @return null
     */
    private function _setPostFields() {
        
        $listElements = $this -> _getListElements();
        // Loads default Post variables
        $defaultPost = $this -> _getDefautlPostFields();

        // Check it there is any valid post
        // if idsFieldFilter is not set, which means the list is calling from Pageload or from some other method otherthan loadlist
        // to avoid unidentified index errors we have to have a default values over tehre 
        if (!isset($_POST['idsFieldFilter'])) {

            // Using default post variables
            $_POST = $defaultPost;
            
        } else {

            // Validating the post variables

            // Validating integers
            if ((int)$_POST['textPageNo'] == 0)
                $_POST['textPageNo'] = $defaultPost['textPageNo'];
            if ((int)$_POST['perPage'] == 0)
                $_POST['perPage'] = $defaultPost['perPage'];

        }
        
        // this will update and rearrange the display fields values according to the user selection 
        $listElements['displayFields'] = $this->_reArrangeDisplayFields();

        if ( !isset($_POST['display_manage_fields']) || !in_array($_POST['display_manage_fields'],array(true,false,'true','false')) ){

            $_POST['display_manage_fields'] = $defaultPost['display_manage_fields'];
            
        }

        if( $_POST['display_manage_fields'] == 'false'){

            $_POST['display_manage_fields'] = false;;
            
        }

        if ( !isset($_POST['display_template']) || !in_array($_POST['display_template'],array(true,false,'true','false')) ){

            $_POST['display_template'] = $defaultPost['display_template'];
            
        }

        if( $_POST['display_template'] == 'false'){

            $_POST['display_template'] = false;

        }
            
        if ($listElements["multiLanguages"] && (int)$_POST['filterLanguage'] == 0){

            $_POST['filterLanguage'] = $defaultPost['filterLanguage'];
            
        }

        $_POST = Plugins::_runAction('lists_set_post_fields', $_POST, $listElements, $defaultPost);

        // Updating post variables to $listElements
        $listElements['_POST'] = $_POST;

        // Calling _setListElements to update the modified $listElements
        $this -> _setListElements($listElements);       

    }

    /**
     * checks weather the given list is running in export mode(for exporting list values) or normal mode
     *
     * @param void
     * @return boolean
     */
    private function _isExportMode() {

        $return = true;

        $listElements = $this -> _getListElements();
        
        if( !$listElements['allowExport'] ){

            $return = false;

        }else if( !isset($listElements['_POST']['typeList']) || $listElements['_POST']['typeList'] != 'export' ){

            $return = false;

        }

        $return = Plugins::_runAction('lists_is_export_mode', $return, $listElements );
        
        return $return;

    }

    /**
     * return the mode of the expert
     *
     * @param void
     * @return boolean
     */
    private function _getExportMode() {

        $listElements = $this -> _getListElements();
        
        $modeExport = $listElements['_POST']['typeExport'];
        
        if( !isset($listElements['_POST']['typeExport']) || !in_array($listElements['_POST']['typeExport'], array(1,2) ) ){

            $modeExport = 2;
                        
        }

        $modeExport = Plugins::_runAction('lists_get_export_mode', $modeExport, $listElements );
        
        return $modeExport;

    }

    /**
     * checks weather the given list is running in export mode(for exporting list values) or normal mode
     *
     * @param void
     * @return boolean
     */
    private function _setExportMode() {

        $listElements = $this -> _getListElements();

        $continue = true;

        $continue = Plugins::_runAction('lists_set_export_mode', $continue, $listElements );
        
        if( !$continue ){
            
            return false;    

        }

        header("Expires: 0");
        header("Pragma: no-cache");
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Cache-Control: pre-check=0, post-check=0, max-age=0');
        header("Content-Description: File Transfer");
        header("Content-Type: application/octet-stream");
        header('Content-Disposition: attachment; filename="'.$listElements['headding'].' '.date('r').'.csv"');
        header("Content-Transfer-Encoding: binary\n");

    }

    /**
     * prepares the csv rows to be exported
     *
     * @param void
     * @return string
     */
    private function _prepareExportData($generatedList) {

        $listElements = $this -> _getListElements();
        
        $generatedCsvData = '';
            
        $row = $generatedCsvRows = array();

        if(is_array($generatedList['list_header'])){

            foreach($generatedList['list_header'] as $key => $head_element){

                $row[] = $head_element;

            }

        }

        $generatedCsvRows[] = implode(",",$row);

        if(is_array($generatedList['list_body'])){
            
            foreach($generatedList['list_body'] as $body_row){
                
                $row = array();

                foreach($body_row as $row_elements){

                    $row[] = $row_elements;

                }

                $generatedCsvRows[] = implode(",",$row);
                
            }
            
        }
                    
        $generatedCsvData = implode("\n", $generatedCsvRows);

        $generatedCsvData = Plugins::_runAction('lists_prepare_export_mode', $generatedCsvData, $generatedCsvRows, $generatedList, $listElements );

        return $generatedCsvData;

    }

    /* validation functions starts from here
     <!-----------------------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * validates search element
     *
     * @param  object (search element),boolean(is the passed element a key)
     * @return boolean(true/false)
     */
    private function _validateSearchFilter($detailsElement,$passedId=false) {

        $return = true;

        // If id is passed the retrieving element details from the id
        if($passedId){

            $detailsElement = $this->_getDetailsFromId($detailsElement);

        }
        
        if(empty($detailsElement)){

            $return = false;            

        }else{

            // Checking weather $keyElement is a valid search type or not
            if (!$detailsElement['dbField'] || $detailsElement['tpx'] == '' || in_array($detailsElement['type'], array('image', 'actions'))){

                $return = false;
                
            }

        }

        $return = Plugins::_runAction('lists_validate_search_filter', $return, $detailsElement);

        return $return;

    }

    /**
     * validats sort element
     *
     * @param  object (sort element ),boolean(is the passed element a key)
     * @return boolean(true/false)
     */
    private function _validateSortFilter($detailsElement,$passedId=false) {

        $return = true;

        // If id is passed the retrieving element details from the id
        if($passedId){

            $detailsElement = $this->_getDetailsFromId($detailsElement);

        }

        if(empty($detailsElement)){

            $return = false;

        }else{

            // Checking weather $keyElement is a valid search type or not
            if (!$detailsElement['dbField'] || $detailsElement['tpx'] == '' || in_array($detailsElement['type'], array('image', 'actions', 'yesno', 'status'))){

                $return = false;
                
            }

        }
        
        $return = Plugins::_runAction('lists_validate_sort_filter', $return, $detailsElement);

        return $return;

    }

    /**
     * validats position element
     *
     * @param  string (search element key )
     * @return boolean(true/false)
     */
    private function _validatePositionFilter($currentFilter) {

        $return = false;

        if( !empty($currentFilter) && array_key_exists($currentFilter, $this->positionFiltersArray) ){

            $return = true;

        }
                
        $return = Plugins::_runAction('lists_validate_position_filter', $return, $currentFilter, $this -> positionFiltersArray);

        return $return;

    }

    /* validation functions ends here
     -----------------------------------------------------------------------------------------------------------------------------------------!>
     */
     
    /**
     * returns element details from id
     *
     * @param string($id)
     * @return $listElements
     */
    private function _getDetailsFromId($idElement) {

        $listElements = $this -> _getListElements();

        $return = false;

        foreach($listElements['displayFields'] as $listElement){

            if( strtolower($listElement['id']) == strtolower($idElement) ){

                $return = $listElement;
                break;

            }

        }

        $return = Plugins::_runAction('lists_get_details_from_id', $return, $listElements);

        return $return;

    }

    /**
     * generates the fielters ( search, position, sort )
     *
     * @param  vaoid
     * @return array
     */
    private function _getFilters() {

        global $Base,$User;

        $listElements = $this -> _getListElements();

        // Generates the empty keys with the given array values
        $listFilters = array_fill_keys(array('field', 'sort', 'position', 'sort_order', 'additional_js'), '');

        $listTemplates = '';
        // Checking weather we have any valid filename or not (like users/ amenus etc)
        // if we have a valid file then only we can have template system
        if( $this->_getFileName() ){

            // Now checking weather we have any templates for this list by this user
            $listTemplates = $User->_getUserPreference('/admin/lists/'.$this->_getFileName().'/preferences');

        }
        
        // Generating the search filters given by the user
        // first we need to get the list of valid search filters by using $this->_generateSearchFilters()
        $validSearchFilters = $this->_generateSearchFilters();

        // Once we have the search filters we have to generate js realated to them
        // Initilizing a varilable to false at the beginingn
        $generatedJsSearchFilters = false;

        // Now checking weather we have any valid search filters or not
        // If yes, then we will generate the js for those
        // otherwise, the value will be $generatedJsSearchFilters   
        if($validSearchFilters && count($validSearchFilters) > 0 ){
            
            // Since there are some search filters applied, we have to generate the javascript which will generate them again once the list is created 
            foreach( $validSearchFilters as $validSearchFilter){

                $generatedJsSearchFilters .= "addFilter('".$this->_getListId()."','".$validSearchFilter['filterField']."','".$validSearchFilter['filterQuery']."','".$validSearchFilter['filterPosition']."');";

            }

        }

        // Generating the sortby filters given by the user
        // first we need to get the list of valid sortby filters by using $this->_generateSearchSortBy()
        $validSearchSortBys = $this->_generateSearchSortBys();

        // Once we have the search sortbys we have to generate js realated to them
        // Initilizing a varilable to false at the beginingn
        $generatedJsSearchSortBys = false;      

        // Now checking weather we have any valid search sortbys or not
        // If yes, then we will generate the js for those
        // otherwise, the value will be $generatedJsSearchSortBys   
        if($validSearchSortBys && count($validSearchSortBys) > 0 ){

            // Since there are some search sortbys applied, we have to generate the javascript which will generate them again once the list is created 
            foreach( $validSearchSortBys as $validSearchSortBy){

                // Checking if the sortby is the default sortby or not
                // If the sortby is the default slider then excluding it from the list of adding it as to the sortby fields             
                if( $validSearchSortBy['idSortByField'] != 'default' ){

                    $generatedJsSearchSortBys .= "addSortBy('".$this->_getListId()."','".$validSearchSortBy['sortbyField']."','".$validSearchSortBy['sortbyOrder']."');";

                }
    
            }
    
        }

        $arrayFielterFields = $arraySelectFielter = '';

        foreach ($listElements['displayFields'] as $key => $ListField) {

            // Validating the elements for filter
            // Validated elements here will be displayed in the filters column
            if ($this -> _validateSearchFilter($ListField)) {

                // Since the elements we are allowing it to be displayed in the filter
                // since javascript is case sensitive, we have to use strtolower($ListField['id']) inorder to avoid conflicts during generation of select box from javascript
                $arrayFielterFields[strtolower($ListField['id'])] = array( 'title' => $ListField['title'], 'type' => $ListField['type'] );

                // Once the elements is allowed for filter, and if the element type is select box, then we have to save its set values for furthur use of those, when that particular filter is selected
                if ($ListField['type'] == 'select') {
    
                    $arraySelectFielter[strtolower($ListField['id'])] = $Base -> _generateSelect($ListField['set']);

                }

            }

            // Validating the elements for sorting
            // Validated elements here will be displayed in the sort drop down
            if ($this -> _validateSortFilter($ListField)) {

                // Since the elements we are allowing it to be displayed in the sort by
                // since javascript is case sensitive, we have to use strtolower($ListField['id']) inorder to avoid conflicts during generation of select box from javascript
                $arraySortByFields[strtolower($ListField['id'])] = array( 'title' => $ListField['title'], 'type' => $ListField['type'] );

            }

        }

        if ($listElements["multiLanguages"]) {

            $Languages = new Languages();
            $listLanguages = $Languages -> _getLanguages(1);
            $languageFilters = '';

            foreach ($listLanguages as $Language) {

                if ($Language -> idLanguage == $listElements['_POST']['filterLanguage']){

                    $selected = 'selected="selected"';

                }else{

                    $selected = '';

                }

                $listFilters['language'] .= '<option value="' . $Language -> idLanguage . '" ' . $selected . '>' . $Language -> nameLanguage . '</option>';

            }

        }

        $listFilters['additional_js'] .= 'var arrayFielterFields_'.$this->_getListId().' = ' . json_encode($arrayFielterFields) . ';';
        $listFilters['additional_js'] .= 'var arraySelectFielter_'.$this->_getListId().' = ' . json_encode($arraySelectFielter) . ';';
        $listFilters['additional_js'] .= 'var arrayFielterPosition_'.$this->_getListId().' = ' . json_encode($this->positionFiltersArray) . ';';
        $listFilters['additional_js'] .= 'var arraySortByFields_'.$this->_getListId().' = ' . json_encode($arraySortByFields) . ';';
        $listFilters['additional_js'] .= 'var arraySortByOrder_'.$this->_getListId().' = ' . json_encode($this->OrderFiltersArray) . ';';
        $listFilters['additional_js'] .= '$( "#datepicker" ).datepicker();';
        $listFilters['additional_js'] .= $generatedJsSearchFilters;
        $listFilters['additional_js'] .= $generatedJsSearchSortBys;
        $listFilters['display_fields'] = $this->_generateDisplayFields();
        $listFilters['display_manage_fields'] = $listElements['_POST']['display_manage_fields'];
        $listFilters['display_template'] = $listElements['_POST']['display_template'];

        $listFilters['additional_js'] .= 'var listTemplates_'.$this->_getListId().' = ' . json_encode($listTemplates) . ';';
        $listFilters['additional_js'] .= 'var listDefaultTemplates_'.$this->_getListId().' = "' . $this->_getDefaultListTemplate() . '";';
        $listFilters['list_templates'] = $listTemplates;

        $listFilters = Plugins::_runAction('lists_get_filters_end', $listFilters, $listElements, $this);

        return $listFilters;

    }

    /**
     * returns the list of display fields
     *
     * @param  void
     * @return array
     */
    private function _generateDisplayFields() {

        // Calling _getListElements to update listElements
        $listElements = $this -> _getListElements();

        $displayFields = array();

        foreach ($listElements['displayFields'] as $key => $ListField) {

            $displayFields[$key] = array('id' => $ListField['id'], 'title' => $ListField['title'], 'show' => $this->_isVisible($ListField['id']));

        }

        $displayFields = Plugins::_runAction('lists_generate_display_fields', $displayFields, $listElements );

        return $displayFields;

    }

    /**
     * returns if the element is visible or not
     *
     * @param  void
     * @return array
     */
    private function _isVisible($keyElement) {

        // Getting the field details from 
        $detailsElement = $this->_getDetailsFromId($keyElement);

        $return = $detailsElement['show'];
        
        if( $this -> _isExportMode() && in_array($detailsElement['id'], array('actions')) ){

            $return = false;
        }

        $return = Plugins::_runAction('lists_is_visible', $return, $detailsElement );
            
        return $return;

    }

    /**
     * converts and returns search filter in array format from the post filter values
     *
     * @param  void
     * @return array/boolean
     */
    private function _generateSearchFilters() {

        // Calling _getPostFields to update listElements
        $listElements = $this -> _getListElements();

        $filtersValid = false;
        
        if( isset($listElements['_POST']['idsFieldFilter']) ){

            // taking the idsFieldFilter from the post variable
            // this will contain the ids of the filters users selected in the format id1,id2
            $idsFieldFilter = $listElements['_POST']['idsFieldFilter'];
            
            if( $idsFieldFilter != '' ){

                $arrayIdsFieldFilter = explode(',',$idsFieldFilter);
                
                $filtersValid = array();
                
                foreach($arrayIdsFieldFilter as $idFilterField){

                    if ($this -> _validateSearchFilter($listElements['_POST']['filterField_'.$idFilterField],true)) {
                        
                        $filtersValid[] = array(
                                                'idFilterField' =>  $idFilterField, 
                                                'filterField'   =>  $listElements['_POST']['filterField_'.$idFilterField], 
                                                'filterPosition'=>  $listElements['_POST']['filterPosition_'.$idFilterField], 
                                                'filterQuery'   =>  $listElements['_POST']['filterQuery_'.$idFilterField]
                                         );

                    }

                }

            }

        }

        $filtersValid = Plugins::_runAction('lists_generate_search_filters', $filtersValid, $listElements );

        return $filtersValid;

    }

    /**
     * generates search filter query and array bind values from the post filter values
     *
     * @param  void
     * @return array/boolean
     */
    private function _generateSearchFilterQuery() {

        // Calling _getPostFields to update listElements
        $listElements = $this -> _getListElements();

        $filtersValid = $this->_generateSearchFilters();

        if( !$filtersValid ){

            return false;

        }

        foreach($filtersValid as $filter){

            // Updating the $whereArray with the valid search filters
            $idFilterField = $filter['idFilterField'];
            $keySearch = $filter['filterField'];
            $filterQuery = $filter['filterQuery'];
            $keyPosition = $filter['filterPosition'];
            
            if( $filterQuery == '' ){

                continue;
            }

            // Getting the field details from 
            $detailsFilterField = $this->_getDetailsFromId($keySearch);

            // Getting the where query format ( table.field like )
            if ($detailsFilterField['tpx'] != ''){

                $fieldExt = $detailsFilterField['tpx'] . ".";

            }else{

                $fieldExt = '';

            }

            $whereTmp = '';

            if ($detailsFilterField['type'] == 'date') {

                if( $filterQuery != '' ){

                    $dateArray = explode("to", $filterQuery);

                    if (count($dateArray) == 2) {

                        $whereTmp .= " (" . $fieldExt . $keySearch . " >= '" . $dateArray[0] . "') and (" . $fieldExt . $keySearch . " <= '" . $dateArray[1] . "')";

                    } else {

                        $whereTmp .= $fieldExt . $keySearch . " like '" . $dateArray[0] . "%'";

                    }

                }
            } else {

                $whereTmp = $fieldExt;
                $whereTmp .= $keySearch . " like ";

                // Validating the where query search position
                if (!$this -> _validatePositionFilter($keyPosition)){

                    $keyPosition = '';

                }

                $whereTmp .= ":filterQuery_".$idFilterField;
                // Getting and updating the where query search position valid : ( '%filterQuery%' or 'filterQuery%' or '%filterQuery' or 'filterQuery' )

                if ($keyPosition == 'exactly' || $detailsFilterField['type'] == 'select'){

                    $filterQuery = "$filterQuery";

                }else if ($keyPosition == ''){

                    $filterQuery = "%$filterQuery%";

                }else if ($keyPosition == 'start'){

                    $filterQuery = "$filterQuery%";

                }else if ($keyPosition == 'end'){

                    $filterQuery = "%$filterQuery";

                }

                $arrayBind[] = array("key" => ":filterQuery_".$idFilterField, "value" => $filterQuery, "type" => PDO::PARAM_STR);

            }

            if( $whereTmp != '' ){

                $whereArray[] = $whereTmp;

            }

        }

        $returnValue = false;

        if( isset($whereArray) && count($whereArray) > 0 ){

            $whereQuery = implode(' and ',$whereArray);

            $returnValue['whereQuery']  = $whereQuery;

            if( isset($arrayBind) ){

                $returnValue['arrayBind']   = $arrayBind;

            }

        }

        $returnValue = Plugins::_runAction('lists_generate_search_filter_query', $returnValue, $listElements, $this );

        return $returnValue;

    }

    /**
     * converts and returns search sortbys in array format from the post filter values
     *
     * @param  void
     * @return array/boolean
     */
    private function _generateSearchSortBys() {

        // Calling _getPostFields to update listElements
        $listElements = $this -> _getListElements();

        // idsFieldSortBy contains the list of ids for all the sorybe filters
        // idsFieldSortBy isnot set when the list is loading for the fist time
        // idsFieldSortBy have null value if the list doesn't have any sortby filters applied
        if( !isset($listElements['_POST']['idsFieldSortBy']) || $listElements['_POST']['idsFieldSortBy'] == '' ){

            // check if we have default sortby value or not
            // returning false if we don't have default sortby value
            if( $listElements['sortby'] == '' ){

                return false;

            }

            // if we have any sortby value then inserting them to the filter to apply filters
            $listElements['_POST']['idsFieldSortBy'] = 'default';
            $listElements['_POST']['sortbyField_default'] = $listElements['sortby'];
            $listElements['_POST']['sortbyOrder_default'] = $listElements['order'];

        }

        // taking the idsFieldSortBy from the post variable
        // this will contain the ids of the filters users selected in the format id1,id2
        $idsFieldSortBy = $listElements['_POST']['idsFieldSortBy'];
        
        if( $idsFieldSortBy == '' ){

            return false;

        }

        $arrayIdsFieldSortBy = explode(',',$idsFieldSortBy);

        $sortbysValid = array();

        foreach($arrayIdsFieldSortBy as $idFilterSortBy){

            if ($this -> _validateSortFilter($listElements['_POST']['sortbyField_'.$idFilterSortBy],true)) {

                $sortbysValid[] = array(
                                        'idSortByField' =>  $idFilterSortBy, 
                                        'sortbyField'   =>  $listElements['_POST']['sortbyField_'.$idFilterSortBy], 
                                        'sortbyOrder'   =>  $listElements['_POST']['sortbyOrder_'.$idFilterSortBy], 
                                 );

            }

        }

        $sortbysValid = Plugins::_runAction('lists_generate_search_sortby', $sortbysValid, $listElements );

        return $sortbysValid;

    }

    /**
     * generates search sortby query from the post sortby values
     *
     * @param  void
     * @return array/boolean
     */
    private function _generateSearchSortByQuery() {

        // Calling _getPostFields to update listElements
        $listElements = $this -> _getListElements();

        $sortbysValid = $this->_generateSearchSortBys();

        $returnValue = false;

        if( $sortbysValid ){

            foreach($sortbysValid as $sortby){
    
                // Updating the $whereArray with the valid search sortbys
                $idSortByField = $sortby['idSortByField'];
                $sortbyField = $sortby['sortbyField'];
                $sortbyOrder = $sortby['sortbyOrder'];

                if( $sortbyField == '' ){

                    continue;

                }

                // Getting the field details from 
                $detailsSortByField = $this->_getDetailsFromId($sortbyField);

                // Getting the where query format ( table.field like )
                if ($detailsSortByField['tpx'] != ''){

                    $fieldExt = $detailsSortByField['tpx'] . ".";

                }else{

                    $fieldExt = '';

                }

                // Updating $orderString with the fields ( order by table.field order )
                $orderArray[] = $fieldExt . $sortbyField . ' '.$sortbyOrder;

            }

            if( count($orderArray) > 0 ){

                $orderString = implode(' , ',$orderArray);

                $returnValue = $orderString;

            }

        }

        $returnValue = Plugins::_runAction('lists_generate_search_sortby_query', $returnValue, $listElements, $this );

        return $returnValue;

    }

    /**
     * generates the list ( search, position, sort )
     *
     * @param  $listElements
     * @return string
     */
    public function _generateList($listElements) {

        $generateListStart = microtime(true);

        $listElements = Plugins::_runAction('generate_list_start', $listElements);

        if (!is_array($listElements)) {

            return false;

        }

        $this->_setDefaultFields();

        // Calling _setListElements to update $listElements
        $this -> _setListElements($listElements);

        // Process list default Elements
        $this -> _validateListElements();

        // Calling _setPostFields to update post fields
        $this -> _setPostFields();

        // this is will get the list template id
        // the default template values will also be updated here
        $generatedList['idListTemplate'] = $this->_getListTemplate();

        // Calling _getPostFields to update listElements
        $listElements = $this -> _getListElements();

        // Starts generating the list
        global $Permissions;

        if ($Permissions -> _checkPagePermission($this->_getFileName(), 'create') && (!isset($listElements["noCreate"]) || !$listElements["noCreate"])) {

            $createButton = $this -> _generateEditorLink();

            $createButton = Plugins::_runAction('generate_list_create_button', $createButton, $listElements);
            $generatedList['create_button_link'] = $createButton;

        }

        // Calling _getFilters to get the filters and merging them with existing array
        $generatedList['filter'] = $this -> _getFilters();

        $arrayBind = $listElements['arrayBind'];
        $whereArray = array();
        $whereString = $orderString = '';
        $query = $listElements['sql'];

        // Checking for the where query passed
        if ($listElements['where'] != '') {

            $whereArray[] = $listElements['where'];

        }

        // Checking weather the list enabled multilanguage options
        if ($listElements["multiLanguages"]) {

            $whereArray[] = $listElements["multiLanguages"] . ' = ' . $listElements['_POST']['filterLanguage'];

        }

        // this will generate where query from the post filters
        $searchFilters = $this->_generateSearchFilterQuery();

        // If we have active filters need to be appended to the query, then appeneding then to the where array and coming the array bind values     
        if( $searchFilters ){

            // Appending the where from filters to the main where array
            $whereArray[] = $searchFilters['whereQuery'];

            // Combining $searchFilters['arrayBind'] from search filters(if exists) to the main array bind  
            if( isset($searchFilters['arrayBind']) ){
                
                if( is_array($arrayBind) && count($arrayBind) > 0 ){
                    
                    $arrayBind = array_merge( $arrayBind , $searchFilters['arrayBind']);

                }else{

                    $arrayBind = $searchFilters['arrayBind'];
                    
                }

            }

        }

        if (count($whereArray)) {

            $whereString = " where " . implode(" and ", $whereArray);

        }

        // this will generate where query from the post filters
        $searchSortBys = $this->_generateSearchSortByQuery();

        // If we have active filters need to be appended to the query, then appeneding then to the where array and coming the array bind values     
        if( $searchSortBys ){

            // Appending the where from filters to the main where array
            $orderString = " order by " . $searchSortBys;

        }

        // Including Group by
        if (isset($listElements['groupby']) && $listElements['groupby'] != '') {

            $groupby = ' Group By ' . $listElements['groupby'];

        } else {

            $groupby = '';

        }

        // Appending the final query
        $query .= $whereString . $groupby . $orderString;

        $gQuery["sql"] = $query;
        $gQuery["arrayBind"] = $arrayBind;

        global $Base;

        if( !$this -> _isExportMode() ){

            // Calling _generatePagination to genereate pagination _generatePagination(query,page no, per page, display pages )
            $pagination = $Base -> _generatePagination($gQuery, $listElements['_POST']['textPageNo'], $listElements['_POST']['perPage'], $listElements['displaypages']);

            $query .= " limit :LL,:LT ";

            $arrayBind[] = array("key" => ":LL", "value" => (int)$pagination['LL'], "type" => PDO::PARAM_INT);
            $arrayBind[] = array("key" => ":LT", "value" => (int)$pagination['LT'], "type" => PDO::PARAM_INT);

        }else{

            $pagination['TR'] = 1;

        }

        $listResults = Core::_getAllRows($query, $arrayBind);

        $generatedList['idList'] = $this->_getListId();
        $generatedList['idLoad'] = $this->idLoad;
        $generatedList['pageLoad'] = $this->pageLoad;
        $generatedList['filename'] = $this->_getFileName();

        $generatedList['params'] = $this->params;

        $generatedList['headding'] = $listElements['headding'];

        $generatedList['pagination'] = $pagination;

        $generatedList['linkSubmit'] = $this -> _generateSubmitLink();
        $generatedList['linkEdit'] = $this -> _generateEditorLink();
        $generatedList['urlEdit'] = $this->_generateEditorUrl();

        $generatedList['defaultTemplate'] = $listElements['defaultTemplate'];

        // Check if results exists
        if ($pagination['TR'] > 0) {

            $table_sorter = 'class="header"';

            $generatedList['list_header'] = $generatedList['list_body'] = $generatedList['list_footer'] = array();
            $i = 0;

            // Generating the table titles
            foreach ($listElements['displayFields'] as $key => $ListField) {

                if( !$this->_isVisible($ListField['id']) ){

                    continue;

                }

                if ($ListField['type'] == 'actions' && $listElements['multiActions']) {

                    $titleAction = '';

                    // Checking edit permissions for the status changer
                    if ( $Permissions -> _checkPagePermission($this->_getFileName(), 'edit') ) {

                        // Checking the action in the user given acations list
                        if ( $listElements['statusField'] != -1 && in_array('status', $ListField['set'])) {

                            $titleAction .= '<option value="1">Invert Status</option>';
                            $titleAction .= '<option value="2">Enable Selected</option>';
                            $titleAction .= '<option value="3">Disable Selected</option>';

                        }

                        // Edit can't be possible if editorLink(Note not editor url) is given dynamically
                        // $this->_generateEditorUrl() return false if givne dynamicall
                        
                        if (in_array('edit', $ListField['set']) && $this->_generateEditorUrl() ) {

                            $titleAction .= '<option value="4">Edit Selected</option>';

                        }

                        // Edit can't be possible if editorLink(Note not editor url) is given dynamically
                        // $this->_generateEditorUrl() return false if givne dynamicall
                        if (in_array('copy', $ListField['set']) && $this->_generateEditorUrl() ) {

                            $titleAction .= '<option value="5">Copy Selected</option>';

                        }

                    }

                    // Checking delete permissions
                    if ($Permissions -> _checkPagePermission($this->_getFileName(), 'delete')) {

                        // Checking the action in the user given acations list
                        if (in_array('delete', $ListField['set'])) {

                            $titleAction .= '<option value="6">Delete Selected</option>';

                        }

                    }

                    $generatedList['multi_actions'][$i] = $titleAction;
                }

                $generatedList['list_header'][$i] = $ListField['title'];
                $i++;

            }

            $displayTotals = false;
            $totals = array();

            // Generates required permissions for the list
            $this -> _generatePermissions();

            $i = 0;
            foreach ($listResults as $result) {

                // Generating all the fields in the row
                foreach ($listElements['displayFields'] as $key => $ListField) {

                    if( !$this->_isVisible($ListField['id']) ){

                        continue;

                    }

                    // Creating the function name
                    $function = '_generate' . $ListField['type'] . 'Data';

                    // Clearing the $key value if it is not a database field
                    if (!$ListField['dbField']) {

                        $result -> $ListField['id'] = '';

                    }

                    //Calculating the totals of the list fields
                    if (isset($ListField['total']) && $ListField['total']) {

                        if (!isset($totals[$ListField['id']])){

                            $totals[$ListField['id']] = 0;

                        }

                        $totals[$ListField['id']] += $result -> $ListField['id'];
                        $displayTotals = true;

                    }

                    // Calling the function like _generateTextData. $ListField contains the details of the field to dispaly
                    // Since objects are passed by reference we need to clone to avoid further collisions
                    $generatedList['list_body'][$i][] = $this -> $function(clone $result, $ListField);

                }

                $i++;

            }

            if ($displayTotals) {

                // Generating all the fields in the row
                foreach ($listElements['displayFields'] as $ListField['id'] => $ListField) {

                    if (isset($ListField['total']) && $ListField['total']) {

                        $generatedList['list_footer'][] = $this -> _replaceFieldData($totals[$ListField['id']], $ListField["display"]);

                    } else {

                        $generatedList['list_footer'][] = '';

                    }

                }

            }

        }

        $generatedList['additional_js'] = '';

        $generatedList = Plugins::_runAction('generate_list_end', $generatedList, $listElements);

        if( $this -> _isExportMode() ){

            $this->_setExportMode();
            $generatedListData = $this->_prepareExportData($generatedList);

            echo $generatedListData;
            die();

        }else{

            ob_start();
            include_once Config::_getDir('admin.temp') . '/elements/lists.phtml';
            $generatedListData = ob_get_clean();

        }

        /*
         ** List generation dompleted
         */

        return $generatedListData;

    }

    /*
     Fields display functions starts here
     <!-----------------------------------------------------------------------------------------------------------------------------------------
     */

    /**
     * replace the :data with $valueField
     *
     * @param  string(replace with),string(replace in)
     * @return string
     */
    public function _replaceFieldData($valueField, $attributesField) {

        return str_replace(":data", $valueField->$attributesField['id'], $attributesField['display']);

    }

    /**
     * generates the text field
     *
     * @param  string(value to display),array(elements attributes)
     * @return string
     */
    public function _generateTextData($valueField, $attributesField) {

        $generatedData = $this -> _replaceFieldData($valueField, $attributesField);

        $generatedData = Plugins::_runAction('lists_generate_text_data', $generatedData, $valueField, $attributesField);

        return $generatedData;

    }

    /**
     * generates the text field
     *
     * @param  string(value to display),array(elements attributes)
     * @return string
     */
    public function _generateLongTextData($valueField, $attributesField) {

        $generatedData = $this -> _replaceFieldData($valueField, $attributesField);

        $generatedData = Plugins::_runAction('lists_generate_longtext_data', $generatedData, $valueField, $attributesField);

        return $generatedData;

    }

    /**
     * generates the date field
     *
     * @param  string(value to display),array(elements attributes)
     * @return string
     */
    public function _generateDateData($valueField, $attributesField) {

        global $Base, $User;

        // Converting the date to the currently logged in user tmezone
        $valueField->$attributesField['id'] = $Base -> _convertTimeZone($valueField->$attributesField['id'], $User -> timezoneUser() );

        $generatedData = $this -> _replaceFieldData($valueField, $attributesField);

        $generatedData = Plugins::_runAction('lists_generate_date_data', $generatedData, $valueField, $attributesField);

        return $generatedData;

    }

    /**
     * generates the size field
     *
     * @param  string(value to display),array(elements attributes)
     * @return string
     */
    public function _generateSizeData($valueField, $attributesField) {

        global $Base;

        $generatedData = $this -> _replaceFieldData($Base -> _convertByes($valueField), $attributesField);

        $generatedData = Plugins::_runAction('lists_generate_size_data', $generatedData, $valueField, $attributesField);

        return $generatedData;

    }

    /**
     * generates the images
     *
     * @param  integer(pathImage),array(elements attributes)
     * @return string(image)
     */
    public function _generateImageData($valueField, $attributesField) {

        global $Base;

        $valueField->$attributesField['id'] = $Base -> _displayPhpthumb($valueField->$attributesField['id'], 50, 50);

        if( $this -> _isExportMode() ){

            $generatedData = $valueField->$attributesField['id'];
            
        }else{

            $generatedData = $this -> _replaceFieldData($valueField, $attributesField);
            
        } 

        $generatedData = Plugins::_runAction('lists_generate_image_data', $generatedData, $valueField, $attributesField);

        return $generatedData;

    }

    /**
     * generates the YesNo data
     *
     * @param  string(key to display),array(elements attributes)
     * @return string
     */
    public function _generateSelectData($valueField, $attributesField) {

        global $Base;

        $listSelect = $Base -> _generateSelect($attributesField['set']);

        if (!isset($listSelect[$valueField->$attributesField['id']])){

            $listSelect[$valueField->$attributesField['id']] = 'Not Found';
            
        }

        $prevValue = $valueField->$attributesField['id'];
        $valueField->$attributesField['id'] = $listSelect[$valueField->$attributesField['id']];

        $generatedData = $this -> _replaceFieldData($valueField, $attributesField);
        
        $valueField->$attributesField['id'] = $prevValue;

        $generatedData = Plugins::_runAction('lists_generate_select_data', $generatedData, $valueField, $attributesField);

        return $generatedData;

    }

    /**
     * Geneates and saves the page permissions
     *
     * @param  void
     * @return null
     */
    public function _generatePermissions() {

        // Getting the list elements
        $listElements = $this -> _getListElements();

        global $Permissions;

        foreach ($this->actionsPermissionsArray as $permission) {

            $this -> generatedPermissios[$permission] = $Permissions -> _checkPagePermission($this->_getFileName(), $permission);

        }

    }

    /** Checks the permission for the current list entry
     *
     * @param  string(permission type)
     * @return null
     */
    public function _checkPermissions($permision) {

        if (isset($this -> generatedPermissios[$permision])){

            return $this -> generatedPermissios[$permision];
            
        }

        return false;

    }

    /**
     * generates the action variables
     *
     * @param  string(value to display),array(elements attributes)
     * @return string
     */
    public function _generateActionsData($result, $listField) {

        // Getting the list elements
        $listElements = $this -> _getListElements();
        
        $systemItem = false;
        global $Base, $Permissions, $Admin;

        if (isset($result -> systemItem) && $result -> systemItem == 1 && !$Admin -> _isDeveloperMode()) {

            $systemItem = true;

            return '<span class="systemActions">System Item</span>';

        }

        $primaryField = isset($result -> $listElements['primaryField']) ? $result -> $listElements['primaryField'] : '';
        $statusValue = isset($result -> $listElements['statusField']) ? $result -> $listElements['statusField'] : '';

        // Returning null if there is no primary key or actions not set or actions set are null
        if ($listElements['primaryField'] == '' || $listField['type'] != 'actions' || count($listField['set']) == 0) {

            return '';

        }

        // Used to store the generated data
        $dataAction = '';

        // Used to track weather multiple actions are required or not. If status/delete actions are allowed, then multiple actions will be activated
        $multipleAction = false;

        $statusImage = ($statusValue == 1) ? 'tick-circle.gif' : 'minus-circle.gif';

        foreach ($listField['set'] as $currentAction) {

            switch($currentAction) {

                case 'view' :
                    // Checking view permissions
                    if ($this -> _checkPermissions('view')) {
                        
                        $dataAction .= '<a href="javascript:viewSub(\'\',\'' . $primaryField . '\',' . $listElements['_POST']['filterLanguage'] . ')">
                                                    <img src="' . Config::_getUrl('admin.temp') . '/images/arrow-curve-000-left.gif" width="16" height="16" alt="go" title="go" />
                                                </a>';

                    }

                    break;

                case 'status' :

                    // Checking edit permissions
                    if ($this -> _checkPermissions('edit') && $listElements['statusField'] != -1) {

                        $dataAction .= '<a href="javascript:statusChanger(\'' . $this -> _generateSubmitLink() . '\',\'' . $primaryField . '\',\'status\',\'\',\'LoadList_'.$this->_getListId().'\')">
                                                    <img src="' . Config::_getUrl('admin.temp') . '/images/' . $statusImage . '" width="16" height="16" alt="Status" title="Status" />
                                                </a>';
                        $multipleAction = true;

                    }

                    break;

                case 'edit' :

                    // Checking edit permissions
                    if ($this -> _checkPermissions('edit')) {

                        $dataAction .= '<a href="' . $this -> _generateEditorLink('edit',$result,$listElements['_POST']['filterLanguage']). '">
                                                    <img src="' . Config::_getUrl('admin.temp') . '/images/pencil.gif" width="16" height="16" alt="edit" title="edit" />
                                                </a>';

                    }

                    break;

                case 'copy' :

                    // Checking view permissions
                    if ($this -> _checkPermissions('create')) {

                        $dataAction .= '<a href="' . $this -> _generateEditorLink('copy',$result,$listElements['_POST']['filterLanguage']). '">
                                                    <img src="' . Config::_getUrl('admin.temp') . '/images/copy.png" width="16" height="16" alt="Copy" title="Copy" />
                                                </a>';

                    }

                    break;

                case 'delete' :
                
                    // Checking delete permissions
                    if ($this -> _checkPermissions('delete')) {

                        $dataAction .= '<a href="javascript:statusChanger(\'' . $this -> _generateSubmitLink() . '\',\'' . $primaryField . '\',\'delete\',\'\',\'LoadList_'.$this->_getListId().'\')">
                                                    <img src="' . Config::_getUrl('admin.temp') . '/images/bin.gif" width="16" height="16" alt="delete" title="delete" />
                                                </a>';

                        $multipleAction = true;

                    }

                    break;

                default :

                    if (is_array($currentAction)) {

                        if ($this -> _checkPermissions($currentAction['permissions'])) {

                            $currentAction['display'] = $this->_replaceFields($currentAction['display'],$result);
                            $dataAction .= str_replace('primaryField', $primaryField, $currentAction['display']);

                        }

                    } else {

                        $currentAction = $this->_replaceFields($currentAction,$result);
                        $dataAction .= str_replace('primaryField', $primaryField, $currentAction);

                    }

            }

        }

        // Generates the multiple action value based on the $multipleAction variable and the user option for the multiple action value
        if ($multipleAction && $listElements['multiActions']) {

            $dataAction = '<input type="checkbox" class="listcheckbox_'.$this->_getListId().'" value="' . $primaryField . '"/>' . $dataAction;
            
        }

        $dataAction = Plugins::_runAction('lists_generate_action_data', $dataAction, $primaryField, $result, $listElements);

        return $dataAction;

    }

    /**
     * This replaces all available fields in the list
     *
     * @param  void
     * @return mixed(string/null)
     */
    public function _replaceFields($replaceString,$resultField = false) {

        $replaceString = str_replace('functionList','LoadList_'.$this->_getListId(), $replaceString);
        $replaceString = str_replace('idList',$this->_getListId(), $replaceString);

        // Getting the list elements
        $listElements = $this -> _getListElements();

        if( $resultField ){

            $primaryField = isset($resultField -> $listElements['primaryField']) ? $resultField -> $listElements['primaryField'] : '-1';

        }else{

            $primaryField = -1;

        }

        $replaceString = str_replace('primaryField', $primaryField, $replaceString);

        return $replaceString;

    }
    
    /**
     * return current template
     *
     * @param  void
     * @return mixed(string/null)
     */
    public function _getListTemplate() {

        // Getting the list elements
        $listElements = $this -> _getListElements();
        
        if( isset($listElements['_POST']['selectListTemplate']) ){

            $idListTemplate = $listElements['_POST']['selectListTemplate'];

        } else {

            $idListTemplate = $this->_getDefaultListTemplate();
            $this->_getTemplateValues($idListTemplate);

            // Getting the list elements
            $listElements = $this -> _getListElements();

            // this is used to differentiate the template loading options in javascript
            // inorder to echo these values to javascript we need to take them as strings instead of boolean
            $listElements['defaultTemplate'] = 'true';

            // Calling _setListElements to update the modified $listElements
            $this -> _setListElements($listElements);       

        }
        
        return $idListTemplate;

    }

    
    /**
     * return current template
     *
     * @param  void
     * @return mixed(string/null)
     */
    public function _getDefaultListTemplate($nameFile = false) {

        $idListTemplate = -1;

        if( !$nameFile ){

            $nameFile = $this->_getFileName();

        }

        if( $nameFile && $nameFile != '' ){

            global $User;
            $idListTemplate = $User->_getUserPreference('/admin/lists/'.$nameFile.'/preferences/default');

        }

        $idListTemplate = Plugins::_runAction('lists_get_default_list_template', $idListTemplate, $nameFile, $this->_getFileName());

        return $idListTemplate;
        
    }

    
    /**
     * sets given template as the filter
     *
     * @param  void
     * @return mixed(string/null)
     */
    public function _getTemplateValues($idListTemplate) {
        // Getting the list elements
        $listElements = $this -> _getListElements();

        global $User;
        $prefList = $User->_getUserPreference('/admin/lists/'.$this->_getFileName().'/preferences');
        
        if( isset($prefList[$idListTemplate]) && isset($prefList[$idListTemplate]['urlList']) ){
            
            $listElements['_POST'] = array_merge($listElements['_POST'],$prefList[$idListTemplate]['urlList']);
            // Calling _setListElements to update the modified $listElements
            $this -> _setListElements($listElements);       

        }

    }

    /**
     * returns current file name
     *
     * @param  void
     * @return mixed(string/null)
     */
    public function _getFileName() {

        // Getting the list elements
        $listElements = $this -> _getListElements();

        if( !isset($listElements['filename']) ){

            return false;

        }

        return $listElements['filename'];

    }

    /**
     * generates editor url
     *
     * @param  void
     * @return mixed(string/null)
     */
    public function _generateEditorUrl() {

        // Getting the list elements
        $listElements = $this -> _getListElements();

        if (isset($listElements['editorLink']) && $listElements['editorLink'] != ''){
            
            // Returning false if custom link is given
            // Note : editorUrl is different from editorLink
            // editorLink = javascript:generateEditor('get/edit/amenus','form_idList_primaryField','$type',primaryField,'functionList',$params)
            // editorUrl = get/edit/amenus
            // In simple words, editor url just mentions the url to which the page has to send the request and the rest of the javascript will be generated automaticall
            // Where as editorLink is the complete url like mentioned above
            
            // Finally the following is the comparision
            // editorUrl(get/edit/amenus) = editorLink(javascript:generateEditor('get/edit/amenus','form_idList_primaryField','$type',primaryField,'functionList',$params))
            
            return false;

        }else if (isset($listElements['editorUrl']) && $listElements['editorUrl'] != ''){

            return $listElements['editorUrl'];

        }
        
        $baseUrl = '';
        
        global $Plugins;
        if( $Plugins->_getWorkingPluginDetails() ){

            $baseUrl = "/plugins/".$Plugins->_getWorkingPluginDetails()->identifierPlugin."/backend/includes/modules/ajax/";

        }

        return $baseUrl."get/edit/".$this->_getFileName();

    }

    /**
     * generates editor link
     *
     * @param  void
     * @return mixed(string/null)
     */
    public function _generateEditorLink($type='create',$resultField = false,$idLanguage=0) {

        // Getting the list elements
        $listElements = $this -> _getListElements();

        // In general the default link will be the get/edit/list_name
        // if in a plugin then it will become /plugins/plugin_identifier/backend/includes/modules/ajax/get/edit/list_name

        if (isset($listElements['editorLink']) && $listElements['editorLink'] != ''){

            $linkEditor = str_replace('typeEditor',$type, $listElements['editorLink']);
            $linkEditor = $this->_replaceFields($linkEditor,$resultField);

        }else{

            $params = $listElements['params'];

            if( empty($params) ){

                $params = "''";

            }

            $linkEditor = "javascript:generateEditor('".$this->_generateEditorUrl()."','form_idList_primaryField','$type',primaryField,'functionList',$params)";
            $linkEditor = $this->_replaceFields($linkEditor,$resultField);

        }

        return $linkEditor;

    }

    /**
     * generates submit link
     *
     * @param  void
     * @return mixed(string/null)
     */
    public function _generateSubmitLink() {

        // Getting the list elements
        $listElements = $this -> _getListElements();

        if (isset($listElements['submitLink']) && $listElements['submitLink'] != ''){

            return $listElements['submitLink'];
            
        }

        $baseUrl = '';

        global $Plugins;

        if( $Plugins->_getWorkingPluginDetails() ){

            $baseUrl = "/plugins/".$Plugins->_getWorkingPluginDetails()->identifierPlugin."/backend/includes/modules/ajax/";

        }

        return $baseUrl.'set/'.$this->_getFileName();

    }

    /* Fields display functions ends here
     -----------------------------------------------------------------------------------------------------------------------------------------!>
     */

    /**
     * Check weather the list page with the given page exists or not
     *
     * @param  string(page),$From(string)
     * @return boolean
     */
    public function _checkListsPage($Page) {

        $return = false;

        if (file_exists(Config::_getDir('admin') . '/includes/core/modules/ajax/get/list/' . $Page . '.php') || file_exists(Config::_getDir('admin') . '/includes/custom/modules/ajax/get/list/' . $Page . '.php')) {

            $return = true;

        }

        $return = Plugins::_runAction('check_lists_page', $return, $Page);

        return $return;

    }

}

