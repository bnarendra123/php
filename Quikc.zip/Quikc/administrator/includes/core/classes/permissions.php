<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

/**
* Permissions class, Contains all the function to create, change and verify the permissions
* All admin permissions will be processed from here. Please don't change unless very critical
*
* @version 1.0
* @http://www.quikc.org/
*/
class Permissions{

	/** Contacins the list of menus accessable to all users
	* 
	*
	* @var object
	*/
    private $menuListAlwaysAccess = array('login','forgot-password','searchme','searchme-preferences');

	/** Contains page that can only accessed by super admins
	* 
	*
	* @var object
	*/
    private $menuListSuperAdmin = array('plugins','pluginsnew');

	/** Contains the list of menus with global access
	* 
	*
	* @var object
	*/
    private $typePermissions = array("view","create","edit","delete");

	/** Constructure, Updates the default variables menuListRestricted and menuListGlobal
	* 
	*
    * @param void
	* @var null
	*/
    public function __construct(){
    }

	/** Checks weather currently logged user is a Super User or not
	* 
	*
    * @param void
	* @var boolean
	*/
	public function _isSuperUser(){

        $return = Admin :: _isSuperUser();

        $return = Plugins::_runAction('permissions_check_super_user', $return);
				
		 return $return;

	}

    /** Checks weather we have a chance to delete or depromote the current super admin
    *   The main purpose of this function is to have atleast one super admin
    *
    * @param Admin Id(int)
    * @var boolean
    */
    public function _checkSuperUserReplacement($idUser){

        $return = true;

        global $User;

        if( !$this->_isSuperUser() ){
            
             // Cheack weather current user is super admin or not
             // Only Super Admin Users can depromote super admins
            $return = false;
            
        }else if( $User -> idUser() != $idUser ){
            
            // if we are here, then the current user is a super admin users and we are not deleting current user
            // which means multiple super admin users and so we can allow the depromotion or deletion of the current admin user
            $return = true;
                        
        }else{

            // Checking weather there are any more super users except us
            $query      = "select * from ".Config::_getTable('users')." where `superUser` = :superUser and `idUser` != :idUser ";
            $arrayBind[]= array("key" => ":superUser",   "value" =>  1 );
            $arrayBind[]= array("key" => ":idUser"  ,    "value" =>  $idUser );
            
            // If condition satify then we are the only super admin, and we decline editing 
            if( Core::_getRowCount($query, $arrayBind) == 0 ){

                $return = false;

            }
            
        }

        $return = Plugins::_runAction('permissions_check_super_user_replacement', $return);
                
         return $return;

    }

	/** Returns the list of menus those can be accessed always
	* 
	*
    * @param void
	* @var array
	*/
	public function _getMenuListAlwaysAccess(){
	    
        $listMenus = $this->menuListAlwaysAccess;
    	
        $listMenus = Plugins::_runAction('permissions_menus_list_always_access', $listMenus);

		return $listMenus;

	}

    /** Returns the list of menus those can be accessed by super admin users only
	* 
	*
    * @param void
	* @var array
	*/
	public function _getMenuListSuperUseronly(){
	    
        $listMenus = $this->menuListSuperAdmin;
        
	    $listMenus = Plugins::_runAction('permissions_menus_list_super_user_only', $listMenus);
	    	
    	return $this->menuListSuperAdmin;

	}

	/** Checks weather we can assign permissions for the current file or not
	* 
	*
    * @param Menu link(string)
	* @var object
	*/
	public function _adminMenuPermissionAllowed($linkMenu){

        $return = true;

		if( in_array($linkMenu,$this->_getMenuListAlwaysAccess()) ){

            // Checking weather the file is allowed to access all the time or not.
            // if yes, then we can't set permissoins for that file
            $return = false;

		}else if( in_array($linkMenu,$this->_getMenuListSuperUseronly()) ){

            // Checking weather the file is only allowed for super admin users or not
            // if yes, then we can't set permissoins for that file
            $return = false;

		}

        $return = Plugins::_runAction('permissions_menus_permissions_allowed', $return);
		
		return $return;

	}

    /** Returns the filtered admin menus. This function removes always allowed and super admin only menus
    * 
    *
    * @param Admin Menus(array of objects)
    * @var Admin Menus( array of objects)
    */
    public function _filterPermissionsAllowed($adminMenus){
        
        foreach($adminMenus as $key => $tmpMenu){

            if( !$this->_adminMenuPermissionAllowed($tmpMenu->linkMenu) ){

                unset($adminMenus[$key]);

            }

        }

        $adminMenus = Plugins::_runAction('permissions_filter_permissions_allowed_admin_menus', $adminMenus);
        
        return $adminMenus;

    }

	/** Returns the filtered admin menus. This function removes the super admin only menus rows
	* 
	*
    * @param Admin Menus(array of objects)
	* @var Admin Menus( array of objects)
	*/
	public function _filterSuperUserMenus($adminMenus){
		
		foreach($adminMenus as $key => $tmpMenu){

			if( !$this->_getMenuListSuperUseronly($tmpMenu->linkMenu) ){

				unset($adminMenus[$key]);

			}

		}

        $adminMenus = Plugins::_runAction('permissions_filter_super_user_menus', $adminMenus);
        
		return $adminMenus;

	}

	/** prepares and returns the list of menus
    *  1. filters always allowed and super admin only menus
    *  2. Removes menus with empty or invalid links
    *  3. Appends multiple menus with same link   
	*  4. Returns the file menus
	*
    * @param Admin Menus(array of objects)
	* @var Admin Menus(array of objects)
	*/
	public function _prepareAdminMenusPermissions($adminMenus){
		
		$adminMenus = $this->_filterPermissionsAllowed($adminMenus);
		$adminMenusFiltered = array();
		
		global $Base;
		
		foreach($adminMenus as $key => $tmpMenu){

			if( $tmpMenu->linkMenu != '' && $Base->_prepareLink($tmpMenu->linkMenu) == $tmpMenu->linkMenu ){

				if( isset($adminMenusFiltered[$tmpMenu->linkMenu]) ){

					$adminMenusFiltered[$tmpMenu->linkMenu]->titleMenu .= ','.$tmpMenu->titleMenu;

				}else{

					$adminMenusFiltered[$tmpMenu->linkMenu] = $tmpMenu;

				}

			}

		}

        $adminMenusFiltered = Plugins::_runAction('permissions_prepare_admin_menus_permissions', $adminMenusFiltered);

		return $adminMenusFiltered;

	}

	/** Prepares the permissions row. Creates new row if no row exists
	* 
	*
    * @param Menu id.(int),Group id.(int)
	* @var null
	*/
	public function _preparePermissionsRow($idMenu,$idGroup){

		$query		= "select * from ".Config::_getTable('admin_permissions')." where `idGroup` = :idGroup and `idMenu` = :idMenu ";
		$arrayBind[]= array("key" => ":idGroup","value" =>  $idGroup);
		$arrayBind[]= array("key" => ":idMenu", "value" =>  $idMenu );
		
		if( Core::_getRowCount($query, $arrayBind) == 0 ){
		
			$query		= "insert into ".Config::_getTable('admin_permissions')." (`idGroup`,`idMenu`) values (:idGroup,:idMenu) ";
			unset($arrayBind);
			$arrayBind[]= array("key" => ":idGroup","value" =>  $idGroup );
			$arrayBind[]= array("key" => ":idMenu", "value" =>  $idMenu );
			
			Core::_runQuery($query, $arrayBind);

		}

        Plugins::_runAction('permissions_prepare_permissions_row', $idMenu, $idGroup);

	}

	/** Updates the admin permissions row // Highly secured. Don't changed unless critical
	* 
	*
    * @param Menu id.(int),Group id.(int),permissions
	* @var null
	*/
	public function _updatePermissionsRow($idMenu,$idGroup,$adminPermissions){

		$query		= "update ".Config::_getTable('admin_permissions')." set `view` = :view, `create` = :create, `edit` = :edit,`delete` = :delete where `idGroup` = :idGroup and `idMenu` = :idMenu";

		$arrayBind[]= array("key" => ":idGroup","value" =>  $idGroup );
		$arrayBind[]= array("key" => ":idMenu", "value" =>  $idMenu );
		$arrayBind[]= array("key" => ":view", 	"value" =>  $adminPermissions['view'] 	);
		$arrayBind[]= array("key" => ":create", "value" =>  $adminPermissions['create'] );
		$arrayBind[]= array("key" => ":edit", 	"value" =>  $adminPermissions['edit']	);
		$arrayBind[]= array("key" => ":delete", "value" =>  $adminPermissions['delete'] );

		Core::_runQuery($query, $arrayBind);

        Plugins::_runAction('permissions_update_permissions_row', $idMenu,$idGroup,$adminPermissions);
        
	}

	/** Prepares global permissions row. Creates new row if no row exists
	* 
	*
    * @param Menu id.(int)
	* @var null
	*/
	public function _prepareGlobalPermissionsRow($idMenu){

		$query		= "select * from ".Config::_getTable('admin_permissions')." where `idMenu` = :idMenu and `idGroup` = :idGroup ";
		$arrayBind[]= array("key" => ":idMenu",	"value" =>  $idMenu );
        $arrayBind[]= array("key" => ":idGroup","value" =>  0 );
		
		if( Core::_getRowCount($query, $arrayBind) == 0 ){
			
			$query		= "insert into ".Config::_getTable('admin_permissions')." (`idMenu`,`idGroup`) values (:idMenu,:idGroup) ";
			unset($arrayBind);
			$arrayBind[]= array("key" => ":idMenu", "value" =>  $idMenu );
            $arrayBind[]= array("key" => ":idGroup","value" =>  0 );
			
			Core::_runQuery($query, $arrayBind);
		}

        Plugins::_runAction('permissions_prepare_global_permissions_row', $idMenu);

	}
	
	/** Updates the admin global permissions row // Highly secured. Don't changed unless critical
	* 
	*
    * @param Menu id.(int),permissions
	* @var null
	*/
	public function _updateGlobalPermissionsRow($idMenu,$adminPermissions){

		$query		= "update ".Config::_getTable('admin_permissions')." set `view` = :view, `create` = :create, `edit` = :edit,`delete` = :delete where `idMenu` = :idMenu and idGroup = :idGroup ";

        $arrayBind[]= array("key" => ":idMenu", "value" =>  $idMenu );
        $arrayBind[]= array("key" => ":idGroup","value" =>  0 );
		$arrayBind[]= array("key" => ":view", 	"value" =>  $adminPermissions['view'] 	);
		$arrayBind[]= array("key" => ":create", "value" =>  $adminPermissions['create'] );
		$arrayBind[]= array("key" => ":edit", 	"value" =>  $adminPermissions['edit']	);
		$arrayBind[]= array("key" => ":delete", "value" =>  $adminPermissions['delete'] );

		Core::_runQuery($query, $arrayBind);

        Plugins::_runAction('permissions_update_global_permissions_row', $idMenu,$adminPermissions);
        
	}

	/** Checks and prepares the permissions page link
	* 
	*
    * @param Page link.(string)
	* @var Converted Page link.(string)
	*/
	private function _preparePermissionsPage($linkPage){

		// File not exists means the link is given directly and we don't need to modify it 		
		if( !file_exists($linkPage) ){
		    
			$fileName = $linkPage;
			
		}else{
            
            // getting file details		    
            $pathinfo = pathinfo($linkPage);
    
            $fileName = $pathinfo['filename'];
            
            // getting the relative path of the file(relative path to quikc installation folder) 
            $relativeFile = str_ireplace(Config::_getDir(),'',$linkPage);

            // Checking if the file belongs to plugins             
            if(substr($relativeFile, 0, 8) == '/plugins'){
                $linkParts = explode("/",$relativeFile);
                $idPlugin = $linkParts[2];
                $fileName = $idPlugin.'-'.$fileName;
            }
		}

        $fileName = Plugins::_runAction('permissions_prepare_permissions_page', $fileName, $linkPage);

		return $fileName;

	}
	
	/** Updates the admin permissions row // Highly secured. Don't changed unless critical
	* 
	*
    * @param Menu id.(int),Admin id.(int),permissions
	* @var null
	*/
	public function _checkPagePermission($linkPage,$typePermission){
	    
        $return = false;
		
		$linkPage = $this->_preparePermissionsPage($linkPage);

        global $Admin, $User;
        
		if( in_array($linkPage,$this->_getMenuListAlwaysAccess()) ){
		    
            // Comparing the permission type with the always access permissions
            // userful to identify the lists which can be accesable always like not logged in menus(login etc) 
            $return = true;

		}else if( !$Admin->_isLogged() ){
		    
            // returnging false since the user is not logged in and the menus is not always accessable
            $return = false;
        
		} else if( !in_array($typePermission,$this->typePermissions) ){
		    
		    // Comparing the permission type with the default permissions list like view, create, edit, delete
            $return = false;
        
  		}else if( $this->_isSuperUser() ){
  		        
            // Checking super admin level
            $return = true;
                        
  		}else if( in_array($linkPage,$this->_getMenuListSuperUseronly()) ){
  		    
            // Checking for Super Admin only access files
            $return = false;
            
  		}else if( $this->_getAdminPageGlobalPermissions($linkPage)->$typePermission == 1 ){

            // Checking for the Global Permissions
            $return = true;
                        
  		}else if($this->_getAdminPageUserGroupsPermissions($linkPage,$User -> idUser() ,$typePermission)){
  		    
            // Checking the individual permissions of the user
            $return = true;
                        
  		}

        $return = Plugins::_runAction('permissions_check_page_permission', $return,$linkPage,$typePermission);
	
		return $return;

	}

	/** Checks weather any groups of current user allow current tyep of permissoins for the current link or not  
	* 
	*
    * @param Menu id.(int),Admin id.(int), Permission Type(string)
	* @var boolean
	*/
	private function _getAdminPageUserGroupsPermissions($linkPage,$idUser,$typePermission){

        $return = false;
        
		global $User;

		// List of groups admin member of
		$user_groups = explode(",",$User -> groupsUser() );

		foreach($user_groups as $idGroup){

			if( $this->_getGroupPagePermissions($linkPage,$idGroup)->$typePermission ){

			    $return = true;

                break;

			}

		}

        $return = Plugins::_runAction('permissions_check_page_user_groups_permission', $return,$linkPage,$idUser,$typePermission);

		return $return;

	}

	/** Returns group permissions for the given page
	* 
	*
    * @param link Page.(string),Group id.(int)
	* @var Group Permissions(object)
	*/
	public function _getGroupPagePermissions($linkPage,$idGroup){

		$permissions = (object) array("view" => 0, "create" => 0, "edit" => 0, "delete" => 0);

		global $User;

		if( $idGroup != '' && $User->_getUserGroupDetailsById($idGroup) && $User->_getUserGroupDetailsById($idGroup)->statusGroup){
    
    		$query = "select `view`,`create`,`edit`,`delete` from ".Config::_getTable('admin_permissions')." ap, ".Config::_getTable('admin_menus')." am where am.idMenu = ap.idMenu and ap.`idGroup` = :idGroup 
    		and am.`linkMenu` = :linkPage ";
    		$arrayBind[]= array("key" => ":idGroup",	"value" => $idGroup );
    		$arrayBind[]= array("key" => ":linkPage",	"value" =>  $linkPage);
    
			$dbPermissions = Core::_getRow($query, $arrayBind);
			
			if( $dbPermissions ){
			    
                $permissions = $dbPermissions;
                
			}
			
        }
        
        $permissions = Plugins::_runAction('permissions_get_group_page_permissions', $permissions,$linkPage,$idGroup);
		
		return $permissions;

	}

	/** Returns the global permissions for the given page
	* 
	*
    * @param link Page(string)
	* @var null
	*/
	public function _getAdminPageGlobalPermissions($linkPage){

		$permissions = (object) array("view" => 0, "create" => 0, "edit" => 0, "delete" => 0);

		$query		= "select `view`,`create`,`edit`,`delete` from ".Config::_getTable('admin_permissions')." ap, ".Config::_getTable('admin_menus')." am where am.idMenu = ap.idMenu and ap.`idGroup` = :idGroup 
		and am.`linkMenu` = :linkPage ";
        $arrayBind[]= array("key" => ":idGroup",  "value" =>  0 );
		$arrayBind[]= array("key" => ":linkPage", "value" =>  $linkPage);

        $dbPermissions = Core::_getRow($query, $arrayBind);
        
        if( $dbPermissions ){
            
            $permissions = $dbPermissions;
            
        }

        $permissions = Plugins::_runAction('permissions_get_global_page_permissions', $permissions,$linkPage);
        
		return $permissions;

	}

}

