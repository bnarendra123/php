<?php

defined('QC_VALID') or die('Restricted Access!');

/**
* Admin class, used for processing admin related actions
* This is an extended class of User class
* All admin related basic will be processed from here. Please don't change unless critical
*
* @version 1.0
* @http://www.quikc.org/
*/
class Admin extends User{

    /** Contains the list of Admin Tables
    * 
    *
    * @var object
    */
    private static $adminTables = array("user","user_groups","user_log_activity","admin_menus","admin_permissions","plugins");

    /** Returns admin tables list
    * 
    *
    * @param void
    * @var Admin Deails(object)
    */
    private static function _adminTables(){

        return $this->$adminTables;

    }

    /** Checks weather the given table is a admin or not
    * 
    *
    * @param string(table name)
    * @var true/false(boolean)
    */
    public static function _isAdminTables($nameTable){

        if( in_array($nameTable,self::$adminTables) ){

            return true;

        }        

        return false;

    }

	/** Returns currently logged in user details
	* 
	*
    * @param void
	* @var user deails(object)
	*/
    public static function _userDetails(){
        
		$detailsUser = parent::_userDetails();

		// will return the details of the user as admin user if the current user is allowed to login to the admin panel
		// step 1: $detailsUser this will check weather the user is logged in or not. If he is not logged in then the condition fails
		// step 2: ($detailsUser->adminUser || $detailsUser->superUser)
		//		   $detailsUser->adminUser will check weather the current user is an admin user or not.
		//  	   $detailsUser->superUser will check weather the current user is a super admin user or not
		//		   If any of the above two conditions valids, means the user is admin user or super admin user then he has the right to login to the admin panel
		// step 3: ( !Config::_get('login.allow.only.super.admins') || $detailsUser->superUser)
		//		   This will check weather the login is allowed only for super admin users and the current user is super admin user or not
		//		   Config::_get('login.allow.only.super.admins') if this is true, which means, the admin login is allowed only for the super admin users. Now we have to check weather the current user is an super admin user or not. this will be done with the below condition
		//  	   $detailsUser->superUser will check weather the current user is a super admin user or not.
		//		   if the condition is on, for only super admin users to login to admin pane, this will do it. 
		if( !$detailsUser || ( !$detailsUser->adminUser && !$detailsUser->superUser ) || ( Config::_get('login.allow.only.super.admins',false) && !$detailsUser->superUser ) ){

            $detailsUser = false;

		}
        
        $detailsUser = Plugins::_runAction('admin_user_details', $detailsUser);
        
		return $detailsUser;

    }

    /** checks and returns the admin logged status of the current session
    * 
    *
    * @param void
    * @var boolean
    */
    public static function _isLogged(){
        
        $return = false;

        // checking weather the user is logged in as admin or not
        if( self :: _userDetails() ){

            $return = true;

        }        
        
        $return = Plugins::_runAction('admin_islogged', $return);
        
        return $return;

    }

    /** checks weather user details for the given key if exists
    * 
    *
    * @param function name(string), $params(parameters)
    * @var mixed
    */
    public static function __callstatic($fun, $params){
        
        if( self :: _isLogged() ){

            $du = self :: _userDetails();
            
            if( isset($du -> $fun) ){

                return $du -> $fun;

            }

        }

    }
    
    /** checks weather user details for the given key if exists
    * 
    *
    * @param function name(string), $params(parameters)
    * @var mixed
    */
    public function __call($fun, $params){
        
        return self :: __callstatic($fun, $params);

    }

    /** Checks weather currently logged user is a Super User or not
    * 
    *
    * @param void
    * @var boolean
    */
    public static function _isSuperUser(){

        $return = false;

        // checks and returs the boolean value of true/false 
        // if the user is super user, then returns true
        // otherwise returns false
        // step 1: checking we the user logged in or not
        
        if( self :: _isLogged() && self :: superUser() == 1 ){
            
            $return = true;
        }
        
        $return = Plugins::_runAction('permissions_check_super_user', $return);
                
         return $return;

    }

	/** Returns list of admin users
	* 
	*
    * @param void
	* @var Admin users Deails(array of object)
	*/
    public function _getAdmins(){
    	
		$query	= "select * from ".Config::_getTable('users')." where adminUser = :adminUser or superUser = :superUser order by nameFirstUser asc";
		$arrayBind[]= array("key" => ":adminUser", "value" =>  1 );
		$arrayBind[]= array("key" => ":superUser", "value" =>  1 );

        $listAdmins = Core::_getAllRows($query, $arrayBind);

        $listAdmins = Plugins::_runAction('admin_admins_list', $listAdmins);
		
        return $listAdmins;

    }

    /** Return the no of active admin users
    * 
    *
    * @param void
    * @var null
    */
    public function _getActiveAdminsCount(){
    
        $query    = "select * from ".Config::_getTable('users')." where ( adminUser = :adminUser or superUser = :superUser ) and `statusUser` = :statusUser  ";
        $arrayBind[]= array("key" => ":adminUser", "value" =>  1 );
        $arrayBind[]= array("key" => ":superUser", "value" =>  1 );
        $arrayBind[]= array("key" => ":statusUser", "value" =>  1 );
        $noAdmins = Core::_getRowCount($query, $arrayBind);

        $noAdmins = Plugins::_runAction('admin_active_admins_count', $noAdmins);

        return $noAdmins;

    }


    /** Return the no of active super admin users
    * 
    *
    * @param void
    * @var null
    */
    public function _getActiveSuperUsersCount(){
    
        $query    = "select * from ".Config::_getTable('users')." where superUser = :superUser and `statusUser` = :statusUser  ";
        $arrayBind[]= array("key" => ":superUser", "value" =>  1 );
        $arrayBind[]= array("key" => ":statusUser", "value" =>  1 );
        $noAdmins = Core::_getRowCount($query, $arrayBind);

        $noAdmins = Plugins::_runAction('admin_active_super_users_count', $noAdmins);

        return $noAdmins;

    }

    /**
    * Returns the system using type(developer/normal)
    *
    * @param void()
    * @return null
    */
    public function _isDeveloperMode(){
            
        $return = false;
        
    	if( Config::_get('developer.mode.global',false) ){

            // Enabling the developer mode if the global developer mode is enabled          
            $return = true; 
            
        }else if( !$this->_allowedDeveloperMode() ){

            // Checking weather the developer mode is allowed for the user or not
            $return = false; 
            
        }else if( !is_null( $this -> loginModeUser() ) && $this -> loginModeUser() ){
            
            // Checking weather the user actived developer or not
            $return = true;
            
        }

        $return = Plugins::_runAction('admin_user_is_developer_mode', $return);
        
        return $return;

    }
    
    /**
    * This will check weather the developer mode is allowed for the user or not.
    *
    * @param void()
    * @return boolean
    */
    public function _allowedDeveloperMode(){

        $return = true;

        global $Permissions;
                
        if(!Config::_get('developer.mode',false)){

            // Checking the Developer Modes Status
            $return = false; 
  
        }else if( !$this->_isLogged() ){
            
            // Return false if the admin is not logged in 
            $return = false; 
                        
        }else if( Config::_get('developer.mode.super.admins.only',false) && !$this->_isSuperUser() ){

            $return = false; 
            
        }

        $return = Plugins::_runAction('admin_user_allowed_developer_mode', $return);

        return $return;

    }
    
    /**
    * This will check weather the developer mode is allowed for the user or not.
    *
    * @param void()
    * @return boolean
    */
    public function _developerModeActions(){
        
        $return = true;
        
		if(!$this->_isDeveloperMode()){

            $return = false;

		}else if(!Config::_get('developer.mode.display.helper')){

            $return = false;

		}

        $return = Plugins::_runAction('admin_user_developer_mode_actions', $return);
		
		return $return;

    }

    /**
    * This will include the devemoper mode actions
    *
    * @param void()
    * @return null
    */
	public function _displayDeveloperModeActions(){

		if(!$this->_developerModeActions()){

            return false;    

		}

        $fileInclude = 'elements/developerhelper.phtml';
		
        $fileInclude = Plugins::_runAction('admin_user_developer_mode_actions_file_include', $fileInclude);

        global $Themes;
		
		$Themes->_inc($fileInclude); 

	}

}
