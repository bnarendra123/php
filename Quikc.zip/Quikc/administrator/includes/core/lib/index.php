<?php

die('Restricted Access');
