<?php

defined('QC_VALID') or die('Restricted Access!');

Config::_setTable('admin'                   , 'admin' );
Config::_setTable('admin_authenticate'      , 'admin_authenticate' );
Config::_setTable('admin_menus'             , 'admin_menus' );

Config::_setTable('admin_permissions'       , 'admin_permissions' );
Config::_setTable('admin_permissions_global', 'admin_permissions_global' );
Config::_setTable('admin_recover_code'      , 'admin_recover_code' );

