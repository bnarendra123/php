<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if(file_exists(Config::_getDir('admin').'/includes/custom/application_bottom.php')){

    include_once Config::_getDir('admin').'/includes/custom/application_bottom.php';

}

$Themes->_incAdminTemplate();

$Admin->_displayDeveloperModeActions();