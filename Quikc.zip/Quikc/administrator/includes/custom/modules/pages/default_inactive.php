<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( $Lists->_checkListsPage($Page) ){

    $loadPage = 'pageLoad("get/list/'.$Page.'")';

}else if( $Forms->_checkFormsPage($Page) ){

    $loadPage = 'generateEditor("get/edit/'.$Page.'","edit")';

}else{

	if($Plugins->_checkPluginLink($Page)){

        $Plugins->_loadPluginPage($Plugins->_generatePluginIdentifier($Page),$Plugins->_generatePluginPage($Page));

	}

}

