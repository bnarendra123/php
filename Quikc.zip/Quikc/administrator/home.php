<?php

define('QC_VALID', true);
define('QC_ADMIN', true);
define('QC_LOGGED', true);

require 'includes/core/application_top.php';

$Page = $Themes->_getCurrentAdminPage();

if( $Permissions->_checkPagePermission($Page,'view') ){

	/* Including the modules pages
	 * 
	 * 1. First checking for the file in custom modules 
	 * 2. If the file doesn't exists in custome modules then checkng for the file in core modules
	 * 3. If the file doesn't exists in core modules also then checkng for the default file in custom modules
	 * 4. If none of the above files exists then includes the default file from core modules
	 * 
	 */

	if( file_exists('includes/custom/modules/pages/'.$Page.'.php') ){

		// Including the modules page from the custom modules
        include 'includes/custom/modules/pages/'.$Page.'.php';	    

	}else if( file_exists('includes/core/modules/pages/'.$Page.'.php') ){

		// Including the modules page from the core modules
        include 'includes/core/modules/pages/'.$Page.'.php';     

	}else if( file_exists('includes/custom/modules/pages/default.php') ){

		// Including the default modules page from the custom modules
        include 'includes/custom/modules/pages/default.php';     

	}else{

		// Including the default modules page from the core modules
        include 'includes/core/modules/pages/default.php';     

	}
	
}else if($Page != '') {
    
    $Themes->_setCurrentAdminPage('raccess');

	if( file_exists('includes/custom/modules/pages/raccess.php') ){

        include 'includes/custom/modules/pages/raccess.php';	    

	}else{

        include 'includes/core/modules/pages/raccess.php';     

	}

}

require 'includes/core/application_bottom.php';
