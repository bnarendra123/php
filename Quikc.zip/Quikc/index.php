<?php

define('QC_VALID', true);
define('QC_NOTLOGGED', true);

require 'includes/core/application_top.php';

if( $Themes->_getCurrentPage() ){

	$moduleFile = $Themes->_getCurrentPageDetails() -> linkPage;
	
	if( file_exists(Config::_getDir().'/includes/custom/modules/pages/'.$moduleFile.'.php') ){

		// Including modules page from the custom modules
	    include Config::_getDir().'/includes/custom/modules/pages/'.$moduleFile.'.php';

	}else if( file_exists(Config::_getDir().'/includes/core/modules/pages/'.$moduleFile.'.php') ){

		// Including modules page from the core modules
	    include Config::_getDir().'/includes/core/modules/pages/'.$moduleFile.'.php';

	}

}

require 'includes/core/application_bottom.php';

