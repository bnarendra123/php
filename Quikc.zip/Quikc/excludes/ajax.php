<?php

define('QC_VALID', true);
define('QC_AJAX', true);

require '../includes/core/application_top.php';

if (isset($_GET['action'])){

    $Action = $_GET['action'];
    
}else{

    $Action = '';
    
}


if( file_exists(Config::_getDir().'/includes/custom/modules/ajax/'.$Action.'.php') ){
	
    include Config::_getDir().'/includes/custom/modules/ajax/'.$Action.'.php';

}else if( file_exists(Config::_getDir().'/includes/core/modules/ajax/'.$Action.'.php') ){

    include Config::_getDir().'/includes/core/modules/ajax/'.$Action.'.php';

}
    
    
