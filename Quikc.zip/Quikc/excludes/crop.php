<?php
extract($_POST);
$imageType = end(explode(".",$src));

$t_width = 512;	// Maximum thumbnail width
$t_height = 384;	// Maximum thumbnail height

$img = $src;

$h = $height;
$w = $width;

$ratio = ($t_width/$w); 
$nw = ceil($w * $ratio);
$nh = ceil($h * $ratio);
$nimg = imagecreatetruecolor($nw,$nh);
if($imageType == 'png' || $imageType == 'PNG' ){
	$new_name = 'user_picture_'.$idUser.'_'.time().'.png';
	$im_src = imagecreatefrompng($img);
	imagecopyresampled($nimg,$im_src,0,0,$x1,$y1,$nw,$nh,$w,$h);
	imagepng($nimg,$path.$new_name,9);
}else if($imageType == 'jpg' || $imageType == 'jpeg' || $imageType == 'JPG' || $imageType == 'JPEG'){
	$new_name = 'user_picture_'.$idUser.'_'.time().'.jpg';
	$im_src = imagecreatefromjpeg($img);
	imagecopyresampled($nimg,$im_src,0,0,$x1,$y1,$nw,$nh,$w,$h);
	imagejpeg($nimg,$path.$new_name,9);
}else if($imageType == 'gif' || $imageType == 'GIF'){
	$new_name = 'user_picture_'.$idUser.'_'.time().'.gif';
	$im_src = imagecreatefromgif($img);
	imagecopyresampled($nimg,$im_src,0,0,$x1,$y1,$nw,$nh,$w,$h);
	imagegif($nimg,$path.$new_name,9);
}

$sql = "update ab_user_picture SET srcPicture='".$new_name."'  WHERE idUser = '".$idUser."'";
$res = Core::_runQuery($sql,$arrayBind);


?>
