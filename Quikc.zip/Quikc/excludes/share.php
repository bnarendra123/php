<?php

define('QC_VALID', true);
define('QC_NOTLOGGED', true);
require '../includes/core/application_top.php';

$fb_user = $facebook->getUser();

if ($fb_user) {
	
	$fb_profile = $facebook->api('/me');
	
	echo '<pre>';
	print_r($fb_profile);
	/*print_r($fb_profile);
	
	die('hi');*/
	
	//$albums = $facebook->api('/me?fields=albums');
	
	/*foreach($albums['albums']['data'] as $album){
		if($album['type'] == 'wall'){
			$timeline_id = $album['id'];
			break;
		}
	}*/
	
	/*if($timeline_id == '')$timeline_id = 'me';*/
	
	/*$photo_details = array(
		"message" => $_GET['desc'] . ' - please visit http://www.imediatube.com/albums for more pics',
		"url"	 => 'http://imediatube.com/cfz_image.php?image=https://s3.amazonaws.com/imediatube.media/photos/'.$_GET['id'].'.jpg'
	);*/
	
	$page_details = array('link'=> 'http://confianza.me/assetbank/100dreams/', 'message' => 'I earned 10 LDP on Assetbank - please visit assetbank');
	
	/*$access_token = $facebook->getAccessToken();
	
	$facebook->setAccessToken($access_token);*/
	
	$fb_profile = $facebook->api('/me');

	$share_link = $facebook->api('/'.$fb_profile['id'].'/feed','post', $page_details);
	
	echo '<pre>';
	var_dump($share_link);
	
	die('fdg');
	
	if($share_link){
		echo 'ok';
	}else{
		echo 'fail';
	}
	
} else {
	
	echo 'login-fail';
	
	/*$params = array('scope' => 'user_photos,publish_actions,photo_upload,share_item');
  	$loginUrl = $facebook->getLoginUrl($params);
  	echo '<script>document.location = "'.$loginUrl.'";</script>';*/ 

}