<?php

define('QC_VALID', true);
define('QC_AJAX', true);

require '../includes/core/application_top.php';

$facebook = new Facebook(array(
	  'appId'  => Config::_get('fb.app.id'),
	  'secret' => Config::_get('fb.app.secret'),
));
	
$user_profile = $facebook->api('/me');
	
$user_profile['access_token'] = $_SESSION['accessToken'] = $facebook->getAccessToken();

$fb_status = checkFacebookUser($user_profile);

$missed_fields = getUserMissedFields();

if($fb_status && $missed_fields){
	
	echo '<script>
		function reloadParentAndClosePopup(){
			if(window.opener && !window.opener.closed){
				window.close();
				window.opener.location.href = "'.Config::_getUrl().'/process/";
			}
		}
		reloadParentAndClosePopup();
		</script>';
	
}else if($fb_status && !$missed_fields){
	
	echo '<script>
		function reloadParentAndClosePopup(){
			if(window.opener && !window.opener.closed){
				window.close();
				window.opener.location.href = "'.Config::_getUrl().'/process/";
			}
		}
		reloadParentAndClosePopup();
		</script>';
	
}else{
	
	$fb_user = null;
	$facebook->destroySession();
	
	echo '<script>
		function reloadParentAndClosePopup(){
			if(window.opener && !window.opener.closed){
				window.close();
				window.opener.location.reload();
			}
		}
		</script>';
		
		
	echo '<h2 style="font-family:calibri;color:#2296DC !important;">Login failed due to some reasons. Please try again later.</h2><br>
	<input type="button" value="Try Again" onclick="reloadParentAndClosePopup();">';
	
}

die();
