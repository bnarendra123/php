<?php
defined('QC_VALID') or die('Restricted Access!');

$User->_authenticateUser();
