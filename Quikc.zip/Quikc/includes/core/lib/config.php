<?php

 /* Config file for quikc 
 * 
 * This file contains the basic details to run quikc.
 *  those details includes database database host, database user name, database password, database name and database prefix, website url
 * 
 */
 
defined('QC_VALID') or die('Restricted Access!');

// your database type comes here
// generaly value will be mysql
Config::_set('db.type'	, 'mysql' );

// your database host 
// if you are running on local server or system, this values might be 127.0.0.1 or localhost
Config::_set('db.host'	, 'localhost' );

// your database username
Config::_set('db.user'	, 'root' );

// your database password 
Config::_set('db.pass'	, '' );

// your database name
Config::_set('db.name'	, 'eaglecloths' );

// your database port
//Config::_set('db.port'	, '5432');

// your website url
Config::_set('base.url' , "http://127.0.0.1:8080/eaglecloths/");

// your database password 
Config::_set('key.site'  , 'adAasd78123Kasd_adsas_123Kasd' );
