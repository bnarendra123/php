<?php

defined('QC_VALID') or die('Restricted Access!');

//Cms Related Tables
Config::_setTable('themes'                  , 'cms_themes' );
Config::_setTable('pages'                   , 'cms_pages' );
Config::_setTable('sets'                    , 'cms_sets' );
Config::_setTable('sets_tables'             , 'cms_sets_tables' );
Config::_setTable('sets_options'            , 'cms_sets_options' );
Config::_setTable('messages_log'            , 'cms_messages_log' );

// Plugins related tables
Config::_setTable('plugins'                  , 'plugins' );

