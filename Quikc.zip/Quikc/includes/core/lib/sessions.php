<?php
defined('QC_VALID') or die('Restricted Access!');

ini_set('session.name', 'quikc_'.Config::_get('key.site'));
ini_set('session.use_cookies', 1);
ini_set('session.use_only_cookies', 0);
//ini_set('session.gc_maxlifetime', intval($config['session_lifetime']));

session_start();
