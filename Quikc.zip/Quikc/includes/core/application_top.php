<?php

defined('QC_VALID') or die('Restricted Access!');

define('_START_TIME', microtime(true));
define('_START_MEMO', memory_get_usage());

// Including the config classs
require dirname(dirname(dirname(__FILE__))) . '/includes/core/classes/config.php';

// Creating the instance for the config class
$Config = new Config;
// calling init to generate the base dir and base url paths
$Config -> init();

require Config::_getDir() . '/includes/core/classes/core.php';

// Now including config file, to configure all default config variables
if( file_exists(Config::_getDir() . '/includes/custom/lib/config.php') ) {

	// including config file from custom folder	
	require Config::_getDir() . '/includes/custom/lib/config.php';

}else{

	// Config file missing
	// going through the installer once again
	require Config::_getDir() . '/includes/core/classes/installer.php';

	$Installer = new Installer;
	$Installer -> _runProcess();

}


// Loading the basic configuration values like developer mode, cache status etc
$Config -> _loadBasicConfigs();

require Config::_getDir() . '/includes/core/lib/sessions.php';
require Config::_getDir() . '/includes/core/lib/database_tables.php';
require Config::_getDir('admin', false) . '/includes/core/lib/database_tables.php';
require Config::_getDir() . '/includes/core/classes/validate.php';
require Config::_getDir() . '/includes/core/classes/user.php';
require Config::_getDir('admin') . '/includes/core/classes/admin.php';

$Validate = new Validate;
$User = new User;
$Admin = new Admin;

require Config::_getDir() . '/includes/core/classes/plugins.php';
$Plugins = new Plugins;

require Config::_getDir() . '/includes/core/classes/base.php';
$Base = new Base;

require Config::_getDir() . '/includes/core/classes/cache.php';

$Config -> _setSystem();

require Config::_getDir() . '/includes/core/lib/authenticate.php';

$Config -> _setLogs();

require Config::_getDir() . '/includes/core/classes/themes.php';
$Themes = new Themes;
$Themes->_rewriteUrl();

require Config::_getDir() . '/includes/core/classes/cms.php';
require Config::_getDir() . '/includes/core/classes/menus.php';
require Config::_getDir() . '/includes/core/classes/mail.php';
require Config::_getDir() . '/includes/core/classes/languages.php';
require Config::_getDir() . '/includes/core/classes/relations.php';

$Cms = new Cms;
$Menus = new Menus;
$Languages = new Languages;
$Relations = new Relations;

require Config::_getDir() . '/includes/core/classes/editor.php';
$Editor = new Editor;

require Config::_getDir() . '/includes/core/classes/spaces.php';
require Config::_getDir() . '/includes/core/classes/widgets.php';
$Widgets = new Widgets;

require Config::_getDir() . '/includes/core/classes/ajax.php';
$Ajax = new Ajax;

$Plugins -> _loadAutoLoadPlugins();

// Check current instance access
$Config -> _checkAccess();

if($Config->_get('website.offline')){

	$Base->_websiteOffline();

}

$Themes->_generateCurrentPage();

if( file_exists(Config::_getDir() . '/includes/custom/application_top.php') ) {

	include_once Config::_getDir() . '/includes/custom/application_top.php';

}

if( $Themes->_getCurrentPageDetails()->requireLogin && !User::_isLogged() ){

	$Base->_pageRedirect(Config::_getUrl());

}
