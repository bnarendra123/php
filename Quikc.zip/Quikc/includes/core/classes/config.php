<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * Config class, used for getting and setting the configure varialbes
 * Paths of all elements will be processed from here. Please don't change unless critical
 *
 * @version 1.0
 * @http://www.quikc.org/
 */
class Config {

	/** $confArray contains all the config variables
	 *
	 *
	 * @var array of strings
	 */
	private static $confArray;

	/** $confDbArray contains all the database table names
	 *
	 *
	 * @var array of strings
	 */
	private static $confDbArray;

	/** $confMessagesArray contains all the messages once retrieved from the database
	 *
	 *
	 * @var array of strings
	 */
	private static $confMessagesArray;

	/** $confCssFiles contains the list of css files to be added
	 *
	 *
	 * @var array of strings
	 */
	private static $confCssFiles = array();

	/** sets the default values base url and the directory
	 *
	 *
	 * @param void
	 * @var null
	 */
	public function init() {

		self::_set('base.dir', dirname(dirname(dirname(dirname(__FILE__)))));
		self::_set('base.url', self::_generateBaseUrl());
	}

	/** returns the base url of the current website
	 *
	 *
	 * @param void
	 * @var null
	 */
	public function _generateBaseUrl() {

		// Finds the server mode weather http or https
		$url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != "off") ? "https" : "http";

		// Getting the main url like httpL//www.quikc.org
		$url = $url . "://" . $_SERVER['HTTP_HOST'];

		// replacing %20 with space to get the url like /confianza cms
		$postUrlPart = str_replace("%20", " ", $_SERVER['REQUEST_URI']);

		// Getting the directory name of the base folder like html or website1
		$baseDirectory = basename(self::_get('base.dir'));

		// Getting the cxcluding path if the files are not in the main folder
		$excludePath = strstr($postUrlPart, $baseDirectory);

		// If the files are in sub folder then then value will be true
		if ($excludePath) {

			// Now replacing the directorys to be excluded from the excluded path
			// Since it will replace the base folder name also, we need to add the path to get the complete url and apped it to the $url
			$url = $url . str_replace($excludePath, "", $postUrlPart) . $baseDirectory;
		}

		return $url;
	}

    /** This function will load all the basic config values. These values are not cached
     *
     *
     * @param void
     * @var null
     */
	public function _loadBasicConfigs() {

		$baseConfigs = array(
		                      'cache.server', 
		                      'cache.path', 
		                      'cache.file.extension', 
		                      'cache.enabled', 
		                      'cache.time.limit', 

		                      'developer.mode.global',
		                      'developer.mode.caching', 
		                      'developer.mode', 
		                      'developer.mode.super.admins.only', 
		                      'developer.mode.display.helper',
                           );

		if (!defined('QC_ADMIN')){

            $baseConfigs[] = 'admin';

		}

		$query = "select * from " . Config::_getTable('configuration') . " where `keyConfig` in ('" . implode("', '", $baseConfigs) . "') and `statusConfig` = :statusConfig";
		$arrayBind[] = array("key" => ":statusConfig", "value" => 1);
		$configurationDetails = Core::_getAllRows($query, $arrayBind);

		foreach ($configurationDetails as $tmpConfig) {
		    
			self::_set($tmpConfig -> keyConfig, $tmpConfig -> valueConfig);
			
		}

		
	}

    /** This function will check wether access is allowed for the current instance or not
     *
     *
     * @param void
     * @var null
     */
    public function _checkAccess() {

        $checkAccess = false;
        
        $currentIp = $_SERVER['REMOTE_ADDR'];

        // Checking if all the ips are blocked except allowed
        if( Config::_get('website.ips.all') ){
            
            $allowedIps = Config::_get('website.ips.allow');

            if( $allowedIps != '' && in_array($currentIp, explode(",",$allowedIps) )){

                $checkAccess = true;

            }
            
        }else{

            $blockedIps = Config::_get('website.ips.block');

            if( $blockedIps == '' || !in_array($currentIp, explode(",",$blockedIps) )){

                $checkAccess = true;

            }

        }

        $checkAccess = Plugins::_runAction('config_check_access', $checkAccess, $currentIp);
        
        if( $checkAccess ) return $checkAccess;
        
        global $Base;
        $Base->_websiteBlocked();

    }

	/** Sets the element with the given key
	 *
	 *
	 * @param key,value
	 * @var null
	 */
	public static function _set($key, $value) {

		self::$confArray[$key] = $value;

	}

	/** Returns the exact config value
	 *
	 *
	 * @param config key(string),cache status(boolean)
	 * @var config value(string)
	 */
	public static function _get($key, $cache = true) {

		if (!isset(self::$confArray[$key])){
		    
            if (!self::_updateConfig($key, $cache)){

                return;

            }

		}

		return self::$confArray[$key];
	}

	/** Removes existing config value
	 *
	 *
	 * @param config key(string)
	 * @var null
	 */
	public static function _remove($key) {

		if (isset(self::$confArray[$key])){

            self::$confArray[$key] = NULL;
		    
		}

	}

	/** Removes existing config value
	 *
	 *
	 * @param config key(string)
	 * @var null
	 */
	public static function _removeAll() {

		unset(self::$confArray);

	}

    /** Returns the configuration  details
    * 
    *
    * @param config Id(int),
    * @var object
    */
    public static function _loadConfigValue($idConfig){

        $query  = " select * from ".Config::_getTable('configuration')."  where idConfig = :idConfig ";
        $arrayBind[]= array("key" => ":idConfig", "value" =>  $idConfig );

        $detailsConfig = Core::_getRow($query,$arrayBind);

        $detailsConfig = Plugins::_runAction('config_load_config_value', $detailsConfig, $idConfig);

        return $detailsConfig;

    }

	/** Checks weather the given configuration for the given key exists in the database or not and updates if the key exists in the database
	 *
	 *
	 * @param config key(string)
	 * @var boolean
	 */
	public static function _updateConfig($key, $cache) {

		if ($cache && Cache::_getInstance() -> _isCached('config_configuration_value_' . $key)) {

			$configurationDetails = Cache::_getInstance() -> _getCache('config_configuration_value_' . $key);

		} else {

			$query = "select * from " . Config::_getTable('configuration') . " where `keyConfig` = :keyConfig and `statusConfig` = :statusConfig";
			$arrayBind[] = array("key" => ":keyConfig", "value" => $key);
			$arrayBind[] = array("key" => ":statusConfig", "value" => 1);

			$configurationDetails = Core::_getRow($query, $arrayBind);

			if (!isset($configurationDetails -> keyConfig)) {

                $configurationDetails = Plugins::_runAction('config_update_config_no_key', $configurationDetails, $key, $cache);

                if (!isset($configurationDetails -> keyConfig)) {

    				return false;

                }

			}

			// Updating the cache if config value exists
			if ($cache){

                Cache::_getInstance() -> _setCache('configuration_value_' . $key, $configurationDetails);
			    
			}
            
		}

        $configurationDetails = Plugins::_runAction('config_update_config', $configurationDetails, $key, $cache);

		self::_set($configurationDetails -> keyConfig, $configurationDetails -> valueConfig);

		return true;

	}

	/** Updates/Creates the configuration entry with the given key or value
	 *
	 *
	 * @param config key(string),config value(string)
	 * @var boolean
	 */
	public static function _updateDbConfigEntry($keyConfig, $valueConfig, $statusConfig = 1, $systemItem = 1, $createdById = '', $createdByType = 'user') {

		$query = "select * from " . Config::_getTable('configuration') . " where `keyConfig` = :keyConfig";
		$arrayBind[] = array("key" => ":keyConfig", "value" => $keyConfig);
		$countConfig = Core::_getRowCount($query, $arrayBind);

		unset($arrayBind);

		if ($countConfig == 0) {

			global $User;

			if ($createdById == ''){

                $createdById = $User -> idUser();
			    
			}

			$query = "insert into " . Config::_getTable('configuration') . " (`keyConfig`,`valueConfig`,`statusConfig`,`systemItem`,`createdById`,`createdByType`,`dateAdditionConfig`) values 
                     (:keyConfig,:valueConfig,:statusConfig,:systemItem,:createdById,:createdByType,NOW()) ";
			$arrayBind[] = array("key" => ":statusConfig", "value" => $statusConfig);
			$arrayBind[] = array("key" => ":systemItem", "value" => $systemItem);
			$arrayBind[] = array("key" => ":createdById", "value" => $createdById);
			$arrayBind[] = array("key" => ":createdByType", "value" => $createdByType);
            
		} else {

			$query = "update " . Config::_getTable('configuration') . " set `valueConfig` = :valueConfig where `keyConfig` = :keyConfig ";

		}

		$arrayBind[] = array("key" => ":keyConfig", "value" => $keyConfig);
		$arrayBind[] = array("key" => ":valueConfig", "value" => $valueConfig);
        
        $return = false;

		if (Core::_runQuery($query, $arrayBind)) {

			// First removing the file level cache. Must be prior to variable cache remover to avoid looping
			Cache::_getInstance() -> _removeCache('config_configuration_value_' . $keyConfig);

			// Remove the cached value. Important to remove it, otherwise, the value will not be retrieved from the database for the following self::_get() function
			self::_remove($keyConfig);

			// Now updating the cached value by calling it from database
			$value = self::_get($keyConfig, false);

			$return = true;

		}

        $return = Plugins::_runAction('config_update_db_config_entry', $return, $keyConfig, $valueConfig, $statusConfig , $systemItem , $createdById , $createdByType );
        
		return $return;

	}

    /**
     * 
     * This will set php and mysql timezones
     * 
     * @param void()
     * @return null
     */
	public function _setSystem(){
	    
       // Setting php timezone     
        date_default_timezone_set(Config::_get('website.timezone'));

        // Generating timezone offset for mysql from php 
        $now = new DateTime();

        $offsetMinutes = $now->getOffset() / 60 ;

        $offsetConverted = floor($offsetMinutes/60).':'.($offsetMinutes%60);

        $offsetConverted = ($offsetMinutes < 0 ? '-' : '+').$offsetConverted;
        
        // Generated offset will be in the format +5:30
        $query = "set time_zone=:time_zone";
        $arrayBind[]= array("key" => ":time_zone", "value" =>  $offsetConverted);
        
        Core::_runQuery($query,$arrayBind);
	    
	}
	
	/** Sets all logs
	 *
	 *
	 * @param void
	 * @var null
	 */
	public function _setLogs() {
	    
		// Setting all errors to output
		error_reporting(E_ALL);

		global $Admin;

		if (!$Admin -> _isDeveloperMode()) {
		    
			// Stopping displaying the errors
			ini_set('display_errors', '0');
			
		} else {
		    
			// displaying all the errors
			ini_set('display_errors', 1);
            
		}

		ini_set('log_errors', '1');
		// Setting the path to the log file
		ini_set('error_log', self::_getDir('logs.errors'));
        
	}

	/** Sets table name with the given key
	 *
	 *
	 * @param key,value
	 * @var null
	 */
	public static function _setTable($key, $value) {

		self::$confDbArray[$key] = $value;

	}

	/** Returns the table name for the given key
	 *
	 *
	 * @param config key(string)
	 * @var config value(string)
	 */
	public static function _getTable($key) {

		if (!isset(self::$confDbArray[$key])){

            self::_setTable($key, $key);
		    
		}

		return self::$confDbArray[$key];

	}

	/** Returns the messages stored in $confMessagesArray
	 *
	 *
	 * @param message key(string)
	 * @var Message(string)
	 */
	public static function _getMessage($key) {

		if (!isset(self::$confMessagesArray[$key])){

            self::_updateMessage($key);
		    
		}

		return self::$confMessagesArray[$key];

	}

	/** Prepare Message for the output by replacing the given identifier with their values
	 *
	 *
	 * @param message key(string), Identifiers(array)
	 * @var Message(string)
	 */
	public static function _prepareMessage($key, $arrayIdentifiers = '') {
	    
		$message = self::_getMessage($key);

		if ($arrayIdentifiers != '') {

			foreach ($arrayIdentifiers as $keyIdentifier => $valueIdentifier) {

				$message = str_replace($keyIdentifier, $valueIdentifier, $message);

			}

		}

        $message = Plugins::_runAction('config_prepare_message', $message, $key, $arrayIdentifiers);

		return $message;

	}

	/** Retrives the message from database and stores in $confMessagesArray
	 *
	 *
	 * @param message key(string)
	 * @var config value(string)
	 */
	public static function _updateMessage($key) {

		if (Cache::_getInstance() -> _isCached('message_log_' . $key)) {

			$messageDetails = new stdClass();
			$messageDetails -> contentMessage    = Cache::_getInstance() -> _getCache('message_log_' . $key);
            $messageDetails -> keyMessage        = $key;
		} else {

			$query = "select * from " . Config::_getTable('messages_log') . " where `keyMessage` = :keyMessage and `statusMessage` = :statusMessage";
			$arrayBind[] = array("key" => ":keyMessage", "value" => $key);
			$arrayBind[] = array("key" => ":statusMessage", "value" => 1);
			$messageDetails = Core::_getRow($query, $arrayBind);

			if (!$messageDetails) {

				$messageDetails = new stdClass;
				$messageDetails -> contentMessage = false;

			} else {

				Cache::_getInstance() -> _setCache('message_log_' . $key, $messageDetails -> contentMessage);

			}

		}

        $messageDetails = Plugins::_runAction('config_update_message', $messageDetails, $key);

		self::$confMessagesArray[$messageDetails -> keyMessage] = $messageDetails -> contentMessage;

	}

	/** Adds new message to the Messages log
	 *
	 *
	 * @param keyMessage(string),contentMessage(string),statusMessage(int)
	 * @var void
	 */
	public static function _addMessage($keyMessage, $contentMessage, $statusMessage, $createdById, $createdByType) {

        $idMessage = false;

		if ( !self::_getMessage($keyMessage) ){
		    
            $query = "insert into " . Config::_getTable('messages_log') . " (`keyMessage`,`contentMessage`,`statusMessage`,`createdById`,`createdByType`,`dateAdditionMessage`) VALUES 
                     (:keyMessage,:contentMessage,:statusMessage,:createdById,:createdByType,NOW()) ";
    
            $arrayBind[] = array("key" => ":keyMessage",    "value" => $keyMessage);
            $arrayBind[] = array("key" => ":statusMessage", "value" => $statusMessage);
            $arrayBind[] = array("key" => ":contentMessage","value" => $contentMessage);
            $arrayBind[] = array("key" => ":createdById",   "value" => $createdById);
            $arrayBind[] = array("key" => ":createdByType", "value" => $createdByType);
    
            if (Core::_runQuery($query, $arrayBind)){
    
                $idMessage = Core::_getLastInsertId();
                
            }

		}

        $idMessage = Plugins::_runAction('config_add_message', $idMessage, $keyMessage, $contentMessage, $statusMessage, $createdById, $createdByType);

		return $idMessage;

	}

	/** Returns the absolute directory path of config value
	 *
	 *
	 * @param config key(string)
	 * @var config value(string)
	 */
	public static function _getDir($key = false, $cache = true) {

		if (!$key || $key == ''){
		    
            return self::_get('base.dir');

		}

		return self::_get('base.dir') . self::_get($key, $cache);

	}

	/** Returns the url of config value
	 *
	 *
	 * @param config key(string)
	 * @var config value(string)
	 */
	public static function _getUrl($key = false, $cache = true) {
		
		if (!$key || $key == ''){

            return self::_get('base.url');
		    
		}
			
		return self::_get('base.url') . self::_get($key, $cache);

	}

	/** Returns the absolute template directory path of config value
	 *
	 *
	 * @param config key(string)
	 * @var config value(string)
	 */
	public static function _getTempDir($key, $cache = true) {

		return self::_get('base.dir') . self::_get('temp') . self::_get($key, $cache);

	}

	/** Returns the template url of config value
	 *
	 *
	 * @param config key(string)
	 * @var config value(string)
	 */
	public static function _getTempUrl($key, $cache = true) {

		return self::_get('base.url') . self::_get('temp') . self::_get($key, $cache);

	}

}

