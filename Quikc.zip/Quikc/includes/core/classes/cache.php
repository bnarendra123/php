<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * Cahce class, used for caching the database and static contents
 *
 * @version 1.0
 * @http://www.quikc.org/
 */
class Cache {

	/**
	 * Contains the location of the file faching
	 *
	 * @var string
	 */
	protected $locationFileCache;

	/**
	 * Contains the object of the current variable
	 *
	 * @var Object
	 */
	private static $instance;

	/**
	 * Contains current cache type
	 *
	 * @var string
	 */
	protected $backEndCache;

	/* Basic Configuration functions starts from here

	 <!-----------------------------------------------------------------------------------------------------------------------------------------
	 */

	/** Constructer of the Cache class. It will set the cache type and its values
	 *
	 *
	 * @param void
	 * @var null
	 */
	private function __construct() {
	    
		$this -> _setBackEndCache();

	}

	/** Checks the database connection status and connets if there is not connection
	 *
	 *
	 * @param void
	 * @var Core class instance(object)
	 */
	public static function _getInstance() {

		if (null === self::$instance) {

			// Getting the name of the class. Here it is Core
			$object = __CLASS__;
			// Starting new class object
			self::$instance = new $object;

		}

		self::$instance = Plugins::_runAction('cache_instance_creation', self::$instance);

		return self::$instance;

	}

	/** Returns the cache status
	 *
	 *
	 * @param void
	 * @var null
	 */
	public function _isCacheEnabled() {

        $return = true;
        
		global $Admin;

		if (!Config::_get('cache.enabled', false)){

            // Return false if cache is disabled
            $return = false;

		}else if ($Admin -> _isDeveloperMode() && !Config::_get('developer.mode.caching', false)){

		    // Return false if system is in developer mode
            $return = false;

		}

        $return = Plugins::_runAction('cache_is_cache_enabled', $return);

		return $return;

	}

	/** Here we will set the cache type. We will use apc_store cache if it is present. If not, then we will use file caching
	 *
	 *
	 * @param void
	 * @var null
	 */
	protected function _setBackEndCache() {

		//check for APC
		if (Config::_get('cache.server') == 'Apc' && function_exists('apc_store')) {

			$this -> backEndCache = 'Apc';
			return;

		}

		$this -> backEndCache = 'File';
		$this -> locationFileCache = Config::_getDir('cache.path', false);

        Plugins::_runAction('cache_set_backend_cache', $this);
        
	}

	/* Basic Configuration functions ends here
	 -----------------------------------------------------------------------------------------------------------------------------------------!>
	 */

	/* Public functions which will be accessable from the outside will be accessable starts from here

	 <!-----------------------------------------------------------------------------------------------------------------------------------------
	 */

	/** Check weather the given key exists in the cache or not.
	 *
	 *
	 * @param $key(string)
	 * @var null
	 */
	public function _isCached($key) {

		// Return false if cache is not enabled
		if (!$this -> _isCacheEnabled()){

            return false;
		    
		}

		$method = '_is' . $this -> backEndCache . 'Cached';

        $return = $this -> $method($key);
        
        $return = Plugins::_runAction('cache_is_cached', $return, $key);

        return $return;

	}

	/** Returns the cache value of the given key, if it is cached
	 *
	 *
	 * @param $key(string)
	 * @var Cached value(string)
	 */
	public function _getCache($key) {
	    
		// Return false if cache is not enabled
		if (!$this -> _isCacheEnabled())
			return false;

		$method = '_get' . $this -> backEndCache . 'Cache';

        $return = $this -> $method($key);
        
        $return = Plugins::_runAction('cache_get_cache', $return, $key);

        return $return;

	}

	/** Set the cache value for the given key
	 *
	 *
	 * @param $key(string),$value(string), $timeExpire(int)
	 * @var Cached value(string)
	 */
	public function _setCache($key, $value, $timeExpire = '') {

		// Return false if cache is not enabled
		if (!$this -> _isCacheEnabled()){

            return false;
		    
		}

		$method = '_set' . $this -> backEndCache . 'Cache';

    	$return = $this -> $method($key, $value, $timeExpire);

        $return = Plugins::_runAction('cache_set_cache',$return, $key, $value, $timeExpire);

        return $return;        

	}

	/** Returns the path of the current cache key file
	 *
	 *
	 * @param $key(string)
	 * @var Boolens(true/false)
	 */
	public function _removeCache($key) {

		$method = '_remove' . $this -> backEndCache . 'Cache';

        $key = Plugins::_runAction('cache_remove_cache', $key);

        $return = false;
        
        if( $key != '' ){
            $return = $this -> $method($key);
        }

        return $return;        

	}

	/** Returns the path of the current cache key file
	 *
	 *
	 * @param void
	 * @var null
	 */
	public function _removeAllCache() {

		$method = '_removeAll' . $this -> backEndCache . 'Cache';

        $return = false;
        $continue = true;

        $continue = Plugins::_runAction('cache_remove_all_cache', $continue);
        
        if( $continue ){

            $return = $this -> $method();

        }

        return $return;        

	}

	/* Public functions which will be accessable from the outside will be accessable ends here
	 -----------------------------------------------------------------------------------------------------------------------------------------!>
	 */

	/* File cache functions starts from here

	 <!-----------------------------------------------------------------------------------------------------------------------------------------
	 */

	/** Returns weather the given key is cached in file cache or not
	 *
	 *
	 * @param $key(string)
	 * @var Boolens(true/false)
	 */
	protected function _isFileCached($key) {

		$path = $this -> _getFilePath($key);

		if (file_exists($path)) {

			if ((time() - Config::_get('cache.time.limit') < filemtime($path))) {

				return true;

			} else {

                global $Base;
                $Base->_removeDir($path);

			}

		}

		return false;

	}

	/** Returns value of the given key cached in file cache
	 *
	 *
	 * @param $key(string)
	 * @var $value(string)
	 */
	protected function _getFileCache($key) {

		$path = $this -> _getFilePath($key);

		if (file_exists($path)) {

			$contents = trim(file_get_contents($path));

			if ($contents && strlen($contents) > 0) {

				$unserialised = unserialize($contents);

				if ($unserialised) {

					return $unserialised;

				}

			}else{

				$this->_removeAllCache();

			}

		}

	}

	/** Creates the cache element for the given key
	 *
	 *
	 * @param $key(string),$value(string),$timeExpire(int)
	 * @var Boolens(true/false)
	 */
	protected function _setFileCache($key, $value, $timeExpire) {
	    
		$path = $this -> _getFilePath($key);
        
		/*$storeData = array(
		 'time'   => time(),
		 'expire' => $timeExpire,
		 'data'   => $value
		 );*/

	    global $Base;
        
		return $Base->_createFile($path, serialize($value));

	}

	/** Returns the path of the current cache key file
	 *
	 *
	 * @param $key(string)
	 * @var Boolens(true/false)
	 */
	protected function _getFilePath($key) {

		return $this -> locationFileCache . '/' . __CLASS__ . '_' . $key . '.' . Config::_get('cache.file.extension');

	}

	/** Returns the path of the current cache key file
	 *
	 *
	 * @param $key(string)
	 * @var Boolens(true/false)
	 */
	protected function _removeFileCache($key) {
	    
		$path = $this -> _getFilePath($key);

		if (file_exists($path)) {

            global $Base;
			if ($Base->_removeDir($path)){

                return true;
			    
			}

		}

		return false;

	}

	/** Returns the path of the current cache key file
	 *
	 *
	 * @param void
	 * @var null
	 */
	protected function _removeAllFileCache() {

        global $Base;
        array_map(array($Base,'_removeDir'), glob(Config::_getDir('cache.path') . "/*"));

	}

	/* File cache functions ends here
	 -----------------------------------------------------------------------------------------------------------------------------------------!>
	 */

	/* Apc cache functions starts from here

	 <!-----------------------------------------------------------------------------------------------------------------------------------------
	 */

	/** Returns weather the given key is cached in Apc cache or not
	 *
	 *
	 * @param $key(string)
	 * @var boolen(true/false)
	 */
	protected function _isApcCached($key) {

		return apc_exists($this -> _getApcKey($key));

	}

	/** Returns value of the given key cached in Apc cache
	 *
	 *
	 * @param $key(string)
	 * @var $value(string)
	 */
	protected function _getApcCache($key) {

		$key = $this -> _getApcKey($key);

		if (apc_exists($key)) {

			$result = apc_fetch($key);

			if ($result) {

				return $result;

			}

		}

		return false;

	}

	/** Creates the cache element for the given key
	 *
	 *
	 * @param $key(string),$value(string),$timeExpire(int)
	 * @var boolen(true/false)
	 */
	protected function _setApcCache($key, $value, $timeExpire) {

		$key = $this -> _getApcKey($key);

		return apc_store($key, $value);

	}

	/** Returns the path of the current cache key Apc
	 *
	 *
	 * @param $key(string)
	 * @var boolen(true/false)
	 */
	protected function _getApcKey($key) {

		return __CLASS__ . '-' . $key;

	}

	/** Returns the path of the current cache key file
	 *
	 *
	 * @param $key(string)
	 * @var Boolens(true/false)
	 */
	protected function _removeApcCache($key) {

		if ($this -> isApcCached($key)) {

			if (apc_delete($this -> getApcKey($key))){

                return true;
			    
			}

		}

		return false;

	}

	/** Returns the path of the current cache key file
	 *
	 *
	 * @param void
	 * @var null
	 */
	protected function _removeAllApcCache() {

		apc_clear_cache();

	}

	/* Apc cache functions ends here
	 -----------------------------------------------------------------------------------------------------------------------------------------!>
	 */
}
