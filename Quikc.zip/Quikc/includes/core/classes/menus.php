<?php

defined('QC_VALID') or die('Restricted Access!');

/**
* Menu class, used for processing menus (front end and back end) related actions
* All menu related actions will be processed from here. 
*
* @version 1.0
* @http://www.quikc.org/
*/
class Menus{

	/**
	* Contains menus information
	* This contains the details of the menus retrieved
	* and the list of menu items of that menu 
	*
	* @var array of objects
	*/
	private $retrievedMenuData;

	/**
	* Contains menus items details with reference as id
	*
	* @var array of objects
	*/
	private $retrievedMenuItemData;

	/** Contains admin menus
	* 
	*
	* @var object
	*/
    private $adminMenus = false;

	/** Contains the information of the current Admin Menu
	* 
	*
	* @var object
	*/
    private $currentAdminMenu = false;

	/** Contains the admin menus allowed for the current user
	* 
	*
	* @var object
	*/
    public $userAdminMenus = false;

    /** Contains system admin menus
    * 
    *
    * @var object
    */
    private $adminSystemMenus = false;

	/**
	 * Returns menu details with the given id
	 *
	 * @param int(menu id)
	 * @return object/boolean
	 */
	public function _getMenuDetails($idMenu) {
		
		if (isset($this -> retrievedMenuData[$idMenu])) {

			$detailsMenu = $this -> retrievedMenuData[$idMenu];

		} else if (Cache::_getInstance() -> _isCached('cms_menus_' . $idMenu)) {

			$detailsMenu = Cache::_getInstance() -> _getCache('cms_menus_' . $idMenu);
			$this -> retrievedMenuData[$idMenu] = $detailsMenu;

		} else {
			
			$query = " select * from " . Config::_getTable('menus') . " where idMenu = :idMenu";
			$arrayBind[] = array("key" => ":idMenu", "value" => $idMenu);
			$detailsMenu = Core::_getRow($query, $arrayBind);
			
			if( $detailsMenu ) {

                $this -> retrievedMenuData[$detailsMenu -> idMenu] = $detailsMenu;
                Cache::_getInstance() -> _setCache('cms_menus_' . $detailsMenu -> idMenu, $detailsMenu);

			}

		}

        $detailsMenu = Plugins::_runAction('menus_get_menu_details', $detailsMenu,$idMenu );
		
		return $detailsMenu;

	}

	/**
	 * Returns items of the given menu 
	 *
	 * @param int(menu id)
	 * @return array of objects
	 */
	public function _getMenuItems($idMenu,$idParent = false) {
		
		if (isset($this -> retrievedMenuData[$idMenu]->items)) {

			$itemsMenu = $this -> retrievedMenuData[$idMenu]->items;

		} else if (Cache::_getInstance() -> _isCached('cms_menus_items_' . $idMenu)) {

			$itemsMenu = Cache::_getInstance() -> _getCache('cms_menus_items_' . $idMenu);
			$this -> retrievedMenuData[$idMenu] = new stdClass;
			$this -> retrievedMenuData[$idMenu]->items = $itemsMenu;

		} else {
			
			$query = " select * from " . Config::_getTable('menu_items') . " where idMenu = :idMenu order by orderMenuItem asc";
			$arrayBind[] = array("key" => ":idMenu", "value" => $idMenu);
			$itemsMenu = Core::_getAllRows($query, $arrayBind);

			$this -> retrievedMenuData[$idMenu] = new stdClass;
			$this -> retrievedMenuData[$idMenu]->items = $itemsMenu;
			Cache::_getInstance() -> _setCache('cms_menus_items_' . $idMenu, $itemsMenu);

		}

		// if value is not false, then this will return subm items
		if( $idParent !== false ){

			foreach($itemsMenu as $key => $itemMenu){

				// Checking if current item parent is matching given parent item
				if( $itemMenu->parentMenuItem != $idParent ){

					unset($itemsMenu[$key]);

				}
				
			}

		}		

        $itemsMenu = Plugins::_runAction('menus_get_menu_items', $itemsMenu,$idMenu,$idParent );
        
		return $itemsMenu;

	}

	/**
	 * Returns details of the menu item with the given id 
	 *
	 * @param int(menu id)
	 * @return array of objects
	 */
	public function _getMenuItemDetails($idMenuItem) {
		
		if (isset($this -> retrievedMenuItemData[$idMenuItem])) {
		    
			$detailsMenuItem = $this -> retrievedMenuItemData[$idMenuItem];
            
		} else if (Cache::_getInstance() -> _isCached('cms_menus_item_' . $idMenuItem)) {
		    
			$detailsMenuItem = Cache::_getInstance() -> _getCache('cms_menus_item_' . $idMenuItem);
			$this -> retrievedMenuItemData[$idMenuItem] = $detailsMenuItem;
            
		} else {
			
			$query = " select * from " . Config::_getTable('menu_items') . " where idMenuItem = :idMenuItem";
			$arrayBind[] = array("key" => ":idMenuItem", "value" => $idMenuItem);
			$detailsMenuItem = Core::_getRow($query, $arrayBind);

			$this -> retrievedMenuItemData[$idMenuItem] = $detailsMenuItem;
			Cache::_getInstance() -> _setCache('cms_menus_item_' . $idMenuItem, $detailsMenuItem);
            
		}

        $detailsMenuItem = Plugins::_runAction('menus_get_menu_item_details', $detailsMenuItem,$idMenuItem );
		
		return $detailsMenuItem;

	}

	/** Generated the list of admin menus with the given parent menu id
	* 
	*
    * @param Parent Menu Id(int)
	* @var object
	*/
    private function _generateAdminMenus($parentMenu){
	
		// Returning the cached menus for no parent menu(Means returning then complete list menus) 
		if($parentMenu == '' && Cache::_getInstance()->_isCached('admin_menus_list')){

        	$menusAdmin = Cache::_getInstance()->_getCache('admin_menus_list');
        	
        }else{

            $query  = "select * from ".Config::_getTable('admin_menus')." am ";
            $arrayBind = array();
            
            // Append the parent menu condition if there is any parentmenu      
            if( $parentMenu != '' ){
                
                $query  .= " where am.parentMenu = :parentMenu ";
                $arrayBind[]= array("key" => ":parentMenu", "value" =>  $parentMenu );
                
            }

            $query .= " order by am.orderMenu ASC ";
    
            $menusAdmin = Core::_getAllRows($query,$arrayBind);
    
            // Enabling the cache for no parent menu(Means caching the complete list of menus) 
            if($parentMenu == ''){

                Cache::_getInstance()->_setCache('admin_menus_list',$menusAdmin);

            }
            
        }

        $menusAdmin = Plugins::_runAction('menus_generate_admin_menus', $menusAdmin,$parentMenu );
        
        return $menusAdmin;

    }

    /** Returns the list of Admins menus in set format
    * 
    *
    * @param Parent Menu Id(int)
    * @var object
    */
    public function _prepareAdminMenuSet($formatSet = true){

        global $Cms;

        $listSet = $Cms -> _prepareTreeView('admin_menus','idMenu','parentMenu','titleMenu',array("statusMenu" => '1'),array("titleMenu"=>'asc'));
        
        if( $formatSet ){
            
            $listSet = array($listSet,'idMenu','titleMenu');
            
        }
        
        return $listSet;  

    }
    
	/** Returns the list of Admins menus with the given parent id
	* 
	*
    * @param Parent Menu Id(int)
	* @var object
	*/
	public function _getAdminMenus($parentMenu=''){

		if(!$this->adminMenus){

			foreach($this->_generateAdminMenus('') as $tmpMenu){

				$this->adminMenus[$tmpMenu->idMenu] = $tmpMenu;

			}

		}

		if($parentMenu == ''){
		    
			$return = $this->adminMenus;

		}else{

			$return = $this->_generateAdminMenus($parentMenu);

        }
        
        $return = Plugins::_runAction('menus_get_admin_menus', $return,$parentMenu );
        
        return $return;

	}
	
	/** Returns the list of active admin menus
	* 
	*
    * @param void
	* @var array of object
	*/
	public function _getActiveAdminMenus(){

		$menus = $this->_getAdminMenus('');
		$activeMenus = $childMenus = array();
		
		global $Plugins;

		foreach($menus as $menu){

			if($menu->statusMenu == 1 && ($menu->createdByType == 'user' || ( $menu->createdByType == 'plugin' && $Plugins->_checkPluginIdentifier($menu->createdById)) ) ){

                $activeMenus[] = $menu;

                if( !isset($childMenus[$menu->parentMenu]) ){

                    $childMenus[$menu->parentMenu] = 1 ;

                }else{

                    $childMenus[$menu->parentMenu] = $childMenus[$menu->parentMenu]++;
                }

			}

		}
        
        $activeMenus = Plugins::_runAction('menus_get_active_admin_menus', $activeMenus );
        
		return $activeMenus;

	}

    /** Returns the filtered admin menus of the current User. User should have view permissions to display a menu
    * 
    *
    * @param void
    * @var object
    */
    public function _getUserAdminMenus(){

		if($this->userAdminMenus){

		    return $this->userAdminMenus;

        }
        
        global $Permissions, $Admin;
        $adminMenus = $this->_getActiveAdminMenus();

        if( !$Admin->_isSuperUser() )
        $adminMenus = $Permissions->_filterPermissionsAllowed($adminMenus);
        
        foreach($adminMenus as $key => $tmpMenu){

            if( $tmpMenu->linkMenu != '' && !$Permissions->_checkPagePermission($tmpMenu->linkMenu,'view') ){

                unset($adminMenus[$key]);

            }

        }    
        
        $adminMenus = $this->_removeEmptyAdminMenus($adminMenus);

		$this->userAdminMenus = $adminMenus;

        $adminMenus = Plugins::_runAction('menus_get_user_admin_menus', $adminMenus );

        return $adminMenus;

    }

    /**
    * Returns the valid page no
    *
    * @param page id(int)
    * @return verified page id(int)
    */
    public function _verifyPageNo($pageNo){

		global $Base;        
        $menuAdmin = $this->_loadAdminMenu($pageNo);

        $menuAdmin = Plugins::_runAction('menus_verify_page_no', $menuAdmin );

        if( !$menuAdmin || $menuAdmin->statusMenu == 0 ) {
            
            $Base->_pageRedirect('home.php');

        }
        
    }

	/** Sets current admin menus to $currentAdminMenu
	* 
	*
    * @param Parent Menu Id(int)
	* @var null
	*/
    public function _setCurrentAdminMenu($idMenu){

		$this->currentAdminMenu = $this->_loadAdminMenu($idMenu);
		$this->_updateVisitHistory($idMenu);

        Plugins::_runAction('menus_set_current_admin_menu', $idMenu );

    }

	/** Updates user menu history
	* 
	*
    * @param Menu Id(int)
	* @var null
	*/
    public function _updateVisitHistory($idMenu){

    	if( !isset($_SESSION['recentMenus']) || !is_array($_SESSION['recentMenus']) ){

    		$_SESSION['recentMenus'][] = $idMenu;

		}else{

	    	if (($key = array_search($idMenu, $_SESSION['recentMenus'])) !== false) {

	    		unset($_SESSION['recentMenus'][$key]);

			}

			array_unshift ($_SESSION['recentMenus'],$idMenu);

		}

        Plugins::_runAction('menus_update_visit_history', $idMenu );
        
    }

	/** Returns list of menus user recently visited
	* 
	*
    * @param 
	* @var array
	*/
    public function _getVisitHistory(){
        
        $return = $_SESSION['recentMenus'];
        
        $return = Plugins::_runAction('menus_get_visit_history', $return );
        
		return $return;

    }

	/** Returns current admin menus details
	* 
	*
    * @param void
	* @var object
	*/
    public function _getCurrentAdminMenu(){
        		
        $return = $this->currentAdminMenu;
        
        $return = Plugins::_runAction('menus_get_current_admin_menu', $return );
        
		return $return;

    }

    /** Remove the 
    * 
    *
    * @param void
    * @var object
    */
    public function _removeEmptyAdminMenus($adminMenus){

        $oldAdminMenus = $adminMenus;

        $childMenus = array();

        foreach($adminMenus as $menu){

            if( !isset($childMenus[$menu->parentMenu]) ){

                $childMenus[$menu->parentMenu] = 1 ;

            }else{

                $childMenus[$menu->parentMenu]++;

            }

        }

        // Removing the menus without a valid link and also without any child menus
        foreach($adminMenus as $key => $menu){

            if($menu->linkMenu == '' && !isset($childMenus[$menu->idMenu])){

                unset($adminMenus[$key]);
                $adminMenus = $this -> _removeEmptyAdminMenus($adminMenus);

                break;

            }

        }

        $adminMenus = Plugins::_runAction('menus_remove_empty_admin_menus', $adminMenus, $oldAdminMenus );
        
        return $adminMenus;

    }

	/** Returns the admin menu details
	* 
	*
    * @param Admin Menu Id(int),
	* @var object
	*/
	public function _loadAdminMenu($idMenu){

        $return = false;
        		
		$adminMenus = $this->_getAdminMenus('');
		
		if( isset($adminMenus[$idMenu]) ) {

		    $return = $adminMenus[$idMenu];;

		} 

        $return = Plugins::_runAction('menus_load_admin_menu', $return, $idMenu );

		return $return;

	}

    /** Returns the admin menu details by link
    * 
    *
    * @param Admin Menu Link(string)
    * @var object
    */
    public function _loadAdminMenuByLink($linkMenu){
        
        $query  = "select * from ".Config::_getTable('admin_menus')." where linkMenu = :linkMenu ";
        $arrayBind[]= array("key" => ":linkMenu", "value" => $linkMenu );
        $detailsMenu = Core::_getRow($query,$arrayBind);

        $detailsMenu = Plugins::_runAction('menus_load_admin_menu_by_link', $detailsMenu, $linkMenu );

        return $detailsMenu;

    }

    /** returns the system admin menus
    * 
    *
    * @param void
    * @var object
    */
    public function _loadAdminSystemMenus(){
        
        $query  = "select * from ".Config::_getTable('admin_menus')." where systemItem = :systemItem ";
        $arrayBind[]= array("key" => ":systemItem", "value" =>  1 );
        $systemMenus = Core::_getAllRows($query,$arrayBind);

        $systemMenus = Plugins::_runAction('menus_load_admin_system_menus', $systemMenus);

        return $systemMenus;

    }
    
    /** Returns the admin menus
    * 
    *
    * @param void
    * @var object
    */
    public function _getAdminSystemMenus(){        
 
        if(!$this->adminSystemMenus){

            $systemMenus = array();
            $Menus = $this->_loadAdminSystemMenus();

            foreach($Menus as $tmpMenu){

                $systemMenus[$tmpMenu->idMenu] = $tmpMenu;

            }

            $this->adminSystemMenus = $systemMenus;

        }
 
        $this->adminSystemMenus = Plugins::_runAction('menus_get_admin_system_menus', $this->adminSystemMenus);
        
        return $this->adminSystemMenus;

    }

    /** Checks weather the given menus is a system menu or not
    * 
    *
    * @param idMenu
    * @var boolean true/false
    */
    public function _checkAdminSystemMenu($idMenu){
        
        $return = false;
        
        $systemMenus = $this->_getAdminSystemMenus();

        if( array_key_exists($idMenu,$systemMenus) ){

            $return = true;

        }

        $return = Plugins::_runAction('menus_check_admin_system_menu', $return,$idMenu);
        
        return $return;

    }

    /** Check weather the plugin menu exists or not
    * 
    *
    * @param Admin Menu Link(String)
    * @var object
    */
    public function _checkPluginMenu($linkMenu,$identifierPlugin){

        $return = false;
        
        $query  = " select * from ".Config::_getTable('admin_menus')."  where linkMenu = :linkMenu and createdByType = 'plugin' and createdById = :createdById";
        $arrayBind[]= array("key" => ":linkMenu", "value" =>  $linkMenu );
        $arrayBind[]= array("key" => ":createdById", "value" =>  $identifierPlugin );

        if( Core::_getRowCount($query, $arrayBind) ){

            $return = true;

        }
        
        $return = Plugins::_runAction('menus_check_plugin_menu', $return,$linkMenu,$identifierPlugin);
        
        return $return;

    }
        
    /** Returhs the plugin menu details
    * 
    *
    * @param Admin Menu Link(String)
    * @var object
    */
    public function _getPluginMenu($linkMenu,$identifierPlugin){

        $query  = " select * from ".Config::_getTable('admin_menus')."  where linkMenu = :linkMenu and createdByType = 'plugin' and createdById = :createdById";
        $arrayBind[]= array("key" => ":linkMenu", "value" =>  $linkMenu );
        $arrayBind[]= array("key" => ":createdById", "value" =>  $identifierPlugin );

        $detailsPluginMenu = Core::_getRow($query, $arrayBind);
                
        $detailsPluginMenu = Plugins::_runAction('menus_get_plugin_menu', $detailsPluginMenu,$linkMenu,$identifierPlugin);
        
        return $detailsPluginMenu;

    }
}
