<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * Editor class, contains functions related to inplace editing of the themes
 *
 *
 * @version 1.0
 * @http://www.quikc.org/
 */

class Editor {

	/**
	 * Construction for editor class
	 *
	 * @param void()
	 * @return null
	 */
	public function __construct() {

	    Plugins::_hookAction('ajax_page_start',array($this,'_processAjaxPage'));

	}

	/**
	 * checks and returns weather the execution is in cmode or not
	 *
	 * @param void()
	 * @return null
	 */
	public function _isCustomizeMode() {

        $return = true;
		
		global $Admin;
		if( !$Admin -> _isLogged() ){

		    $return = false;

		}

		if( !isset($_GET['cmode']) ){

		    $return = false;

		} 

        $return = Plugins::_runAction('editor_is_customize_mode', $return);
		
    	return $return;

	}

    /**
     * process the ajac page for the customize editor
     *
     * @param string($Action)
     * @return string
     */
    public function _processAjaxPage($Action) {

        if($Action != 'get/edit/customeditor' && $Action != 'set/customeditor'){

            $return = $Action;  

        }else{
            
            if($Action == 'get/edit/customeditor'){

                Plugins::_hookAction('generate_form_start',array($this,'_filterEditorForm'));

            } 
    
            if($Action == 'set/customeditor') {

                Plugins::_hookAction('generate_form_process_form_start',array($this,'_filterEditorForm'));
                Plugins::_hookAction('generate_form_process_form_end',array($this,'_filterSetEditorForm'));

            }
            
            extract($_POST);

            if( isset($pageQuickedit) ){

                $return = $pageQuickedit;
                
            }
            
            if( isset($formId) ){

                $return = ${'pageQuickedit_'.$formId}; 

            }
    
        }

        $return = Plugins::_runAction('editor_process_ajax_page', $return,$Action);

        return $return;

    }

    /**
     * filters the fields for the editor form
     *
     * @param string($args)
     * @return array of fields
     */
    public function _filterEditorForm($args) {
        
        $formElements = $args[0];
        $detailsForm  = $args[1];

		global $Forms;

		if(isset($_POST['formId'])){

            $_POST = $Forms->_removeFieldIds($_POST);
		    
		}
		
        extract($_POST);
        
        if(isset($fieldsQuickedit) && $fieldsQuickedit != ''){
            
            $displayFieldsNew = $buttonField = array();
    
            $fieldsQuickArray = explode(',',$fieldsQuickedit);

            foreach($formElements['fields'] as $dispalyField){

                if(in_array($dispalyField['id'], $fieldsQuickArray)){

                    $displayFieldsNew[] = $dispalyField;

                }

                if( strtolower($dispalyField['type']) == 'button'){

                    $buttonField = $dispalyField;

                }

            }

            if(count($buttonField)>0){

                $displayFieldsNew[] = $buttonField;

            }

			$displayFieldsNew[] = array("id" => "fieldsQuickedit", "type" => "Hidden",	"label" => "","req" => true ,"value" => $fieldsQuickedit, "additional" => '');
            $formElements['fields'] = $displayFieldsNew;

        }

		$formElements['fields'][] = array("id" => "pageQuickedit", "type" => "Hidden",	"label" => "","req" => true ,"value" => $formElements['url'], "additional" => '');
		$formElements['success'] = "CustomizeEditorSuccess()";
        $formElements['url'] = 'set/customeditor';
        $formElements['closeLink'] = '';

        $return = Plugins::_runAction('editor_filter_editor_form', array($formElements,$detailsForm),$args);

        $formElements = $return[0];
        $detailsForm  = $return[1];

        return array($formElements,$detailsForm);

    }

    /**
     * Processes the processedform data before passing from the _processForm funciton
	 * Mainly used to remove previously added quick edit fields fieldsQuickedit,page
     *
     * @param array($formElements)
     * @return array($formElements)
     */
    public function _filterSetEditorForm($formElements) {

        $oldFormElements = $formElements;

        foreach($formElements['fields'] as $key => $field){

            if(in_array($field, array('fieldsQuickedit','pageQuickedit'))){
                
                unset($formElements['fields'][$key]);

            }

        }

        $formElements = Plugins::_runAction('editor_filter_set_editor_form', $formElements,$oldFormElements );
        
        return $formElements;

    }

	/**
	 * This will generate editor for the given element 
	 *
	 * @param void()
	 * @return null
	 */
	public function _generate($urlForm,$idPrimary,$fieldsQuickedit = '',$create = true,$edit = true,$space = false) {

	    if(is_array($fieldsQuickedit)){

            $stringQuickedit = implode(',', $fieldsQuickedit);	        

	    }else{

	        $stringQuickedit = $fieldsQuickedit;

	    }
		
		if(is_array($urlForm)){

            $urlForm = implode(",",$urlForm);		    

		} 

		$return = 'onmouseover="return mouseOverEditor(event,this,\''.$urlForm.'\',\''.$idPrimary.'\',\''.$stringQuickedit.'\',\''.$create.'\',\''.$edit.'\',\''.$space.'\')"';

        $return = Plugins::_runAction('editor_generate', $return,$urlForm,$idPrimary,$fieldsQuickedit ,$create ,$edit ,$space );
        
        return $return;

	}

}

