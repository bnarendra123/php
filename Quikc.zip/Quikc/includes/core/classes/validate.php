<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* Validate class, Contains all the function to validate input fields
*
* @version 1.0
* @http://www.quikc.org/
*/
class Validate{

	/** Contains the magic quotes status
	* 
	*
	* @var object
	*/
    private static $magicQuotes;

	/** Constructure for the validate class
	* 
	*
    * @param void
	* @var null
	*/
    public function __construct(){

		if(get_magic_quotes_gpc()){
		    
			self::$magicQuotes = true;

		}else{

            //self::$magicQuotes = true;
			self::$magicQuotes = false;

		}	

	}
	
	/** Calls _sanitizeVariable function for all the elements of the array
	* 
	*
    * @param array
	* @var array
	*/
	public static function _Sanitize($array){
		foreach($array as $key => $value){	
			if(!is_array($value)){
				$array[$key] = self::_sanitizeVariable($value); 
			}else{
				$array[$key] = self::_Sanitize($value);				
			}	
		}
		return $array;
	}

	/** Calls _unsanitizeVariable function for all the elements of the array
	* 
	*
    * @param array
	* @var array
	*/
	public static function _unSanitize($array){
		foreach($array as $key => $value){	
			if(!is_array($value)){
				$array[$key] = self::_unsanitizeVariable($value);		
			}else{
				$array[$key] = self::_unSanitize($value);				
			}	
		}
		return $array;
	}
	
	/** Sanitizes variables
	* 
	*
    * @param string
	* @var string
	*/
	public static function _sanitizeVariable($variable) {
	 
		//$variable = htmlspecialchars($variable);
		
		if(!self::$magicQuotes) 
		$variable = addslashes($variable); 
	
		return $variable;
	} 

	/** unstrips arrays or variables
	* 
	*
    * @param string/array
	* @var string/array
	*/
    public function _stripslashes($variable){

    	if(is_object($variable)) return $variable;

        $variable = is_array($variable) ?
                    array_map(array($this,'_stripslashes'), $variable) :
                    stripslashes($variable);
    
        return $variable;
    }	

    /** unSanitizes variables
    * 
    *
    * @param string
    * @var string
    */
    public static function _unsanitizeVariable($variable){
		
        $variable = stripcslashes($variable);       
		$variable = htmlspecialchars_decode($variable);
    
        return $variable; 
    } 

    /** Prepares the variables for displaying in textbox
    * 
    *
    * @param string
    * @var string
    */
    public static function _prepareTextboxValue($variable){
        $variable = htmlentities($variable);
        return $variable;
    } 

    /** Prepares the variables for javascript aurgment
    * 
    *
    * @param string
    * @var string
    */
    public static function _prepareJavascriptValue($variable){
        $variable = addslashes($variable);
        return $variable;
    } 

    /** Validates Username
    * 
    *
    * @param user name(string)
    * @var boolean
    */
    public static function _validateUsername($username){
        if(!preg_match("/^[a-z\d_]{6,20}$/i",$username) && $username != '' ){
            return false;
        } else{
            return true;
        }   
    }

	/** Validates email
	* 
	*
    * @param email(string)
	* @var boolean
	*/
	public static function _validateEmail($email){
		if( !filter_var($email, FILTER_VALIDATE_EMAIL) && $email != '' ){
			return false;
		}
		return true;
	}

	/** Validates user password
	* 
	*
    * @param email(string)
	* @var boolean
	*/
	public static function _validatePassword($password){

		if( $password == '' || preg_match("#.*^(?=.{5,20})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W).*$#", $password) ){
			return true;
		}else{
			return false;
		}
	}

	/** Validates mobile number
	* 
	*
    * @param mobile number(int)
	* @var boolean
	*/
	public static function _validateMobileNo($numberMobile){
		if(!preg_match("/^[a-z0-9]+)){10,15}$/i",$numberMobile) && $numberMobile != '' ){
			return false;
		} else{
			return true;
		}	
	}
	
	/** Validates numbers
	* 
	*
    * @param mobile number(int)
	* @var boolean
	*/
	public static function _validateNumber($number){
		if(is_numeric($number)){
			return true;
		} else{
			return false;
		}	
	}

	/** Validates date
	* 
	*
    * @param mobile number(int)
	* @var boolean
	*/
	public static function _validateDate($date){
		
		if( $date == '' || ( $date == date('Y-m-d H:i:s',strtotime($date)) || $date == date('Y-m-d',strtotime($date)) ) ) return true;
		
		return false;
	}

	/** Validates all the fields in the array( for empty values )
	* 
	*
    * @param (array)
	* @var array
	*/
	public static function _validateInput($inputArray){	
		$error = array();
		foreach($inputArray as $inputsubArray){
			if( $inputsubArray[0] == '' ){
				$error[] = $inputsubArray[1];	
			}
		}
		return $error;
	}
}

