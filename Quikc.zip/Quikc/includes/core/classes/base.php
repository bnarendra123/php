<?php

defined('QC_VALID') or die('Restricted Access!');

/**
 * Base class, contains general function which doesn't belongs to any class
 * This includes converterror, pageredirect, randomstring etc
 *
 * @version 1.0
 * @http://www.quikc.org/
 */

class Base {

	/**
	 * Construction for base
	 *
	 * @param void()
	 * @return null
	 */
	public function __construct() {
	}

	/**
	 * Returns the executions so far in seconds
	 *
	 * @param void()
	 * @return float(time)
	 */
	public function _getExecutionTime() {

		return (microtime(true) - _START_TIME);

	}

	/**
	 * Returns the executions so far in seconds
	 *
	 * @param void()
	 * @return int(size in bytes)
	 */
	public function _getExecutionMemory() {

		return (memory_get_usage() - _START_MEMO);

	}

	/**
	 * Will return the variable if exists or default if variables doesn't exists
	 *
	 * @param varialbe,default values
	 * @return string/boolean
	 */
	public function _prepareOutput($var, $default = false) {

        $output = isset($var) ? $var : $default;	    

        $output = Plugins::_runAction('base_prepare_output', $output, $var, $default);
        
		return $output;

	}
	
	/**
	 * Converts the given array into string
	 *
	 * @param $error(array),if true returns else echo strings and dies(boolean)
	 * @return string/null
	 */
	public static function _convertError($error, $continue) {

        $return = Plugins::_runAction('base_convert_error', array($error, $continue));

        $error = $return[0];
        $continue = $return[1];
	    
		// return true if no error;
		if (count($error) == 0 || $error == ''){

            return true;
		    
		}

		if (is_array($error)) {

			// converting the array into string
			$error_c = implode("</li><li>", $error);

		} else {

			$error_c = $error;

		}

		if ($continue) {

			// return the converted error
			return '<ul><li>' . $error_c . '</li></ul>';

		} else {

			// print the converted error and stop
			echo '<ul><li>' . $error_c . '</li></ul>';
			die();

		}

	}

	/**
	 * Actions to be done when website is in offline mode
	 *
	 * @param boolean
	 * @return null
	 */
	public function _websiteOffline() {
		
        $continue = true;
        $continue = Plugins::_runAction('base_website_offinle',$continue);
        
        if( !$continue ) return false;

		global $Themes;

		if( !$Themes->_inc('site-offline.phtml') ){ ?>

			<div style="text-align: center">
			<h1><?php echo Config::_get('website.title'); ?></h1>

			<?php if(Config::_get('website.offline.image') != '' && file_exists(Config::_getDir('img').'/'.Config::_get('website.offline.image'))): ?>

    			<img src="<?php echo $this->_displayPhpthumb(Config::_get('website.offline.image')); ?>" /><br/>

		<?php endif; ?>

			<?php echo Config::_get('website.offline.message'); ?>
			</div>
		<?php
		
		}
		
		die();
        
	}

    /**
     * Actions to be done when website is blocked
     *
     * @param boolean
     * @return null
     */
    public function _websiteBlocked() {

        $continue = true;
        $continue = Plugins::_runAction('base_website_blocked',$continue);
        
        if( !$continue ){
            
            return false;
                        
        } 

        if( Config::_get('website.ips.block.message.offline') ){

            $this->_websiteOffline();            

        }else{
            ?>
                <div style="text-align: center">
                    <?php echo Config::_get('website.ips.block.message'); ?>
                </div>
            <?php
        }
        
        die();

    }

	/**
	 * Actions to be done for Restricted access
	 *
	 * @param $continue(boolean)
	 * @return null
	 */
	public static function _accessRestricted( $continue = false ) {
		
        $continue = Plugins::_runAction('base_access_restricted',$continue);
        
        if( !$continue ){

            return false;
                        
        } 

		$action = '<script>raccess();</script>';

		if($continue){

            return $action;		    

		} 
		
		die($action);

	}

	/**
	 * Returns file name with our extension
	 *
	 * @param $url(sting)
	 * @return file name(string)
	 */
	public static function _getFileName($filepath) {

		$pathinfo = pathinfo($filepath);

        $nameFile = $pathinfo['filename'];

        $nameFile = Plugins::_runAction('base_get_file_name',$nameFile,$filepath);

		return $nameFile;

	}

	/**
	 * Redirects the page to given url
	 *
	 * @param $url(sting)
	 * @return null
	 */
	public static function _pageRedirect($url) {
	    
        $continue = true;
        $return = Plugins::_runAction('base_page_redirect',array($url,$continue) );

        $url = $return[0];
        $continue = $return[1];
        
        if( !$continue ){

            return false;            

        } 
        
		// Closing the session_write
		session_write_close();
		// Checking the header_sent status
		if (headers_sent()) {

			// If header alredy sent then redirecting the page in javascript
			echo "<script>document.location.href='" . $url . "';</script>\n";

		} else {

			// If header didn't sent then redirecting the page in php
			header('Location: ' . $url);

		}

		// Halting further execution of the page
		die();

	}

	/**
	 * Generates randomg string
	 *
	 * @param $length(int)
	 * @return string
	 */
	public static function _generateRandomString($length) {

		// Source to generate random string from
		$characters = "0123456789abcdefghijklmnopqrstuvwxyz";
		$string = '';

		for ($p = 0; $p < $length; $p++) {

			$string .= $characters[mt_rand(0, strlen($characters) - 1)];

		}

        $string = Plugins::_runAction('base_generate_random_string',$string,$length );

		return $string;

	}

	/**
	 * Generates randomg nuber
	 *
	 * @param $length(int)
	 * @return int
	 */
	public static function _generateRandomNo($length) {

		// Source to generate random no from
		$characters = "0123456789";
		$number = '';

		for ($p = 0; $p < $length; $p++) {
		    
			$number .= $characters[mt_rand(0, strlen($characters) - 1)];

		}

        $number = (int)$number;
        $number = Plugins::_runAction('base_generate_random_no',$number,$length );

		return $number;

	}

	/**
	 * Generates Pagination
	 *
	 * @param sql query(string),current page(int),per page(int),display page no(int)
	 * @return int
	 */
	public static function _generatePagination($query, $currentpage, $perpage, $display) {// Function to Generate List of Pages

		if ((int)$currentpage == 0){

            $currentpage = 1;
		    
		}

		if ((int)$perpage <= 0){

            $perpage = 10;
		    
		}

		// Fetching the no of results
		$numRows = Core::_getRowCount($query["sql"], $query["arrayBind"]);

		// Calculating the total no of pages.
		$totalpages = ceil($numRows / $perpage);

		// Validating the lower boundaaries of $currentpage
		if ($currentpage < 1) {

			$currentpage = 1;

		}

		// Validating the upper boundaaries of $currentpage
		if ($currentpage > $totalpages) {

			$currentpage = $totalpages;

		}

		// Calculating the lower limit of pages to display. First page starts from $LL
		$LL = $currentpage - $display;

		// Validating case where display is greater than or equal to current pages
		// Calculating the upper limit of pages to display. Last page ends at $UL
		if ($LL < 1) {

			$UL = $currentpage + $display - ($currentpage - $display) + 1;
			$LL = 1;

		} else {

			$UL = $currentpage + $display;

		}

		// Validating case where display is greater total pages
		if ($UL > $totalpages) {

			$LL = $currentpage - $display - ($currentpage + $display) + $totalpages;
			$UL = $totalpages;

		}

		// Final validation of Lower Limit of pages
		if ($LL < 1){

            $LL = 1;
		    
		}

		// Pages generation starts here
		$pages = array();

		// Generating previous page
		if ($currentpage > 1) {

			$tmp_page['key'] = $currentpage - 1;
			$tmp_page['value'] = Config::_getMessage('lists.pagination.previous');
			$pages[] = $tmp_page;

		}
        
		// Generating pages
		for ($i = $LL; $i <= $UL; $i++) {

			$tmp['key'] = $i;
			$tmp['value'] = $i;
			$pages[] = $tmp;

		}
        
		// Generating Next page
		if ($currentpage < $totalpages) {

			$tmp_page['key'] = $currentpage + 1;
			$tmp_page['value'] = Config::_getMessage('lists.pagination.next');
			$pages[] = $tmp_page;

		}

		// Calculating Lower Limit. This will be used as the lower limit in generating database queries
        $pagination['LL'] = ($currentpage == 0 ) ? 0 : ( ($currentpage - 1) * $perpage );
		// Calculating Limit. This will be used as the limit in generating database queries
		$pagination['LT'] = $perpage;
		// Calculating Display From. This will be used to display the display from count
		$pagination['DF'] = ($numRows == 0) ? 0 : ($pagination['LL'] + 1);
		// Calculating Display To. This will be used to display the display to count
		$pagination['DT'] = (($pagination['LL'] + $pagination['LT']) > $numRows) ? $numRows : ($pagination['LL'] + $pagination['LT']);
		// This will be total no of pages
		$pagination['TR'] = $numRows;
		// No of records Per Page
		$pagination['PP'] = $perpage;
		// Current page
		$pagination['current_page'] = $currentpage;
		// Generated list of pages
		$pagination['pages'] = $pages;

        $pagination = Plugins::_runAction('base_generate_pagination',$pagination, $query, $currentpage, $perpage, $display );

		return $pagination;

	}

	/**
	 * Generates image code through php
	 *
	 * @param source of the image(string),width of the image(int),height of the image(int)
	 * @return generated image code(string)
	 */
	public static function _displayPhpthumb($src, $width = '', $height = '') {
		
		$ext = explode('.',$src);
		
		$extension = isset($ext[1])?$ext[1]:'';
		
		if($extension == 'flv'){			
			$path = Config::_getUrl('img') . '/video-icon.jpg';
		}else{
			$path = Config::_getUrl('img') . '/' . $src;
		}

		$path = Plugins::_runAction('display_php_thumbs', $path, $src, $width, $height);

		return $path;

	}

	/**
	 * Converts byts to Display Size
	 *
	 * @param image id(int)
	 * @return image path(string)
	 */
	public static function _convertByes($bytes, $precision = 2) {

		$kilobyte = 1024;
		$megabyte = $kilobyte * 1024;
		$gigabyte = $megabyte * 1024;
		$terabyte = $gigabyte * 1024;

		if (($bytes >= 0) && ($bytes < $kilobyte)) {

			$bytesC = $bytes . ' B';

		} elseif (($bytes >= $kilobyte) && ($bytes < $megabyte)) {

			$bytesC = round($bytes / $kilobyte, $precision) . ' KB';

		} elseif (($bytes >= $megabyte) && ($bytes < $gigabyte)) {

			$bytesC = round($bytes / $megabyte, $precision) . ' MB';

		} elseif (($bytes >= $gigabyte) && ($bytes < $terabyte)) {

			$bytesC = round($bytes / $gigabyte, $precision) . ' GB';

		} elseif ($bytes >= $terabyte) {

			$bytesC = round($bytes / $terabyte, $precision) . ' TB';

		} else {

			$bytesC = $bytes . ' B';

		}

        $bytesC = Plugins::_runAction('display_convert_bytes', $bytesC, $bytes, $precision);
        
        return $bytesC;

	}

	/**
	 * Returns the valid page no
	 *
	 * @param page id(int)
	 * @return verified page id(int)
	 */
	public static function _verifyPageNo($pageNo) {

        $verified = true;
        
		global $Menus;
		$menuAdmin = $Menus -> _loadAdminMenu($pageNo);

		if (!$menuAdmin || !$menuAdmin -> statusMenu ){

		    $verified = false;

		}

        $verified = Plugins::_runAction('base_vefiry_page_no',$verified,$pageNo );
            
        if( !$verified ){

            self::_pageRedirect('home.php');

        }

	}

	/**
	 * Prepares link to use in url
	 *
	 * @param link(string)
	 * @return link(string)
	 */
	public function _prepareLink($link) {

		$old_pattern = array("/ /", "/[^a-zA-Z0-9.-]/");
		$new_pattern = array("-", "");

		$newLink = strtolower(preg_replace($old_pattern, $new_pattern, $link));

        $newLink = Plugins::_runAction('base_prepare_link',$newLink,$link );
        
		return $newLink;

	}

	/**
	 * Containts the list of selects like gender, status etc. Returns required select values
	 * Also converts the normal array into the preferrent select generation form
	 *
	 * @param select array key/ array(string/array)
	 * @return array
	 */
	public static function _generateSelect($keySelect) {

		global $Cms;
        
        $generatedArray = false;        

		// Here we convert to different types of arrays as sets.
		// Type 1: Used to convert array of objects
		// There are useful especilaly for multidimenssional array or rows generated from database
		// ex: $users = array( {userid,name,email},{userid,name,email})
		// We can convert this by sending _generateSelect(array($users,userid,name))
		// This will create an array with keys as useids and names as values
		if (is_array($keySelect) && count($keySelect) > 0) {

			if(isset($keySelect[0]) && is_array($keySelect[0]) && count($keySelect) == 3){

				foreach ($keySelect[0] as $key => $value) {

					$generatedArray[$value -> $keySelect[1]] = $value -> $keySelect[2];

				}

			}else{

				// If it is an array butnot falls under that condition, then we will simply return the array by considering it is in the set format array[key]=value.
				$generatedArray = $keySelect;

			}

		}


        if( !$generatedArray ){

            if (Cache::_getInstance() -> _isCached('select_' . $keySelect)) {

                $generatedArray = Cache::_getInstance() -> _getCache('select_' . $keySelect);

            } else if ($Cms -> _checkLinkSet($keySelect)) {
                
                $selectValues = $Cms -> _prepareSet($keySelect);
                Cache::_getInstance() -> _setCache('select_' . $keySelect, $selectValues);
                $generatedArray = $selectValues;

            }

        }

        $generatedArray = Plugins::_runAction('base_default_select',$generatedArray,$keySelect );

		return $generatedArray;

	}

	/**
	 * Sorts multi dimenssion array by a key
	 *
	 * @param array,sub key
	 * @return array
	 */
	public static function _sortSubKey($a, $subkey) {

		if (count($a) > 1) {

			foreach ($a as $k => $v) {

				$b[$k] = strtolower($v[$subkey]);

			}

			asort($b);

			foreach ($b as $key => $val) {

				$c[] = $a[$key];

			}

			return $c;

		} else{

            return $a;
		    
		}

	}

	/**
	 * Returns sequence of nos
	 *
	 * @param start sequence from(int),end sequence at(int),increate sequence by(int)
	 * @return array
	 */
	public static function _getSequence($llimit, $ulimit, $step) {

		for ($i = $llimit; $i <= $ulimit; $i = $i + $step) {

			$sequence[$i] = $i;

		}
        
        $sequence = Plugins::_runAction('base_get_sequence',$sequence,$llimit, $ulimit, $step);
        
		return $sequence;

	}

	/**
	 * Returns years from this year to year-limit
	 *
	 * @param no of years(int)
	 * @return array
	 */
	public static function _getYears($limit) {

		// Current year
		$year = date('Y', time());

		// Generating yeras
		for ($i = 0; $i < $limit; $i++) {

			$years[] = $year - $i;

		}

		return $years;

	}

	/**
	 * Converts to given timestamp
	 *
	 * @param date(string),time zone(string)
	 * @return array
	 */
	public static function _convertTimeZone($time, $timezone = '') {

		if ($timezone == ''){

            $convertedDate = $time;

		}else{
		    
            $dtzone = new DateTimeZone($timezone);
            $dtime = new DateTime($time);
            $dtime -> setTimeZone($dtzone);
            $convertedDate = $dtime -> format('Y-n-d h:i.s');
		}

        $convertedDate = Plugins::_runAction('base_convert_time_zone',$convertedDate, $time, $timezone);

		return $convertedDate;

	}

	/**
	 * Removes duplicates from array
	 *
	 * @param array
	 * @return array(with out duplicates)
	 */
	public static function _removeArrayDuplicates($array) {

		if (!is_array($array)){

            return false;
		    
		}

		$duplicates = array_unique($array);

		return $duplicates;

	}

	/**
	 * Returns duplicates in array
	 *
	 * @param array
	 * @return array(duplicates)
	 */
	public static function _arrrayDuplicates($array) {

		if (!is_array($array)){

            return false;
		    
		}

		$duplicates = array();
		$unique = array_unique($array);

		if (count($array) > count($unique)) {

			for ($i = 0; $i < count($array); $i++) {

				if (!array_key_exists($i, $unique)) {

					$duplicates[] = $array[$i];

				}

			}

		}

		return $duplicates;

	}

	/**
	 * Creates the file in the given directory with the given content
	 * Creates the directory if doesn't exists
	 *
	 * @param $pathFile(string),$contentFile(string)
	 * @return boolean
	 */

	public function _createFile($pathFile, $contentFile) {

		$dirPath = dirname($pathFile);

		if (!file_exists($dirPath) || !is_dir($dirPath)) {

            $oldmask = umask(0);

			if(!mkdir($dirPath, 0755, true)){

                return false;			    

			}

            umask($oldmask);        

		}

		if(!file_put_contents($pathFile, $contentFile)){

            return false;;		    

		}

		return true;

	}

	/**
	 * Reads the list of the files in a given directoy recursively
	 *
	 * @param path name
	 * @return array(list of the files)
	 */
	public function _readDir($dir) {

		$listFiles = array();

		if (!is_dir($dir) || is_link($dir)) {

			return $dir;

		}

		if (is_dir($dir)) {

			foreach (scandir($dir) as $file) {

				if ($file == '.' || $file == '..'){

                    continue;
				    
				}

				if (is_dir($dir . DIRECTORY_SEPARATOR . $file)) {

					$listFiles = array_merge($listFiles, $this -> _readDir($dir . DIRECTORY_SEPARATOR . $file));

				} else {

					$listFiles[] = $dir . DIRECTORY_SEPARATOR . $file;

				}

			}

		}

		return $listFiles;

	}

	/**
	 * Remove the file or folder
	 * If it is a folder then it will remove it recursively
	 *
	 * @param path name
	 * @return boolean
	 */
	public function _removeDir($dir) {

		if (!is_dir($dir) || is_link($dir)) {

			if (file_exists($dir)) {

				return unlink($dir);

			}

		}

		if (is_dir($dir)) {

			foreach (scandir($dir) as $file) {

				if ($file == '.' || $file == '..'){

                    continue;
				    
				}

				if (!self::_removeDir($dir . DIRECTORY_SEPARATOR . $file)) {

					chmod($dir . DIRECTORY_SEPARATOR . $file, 0777);

					if (!self::_removeDir($dir . DIRECTORY_SEPARATOR . $file)){

                        return false;
					    
					}

				};

			}

			return rmdir($dir);

		}

	}

	/**
	 * Copies entire directory content to another directory
	 * If it is a folder then it will copy it recursively
	 *
	 * @param path (source), path(destination)
	 * @return boolean
	 */
	public function _copyDir($src, $dst) {

		$dir = opendir($src);

		@mkdir($dst);

		while (false !== ($file = readdir($dir))) {

			if (($file != '.') && ($file != '..')) {

				if (is_dir($src . '/' . $file)) {

					$this -> _copyDir($src . '/' . $file, $dst . '/' . $file);

				} else {

					copy($src . '/' . $file, $dst . '/' . $file);

				}

			}

		}

		closedir($dir);

	}

}


