<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* List class, used for generating lists 
* This includes handling generating, searching, sorting, page generation of lists
*
* @version 1.0
* @http://www.quikc.org/
*/

class Mail{

    /**
    * Contains the from address
    *
    * @var string
    */
 	private $from;

    /**
    * Contains the array of to addresses
    *
    * @var array of strings
    */
 	private $to = array();
	
	 /**
    * Contains the Reply-to address
    *
    * @var string
    */
 	private $replyTo = array();

    /**
    * Contains the subject of the mail
    *
    * @var string
    */
 	private $subject;

    /**
    * Contains the body of the mail
    *
    * @var string
    */
 	private $body;

    /**
    * Contains the variables to be replaced in the subject and the body of the mail
    *
    * @var array of strings
    */
 	private $variables;

    /**
    * Contains the list of error messages
    *
    * @var array of strings
    */
 	private $errors = false;
	
	
    /**
    * updates the from address
    *
    * @param $email(string)
    * @return null
    */
    public function _setFrom($email){	
		$this->from = $email;
	}

    /**
    * Returns the from address
    *
    * @param void
    * @return $email(string)
    */
    private function _getFrom(){	
		return $this->from;
	}

    /**
    * updates the to address
    *
    * @param $email(string)
    * @return null
    */
    public function _setTo($email){	
		$this->to[] = $email;
	}

    /**
    * Returns the to address
    *
    * @param void
    * @return $email(array of strint string)
    */
    private function _getTo(){	
		return $this->to;
	}

    /**
    * updates the subject of the mail
    *
    * @param $subject(string)
    * @return null
    */
    public function _setSubject($subject){	
		$this->subject = $subject;
	}

    /**
    * Returns the subject of the mail
    *
    * @param void
    * @return $subject(string)
    */
    private function _getSubject(){	
		return $this->subject;
	}

    /**
    * updates the body of the mail
    *
    * @param $body(string)
    * @return null
    */
    public function _setBody($body){	
		$this->body = $body;
	}

    /**
    * Returns the body of the mail
    *
    * @param void
    * @return $body(string)
    */
    private function _getBody(){	
		return $this->body;
	}

    /**
    * updates the variables to be replaced in the subject and body of the mail
    *
    * @param $variables(array)
    * @return null
    */
    public function _setVariables($variables){	
		$this->variables = $variables;
	}

    /**
    * Returns the variables to be replaced in the subject and body of the mail
    *
    * @param void
    * @return $vataibles(array of strings)
    */
    private function _getVariables(){	
		return $this->variables;
	}
	
	/**
    * Returns errors messages
    *
    * @param void
    * @return $body(string)
    */
    private function _getErrors(){	
		return $this->errors;
	}
	
	/**
    * Returns errors messages
    *
    * @param $body(string)
    * @return null
    */
    private function _setError($error){	
		$this->errors[] = $error;
	}
	
	/**
    * Sets mail for Add Reply To
    *
    * @param $body(string)
    * @return null
    */
    private function _setReplyTo($email){	
		$this->replyTo = $email;
	}
	
	/**
    * Returns reply-to mail address
    *
    * @param void
    * @return $body(string)
    */
    private function _getReplyTo(){	
		return $this->replyTo;
	}

    /**
    * Retrieves the mail content from database by link
    *
    * @param $body(string)
    * @return null
    */
    public function _setDbMail($linkMail){

		global $Cms;

		$content = $Cms->_getMailDetailsByLink($linkMail);
		
		$this->_setFrom($content->from);
		$this->_setReplyTo($content->replyTo);
		$this->_setSubject($content->subject);
		$this->_setBody($content->body);	
	}

    /** Prepare the subject and body by replacing with appropriate variables
    * 
    *
    * @param void
    * @var null
    */
    private function _replaceVariables(){
    	$variables  = $this->_getVariables();
        $subject	= $this->_getSubject();
        $body		= $this->_getBody();

		if(count($variables) > 0){
	        foreach($variables as $keyIdentifier => $valueIdentifier){
	            $subject = str_replace($keyIdentifier, $valueIdentifier, $subject);
	            $body 	= str_replace($keyIdentifier, $valueIdentifier, $body);
	        }
		}
		$this->_setSubject($subject);
		$this->_setBody($body);
    }

    /** Validates the fields of the mails
    * 
    *
    * @param void
    * @var null
    */
    private function _validateFields(){

		$from	 = $this->_getFrom();
		$to   	 = $this->_getTo();
		$replyTo = $this->_getReplyTo();
		$subject = $this->_getSubject();
		$body    = $this->_getBody();
		
		if( $from == '' && Config::_get('email.default') == '' ){
			$this->_setError(Config::_getMessage('mails.empty.from'));
		}else if( $from == '' ){
			$this->_setFrom(Config::_get('email.default'));
			$from 	= $this->_getFrom();
		}
		if( !Validate::_validateEmail($from) ){
			$this->_setError(Config::_prepareMessage('mails.invalid.from'),array(':MAIL_ADDRESS'=>$from));
		}
		
		if( $replyTo == ''){
			$this->_setReplyTo($from);
		}
		
		if( count($to) == 0 ){
			$this->_setError(Config::_getMessage('mails.empty.to'));
		}else{
			foreach($to as $email){
				if( !Validate::_validateEmail($email) ){
					$this->_setError(Config::_prepareMessage('mails.invalid.to'),array(':MAIL_ADDRESS'=>$email));
				}				
			}
		}
		
		if( $subject == '' ){
			$this->_setError(Config::_getMessage('mails.empty.subject'));
		}
		
		if( $body == '' ){
			$this->_setError(Config::_getMessage('mails.empty.body'));
		}
		
    }

    /**
    * Sends the email
    *
    * @param void
    * @return $status(string/array of strings)
    */
    public function _send(){
		
		$this->_replaceVariables();
		$this->_validateFields();
		
		$from 	 = $this->_getFrom();
		$to   	 = $this->_getTo();
		$replyTo = $this->_getReplyTo();
		$subject = $this->_getSubject();
		$body    = $this->_getBody();
		$errors  = $this->_getErrors();
		
		if( $errors ){
			return $errors;
		}else{
		    
            if( Config::_get('mail.send.server') == 'defaultphpmailer' ){
                
                //$result = mail();
            }
            
            $result = Plugins::_runAction('send_mail',$this); 
                		
			include_once(Config::_getDir().'/includes/apis/phpmailer/class.phpmailer.php');
			
			$PHPmail = new PHPMailer();
			$PHPmail->SetFrom($from);
			foreach($to as $to_mail){
				$PHPmail->AddAddress($to_mail);
			}
			$PHPmail->AddReplyTo($replyTo);
			$PHPmail->Subject = $subject;
			$PHPmail->MsgHTML($body);
			$result = $PHPmail->send();
			
			return $result;
		}
	}
}

