<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * SearchMe class, contains functions related to instant search
 *
 *
 * @version 1.0
 * @http://www.quikc.org/
 */
 
class SearchMe {

	/**
	 * Contains the object of the current variable
	 *
	 * @var Object
	 */
	 private static $listFiles = false;
	 
    /**
     * returns the list of search me files found
     *
     * @param string($Action)
     * @return null
     */
    public function _filesSearchMe() {
    	
		if( self::$listFiles ) return self::$listFiles;

		global $Base;

		$locationsFile = array(
							Config::_getDir('admin').'/includes/core/modules/ajax/get/searchme',
							Config::_getDir('admin').'/includes/custom/modules/ajax/get/searchme',
						 );

		$listFiles = array();
				
		foreach($locationsFile as $location){
			$loadedFiles = false;
			$loadedFiles = $Base->_readDir($location);
			
			if( is_array($loadedFiles) ){
				$listFiles = array_merge($listFiles,$loadedFiles);
			}
		}
		
		self::$listFiles = $listFiles;

        $listFiles = Plugins::_runAction('searchme_files_searchme', $listFiles);

        return $listFiles;
    }

    /**
     * returns the default limit for each item in search results
     *
     * @param void
     * @return int
     */
    public function _defaultLimit() {

        $limit = 5;

        $limit = Plugins::_runAction('searchme_default_limit', $limit);

    	return $limit;
	}

    /**
     * returns the max limit for the search items
     *
     * @param void
     * @return int
     */
    public function _maxLimit() {
        $limit = 25;

        $limit = Plugins::_runAction('searchme_max_limit', $limit);

        return $limit;
	}
	
    /**
     * performs the search query and returns the results
     *
     * @param $query, $arrayBind = array(), $limit
     * @return array of object/boolean
     */
    public function _processQuery($query, $arrayBind = array(), $limit) {
    	
        $resultsQuery = false;
        
		if( $query != '' ){

            $defaultLimit = $this->_defaultLimit();
        
            $limit = (int)$limit;   
    
            if( !is_int($limit) || $limit < 0 ){
                $limit = $defaultLimit;
            }else if( $limit > $this->_maxLimit() ){
                $limit = $this->_maxLimit();
            }   
            
            $query .= ' limit 0, :limit ';
            $arrayBind[]= array("key" => ":limit",   "value" =>  $limit );
            
            $resultsQuery = Core::_getAllRows($query, $arrayBind);
		    
		}
        
        $resultsQuery = Plugins::_runAction('searchme_process_query', $resultsQuery,$query, $arrayBind , $limit);
		
        return $resultsQuery;
    }

    /**
     * returns the default preferences 
     *
     * @param void
     * @return int
     */
    public function _getDefaultPreference() {

		global $User;
		
		$idPref = $User->_getUserPreference('/admin/searchme/preferences/default');

		if( $idPref == '' ){
			$idPref = -1;
		}else{
	
			$listPref = $User->_getUserPreference('/admin/searchme/preferences');
			
			if( !isset($listPref[$idPref]) ){
				$idPref = -1;
			}
		}

        $idPref = Plugins::_runAction('searchme_get_default_preference', $idPref);
		
    	return $idPref;
	}

    /**
     * processes and returns search preferences from string 
     *
     * @param string
     * @return array
     */
    public function _processPreferences($prefString) {
    	
        if( $prefString == '' ) return;
        
		$prefArray   = explode("_SPLIT_",$prefString);
		$sortedItems = array();
		
		foreach($prefArray as $item){
			$detailsItem = explode(",",$item);	
			$sortedItems[$detailsItem[0]] = array( 'active' => $detailsItem[1], 'rows' => $detailsItem[2]);
		}

        $sortedItems = Plugins::_runAction('searchme_process_preferences', $sortedItems, $prefString);

    	return $sortedItems;
	}
	
}
