<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * This class contains functions related to space
 *
 * @version 1.0
 * @http://www.quikc.org/
 */
class Spaces {

	/**
	 * Contains cache key for  the current space instance
	 *
	 * @var string
	 */
	private $keyCache;

	/**
	 * Contains the page id for the current space instance
	 *
	 * @var idPage
	 */
	private $idPage;

	/**
	 * Contains details of the spaces information
	 *
	 * @var array of objects
	 */
	private static $retrievedSpaces;

	/**
	 * Contains the object of the current variable
	 *
	 * @var Object
	 */
	private static $instances;

	/**
	 * Contains details of the current space
	 *
	 * @var objects
	 */
	private $detailsSpace;

	/** Constructer of the Spaces class.
	 *
	 *
	 * @param void
	 * @var null
	 */
	private function __construct() {
	}

	/** Sets given value as space cache key
	 *
	 *
	 * @param string
	 * @var null
	 */
	private function _setCacheKey($key) {
	    
        $key = Plugins::_runAction('spaces_set_cache_key', $key);

		$this->keyCache = $key;

	}

	/** Returns current cache key
	 *
	 *
	 * @param void
	 * @var string
	 */
	private function _getCacheKey() {
	    
        $key = $this->keyCache;
        
        $key = Plugins::_runAction('spaces_get_cache_key');

		return $key;

	}

	/** Sets given idPage as space page
	 *
	 *
	 * @param string
	 * @var null
	 */
	private function _setPage($idPage) {
	    
        $idPage = Plugins::_runAction('spaces_set_page',$idPage);
        
		$this->idPage = $idPage;

	}

	/** Returns current cache key
	 *
	 *
	 * @param void
	 * @var string
	 */
	private function _getPage() {

        $idPage = $this->idPage;

        $idPage = Plugins::_runAction('spaces_get_page',$idPage);
        
		return $idPage;

	}

	/** Creates the instance by id
	 * Note: This won't create any new instances if doesn't exiss, only returns the instances
	 *
	 *
	 * @param $idSpace(int)
	 * @var mixed(Core class instance(object)|boolean)
	 */
	public static function _getInstanceById($idSpace) {

        $instance = false;
		
		if( $idSpace && ($detailsSpace = self::_getSpaceDetailsById($idSpace) )  ) {

            $titleSpace = $detailsSpace->titleSpace;
            
            if($detailsSpace->globalSpace){

                $instance = self::_getGlobalInstance($titleSpace);

            }else{

                $instance = self::_getInstance($titleSpace,$detailsSpace->idPage);

            }
		    
		}
		
        $instance = Plugins::_runAction('spaces_get_instance_by_id',$instance,$idSpace);

		return $instance;

	}

	/** Creates local space instance or returns existing instances
	 *
	 *
	 * @param $titleSpace(string),$idSpace(int)
	 * @var Core class instance(object)
	 */
	public static function _getInstance($titleSpace,$idPage=false) {
		
		global $Themes;
		
		if($idPage){

			$keyCache = $idPage;

		}else if(isset($Themes->_getCurrentPageDetails()->idPage)){

			$keyCache	= $Themes->_getCurrentPageDetails()->idPage;
			$idPage		= $Themes->_getCurrentPageDetails()->idPage;

		}else{

			return false;

		}
		
		//$this->
		if (isset(self::$instances[$keyCache][$titleSpace])){
		    
            $instanceSpace = self::$instances[$keyCache][$titleSpace];
            
            $instanceSpace = Plugins::_runAction('spaces_get_instance',$instanceSpace,$titleSpace,$idPage);
            
            return $instanceSpace;

		}

		// Getting the name of the class. Here it is Core
		$object = __CLASS__;
		// Starting new class object
		$instance = new $object;

		// Updating above calculated $keyCache as cache variable
		// This will be updated once the details retrieved again
		// It is used as temporary for the first time data get
		$instance -> _setCacheKey($keyCache);

		// Updating above calculated $idPage as page id variable
		// This will be updated once the details retrieved again
		// It is used as temporary for the first time data get
		$instance -> _setPage($idPage);
		
		$detailsSpace = $instance -> _getSpaceDetails($titleSpace);

		if (!$detailsSpace) {

			if (!$instance -> _createSpace($titleSpace)){

                die("Can't Create Space :" . $titleSpace);

			}

			$detailsSpace = $instance -> _getSpaceDetails($titleSpace);
		}
		
		$instance -> detailsSpace = $detailsSpace;
		
		$instance -> _setCacheKey($keyCache);
		
		$instance -> _setPage($detailsSpace -> idPage);

		self::$instances[$instance -> _getCacheKey()][$titleSpace] = $instance;

        $instanceSpace = self::$instances[$instance -> _getCacheKey()][$titleSpace];

        $instanceSpace = Plugins::_runAction('spaces_get_instance',$instanceSpace,$titleSpace,$idPage);

		return $instanceSpace;

	}

	/** Creates global space instance
	 *
	 *
	 * @param void
	 * @var Core class instance(object)
	 */
	public static function _getGlobalInstance($titleSpace) {

		if (isset(self::$instances['global'][$titleSpace])){

            $instanceSpace = self::$instances['global'][$titleSpace];
            
            $instanceSpace = Plugins::_runAction('spaces_get_global_instance',$instanceSpace,$titleSpace);
            
            return $instanceSpace;

		}

		// Getting the name of the class. Here it is Core
		$object = __CLASS__;
		// Starting new class object
		$instance = new $object;

		$instance -> _setCacheKey('global');
		$detailsSpace = $instance -> _getSpaceDetails($titleSpace,'global');
		
		if (!$detailsSpace) {

			if (!$instance -> _createSpace($titleSpace,'global')){

                die("Can't Create Global Space :" . $titleSpace);
			    
			}

			$detailsSpace = $instance -> _getSpaceDetails($titleSpace,'global');
		}

		$instance -> detailsSpace = $detailsSpace;

		self::$instances[$instance -> _getCacheKey()][$titleSpace] = $instance;

        $instanceSpace = self::$instances[$instance -> _getCacheKey()][$titleSpace];

        $instanceSpace = Plugins::_runAction('spaces_get_global_instance',$instanceSpace,$titleSpace);

        return $instanceSpace;

	}
	
	/** This will update the cache of current space id
	 *
	 *
	 * @param void
	 * @var none
	 */
	public function _updateCache() {

		$detailsSpace = self::_getSpaceDetailsById($this -> _getDetails() -> idSpace);
		
		self::$retrievedSpaces[$this->_getCacheKey()][$detailsSpace->titleSpace] = $detailsSpace;
		Cache::_getInstance() -> _setCache('spaces_'.$this->_getCacheKey().'_' . $detailsSpace->titleSpace,$detailsSpace);

        Plugins::_runAction('spaces_update_cache',$detailsSpace);
        
	}

	/**
	 * Creates New Space
	 *
	 * @param string(Space Title)
	 * @return boolean
	 */
	public function _createSpace($titleSpace,$globalSpace=false) {
		
        $return = false;
        
		global $Themes;
		
		if(isset($Themes->_getCurrentPageDetails()->idPage)){

            if($globalSpace == 'global'){
                
                $globalSpace = 1;

            }else{
                
                $globalSpace = 0;
            }
                
            $query = " insert into " . Config::_getTable('spaces') . " (titleSpace,idPage,globalSpace,dateAdditionSpace) 
            values (:titleSpace,:idPage,:globalSpace,NOW()) ";
    
            $arrayBind[] = array("key" => ":titleSpace" , "value" => $titleSpace);
            $arrayBind[] = array("key" => ":idPage"     , "value" => $Themes->_getCurrentPageDetails()->idPage);
            $arrayBind[] = array("key" => ":globalSpace", "value" => $globalSpace);
    
            if (Core::_runQuery($query, $arrayBind)){

                $return = true;

            }
		    
		}

        $return = Plugins::_runAction('spaces_create_space',$return,$titleSpace,$globalSpace);

		return $return;

	}

	/**
	 * Returns current space details
	 *
	 * @param string(Space Title)
	 * @return boolean
	 */
	public function _getDetails() {

        $detailsSpace = $this->detailsSpace ;
        
        $detailsSpace = Plugins::_runAction('spaces_get_details',$detailsSpace);

		return $detailsSpace;

	}

	/**
	 * Generates the list of widgets for the space
	 *
	 * @param void
	 * @return array of objects
	 */
	public function _generateWidgets() {
		
		global $Relations,$Widgets;

		$listWidgetItems = $Relations->_getRalations('space_to_widget',$this -> _getDetails() -> idSpace,'','','','','dateAdditionRelation');
		
		foreach($listWidgetItems as $key => $relation){
		    
			$detailsWidgetItem = $Widgets->_getWidgetItem($relation->idTo);

			// If widget items doesn't exists or it is not global and not created by the space, then deleting that widget
			if( !$detailsWidgetItem || ( !$detailsWidgetItem->globalWidgetItem && $detailsWidgetItem->idSpace != $this -> _getDetails() -> idSpace )  ){

				unset($listWidgetItems[$key]);

			}
		}

        $listWidgetItems = Plugins::_runAction('spaces_generate_widgets',$listWidgetItems);

		return $listWidgetItems;

	}

	/**
	 * Returns Space details
	 *
	 * @param string(titleSpace Ttiel)
	 * @return mixed(object|boolean)
	 */
	public function _getSpaceDetails($titleSpace,$globalSpace=false) {

		global $Themes;
		
		if (isset(self::$retrievedSpaces[$this->_getCacheKey()][$titleSpace])) {

			$detailsSpace = self::$retrievedSpaces[$this->_getCacheKey()][$titleSpace];

		} else if (Cache::_getInstance() -> _isCached('spaces_'.$this->_getCacheKey().'_' . $titleSpace)) {

			$detailsSpace = Cache::_getInstance() -> _getCache('spaces_'.$this->_getCacheKey().'_' . $titleSpace);

		} else {
			
			if($globalSpace == 'global'){

				$query = " select * from " . Config::_getTable('spaces') . " where titleSpace = :titleSpace and globalSpace = :globalSpace ";
				$arrayBind[] = array("key" => ":titleSpace", 	"value" => $titleSpace);
				$arrayBind[] = array("key" => ":globalSpace",	"value" => 1);

			}else{

				$query = " select * from " . Config::_getTable('spaces') . " where titleSpace = :titleSpace and idPage = :idPage and globalSpace = :globalSpace ";
				$arrayBind[] = array("key" => ":titleSpace",	"value" => $titleSpace);
				$arrayBind[] = array("key" => ":globalSpace",	"value" => 0);
				$arrayBind[] = array("key" => ":idPage",		"value" => $this->_getPage());

			}

			$detailsSpace = Core::_getRow($query, $arrayBind);
			
			if ($detailsSpace){

                Cache::_getInstance() -> _setCache('spaces_' .$this->_getCacheKey().'_' .$detailsSpace -> titleSpace, $detailsSpace);

			}

		}

        if ($detailsSpace){

    		self::$retrievedSpaces[$this->_getCacheKey()][$detailsSpace -> titleSpace] = $detailsSpace;

        }
        
        $detailsSpace = Plugins::_runAction('spaces_get_space_details',$detailsSpace,$titleSpace,$globalSpace);

		return $detailsSpace;

	}

	/**
	 * Returns Space details
	 *
	 * @param int(idSpace)
	 * @return mixed(object)
	 */
	public static function _getSpaceDetailsById($idSpace,$globalSpace=false) {

		global $Themes;
		
		$query = " select * from " . Config::_getTable('spaces') . " where idSpace = :idSpace ";
		$arrayBind[] = array("key" => ":idSpace", 		"value" => $idSpace);

		$detailsSpace = Core::_getRow($query, $arrayBind);

        $detailsSpace = Plugins::_runAction('spaces_get_space_details_by_id',$detailsSpace,$idSpace,$globalSpace);
		
		return $detailsSpace;

	}

	/**
	 * Returns widget details
	 *
	 * @param int(idWidget id)
	 * @return none
	 */
	public function _display() {

		global $Widgets,$Editor;
		$listWidgets = $this->_generateWidgets();

        $listWidgets = Plugins::_runAction('spaces_list_display_widgets',$listWidgets);

        $dataDisplay = '';
        
		if( $this -> _getDetails() -> statusSpace && count($listWidgets) > 0 ){

			foreach($listWidgets as $widget){

				$Widgets->_displayWidget($widget->idTo,$widget->idFrom);

			}

		}elseif( !$this -> _getDetails() -> statusSpace && $Editor->_isCustomizeMode() ){

            $dataDisplay = '
                <span class="customEditorLabel customEditorLabel_enable">
                    <a href="javascript:parent.statusChanger(\'set/spaces\',\''.$this -> _getDetails() -> idSpace.'\',\'status\',\'\',\'CustomizeEditorSuccess\')">Enable Status</a>
                <span>
            ';

		}elseif( $Editor->_isCustomizeMode() ){ 

            $dataDisplay = '
                <span class="customEditorLabel customEditorLabel_enable">
                    <a href="javascript:parent.manageSpace(\''.$this -> _getDetails() -> idSpace.'\',\'CustomizeEditorSuccess\')">Manage Space</a>
                <span>
            ';

		}
        
        $dataDisplay = Plugins::_runAction('spaces_display_data',$dataDisplay);
        
        echo $dataDisplay;
        
	}

}


