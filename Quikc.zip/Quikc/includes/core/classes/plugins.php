<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * Plugin class, used for generating handling plugins
 * This includes installing plugins, manuplating and using of plugins
 *
 * @version 1.0
 * @http://www.quikc.org/
 */
class Plugins {

	/**
	 * Contains the list of initilized plugins
	 *
	 * @var array
	 */
	private static $initilizedPlugins = array();

	/**
	 * Contains the list of hooked plugins
	 *
	 * @var array
	 */
	private static $hookedActions = array();

	/**
	 * Contains the details of all the plugins
	 *
	 * @var object
	 */
	private static $detailsPlugins = array();

	/**
	 * Contains the list of working plugins
	 *
	 * @var array
	 */
	private static $workingPlugins = array();

	/**
	 * Contains the log details of all the plugins
	 *
	 * @var object
	 */
	public static $logsPlugins = array();

	/**
	 * Contains the information of the current plugin
	 *
	 * @var object
	 */
	private $detailsWorkingPlugin = false;

	/**
	 * Generates the id for the hook
	 *
	 * @param $hook_point(string),$function(array/string),$priority(integer),
	 * @return true(boolean)
	 */
	public static function _generateHookId($hook_point, $function, $priority) {

		if (is_string($function))
			return $function;

		if (is_object($function)) {
			$function = array($function, '');
		} else {
			$function = (array)$function;
		}

		if (is_object($function[0])) {
			return spl_object_hash($function[0]) . '_' . $function[1];
		} else if (is_string($function[0])) {
			return $function[0] . '_' . $function[1];
		}

		return true;
	}

	/**
	 * Hooks the function of a plugin
	 *
	 * @param $hook_point(string),$function(array/string),$priority(integer), $aurgments_count(integer)
	 * @return true(boolean)
	 */
	public static function _hookAction($hook_point, $function, $priority = 20, $aurgments_count = 1) {

		$idHook = self::_generateHookId($hook_point, $function, $priority);

		global $Plugins;

		$identifierPlugin = false;

		if (isset($Plugins -> _getWorkingPluginDetails() -> identifierPlugin))
			$identifierPlugin = $Plugins -> _getWorkingPluginDetails() -> identifierPlugin;

		self::$hookedActions[$hook_point][$priority][$idHook] = array('function' => $function, 'aurgments_count' => $aurgments_count, 'plugin' => $identifierPlugin);

		return true;
	}

	/**
	 * Hooks the function of a plugin
	 *
	 * @param $aurgments(array)
	 * @return null
	 */
	private static function _runAllActions($args) {

		reset(self::$hookedActions['all']);

		do {
			foreach ((array)current(self::$hookedActions['all']) as $action) {
				if (!is_null($action['function']) && is_callable($action['function'])) {
					call_user_func_array($action['function'], $args);
				}
			}
		} while(next(self::$hookedActions['all']) !== false );
	}

	/**
	 * Run the Hooked function for a particular tag
	 *
	 * @param $hook_point(string)
	 * @return null
	 */
	public static function _runAction($hook_point) {

		$args = array();

		$args = func_get_args();

		if (count($args) > 0){

            array_shift($args);
		    
		}

		if (!isset($args[0])){

            $args[0] = NULL;
		    
		}

		if (!isset(self::$hookedActions[$hook_point]) || !is_array(self::$hookedActions[$hook_point]) || 0 == count(self::$hookedActions[$hook_point])) {

			return $args[0];

		}

		if (isset(self::$hookedActions['all']) && is_array(self::$hookedActions['all'])) {

			self::_runAllActions(func_get_args());

		}

		ksort(self::$hookedActions[$hook_point]);

		reset(self::$hookedActions[$hook_point]);

		global $Plugins;

		do {

			foreach ((array)current(self::$hookedActions[$hook_point]) as $action) {

				if (!is_null($action['function']) && is_callable($action['function'])) {

					if (isset($action['plugin']) && $action['plugin']) {

						$Plugins -> _workingPlugin($action['plugin']);

					}

					$args[0] = call_user_func_array($action['function'], $args);
					//$value = call_user_func_array($action['function'], array_slice($args, 0,(int)$action['aurgments_count']));
					
				}
                
			}
            
		} while(next(self::$hookedActions[$hook_point]) !== false );

		$Plugins -> _removeWorkingPlugin();

		return $args[0];

	}

	/**
	 * Unhooks Action From the hook point
	 *
	 * @param $hook_point(string),$function(array/string),$priority(integer)
	 * @return true(boolean)
	 */
	public static function _unhookAction($hook_point, $function, $priority = 20) {

		$idHook = self::_generateHookId($hook_point, $function, $priority);

		if (self::$hookedActions[$hook_point][$priority][$idHook]) {
			unset(self::$hookedActions[$hook_point][$priority][$idHook]);

			if (empty(self::$hookedActions[$hook_point][$priority])) {
				unset(self::$hookedActions[$hook_point][$priority]);
			}

			if (empty(self::$hookedActions[$hook_point])) {
				unset(self::$hookedActions[$hook_point]);
			}

			return true;
		}

		return false;
	}

    /**
     * returns the list of installed plugins
     *
     * @param void
     * @return $listPlugins(array of objects)
     */
    public function _getActivePlugins() {
    
        $query = "select * from " . Config::_getTable('plugins') . " where `statusPlugin` = :statusPlugin ";
        $arrayBind[] = array("key" => ":statusPlugin", "value" => '1');
    
        $listPlugins = Core::_getAllRows($query, $arrayBind);

        $listPlugins = Plugins::_runAction('plugins_get_active_plugins', $listPlugins);
    
        return $listPlugins;
        
     }

	/**
	 * Generates the plugin Identifier from the menu link
	 *
	 * @param $linkMenu(string)
	 * @return $pluginLink(string)
	 */
	public function _generatePluginIdentifier($linkMenu) {

		$identifierPlugin = explode("-", $linkMenu);

        $identifierPlugin[0] = Plugins::_runAction('plugins_generate_identifier', $identifierPlugin[0],$linkMenu);

		return $identifierPlugin[0];
	}

	/**
	 * Generates the plugin page link
	 *
	 * @param $linkMenu(string)
	 * @return $pageLink(string)
	 */
	public function _generatePluginPage($linkMenu) {

		$pageLink = explode("-", $linkMenu);

		// Removing the Plugin identifier
		array_shift($pageLink);

        $return = implode("-", $pageLink);
        
        $return = Plugins::_runAction('plugins_generate_plugin_page', $return,$linkMenu);

		return $return;
	}

	/**
	 * checks the plugins with the given menu link
	 *
	 * @param $linkMenu(string)
	 * @return boolean
	 */
	public function _checkPluginLink($linkMenu) {

		$identifierPlugin = $this -> _generatePluginIdentifier($linkMenu);
        
        $return = $this -> _checkPluginIdentifier($identifierPlugin);
        
        $return = Plugins::_runAction('plugins_check_plugin_link', $return,$linkMenu);
        
		return $return;
	}

	/**
	 * Returns the list of auto load Plugins
	 *
	 * @param void
	 * @return array of objects
	 */
	public function _getAutoLoadPlugins() {

		$query = "select * from " . Config::_getTable('plugins') . " where statusPlugin = :statusPlugin and autoLoadPlugin = :autoLoadPlugin ";
		$arrayBind[] = array("key" => ":statusPlugin", "value" => 1);
		$arrayBind[] = array("key" => ":autoLoadPlugin", "value" => 1);

        $listPlugins = Core::_getAllRows($query, $arrayBind);
    
        $listPlugins = Plugins::_runAction('plugins_get_autoload_plugins', $listPlugins);

		return $listPlugins;
	}

	/**
	 * Loads all the auto load Plugins
	 *
	 * @param void
	 * @return array of objects
	 */
	public function _loadAutoLoadPlugins() {

		$listPlugins = $this -> _getAutoLoadPlugins();

		foreach ($listPlugins as $Plugin) {
			$this -> _initilizePlugin($Plugin -> identifierPlugin);
		}

        Plugins::_runAction('plugins_load_autoload_plugins');
        
	}

	/**
	 * checks the plugins with the given plugin identifier
	 *
	 * @param $identifierPlugin(string)
	 * @return boolean
	 */
	public function _checkPluginIdentifier($identifierPlugin) {

        $return = false;

		if (isset($this -> _getPluginDetailsByIdentifier($identifierPlugin) -> statusPlugin) && $this -> _getPluginDetailsByIdentifier($identifierPlugin) -> statusPlugin) {
			$return = true;
		}

        $return = Plugins::_runAction('plugins_check_plugin_identifier',$return,$identifierPlugin);

		return $return;
	}

	/**
	 * Returns the details of the plugin by using the id
	 *
	 * @param $idPlugin(string)
	 * @return boolean
	 */
	public function _getPluginDetailsById($idPlugin) {

		$query = "select * from " . Config::_getTable('plugins') . " where `idPlugin` = :idPlugin ";
		$arrayBind[] = array("key" => ":idPlugin", "value" => $idPlugin);

        $detailsPlugins = Core::_getRow($query, $arrayBind);

        $detailsPlugins = Plugins::_runAction('plugins_get_plugin_details_by_link',$detailsPlugins,$idPlugin);
        
        return $detailsPlugins;
	}

	/**
	 * Returns the details of the plugin by using the identifier
	 *
	 * @param $identifierPlugin(string)
	 * @return boolean
	 */
	public function _getPluginDetailsByIdentifier($identifierPlugin) {

		if (isset(self::$detailsPlugins[$identifierPlugin])) {
		} else if (Cache::_getInstance() -> _isCached('plugin_details_' . $identifierPlugin)) {
			self::$detailsPlugins[$identifierPlugin] = Cache::_getInstance() -> _getCache('plugin_details_' . $identifierPlugin);
		} else {
			$query = "select * from " . Config::_getTable('plugins') . " where `identifierPlugin` = :identifierPlugin and statusPlugin = :statusPlugin ";
			$arrayBind[] = array("key" => ":identifierPlugin", "value" => $identifierPlugin);
			$arrayBind[] = array("key" => ":statusPlugin", "value" => 1);

			$detailsPlugin = Core::_getRow($query, $arrayBind);

			if ($detailsPlugin) {
				self::$detailsPlugins[$identifierPlugin] = $detailsPlugin;
				Cache::_getInstance() -> _setCache('plugin_details_' . $identifierPlugin, $detailsPlugin);
			}
		}

        $return = isset(self::$detailsPlugins[$identifierPlugin]) ? self::$detailsPlugins[$identifierPlugin] : false;
        
        $return = Plugins::_runAction('plugins_get_plugin_details_by_identifier',$return,$identifierPlugin);

		return $return;
	}

	/**
	 * Returns the details of the current working plugin
	 *
	 * @param void
	 * @return object
	 */
	public function _getWorkingPluginDetails() {
		return $this -> detailsWorkingPlugin;
	}

	/** Retrieves and save the working plugin information.
	 *
	 *
	 * @param $identifierPlugin(string)
	 * @return null
	 */
	public function _workingPlugin($identifierPlugin) {

		global $Admin;
		/* Developer mode actions starts here */
		if ($Admin -> _developerModeActions()) {
			if (!isset(self::$logsPlugins[$identifierPlugin])) {
				self::$logsPlugins[$identifierPlugin] = array('counter' => 1, 'timer' => 0, 'memory' => 0);
			} else {
				self::$logsPlugins[$identifierPlugin]['counter']++;
			}
			self::$logsPlugins[$identifierPlugin]['last_started']['time'] = microtime(true);
			self::$logsPlugins[$identifierPlugin]['last_started']['memo'] = memory_get_usage();
		}
		/*  Developer mode actions ends here */

		$this -> _setWorkingPluginDetails($identifierPlugin);

        Plugins::_runAction('plugins_set_working_plugin',$identifierPlugin);
        
	}

	/** Removes the working plugin information.
	 *
	 *
	 * @param void
	 * @return null
	 */
	public function _removeWorkingPlugin() {

		// If there is no active plugin
		if (!$this -> _getWorkingPluginDetails())
			return;

		global $Admin;

		/* Developer mode actions starts here */
		if ($Admin -> _developerModeActions()) {
			$identifierPlugin = $this -> _getWorkingPluginDetails() -> identifierPlugin;
			self::$logsPlugins[$identifierPlugin]['timer'] += microtime(true) - self::$logsPlugins[$identifierPlugin]['last_started']['time'];
			self::$logsPlugins[$identifierPlugin]['memory'] += memory_get_usage() - self::$logsPlugins[$identifierPlugin]['last_started']['memo'];
		}
		/*  Developer mode actions ends here */

		$continue = true;
		
        $continue = Plugins::_runAction('plugins_remove_working_plugin',$continue);

        if( $continue ){
            
            $this -> _setWorkingPluginDetails(-1);
            
        }
        
	}

	/**
	 * Sets or removes the given identifier plugin as the currents plugin
	 *
	 * @param $identifierPlugin(string)
	 * @return null
	 */
	public function _setWorkingPluginDetails($identifierPlugin) {

		if ($identifierPlugin == -1) {
			// Deleting current.working plugin from array
			array_pop(self::$workingPlugins);

			if (is_array(self::$workingPlugins) && count(self::$workingPlugins) > 0) {
				// Now retrieving the previous plugin identifier
				$identifierPlugin = self::$workingPlugins[count(self::$workingPlugins) - 1];
			} else {
				$detailsPlugins = $currentPlugin = false;
			}
		} else {
			self::$workingPlugins[] = $identifierPlugin;
		}

		if ($identifierPlugin != -1) {
			$detailsPlugins = $this -> _getPluginDetailsByIdentifier($identifierPlugin);

			if (!$detailsPlugins) {
				array_pop(self::$workingPlugins);
				return;
			}

			$currentPlugin = Config::_get('plugins') . '/' . $detailsPlugins -> identifierPlugin;
		}

		$this -> detailsWorkingPlugin = $detailsPlugins;
		Config::_set('current.plugin', $currentPlugin);
        
        Plugins::_runAction('plugins_set_working_plugin',$identifierPlugin);
        
	}

	/**
	 * Add the current plugin to the initilized plugins list
	 *
	 * @param $identifierPlugin(string)
	 * @return null
	 */
	private function _addInitilizedPlugin($identifierPlugin) {
		self::$initilizedPlugins[] = $identifierPlugin;

        Plugins::_runAction('plugins_add_initilized_plugin',$identifierPlugin);
        
	}

	/**
	 * Returns an array containing the list of initilized plugins
	 *
	 * @param void
	 * @return $initilizedPlugins(array of strings)
	 */
	private function _getInitilizedPlugins() {

        $return = self::$initilizedPlugins;
        
        $return = Plugins::_runAction('plugins_add_initilized_plugin',$return);
        
		return $return;
	}

	/**
	 * Checks weather the plugin with the given identifier is installed or not
	 *
	 * @param $identifierPlugin(string)
	 * @return boolean
	 */
	private function _checkInitilizedPlugins($identifierPlugin) {
	    
        $return = false;
		if (in_array($identifierPlugin, $this -> _getInitilizedPlugins()))
			$return = true;

        $return = Plugins::_runAction('plugins_check_initilized_plugin',$return,$identifierPlugin);

		return $return;
	}

	/**
	 * Loads the loader file for the plugins
	 *
	 * @param $identifierPlugin(string)
	 * @return boolean
	 */
	public function _initilizePlugin($identifierPlugin) {

		$this -> _workingPlugin($identifierPlugin);

		if (!$this -> _checkInitilizedPlugins($identifierPlugin) && file_exists(Config::_getDir('plugins') . '/' . $identifierPlugin . '/loader.php')) {
			include_once Config::_getDir('plugins') . '/' . $identifierPlugin . '/loader.php';
			$this -> _addInitilizedPlugin($identifierPlugin);
		}

		$this -> _removeWorkingPlugin();

        Plugins::_runAction('plugins_initilize_plugin',$identifierPlugin);
	}

	/**
	 * Loads the page for the plugins
	 *
	 * @param $identifierPlugin(string),$namePage(Page Name)
	 * @return boolean
	 */
	public function _loadPluginPage($identifierPlugin, $pagePlugin) {

		$this -> _initilizePlugin($identifierPlugin);
		$this -> _workingPlugin($identifierPlugin);

		// Varible is used further in plugin files.
		global $Permissions, $Base, $Validate, $Languages, $Admin, $User, $Cms, $Lists, $Forms;
		global $loadPage;

		if (file_exists(Config::_getDir('plugins') . '/' . $identifierPlugin . '/backend/includes/modules/pages/' . $pagePlugin . '.php')) {
			include_once Config::_getDir('plugins') . '/' . $identifierPlugin . '/backend/includes/modules/pages/' . $pagePlugin . '.php';
		} else {
			include_once Config::_getDir('plugins') . '/' . $identifierPlugin . '/backend/includes/modules/pages/default.php';
		}
		$this -> _removeWorkingPlugin();

        Plugins::_runAction('plugins_load_plugin_page',$identifierPlugin,$pagePlugin);
	}

	/**
	 * Loads the ajax page for the plugin
	 *
	 * @param $identifierPlugin(string),$identifierLink(Page Identifier link)
	 * @return boolean
	 */
	public function _loadPluginAjaxPage($identifierPlugin, $identifierLink) {

		global $Permissions, $Base, $Validate, $Languages, $Admin, $User, $Cms, $Lists, $Forms;

		$this -> _initilizePlugin($identifierPlugin);
		$this -> _workingPlugin($identifierPlugin);

		$identifierArrayLink = explode("/", $identifierLink);

		if (!isset($identifierArrayLink[7]))
			$identifierArrayLink[7] = '';
		if (!isset($identifierArrayLink[8]))
			$identifierArrayLink[8] = '';

		//This includes the forms for the files like check/, set/, get/edit
		if ($identifierArrayLink[7] == 'get' && $identifierArrayLink[8] == 'list') {

			$listName = $identifierArrayLink[count($identifierArrayLink) - 1];

			if (file_exists(Config::_getDir('plugins') . '/' . $identifierPlugin . '/backend/includes/modules/lists/' . $listName . '.php')) {

				// Including the default lists page in the core modules
				include Config::_getDir('admin') . '/includes/core/modules/lists/default.php';
				if (file_exists(Config::_getDir('admin') . '/includes/custom/modules/lists/default.php')) {
					// Including the default lists page in the core modules
					include Config::_getDir('admin') . '/includes/custom/modules/lists/default.php';
				}

				include Config::_getDir('plugins') . '/' . $identifierPlugin . '/backend/includes/modules/lists/' . $listName . '.php';
			}
		}

		//This includes the forms for the files like check/, set/, get/edit
		if ($identifierArrayLink[7] == 'check' || $identifierArrayLink[7] == 'set' || $identifierArrayLink[8] == 'edit') {

			$formName = $identifierArrayLink[count($identifierArrayLink) - 1];

			if (file_exists(Config::_getDir('plugins') . '/' . $identifierPlugin . '/backend/includes/modules/forms/' . $formName . '.php')) {

				// Including the default forms page in the core modules
				include Config::_getDir('admin') . '/includes/core/modules/forms/default.php';
				if (file_exists(Config::_getDir('admin') . '/includes/custom/modules/forms/default.php')) {
					// Including the default forms page in the core modules
					include Config::_getDir('admin') . '/includes/custom/modules/forms/default.php';
				}

				include Config::_getDir('plugins') . '/' . $identifierPlugin . '/backend/includes/modules/forms/' . $formName . '.php';
			}
		}

        $identifierLink = Plugins::_runAction('plugins_load_plugin_ajax_page', $identifierLink, $identifierPlugin);

		if (file_exists(Config::_getDir() . $identifierLink . '.php')) {
			include Config::_getDir() . $identifierLink . '.php';
		}

		$this -> _removeWorkingPlugin();
        
	}

	/**
	 * Checks the plugin files
	 *
	 * @param $pathSql(string)
	 * @return boolean
	 */
	public function _checkPluginFiles($pathFiles) {

		$configFile = false;
		$messages = array();
		$tempFolder = Config::_getDir('plugins.store');

		$zip = new ZipArchive;
		if ($zip -> open($pathFiles) === TRUE) {

			for ($i = 0; $i < $zip -> numFiles; $i++) {

				$filename = $zip -> getNameIndex($i);
				$fileinfo = pathinfo($filename);

				if ($fileinfo['dirname'] == '.') {
					$baseFolder = $fileinfo['basename'];
				}
				if ($filename == $baseFolder . '/actions/config.php') {

					$configFile = true;
					$errors = false;
					$messages[] = 'Config file found.';
					$messages[] = 'Extracting config file.';

					$zip -> extractTo($tempFolder, array($filename));

					$messages[] = 'Reading config file.';

					unset($pluginConfig);
					include $tempFolder . '/' . $baseFolder . '/actions/config.php';

					if (!isset($pluginConfig)) {
						$messages[] = 'Config variable $pluginConfig not found.';
						$errors = true;
					}
					if (!isset($pluginConfig['identifier'])) {
						$messages[] = 'Config variable $pluginConfig does not contain <b>Plugin Identifier Information</b>.';
						$errors = true;
					} else if ($pluginConfig['identifier'] != $baseFolder) {
						$messages[] = 'Folder name(' . $baseFolder . ') must be same as the Plugin Identifier.(' . $pluginConfig['identifier'] . ')';
						$errors = true;
					}
					if (!isset($pluginConfig['version'])) {
						$messages[] = 'Config variable $pluginConfig does not contain <b>Plugin Version Information</b>.';
						$errors = true;
					}
					if (!isset($pluginConfig['install-type'])) {
						$messages[] = 'Config variable $pluginConfig does not contain <b>Plugin Install Type Information</b>.';
						$errors = true;
					}
					if (!isset($pluginConfig['name'])) {
						$messages[] = 'Config variable $pluginConfig does not contain <b>Plugin Name Information</b>.';
						$errors = true;
					}

					if (!$errors) {
						if ($this -> _checkPluginIdentifier($pluginConfig['identifier'])) {

							if ( $pluginConfig['install-type'] != 'upgrage') {
								$messages[] = 'A versoin(' . $this -> _getPluginDetailsByIdentifier($pluginConfig['identifier']) -> versionPlugin . ') of this plugin already installed.<br/> 
    To upgrade, please use the upgrade version or delete previous version and install new version(you may loose the data)';
							}else{
								if( $pluginConfig['version'] > $this->_getPluginDetailsByIdentifier($pluginConfig['identifier'])->versionPlugin ){
									if ($this -> _upgradePlugin($pathFiles)) {
										$messages[] = 'Plugin Installed Successfully.';
									}
								}else{
									$messages[] = 'A Latest versoin(' . $this -> _getPluginDetailsByIdentifier($pluginConfig['identifier']) -> versionPlugin . ') of this plugin is already installed.';
								}
							}
						} else {
							if ($this -> _installPlugin($pathFiles)) {
								$messages[] = 'Plugin Installed Successfully.';
							}
						}
					}
				}
			}
			$zip -> close();
			if (!$configFile) {
				$messages[] = 'Config file not found. Please try again.';
			}
			//$process['success'][] = 'Plugin Installed Successfully ';
		} else {
			$messages[] = "Failed to open the zip file";
		}

        $messages = Plugins::_runAction('plugins_check_plugin_files', $messages, $pathFiles);

		global $Base;
		$Base -> _removeDir($pathFiles);
		$Base -> _removeDir($tempFolder . '/' . $baseFolder);

		return $messages;
	}

	/**
	 * Installs the plugin files
	 *
	 * @param $pathSql(string)
	 * @return boolean
	 */
	private function _installPlugin($pathFiles) {

        $return = true;

		$messages = array();
		$tempFolder = Config::_getDir('plugins');

		$zip = new ZipArchive;
		if ($zip -> open($pathFiles) === TRUE) {

			for ($i = 0; $i < $zip -> numFiles; $i++) {

				$filename = $zip -> getNameIndex($i);

				$zip -> extractTo($tempFolder, array($filename));

				$fileinfo = pathinfo($filename);

				if ($fileinfo['dirname'] == '.') {
					$baseFolder = $fileinfo['basename'];
				}
			}
			$zip -> close();

			include $tempFolder . '/' . $baseFolder . '/actions/config.php';

			$query = "insert into " . Config::_getTable('plugins') . " (namePlugin,identifierPlugin,statusPlugin,autoLoadPlugin,versionPlugin,authorPlugin,urlPlugin,dateAdditionPlugin,dateInstallationPlugin)
             values (:namePlugin,:identifierPlugin,1,:autoLoadPlugin,:versionPlugin,:authorPlugin,:urlPlugin,NOW(),NOW())";
			$arrayBind[] = array("key" => ":namePlugin", "value" => $pluginConfig['name']);
			$arrayBind[] = array("key" => ":identifierPlugin", "value" => $pluginConfig['identifier']);
			$arrayBind[] = array("key" => ":autoLoadPlugin", "value" => $pluginConfig['auto-load']);
			$arrayBind[] = array("key" => ":versionPlugin", "value" => $pluginConfig['version']);
			$arrayBind[] = array("key" => ":authorPlugin", "value" => $pluginConfig['author']);
			$arrayBind[] = array("key" => ":urlPlugin", "value" => $pluginConfig['url']);
			if (Core::_runQuery($query, $arrayBind)) {
				// Don't unser Query as it will effect the further actions in the plugin installation page(string to array conversion error)
				unset($query);
				unset($arrayBind);

				$this -> _workingPlugin($pluginConfig['identifier']);

				include $tempFolder . '/' . $baseFolder . '/actions/install.php';

				unset($pluginConfig);

		        Plugins::_runAction('plugins_install_plugin_success',$pathFiles);
				
				global $Base;
				//$Base->_removeDir($tempFolder.'/'.$baseFolder.'/actions/install.php');
				$this -> _removeWorkingPlugin();
			} else {
				$return = false;
			}
		}

        $return = Plugins::_runAction('plugins_install_plugin_end',$return, $pathFiles);

		return $return;
	}

	/**
	 * Upgrade plugin version
	 *
	 * @param $pathSql(string)
	 * @return boolean
	 */
	private function _upgradePlugin($pathFiles) {

        $return = true;

		$messages = array();
		$tempFolder = Config::_getDir('plugins');

		$zip = new ZipArchive;
		if ($zip -> open($pathFiles) === TRUE) {

			for ($i = 0; $i < $zip -> numFiles; $i++) {

				$filename = $zip -> getNameIndex($i);

				$zip -> extractTo($tempFolder, array($filename));

				$fileinfo = pathinfo($filename);

				if ($fileinfo['dirname'] == '.') {
					$baseFolder = $fileinfo['basename'];
				}
			}
			$zip -> close();

			include $tempFolder . '/' . $baseFolder . '/actions/config.php';

			$query = "update " . Config::_getTable('plugins') . " set namePlugin=:namePlugin,autoLoadPlugin=:autoLoadPlugin,versionPlugin=:versionPlugin,
			authorPlugin=:authorPlugin,urlPlugin=:urlPlugin where identifierPlugin = :identifierPlugin";
			$arrayBind[] = array("key" => ":namePlugin", "value" => $pluginConfig['name']);
			$arrayBind[] = array("key" => ":identifierPlugin", "value" => $pluginConfig['identifier']);
			$arrayBind[] = array("key" => ":autoLoadPlugin", "value" => $pluginConfig['auto-load']);
			$arrayBind[] = array("key" => ":versionPlugin", "value" => $pluginConfig['version']);
			$arrayBind[] = array("key" => ":authorPlugin", "value" => $pluginConfig['author']);
			$arrayBind[] = array("key" => ":urlPlugin", "value" => $pluginConfig['url']);
			
			if (Core::_runQuery($query, $arrayBind)) {
				// Don't unser Query as it will effect the further actions in the plugin installation page(string to array conversion error)
				unset($query);
				unset($arrayBind);

				$this -> _workingPlugin($pluginConfig['identifier']);

				include $tempFolder . '/' . $baseFolder . '/actions/install.php';

				unset($pluginConfig);

                Plugins::_runAction('plugins_upgrade_plugin_success',$pathFiles);
                
				global $Base;
				//$Base->_removeDir($tempFolder.'/'.$baseFolder.'/actions/install.php');
				$this -> _removeWorkingPlugin();
			} else {
				$return = false;
			}
		}

        $return = Plugins::_runAction('plugins_upgrade_plugin_end',$return, $pathFiles);

		return $return;
	}
	/**
	 * Add new plugin menu
	 *
	 * @param $linkMenu(menu link, string),$topMenu (Top Menu, Tinyint),$parentMenu(menu parent, int),$titleMenu(menu title, string)
	 * @return boolean
	 */
	public function _getParentMenu($linkMenu, $topMenu = 1, $parentMenu = 0, $titleMenu = '') {

        $idParent = 0;
        
		$query = "select * from " . Config::_getTable('admin_menus') . " where linkMenu = :linkMenu and parentMenu = :parentMenu and topMenu = :topMenu ";
		$arrayBind[] = array("key" => ":linkMenu", "value" => $linkMenu);
		$arrayBind[] = array("key" => ":parentMenu", "value" => $parentMenu);
		$arrayBind[] = array("key" => ":topMenu", "value" => $topMenu);

		if ($titleMenu != '') {
			$query = " and titleMenu like :titleMenu ";
			$arrayBind[] = array("key" => ":titleMenu", "value" => $titleMenu);
		}

		$detailsMenu =  Core::_getRow($query, $arrayBind) -> idMenu;
        
        if( $detailsMenu ){
            $idParent = $detailsMenu -> idMenu;
        }

        $idParent = Plugins::_runAction('plugins_get_parent_menu',$idParent, $linkMenu, $topMenu , $parentMenu , $titleMenu);

		return $idParent;
	}

	/**
	 * Add new plugin menu
	 *
	 * @param $menuOptions(array)
	 * @return boolean
	 */
	public function _addPluginMenu($menuOptions) {

		$identifierPlugin = $this -> _getWorkingPluginDetails() -> identifierPlugin;

		global $Admin;
		$errors = array();

		$validateFields = array('titleMenu');
		$nullValues = array('parentMenu', 'imageMenu', 'statusMenu', 'orderMenu', 'dashboardMenu', 'topMenu', 'showSubMenus');

		foreach ($validateFields as $tmpMenu) {
			if ($menuOptions[$tmpMenu] == '') {
				$errors[] = 'Please Enter ' . $tmpMenu;
			}
		}
		foreach ($nullValues as $tmpMenu) {
			if (!isset($menuOptions[$tmpMenu]) || $menuOptions[$tmpMenu] == '') {
				$menuOptions[$tmpMenu] = '0';
			}
		}

		if (count($errors) == 0) {
			unset($arrayBind);
			$query = "insert into " . Config::_getTable('admin_menus') . " (titleMenu,linkMenu,createdById,createdByType,parentMenu,imageMenu,statusMenu,orderMenu,dashboardMenu,topMenu,showSubMenus,dateAdditionAdminMenu)
             values (:titleMenu,:linkMenu,:createdById,:createdByType,:parentMenu,:imageMenu,:statusMenu,:orderMenu,:dashboardMenu,:topMenu,:showSubMenus,NOW())";
			$arrayBind[] = array("key" => ":titleMenu", "value" => $menuOptions['titleMenu']);
			$arrayBind[] = array("key" => ":linkMenu", "value" => ($menuOptions['linkMenu'] != '')?($identifierPlugin . '-' . $menuOptions['linkMenu']):'');
			$arrayBind[] = array("key" => ":createdById", "value" => $identifierPlugin);
			$arrayBind[] = array("key" => ":createdByType", "value" => 'plugin');
			$arrayBind[] = array("key" => ":parentMenu", "value" => $menuOptions['parentMenu']);
			$arrayBind[] = array("key" => ":imageMenu", "value" => $menuOptions['imageMenu']);
			$arrayBind[] = array("key" => ":statusMenu", "value" => $menuOptions['statusMenu']);
			$arrayBind[] = array("key" => ":orderMenu", "value" => $menuOptions['orderMenu']);
			$arrayBind[] = array("key" => ":dashboardMenu", "value" => $menuOptions['dashboardMenu']);
			$arrayBind[] = array("key" => ":topMenu", "value" => $menuOptions['topMenu']);
			$arrayBind[] = array("key" => ":showSubMenus", "value" => $menuOptions['showSubMenus']);
			Core::_runQuery($query, $arrayBind);
			$return = Core::_getLastInsertId();
		} else {
			$return = false;
		}
		
        $return = Plugins::_runAction('plugins_add_plugin_menu',$return, $menuOptions);

        return $return;		
	}

	/**
	 * Add new message to the message log
	 *
	 * @param $messageOptions(array)
	 * @return boolean
	 */
	public function _addMessage($messageOptions) {

		$identifierPlugin = $this -> _getWorkingPluginDetails() -> identifierPlugin;

		if (Config::_addMessage($messageOptions['keyMessage'], $messageOptions['contentMessage'], $messageOptions['statusMessage'], $identifierPlugin, 'plugin'))
			$return = true;
			     
        $return = Plugins::_runAction('plugins_add_message',$return, $messageOptions);
            
		return $return;
	}

	/**
	 * Add new config key to the configuration talble
	 *
	 * @param $configurationOptions(array)
	 * @return boolean
	 */
	public function _addConfig($configurationOptions) {

		$identifierPlugin = $this -> _getWorkingPluginDetails() -> identifierPlugin;

		if (!isset($configurationOptions['statusConfig']))
			$configurationOptions['statusConfig'] = 1;
		if (!isset($configurationOptions['systemItem']))
			$configurationOptions['systemItem'] = 1;

		Config::_updateDbConfigEntry($configurationOptions['keyConfig'], $configurationOptions['valueConfig'], $configurationOptions['statusConfig'], $configurationOptions['systemItem'], $identifierPlugin, 'plugin');

        Plugins::_runAction('plugins_add_config',$configurationOptions);
	}

	/**
	 * Executes the array of sql queries
	 *
	 * @param $query(array of queries)
	 * @return boolean
	 */
	public function _executePluginDatabase($query) {

		if (is_array($query) && count($query) > 0) {
			foreach ($query as $tmpQuery) {
				Core::_runQuery($tmpQuery, '');
			}
		}

        Plugins::_runAction('plugins_execute_plugin_database',$query);
	}

	/**
	 * Executes the sql file for the plugin
	 *
	 * @param $pathSql(string)
	 * @return boolean
	 */
	public function _executePluginDatabaseFile($pathSql) {

        $return = false;

		if (file_exists($pathSql)) {
			$query = file_get_contents($pathSql);

			Core::_runQuery($query, '');
			if (Core::_runQuery($query, ''))
				$return = true;

		}

        $return = Plugins::_runAction('plugins_execute_plugin_database_file',$return,$pathSql);

		return $return;
	}

	/**
	 * Removes/Uninstalls the plugin
	 *
	 * @param $identifierPlugin(string)
	 * @return none
	 */
	public function _removePlugin($identifierPlugin) {

		$this -> _addInitilizedPlugin($identifierPlugin);

        $continue = true;

        $continue = Plugins::_runAction('plugins_remove_plugin_start',$continue,$identifierPlugin);
        
        if( !$continue ) return false;


		if (file_exists(Config::_getDir('plugins') . '/' . $identifierPlugin . '/actions/uninstall.php')) {
			include_once Config::_getDir('plugins') . '/' . $identifierPlugin . '/actions/uninstall.php';
		}

		$this -> _removePluginMenus($identifierPlugin);
		$this -> _removePluginMessages($identifierPlugin);
		$this -> _removePluginConfigurations($identifierPlugin);

		global $Base;
		$Base -> _removeDir(Config::_getDir('plugins') . '/' . $identifierPlugin);

		$query = "delete from " . Config::_getTable('plugins') . " where identifierPlugin = :identifierPlugin";
		$arrayBind[] = array("key" => ":identifierPlugin", "value" => $identifierPlugin);
		Core::_runQuery($query, $arrayBind);

        Plugins::_runAction('plugins_remove_plugin_end',$identifierPlugin);

	}

	/**
	 * Removes/Uninstalls the plugin menus
	 *
	 * @param $identifierPlugin(string)
	 * @return none
	 */
	public function _removePluginMenus($identifierPlugin) {

        $identifierPlugin = Plugins::_runAction('plugins_remove_plugin_menus',$identifierPlugin);
        
        if( !$identifierPlugin ) return false;

		$query = "delete from " . Config::_getTable('admin_menus') . " where createdByType = 'plugin' and createdById = :identifierPlugin";
		$arrayBind[] = array("key" => ":identifierPlugin", "value" => $identifierPlugin);
		Core::_runQuery($query, $arrayBind);
	}

	/**
	 * Removes/Uninstalls the plugin Messages
	 *
	 * @param $identifierPlugin(string)
	 * @return none
	 */
	public function _removePluginMessages($identifierPlugin) {
	        
        $identifierPlugin = Plugins::_runAction('plugins_remove_plugin_messages',$identifierPlugin);
        
        if( !$identifierPlugin ) return false;

		$query = "delete from " . Config::_getTable('cms_messages_log') . " where createdByType = 'plugin' and createdById = :identifierPlugin";
		$arrayBind[] = array("key" => ":identifierPlugin", "value" => $identifierPlugin);
		Core::_runQuery($query, $arrayBind);
	}

	/**
	 * Removes/Uninstalls the plugin Configurations
	 *
	 * @param $identifierPlugin(string)
	 * @return none
	 */
	public function _removePluginConfigurations($identifierPlugin) {
	        
        $identifierPlugin = Plugins::_runAction('plugins_remove_plugin_configurations',$identifierPlugin);
        
        if( !$identifierPlugin ) return false;

		$query = "delete from " . Config::_getTable('configuration') . " where createdByType = 'plugin' and createdById = :identifierPlugin";
		$arrayBind[] = array("key" => ":identifierPlugin", "value" => $identifierPlugin);
		Core::_runQuery($query, $arrayBind);
	}

}

