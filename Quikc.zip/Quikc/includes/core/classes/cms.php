<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * Cms class, contains all functions related to Cms
 * This includes Themes, Pages etc
 *
 * @version 1.0
 * @http://www.quikc.org/
 */

class Cms {

	/**
	 * Contains select box values
	 * Used to sort the retrieved select data, so that we can only  retrieve it once
	 *
	 * @var array of objects
	 */
	private $retrievedSelectData;

	/**
	 * Contains the information of the default page
	 *
	 * @var array of objects
	 */
	private $defaultPageData;

	/**
	 * Contains pages information
	 *
	 * @var array of objects
	 */
	private $retrievedPageData;

	/**
	 * Contains table join types
	 * These values will be applied for joining multiple table through all the cms functions
	 *
	 * @var array of types
	 */
	private $joinTableTypes = array('Join', 'Left Join', 'Right Join');

    /**
     * Construction for base
     *
     * @param void()
     * @return null
     */
    public function __construct() {
    }

	/** Return the list of join types
	 *
	 *
	 * @param void
	 * @var join types(array)
	 */
	public function _getTableJoinTypes() {
	    
		return $this -> joinTableTypes;
        
	}

	/**
	 * Returns messagelog details
	 *
	 * @param int(Message id)
	 * @return boolean
	 */
	public function _getMessagelogDetails($idMessage) {

		$query = " select * from " . Config::_getTable('cms_messages_log') . " where idMessage = :idMessage";
		$arrayBind[] = array("key" => ":idMessage", "value" => $idMessage);
		$detailsMessages = Core::_getRow($query, $arrayBind);

        $detailsMessages = Plugins::_runAction('cms_message_log_details', $detailsMessages,$idMessage);

		return $detailsMessages;
        
	}

	/**
	 * Returns mails details
	 *
	 * @param int(mail id)
	 * @return boolean
	 */
	public function _getMailDetails($idMail) {

		$query = " select * from " . Config::_getTable('mails') . " where idMail = :idMail";
		$arrayBind[] = array("key" => ":idMail", "value" => $idMail);
		$detailsMail = Core::_getRow($query, $arrayBind);

        $detailsMail = Plugins::_runAction('cms_mail_details', $detailsMail,$idMail);

		return $detailsMail;
        
	}

	/**
	 * Returns mails details
	 *
	 * @param int(mail id)
	 * @return boolean
	 */
	public function _getMailDetailsByLink($link) {

		$query = " select * from " . Config::_getTable('mails') . " where link = :link";
		$arrayBind[] = array("key" => ":link", "value" => $link);
		$detailsMail = Core::_getRow($query, $arrayBind);

        $detailsMail = Plugins::_runAction('cms_mail_details_by_link', $detailsMail,$link);

		return $detailsMail;
        
	}

    /**
     * prepares given set values in tree view and returns
     *
     * @param $nameTable,  $nameCategoryField, $nameCategoryParentField, $titleField, $idFilters = false,        $idSortBy = false,        $idParentCategory = 0,$depathCategory = 0,$append = '--',$previousParents = array()
     *        'cms_pages','idPage'             ,'idParentPage'          ,'namePage'   ,array("statusPage" => 1), array("namePage"=>'asc'), 
     * $previousParents is an array which contains the list of parent ids from which the current element has been defined  
     * @return object
     */
    public function _prepareTreeView($nameTable, $nameCategoryField, $nameCategoryParentField, $titleField, $idFilters = false, $idSortBy = false, $idParentCategory = 0,$depathCategory = 0,$append = '---',$previousParents = array() ){
        
        $return = false;
            
        if( $nameTable != '' && $nameCategoryField != '' && $nameCategoryParentField != '' && $titleField != '' ){


            // preparing filter fields
            $fieldsFilter = array($nameCategoryParentField => $idParentCategory);
            
            if( $idFilters && is_array($idFilters) && count($idFilters) > 0 ){
                
                // if fields are not null then appending them to the category filter
                $fieldsFilter = array_merge($fieldsFilter,$idFilters);
                
            }

            // preparing filter fields
            $fieldsSortby = array();

            if( $idSortBy && is_array($idSortBy) && count($idSortBy) > 0 ){
                
                // if fields are not null then appending them to the category filter
                $fieldsSortby = array_merge($fieldsSortby,$idSortBy);
                
            }

            // now getting the list of results basing on the query valuse                        
            $listResults = Core::_gAR($nameTable,$fieldsFilter,$fieldsSortby);

            // now appending the appendstrng                         
            $appendString = '';
            for( $i = 0; $i < $depathCategory; $i++ ){
                
                $appendString .= $append; 
    
            }   

            // Incrementing the depth category value for the next function passes
            $depathCategory++;
    
            $return = array();
            
            foreach($listResults as $key =>$result){
                
                // Now     
                $result->$titleField = $appendString.$result->$titleField;

                if( !isset($result->idsParent) || !is_array($result->idsParent) ){

                    $result->idsParent = array();

                }

                if( !in_array($idParentCategory, $previousParents)){

                    $previousParents [] = $idParentCategory;
                    $result->idsParent =  $previousParents;

                }
                
                $return[] = $result;
                $return = array_merge($return,$this -> _prepareTreeView($nameTable, $nameCategoryField, $nameCategoryParentField, $titleField, $idFilters, $idSortBy, $result->$nameCategoryField,$depathCategory,$append,$previousParents));
                
            }
            
        }
        
        return $return;
        
    }
    
    /**
     * prepares and returns the page set in the required format
     *
     * @param void
     * @return array of objects
     */
    public function _preparePageSet($formatSet = true){
        
        $listSet = $this -> _prepareTreeView('cms_pages','idPage','idParentPage','namePage',array("statusPage" => 1),array("namePage"=>'asc'));
        
        if( $formatSet ){
            
            $listSet = array($listSet,'idPage','namePage');

        }
        
        return $listSet;  
          
    }

	/**
	 * Returns Page details
	 *
	 * @param int(Page id)
	 * @return boolean
	 */
	public function _getPageDetails($idPage) {

		$query = " select * from " . Config::_getTable('pages') . " where idPage = :idPage";
		$arrayBind[] = array("key" => ":idPage", "value" => $idPage);
		$detailsPage = Core::_getRow($query, $arrayBind);

		if ($detailsPage){
		    
            $this -> retrievedPageData[$detailsPage -> linkPage] = $detailsPage;
            Cache::_getInstance() -> _setCache('cms_pages_' . $detailsPage -> linkPage, $detailsPage);
    
            // Updating default page details in cache
            if ($detailsPage -> defaultPage) {

                $this -> _setDefaultPage($detailsPage -> linkPage);
                Cache::_getInstance() -> _setCache('cms_pages_default_page', $detailsPage -> linkPage);

            }
    
		}

        $detailsPage = Plugins::_runAction('cms_page_details', $detailsPage,$idPage);

		return $detailsPage;

	}

	/**
	 * Returns Page details by full link
	 *
	 * @param string(Page Link)
	 * @return object
	 */
	public function _getPageDetailsByLink($fullLinkPage) {
		
		
		//echo $fullLinkPage;
		//die('<br>--------');

		if (isset($this -> retrievedPageData[$fullLinkPage])) {

			$detailsPage = $this -> retrievedPageData[$fullLinkPage];

		} else if (Cache::_getInstance() -> _isCached('cms_pages_' . $fullLinkPage)) {

			$detailsPage = Cache::_getInstance() -> _getCache('cms_pages_' . $fullLinkPage);
			$this -> retrievedPageData[$fullLinkPage] = $detailsPage;

		} else {

			$query = " select * from " . Config::_getTable('pages') . " where fullLinkPage = :fullLinkPage";
			$arrayBind[] = array("key" => ":fullLinkPage", "value" => $fullLinkPage);
			$detailsPage = Core::_getRow($query, $arrayBind);

			// Updating page details in cache
			Cache::_getInstance() -> _setCache('cms_pages_' . $fullLinkPage, $detailsPage);

			// Updating default page details in cache
			if (isset($detailsPage -> defaultPage) && $detailsPage -> defaultPage) {

				$this -> _setDefaultPage($detailsPage -> fullLinkPage);
				Cache::_getInstance() -> _setCache('cms_pages_default_page', $detailsPage -> fullLinkPage);

			}

			$this -> retrievedPageData[$fullLinkPage] = $detailsPage;
		}

        $detailsPage = Plugins::_runAction('cms_page_details_by_link', $detailsPage,$fullLinkPage);

		return $detailsPage;

	}

	/**
	 * Sets the detault page details
	 *
	 * @param string(default page link)
	 * @return null
	 */
	public function _setDefaultPage($defaultPage) {

        $defaultPage = Plugins::_runAction('cms_set_default_page', $defaultPage);

		$this -> defaultPageData = $defaultPage;
		
	}

	/**
	 * Returns the default Page details
	 *
	 * @param void
	 * @return boolean
	 */
	public function _getDefaultPage() {

		if (isset($this -> defaultPageData)) {

			$defaultPage = $this -> defaultPageData;

		} else if (Cache::_getInstance() -> _isCached('cms_pages_default_page')) {

			$defaultPage = Cache::_getInstance() -> _getCache('cms_pages_default_page');
			$this -> _setDefaultPage($defaultPage);

		} else {

			$query = " select * from " . Config::_getTable('pages') . " where defaultPage = :defaultPage";
			$arrayBind[] = array("key" => ":defaultPage", "value" => 1);
			$detailsPage = Core::_getRow($query, $arrayBind);

			if ($detailsPage){
            
                $defaultPage = $detailsPage -> fullLinkPage;
    
                Cache::_getInstance() -> _setCache('cms_pages_default_page', $detailsPage -> fullLinkPage);
                $this -> _setDefaultPage($detailsPage -> fullLinkPage);
                
			}

		}

        $defaultPage = Plugins::_runAction('cms_get_default_page', $defaultPage);

		return $defaultPage;

	}

	/**
	 * Checks weather the given page link exists or not
	 *
	 * @param string(Page Link)
	 * @return boolean
	 */
	public function _getPageLink($idPage) {

        $detailsPage = $this -> _getPageDetails($idPage);
        
        if( !$detailsPage ) return false;
        
        $linkPage = $detailsPage -> linkPage.'/';
        
        if( $detailsPage->idParentPage ){

            $linkPage = $this -> _getPageLink($detailsPage->idParentPage) . $linkPage;

        }

        return $linkPage;
        
	}

    /**
     * updates full page link of the current page
     *
     * @param string(Page Link)
     * @return boolean
     */
    public function _updateFullLinkPage($idPage) {

        $fullLinkPage = $this -> _getPageLink($idPage);
        
        $query = " update " . Config::_getTable('pages') . " set fullLinkPage = :fullLinkPage where idPage = :idPage ";
        $arrayBind[] = array("key" => ":idPage",        "value" => $idPage);
        $arrayBind[] = array("key" => ":fullLinkPage",  "value" => $fullLinkPage);

        $return = Core::_runQuery($query, $arrayBind);

        $return = Plugins::_runAction('cms_udpate_full_link_page', $return, $idPage);

        return $return;
        
    }

	 /**
     * Checks weather the given page link exists or not
     *
     * @param string(Page Link)
     * @return boolean
     */
    public function _checkLinkPage($linkPage) {

        $return = false;

        if ($this -> _getPageDetailsByLink($linkPage)) {

            $return = true;

        }

        $return = Plugins::_runAction('cms_check_page_link', $return, $linkPage);

        return $return;

    }
	
	/* Sets related functions starts here
	 <!-----------------------------------------------------------------------------------------------------------------------------------------
	 */

	/**
	 * Returns list of active sets
	 *
	 * @param void
	 * @return array of objects
	 */
	public function _getListSets() {

		$query = " select * from " . Config::_getTable('sets') . " where statusSet = :statusSet";
		$arrayBind[] = array("key" => ":statusSet", "value" => 1);
		$listSets = Core::_getAllRows($query, $arrayBind);

        $listSets = Plugins::_runAction('cms_get_list_sets', $listSets);

		return $listSets;
        
	}

	/**
	 * Checks weather the given Sets link exists or not
	 *
	 * @param string(Set Link)
	 * @return boolean
	 */
	public function _checkLinkSet($linkSet) {

        $return = false;

		$query = " select * from " . Config::_getTable('sets') . " where linkSet = :linkSet";
		$arrayBind[] = array("key" => ":linkSet", "value" => $linkSet);
		$detailsSet = Core::_getRow($query, $arrayBind);

		if ($detailsSet) {
		    
			$return = true;
            
		}

        $return = Plugins::_runAction('cms_check_link_set', $return, $linkSet);

        return $return;        
        
	}

	/**
	 * Returns the Set elements from database by id
	 *
	 * @param int(Id Set)
	 * @return set details(object)
	 */
	public function _getSetDetails($idSet) {

		$query = " select * from " . Config::_getTable('sets') . " where idSet = :idSet";
		$arrayBind[] = array("key" => ":idSet", "value" => $idSet);
		$detailsSet = Core::_getRow($query, $arrayBind);

		$detailsSet -> tables = $this -> _getSetTables($detailsSet -> idSet);
		$detailsSet -> options = $this -> _getSetOptions($detailsSet -> idSet);

        $detailsSet = Plugins::_runAction('cms_get_set_details', $detailsSet, $idSet);

		return $detailsSet;
        
	}

	/**
	 * Returns the Set elements from database by link
	 *
	 * @param string(Set Link)
	 * @return Set details(object)
	 */
	public function _getSetDetailsByLink($linkSet) {

		$query = " select * from " . Config::_getTable('sets') . " where linkSet = :linkSet";
		$arrayBind[] = array("key" => ":linkSet", "value" => $linkSet);
		$detailsSet = Core::_getRow($query, $arrayBind);

		$detailsSet -> tables = $this -> _getSetTables($detailsSet -> idSet);
		$detailsSet -> options = $this -> _getSetOptions($detailsSet -> idSet);

        $detailsSet = Plugins::_runAction('cms_get_set_details_by_link', $detailsSet, $linkSet);
		
		return $detailsSet;
        
	}

	/**
	 * Returns set Tables from database by id
	 *
	 * @param Integer(Id Set)
	 * @return Tables(array of object)
	 */
	public function _getSetTables($idSet) {

		$arrayBind[] = array("key" => ":idSet", "value" => $idSet);
		$query = " select * from " . Config::_getTable('sets_tables') . " where idSet = :idSet";
		$tables = Core::_getAllRows($query, $arrayBind);

        $tables = Plugins::_runAction('cms_get_set_tables', $tables, $idSet);

		return $tables;
        
	}

	/**
	 * Returns Set Options from database by id
	 *
	 * @param int(Set Id)
	 * @return Options(array of object)
	 */
	public function _getSetOptions($idSet) {

		$arrayBind[] = array("key" => ":idSet", "value" => $idSet);
		$query = " select * from " . Config::_getTable('sets_options') . " where idSet = :idSet order by orderOption asc";
		$options = Core::_getAllRows($query, $arrayBind);

        $options = Plugins::_runAction('cms_get_set_options', $options, $idSet);

		return $options;
        
	}

	/**
	 * Returns the prepared set from the database
	 *
	 * @param int(Set Link)
	 * @return Options(array of object)
	 */
	public function _prepareSet($linkSet) {

        $preparedSet = false;

		// check weather the set already retrieved and saved in variable
		if (isset($this -> retrievedSelectData[$linkSet])) {

			$preparedSet = $this -> retrievedSelectData[$linkSet];

		}else{
    
            $detailsSet = $this -> _getSetDetailsByLink($linkSet);
    
            // Verifying the status of the list
            if ($detailsSet -> statusSet){
    
                $preparedSet = array();
        
                if ($detailsSet -> databaseSet == '1') {
        
                    $sqlArray[] = "select " . $detailsSet -> keyFieldSet . "," . $detailsSet -> displayFieldSet . " from ";
                    $whereArray = array();
        
                    // $databaseList->tables contains list of tables and their info
                    foreach ($detailsSet->tables as $table) {
        
                        // Appending the table with its prefix
                        $sqlTmp = " " . Config::_getTable($table -> tableSet) . " " . $table -> identifierTableSet;
        
                        // Checking for the join type of the table and validating
                        if ($table -> joinTypeTable != '' && in_array($table -> joinTypeTable, array('join', 'left join', 'right join')) && $table -> joinOnTable != '') {
                            
                            $sqlTmp = $table -> joinTypeTable . " " . $sqlTmp . " on " . $table -> joinOnTable;
                            
                        }
                        
                        if ($table -> multiLanguageField != '' && Core::_checkColumn(Config::_getTable($table -> tableSet), Core::_getField($table -> multiLanguageField))) {
                            
                            $whereArray[] = $table -> identifierTableSet . '.' . Core::_getField($table -> multiLanguageField) . '=' . Languages::_getdefaultLanguage();
                            
                        }
        
                        $sqlArray[] = $sqlTmp;
                        
                    }

                    $query = implode(' ', $sqlArray);
        
                    // inserting user given where set value to the where array list
                    if ($detailsSet -> whereSet != '') {
                        
                        $whereArray[] = $detailsSet -> whereSet;
                        
                    }
        
                    if (count($whereArray) > 0) {
                        
                        $query .= " where " . implode(" and ", $whereArray);
                        
                    }
                    
                    //order the data by asc or desc for cmssets
                    if ($detailsSet -> sortFieldSet != '') {
                        
                        $query .= " order by " . $detailsSet -> sortFieldSet . " " . $detailsSet -> sortOrderFieldSet;
                        
                    }
        
                    $results = Core::_getAllRows($query, '');
        
                    $keyField = Core::_getField($detailsSet -> keyFieldSet);
                    $displayField = Core::_getField($detailsSet -> displayFieldSet);
        
                    foreach ($results as $result) {
                        
                        $preparedSet[$result -> $keyField] = $result -> $displayField;
                        
                    }
                    
                } else {
                    
                    foreach ($detailsSet->options as $option) {
                        
                        if ($option -> statusOption == 1) {
                            
                            $preparedSet[$option -> keyOption] = $option -> titleOption;
                            
                        }
                        
                    }
                    
                }
                
                // Saving the set to variable. So that we don't require to retrieve from the database agin and again
                $this -> retrievedSelectData[$linkSet] = $preparedSet;
                
            }
		    
		}

        $preparedSet = Plugins::_runAction('cms_prepare_set', $preparedSet, $linkSet);

		return $preparedSet;
        
	}

	/**
	 * Returns true if from is dynamic
	 *
	 * @param varchar(Form Link)
	 * @return boolean
	 */
	public function _checkDynamicForm($linkForm) {
		
		$arrayBind = array();
		
		$query = " select * from " . Config::_getTable('cms_forms') . " where linkForm = :linkForm and statusForm = :statusForm limit 0,1";
		
		$arrayBind[] = array("key" => ":linkForm", "value" => $linkForm);
		$arrayBind[] = array("key" => ":statusForm", "value" => 1);
		
		$count = Core::_getRowCount($query,$arrayBind);
		
		if( file_exists(Config::_getDir('admin').'/includes/custom/modules/froms/'.$linkForm.'.php') || 
				file_exists(Config::_getDir('admin').'/includes/core/modules/forms/'.$linkForm.'.php') || $count == 0){
		    return false;
		
		}
		
		return true;
        
	}
	
	
	/**
	 * Returns true if from is dynamic
	 *
	 * @param varchar(Form Link)
	 * @return boolean
	 */
	public function _checkDynamicList($linkList) {
		
		$arrayBind = array();
		
		$query = " select * from " . Config::_getTable('cms_lists') . " where linkList = :linkList and statusList = :statusList limit 0,1";
		
		$arrayBind[] = array("key" => ":linkList", "value" => $linkList);
		$arrayBind[] = array("key" => ":statusList", "value" => 1);
		
		$count = Core::_getRowCount($query,$arrayBind);
		
		if( file_exists(Config::_getDir('admin').'/includes/custom/modules/lists/'.$linkList.'.php') || 
				file_exists(Config::_getDir('admin').'/includes/core/modules/lists/'.$linkList.'.php') || $count == 0){
		    return false;
		
		}
		
		if($count == 0){
			return false;
		}
		
		return true;
        
	}

	/**
	 * Returns List id
	 *
	 * @param varchar(list Link)
	 * @return int(idList)
	 */
	public function _getDynamicListId($linkList) {
		
		$arrayBind = array();
		
		$query = " select * from " . Config::_getTable('cms_lists') . " where linkList = :linkList and statusList = :statusList limit 0,1";
		
		$arrayBind[] = array("key" => ":linkList", "value" => $linkList);
		$arrayBind[] = array("key" => ":statusList", "value" => 1);
		
		$list = Core::_getRow($query,$arrayBind);
		
		return $list->idList;
        
	}
	
	
	/**
	 * Returns List id
	 *
	 * @param varchar(list Link)
	 * @return int(idList)
	 */
	public function _getDynamicFormId($linkForm) {
		
		$arrayBind = array();
		
		$query = " select * from " . Config::_getTable('cms_forms') . " where linkForm = :linkForm and statusForm = :statusForm limit 0,1";
		
		$arrayBind[] = array("key" => ":linkForm", "value" => $linkForm);
		$arrayBind[] = array("key" => ":statusForm", "value" => 1);
		
		$form = Core::_getRow($query,$arrayBind);
		
		return $form->idForm;
        
	}

	/* Sets related functions ends here
	 -----------------------------------------------------------------------------------------------------------------------------------------!>
	 */
}

