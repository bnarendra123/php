<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* Languages class, used for processing language related actions
*
* @version 1.0
* @http://www.quikc.org/
*/
class Languages{

    /**
    * Contains the details of the default language
    * Used to sort the default language 
    *
    * @var details of default language
    */
    private static $defaultLanguage = false;

	/** Return the default language
	* 
	*
    * @param void
	* @var Language Id(int)
	*/
	public static function _getdefaultLanguage(){
	    
	    if(!self::$defaultLanguage) self::_updatedefaultLanguage();
		
		return self::$defaultLanguage->idLanguage;
	}
	
    /** Return the default language
    * 
    *
    * @param void
    * @var Language Id(int)
    */
    private static function _updatedefaultLanguage(){   
        // Query to get the language id for the detault language
        $query = "select idLanguage from ".Config::_getTable('languages')." where `defaultLanguage`='1'";
        self::$defaultLanguage = Core::_getRow($query,'');
    }

	/** Sets the current language
	* 
	*
    * @param Language Id(int), Allowed Languages
	* @var boolean
	*/
	public function _setLanguage($language, $allowedLanguages){
	
		if( array_key_exists($language, $allowedLanguages) ){
			$_SESSION['language'] = $language;
			return true;
		}else{
			return false;
		}
	}

	/** Returns an object containing the languages list
	* 
	*
    * @param Language Status(int)
	* @var Languages List(Object)
	*/
	public function _getLanguages($status){
	
		// Query to get all the languages
		$query 		= "select * from ".Config::_getTable('languages');
		$arrayBind	= array();
		
		// Adding status condition, If status is given 
		if($status != ''){
			$query 		.= " where statusLanguage = :status";
			$arrayBind[] = array("key" => ":status", "value" =>  $status );
		}
		// Executing the query		
		$languages = Core::_getAllRows( $query, $arrayBind );		
		return $languages;
	}
	
	
	/** Returns an object with the details of the given language id
	* 
	*
    * @param Language id(int)
	* @var Languages List(Object)
	*/
	public function _loadLanguage($idLanguage){

		// Query to get all the languages
		$query 		= "select * from ".Config::_getTable('languages')." where idLanguage = :idLanguage";
		$arrayBind[] = array("key" => ":idLanguage", "value" =>  $idLanguage );

		// Executing the query		
		$detailsLanguage = Core::_getRow($query, $arrayBind);		
		return $detailsLanguage;
	}
	
 }

