<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * This class contains functions related to widgets
 *
 * @version 1.0
 * @http://www.quikc.org/
 */
class Widgets {

	/**
	 * Contains details of the widget information
	 *
	 * @var array of objects
	 */
	private $retrievedWidgets;

	/**
	 * Contains details of the widget items information
	 *
	 * @var array of objects
	 */
	private $retrievedWidgetItems;

	/** Constructer of the Widgets class.
	 *
	 *
	 * @param void
	 * @var null
	 */
	public function __construct() {
	}

	/**
	 * Returns widget details
	 *
	 * @param int(idWidget id)
	 * @return mixed(object|boolean)
	 */
	public function _getWidgetDetails($idWidget) {

		if (isset($this -> retrievedWidgets[$idWidget])) {
			$detailsWidget = $this -> retrievedWidgets[$idWidget];
		} else if (Cache::_getInstance() -> _isCached('widgets_' . $idWidget)) {
			$detailsWidget = Cache::_getInstance() -> _getCache('widgets_' . $idWidget);
		} else {
			$query = " select * from " . Config::_getTable('widgets') . " where idWidget = :idWidget";
			$arrayBind[] = array("key" => ":idWidget", "value" => $idWidget);
			$detailsWidget = Core::_getRow($query, $arrayBind);
            
            $phpCodeWidget = '';
            
            $pathFile = Config::_getDir('current.plugin')."/backend/includes/modules/generated/widgets/".$idWidget."/view.php";

            if( file_exists($pathFile) && !is_dir($pathFile) ){

                $phpCodeWidget = file_get_contents($pathFile);

            }

            $detailsWidget -> phpCodeWidget = $phpCodeWidget;

			if ($detailsWidget){
                Cache::_getInstance() -> _setCache('widgets_' . $idWidget, $detailsWidget);
			}
		}

        if ($detailsWidget){
            $this -> retrievedWidgets[$detailsWidget -> idWidget] = $detailsWidget;
        }

        $detailsWidget = Plugins::_runAction('widgets_get_widget_details', $detailsWidget,$idWidget);

		return $detailsWidget;

	}

	/**
	 * Returns widget details by path
	 *
	 * @param int(idWidget id)
	 * @return mixed(object|boolean)
	 */
	public function _getWidgetDetailsByPath($pathWidget) {

		$query = " select * from " . Config::_getTable('widgets') . " where pathWidget = :pathWidget";
		$arrayBind[] = array("key" => ":pathWidget", "value" => $pathWidget);
		$detailsWidget = Core::_getRow($query, $arrayBind);

        $detailsWidget = Plugins::_runAction('widgets_get_widget_details_by_path', $detailsWidget,$pathWidget);

		return $detailsWidget;

	}

	/**
	 * Returns list of widgets
	 *
	 * @param void
	 * @return array of objects
	 */
	public function _getWidgets() {
		
		$query = " select * from " . Config::_getTable('widgets') . " where statusWidget = :statusWidget order by titleWidget";
        $arrayBind[] = array("key" => ":statusWidget", "value" => 1);
		
		$listWidgets = Core::_getAllRows($query, $arrayBind);

		if (is_array($listWidgets) && count($listWidgets) > 1) {

			foreach ($listWidgets as $detailsWidget) {

				Cache::_getInstance() -> _setCache('widgets_' . $detailsWidget -> idWidget, $detailsWidget);
				$this -> retrievedWidgets[$detailsWidget -> idWidget] = $detailsWidget;
			}
		}

        $listWidgets = Plugins::_runAction('widgets_get_list_widgets', $listWidgets);

		return $listWidgets;

	}

	/**
	 * Returns list of widget items for a given widget
	 *
	 * @param $idWidget(Widget id)
	 * @return array of objects
	 */
	public function _getWidgetItemsByWidget($idWidget) {
		
		if(!$idWidget) return false;

		$query = " select * from " . Config::_getTable('widget_items') . " where idWidget = :idWidget ";
		$arrayBind[] = array("key" => ":idWidget", "value" => $idWidget);

		$listWidgetItems = Core::_getAllRows($query, $arrayBind);

        $listWidgetItems = Plugins::_runAction('widgets_get_widget_items_by_widget', $listWidgetItems,$idWidget);

		return $listWidgetItems;

	}

	/**
	 * Returns list of widget items for a given space
	 *
	 * @param $idSpace(Space id)
	 * @return array of objects
	 */
	public function _getWidgetItems($idSpace = false) {

		$query = " select * from " . Config::_getTable('widget_items') . " where globalWidgetItem = :globalWidgetItem ";
		$arrayBind[] = array("key" => ":globalWidgetItem", "value" => 1);

		if($idSpace){
			$query .= ' or idSpace = :idSpace '; 	
			$arrayBind[] = array("key" => ":idSpace", "value" => $idSpace);
		}

		$listWidgetItems = Core::_getAllRows($query, $arrayBind);
		if (is_array($listWidgetItems) && count($listWidgetItems) > 1) {

			foreach ($listWidgetItems as $detailsWidgetItem) {

				Cache::_getInstance() -> _setCache('widget_item_' . $detailsWidgetItem -> idWidgetItem, $detailsWidgetItem);
				$this -> retrievedWidgetItems[$detailsWidgetItem -> idWidgetItem] = $detailsWidgetItem;
			}
		}

        $listWidgetItems = Plugins::_runAction('widgets_get_widget_items_by_space', $listWidgetItems,$idSpace);

		return $listWidgetItems;

	}

	/**
	 * Returns widget item details
	 *
	 * @param int(idWidgetitem id)
	 * @return details widget Item(object)
	 */
	public function _getWidgetItem($idWidgetItem) {

		if (isset($this -> retrievedWidgetItems[$idWidgetItem])) {
			$detailsItem = $this -> retrievedWidgetItems[$idWidgetItem];
		} else if (Cache::_getInstance() -> _isCached('widget_item_' . $idWidgetItem)) {
			$detailsItem = Cache::_getInstance() -> _getCache('widget_item_' . $idWidgetItem);
		} else {
			$query = " select * from " . Config::_getTable('widget_items') . " where idWidgetItem = :idWidgetItem";
			$arrayBind[] = array("key" => ":idWidgetItem", "value" => $idWidgetItem);
			$detailsItem = Core::_getRow($query, $arrayBind);

			if ($detailsItem){
                Cache::_getInstance() -> _setCache('widget_item_' . $detailsItem -> idWidgetItem, $detailsItem);
			}
		}

        if ($detailsItem){
            $this -> retrievedWidgetItems[$detailsItem -> idWidgetItem] = $detailsItem;
        }

        $detailsItem = Plugins::_runAction('widgets_get_widget_item_details', $detailsItem,$idWidgetItem);

		return $detailsItem;

	}

	/**
	 * Deletes given widget item
	 *
	 * @param int(idWidgetitem id)
	 * @return null
	 */
	public function _deleteWidgetItem($idWidgetItem) {

		$tmpId = Plugins::_runAction('widgets_delete_widget_item',$idWidgetItem);
        
        if( !$tmpId ) return;
		
        $query  = "delete from ".Config::_getTable('widget_items')." where idWidgetItem = :primaryField";
        $arrayBind[]= array("key" => ":primaryField", "value" =>  $idWidgetItem);
        Core::_runQuery($query,$arrayBind);
        
		// Removing the cache
		Cache::_getInstance() -> _removeCache('widgets_item_' . $idWidgetItem);
		
		global $Relations;
		
		$Relations->_deleteRalations('space_to_widget','',$idWidgetItem);

	}

	/**
	 * displays widget details
	 *
	 * @param int(idWidget id)
	 * @return none
	 */
	public function _displayWidget($idWidgetitem,$idSpace=false) {

        $idWidgetitem = Plugins::_runAction('widgets_display_widget_start',$idWidgetitem,$idSpace);

		$detailsItem = $this -> _getWidgetItem($idWidgetitem);

		if (!$detailsItem || !$detailsItem -> statusWidgetItem)
			return;

		$detailsWidget = $this -> _getWidgetDetails($detailsItem -> idWidget);

		if (!$detailsWidget || !$detailsWidget -> statusWidget)
			return;

        $detailsWidget = (object) array_merge((array) $detailsWidget, (array) $detailsItem);
        
		$detailsWidget -> options = unserialize($detailsWidget -> optionsWidgetItem);

		global $Base, $Cms, $Editor, $Plugins, $Themes, $Validate ; 

		$pathFile = Config::_getDir() . '/' . $detailsWidget -> pathWidget . '/view.php';

        $displayContentWidget = '';

		if (file_exists($pathFile)) {

            ob_start();			
			include $pathFile;
            $displayContentWidget = ob_get_clean();

		}

        $displayContentWidget = Plugins::_runAction('widgets_display_widget_content',$displayContentWidget, $detailsWidget, $detailsItem, $idWidgetitem,$idSpace);

        global $Editor;

        if( $Editor->_isCustomizeMode() ){
            
            $displayContentWidget = '<span class="customEditorLabel customEditorLabel_enable "' . $Editor -> _generate('widgets-items', $detailsItem -> idWidgetItem,'',false,true,$idSpace) . '>'
                                    .$displayContentWidget
                                    .'</span>';

        }
        
        echo $displayContentWidget;
        
        Plugins::_runAction('widgets_display_widget_end',$idWidgetitem,$idSpace);

	}


}
