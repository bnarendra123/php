<?php defined('QC_VALID') or die('Restricted Access!');

/**
 * Ajax class, contains functions related to ajax actions
 *
 *
 * @version 1.0
 * @http://www.quikc.org/
 */

class Ajax {

    /**
     * Contains isAjax value
     * Used to detect weather the given execution is ajax execution or not
     *
     * @var array of objects
     */
    private static $isAjax = null;

    /**
     * Construction for ajax class
     *
     * @param void()
     * @return null()
     */
    public function __construct() {
    }

    /**
     * Returns the ajax execution status of current load
     *
     * @param void()
     * @return boolean()
     */
    public static function _isAjax() {

        return self::_getIsAjax();

    }

    /**
     * Returns current isAjax value
     *
     * @param void()
     * @return boolean()
     */
    public static function _getIsAjax() {

        if (is_null(self::$isAjax)) {

            self::_updateIsAjax();

        }

        $isAjax = self::$isAjax;

        $isAjax = Plugins::_runAction('ajax_get_is_ajax', $isAjax);

        return $isAjax;

    }

    /**
     * Updates current ajax load type
     *
     * @param boolean()
     * @return null
     */
    public static function _setIsAjax($isAjax) {

        $isAjax = Plugins::_runAction('ajax_set_is_ajax', $isAjax);

        self::$isAjax = $isAjax;

    }

    /**
     * Checks weather current execution is an ajax execution or not
     *
     * @param void()
     * @return null
     */
    public static function _updateIsAjax() {

        $isAjax = false;

        if (defined('QC_AJAX')) {

            $isAjax = true;

        }

        if (isset($_GET['ajax'])) {

            $isAjax = true;

        }

        $isAjax = Plugins::_runAction('ajax_is_ajax', $isAjax);

        self::_setIsAjax($isAjax);

    }

}
