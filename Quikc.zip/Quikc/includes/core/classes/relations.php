<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * Relations class contains the function related to the relation between two elements
 * This includes relations, status, relation updates etc
 *
 * @version 1.0
 * @http://www.quikc.org/
 */

class Relations {

	/**
	 * Contains retrieved ralation values
	 * Used to sort the retrieved relation, so that we can only  retrieve it once
	 *
	 * @var array of objects
	 */
	private $retrievedRelations;

	/** Return the list of Relations with the given keys
	 *
	 *
	 * @param $typeRelation(string),$idFrom(string),$idTo(string),$fieldAdditional1(string),$fieldAdditional2(string),$fieldAdditional3(string)
	 * @var array of object
	 */
	public function _getRalations($typeRelation,$idFrom = '',$idTo = '',$fieldAdditional1='',$fieldAdditional2='',$fieldAdditional3='',$orderBy='') {

		$query = " select * from " . Config::_getTable('relations') . " where typeRelation = :typeRelation ";
		$arrayBind[] = array("key" => ":typeRelation",	"value" => $typeRelation);
		
		if( $idFrom != ''){
			$query .= " and idFrom = :idFrom ";
			$arrayBind[] = array("key" => ":idFrom","value" => $idFrom);
		}

		if( $idTo != ''){
			$query .= " and idTo = :idTo ";
			$arrayBind[] = array("key" => ":idTo",	"value" => $idTo);
		}

		if( $fieldAdditional1 != ''){
			$query .= " and fieldAdditional1 = :fieldAdditional1 ";
			$arrayBind[] = array("key" => ":fieldAdditional1",	"value" => $fieldAdditional1);
		}

		if( $fieldAdditional2 != ''){
			$query .= " and fieldAdditional2 = :fieldAdditional2 ";
			$arrayBind[] = array("key" => ":fieldAdditional2",	"value" => $fieldAdditional2);
		}

		if( $fieldAdditional3 != ''){
			$query .= " and fieldAdditional3 = :fieldAdditional3 ";
			$arrayBind[] = array("key" => ":fieldAdditional3",	"value" => $fieldAdditional3);
		}

		if( $orderBy != ''){
			
			if( in_array($orderBy, array('idFrom','idTo','fieldAdditional1','fieldAdditional2','fieldAdditional3','dateAdditionRelation','dateUpdationRelation'))){
				$query .= " order by $orderBy";
			}
		}

		$listRelations = Core::_getAllRows($query, $arrayBind);

        $listRelations = Plugins::_runAction('relations_get_relation', $listRelations,$typeRelation,$idFrom,$idTo,$fieldAdditional1,$fieldAdditional2,$fieldAdditional3,$orderBy);

		return $listRelations;

	}

	/** Generates a new ralation
	 *
	 *
	 * @param $typeRelation(string),$idFrom(string),$idTo(string),$fieldAdditional1(string),$fieldAdditional2(string),$fieldAdditional3(string)
	 * @var boolean
	 */
	public function _generateRalation($typeRelation,$idFrom,$idTo,$fieldAdditional1='',$fieldAdditional2='',$fieldAdditional3='') {

        $return = false;

		if($typeRelation != '' && $idFrom != '' && $idTo != '' ){
		    
            $query = " insert into " . Config::_getTable('relations') . " (typeRelation,idFrom,idTo,fieldAdditional1,fieldAdditional2,fieldAdditional3,dateAdditionRelation)
            values (:typeRelation,:idFrom,:idTo,:fieldAdditional1,:fieldAdditional2,:fieldAdditional3,NOW()) ";
    
            $arrayBind[] = array("key" => ":typeRelation",  "value" => $typeRelation);
            $arrayBind[] = array("key" => ":idFrom","value" => $idFrom);
            $arrayBind[] = array("key" => ":idTo",  "value" => $idTo);
            $arrayBind[] = array("key" => ":fieldAdditional1",  "value" => $fieldAdditional1);
            $arrayBind[] = array("key" => ":fieldAdditional2",  "value" => $fieldAdditional2);
            $arrayBind[] = array("key" => ":fieldAdditional3",  "value" => $fieldAdditional3);
    
            if(Core::_runQuery($query, $arrayBind)){
                $return = true;
            }
		}

        $return = Plugins::_runAction('relations_get_relation', $return,$typeRelation,$idFrom,$idTo,$fieldAdditional1,$fieldAdditional2,$fieldAdditional3);
		
		return $return;
	}

	/** Deletes the relations for the given from key in the given type
	 *
	 *
	 * @param $typeRelation(string),$idFrom(string),$id(string)
	 * @var boolean
	 */
	public function _deleteRalations($typeRelation,$idFrom = '',$idTo = '') {
	    
        $return = false;

		if($idFrom != '' || $idTo != ''){
		    
            $query = " delete from " . Config::_getTable('relations') . " where typeRelation = :typeRelation ";
            $arrayBind[] = array("key" => ":typeRelation",  "value" => $typeRelation);
            
            if($idFrom != '' ){
                $query .= " and idFrom = :idFrom ";
                $arrayBind[] = array("key" => ":idFrom","value" => $idFrom);
            }
    
            if($idTo != '' ){
                $query .= " and idTo = :idTo";
                $arrayBind[] = array("key" => ":idTo","value" => $idTo);
            }
            
            if(Core::_runQuery($query, $arrayBind)){
                $return = true;
            }
		    
		}
        
        $return = Plugins::_runAction('relations_get_relation', $return,$typeRelation,$idFrom,$idTo);
		
		return $return;
	}
	 
}
