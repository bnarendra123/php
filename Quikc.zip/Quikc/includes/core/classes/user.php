<?php

defined('QC_VALID') or die('Restricted Access!');

/**
* user class, used for processing user related actions
* All user related basic will be processed from here. Please don't change unless critical
*
* @version 1.0
* @http://www.quikc.org/
*/
class User{

	/** Contains the logged in user details
	* 
	*
	* @var object
	*/
    private static $userDetails = false;

	/** Cache for the user groups
	* 
	*
	* @var object
	*/
    private $listUserGroups;

	/** Verified user details and logs him in, if the details matched
	* 
	*
    * @param User Email(string), User Password(string)
	* @var null
	*/
	public function _doLogin($emailUser,$passwordUser){

        global $Base;
		$errors = array();
		
		if( $emailUser == '' ) $errors[] = 'Please Enter Email';
		if( $passwordUser == '' ) $errors[] = 'Please Enter Password';

		if( count($errors) == 0 && $this->_checkEmailExistance($emailUser) == false ){
			$errors[] = Config::_getMessage('forms.error.email.password');
		}

		// If there are any errors, then this will return them back		
		if( count($errors) == 0 ){

            $detailsUser = $this->_getUserDetailsByEmail($emailUser);
    
            if( $detailsUser->statusUser ){

                //checking the password
                if( $detailsUser->passwordUser == md5($passwordUser) ){
                    // Since the password matched, logging in the user
                    $this->_directLogin($detailsUser->idUser);      

                    $return = 'ok';
                    
                    $return = Plugins::_runAction('users_do_login_success', $return, $emailUser);
                    
                    return $return;
                    
                }else{
                    $errors[] = Config::_getMessage('forms.error.email.password');
                }

            }else{
                $errors[] = Config::_getMessage('forms.validate.account.disabled');
            }
		}
        
        $return = $Base->_convertError($errors,true);

        $return = Plugins::_runAction('users_do_login_errors', $return ,$errors);

        return $return;

	}

	public function _doLoginAssociate($emailUser,$passwordUser){
		

        global $Base;
		$errors = array();
		
		if( $emailUser == '' ) $errors[] = 'Please Enter Email';
		if( $passwordUser == '' ) $errors[] = 'Please Enter Password';

		if( count($errors) == 0 && $this->_checkEmailExistanceAssociate($emailUser) == false ){
			
			$errors[] = Config::_getMessage('forms.error.email.password');
		}

		// If there are any errors, then this will return them back		
		if( count($errors) == 0 ){
			
            $detailsUser = $this->_getAssociateDetailsByEmail($emailUser);
			
            if( $detailsUser->statusUser ){

                //checking the password
                if( $detailsUser->passwordUser == md5($passwordUser) ){
                    // Since the password matched, logging in the user
                    $this->_directLoginAssociate($detailsUser->idUser);      

                    $return = 'ok';
                    
                    $return = Plugins::_runAction('users_do_login_success', $return, $emailUser);
                    
                    return $return;
                    
                }else{
                    $errors[] = Config::_getMessage('forms.error.email.password');
                }

            }else{
                $errors[] = Config::_getMessage('forms.validate.account.disabled');
            }
		}
        
        $return = $Base->_convertError($errors,true);

        $return = Plugins::_runAction('users_do_login_errors', $return ,$errors);

        return $return;

	}	
	
	
	/** Verified user details and logs him in, if the details matched
	* 
	*
    * @param User Email(string), User Password(string)
	* @var null
	*/
	public function _abDoLogin($emailUser,$passwordUser,$sourceUser = 'facebook'){

        global $Base;
		$errors = array();
		
		if( $emailUser == '' ) $errors[] = 'Please Enter Email';
		if( $passwordUser == '' ) $errors[] = 'Please Enter Password';

		if( count($errors) == 0 && $this->_checkEmailExistance($emailUser) == false ){
			$errors[] = Config::_getMessage('forms.error.email.password');
		}

		// If there are any errors, then this will return them back		
		if( count($errors) == 0 ){

            $detailsUser = $this->_getFbUserDetailsByEmail($emailUser);
    
            if( $detailsUser->statusUser ){

                //checking the password
                if( $detailsUser->passwordUser == md5($passwordUser) ){
                    // Since the password matched, logging in the user
                    $this->_directLogin($detailsUser->idUser);      

                    $return = 'ok';
                    
                    $return = Plugins::_runAction('users_do_login_success', $return, $emailUser);
                    
                    return $return;
                    
                }else{
                    $errors[] = Config::_getMessage('forms.error.email.password');
                }

            }else{
                $errors[] = Config::_getMessage('forms.validate.account.disabled');
            }
		}
        
        $return = $Base->_convertError($errors,true);

        $return = Plugins::_runAction('users_do_login_errors', $return ,$errors);

        return $return;

	}

	/** Logins the user with the ginven id
	* 
	*
    * @param User Id.(int)
	* @var null
	*/
	public function _directLogin($idUser){

        $return = false;

		if( isset($_SESSION['user']) ){
			unset($_SESSION['user']);			
		} 

		$_SESSION['user']['statusLogged']	= true;	
		$_SESSION['user']['idUser']			= $idUser;	
		$_SESSION['user']['lastAccess'] 	= time();
		
		if( $this->_verify($idUser) ){
			if(Config::_get('developer.mode.login.reset')){
				// Query to update the login mode to normal
		        $query      = "update ".Config::_getTable('users')." set loginModeUser = 0 where `idUser`=:idUser ";
				$arrayBind[]= array("key" => ":idUser", "value" => $idUser);

		        // Executing delete query
		        if( Core::_runQuery($query, $arrayBind) ){
                    $return = true;
		        }
			}
		}

        $return = Plugins::_runAction('users_do_login_success', $return, $idUser);

        return $return;				
	}
	
	
	public function _directLoginAssociate($idUser){

        $return = false;

		if( isset($_SESSION['user']) ){
			unset($_SESSION['user']);			
		} 

		$_SESSION['user']['statusLogged']	= true;	
		$_SESSION['user']['idUser']		= $idUser;	
		$_SESSION['user']['lastAccess'] 	= time();
		$_SESSION['user']['associate'] 	= true;
		
		if( $this->_verify($idUser) ){
			if(Config::_get('developer.mode.login.reset')){

		        $query      = "update ".Config::_getTable('associate')." set loginModeUser = 0 where `idUser`=:idUser ";
				$arrayBind[]= array("key" => ":idUser", "value" => $idUser);
		        if( Core::_runQuery($query, $arrayBind) ){
                    $return = true;
		        }
			}
		}

        $return = Plugins::_runAction('users_do_login_success', $return, $idUser);

        return $return;				
	}
	
	/** Checks the log activity of current user
	* 
	*
    * @param user Details( Array of objects )
	* @var null
	*/
	public function _checkUserLogActivity($detailsUser){
		
		// Setting Captcha Status
		if(Config::_get('login.invalid.show.captcha') ){
			$_SESSION['captcha_active'] = 1;
		}

		//Sending mail to the corresponding user
		// Setting mail Status
		if( $detailsUser->failure_attempts == Config::_get('login.invalid.attempts') && Config::_get('login.invalid.send.mail') ){

			$Mail = new Mail;
			$variables = array('[:User:]' => $detailsUser->nameFirstUser);
			$Mail->_setVariables($variables);
			$Mail->_setDbMail('frequent_login_attempts');
			$Mail->_setTo($detailsUser->emailUser);
			$result = $Mail->_send();
			unset($Mail);
			
			die('reload');
		}
	}

	/** Logsout the logged in user
	* 
	*
    * @param void
	* @var null
	*/
	public function _logout(){

        $return = false;  
	    
        $detailsUser = $this->_userDetails();
        
        if( $detailsUser ){

            if( isset($_SESSION['user']['viewas']) ){

	            unset($_SESSION['user']['associate']);
	            unset($_SESSION['user']['viewas']);
            	
			}else{
				
	            unset($_SESSION['user']);
	            $return = true;

			}

        } 
	
        $return = Plugins::_runAction('users_do_logout', $return, $detailsUser);
    
        return $return; 
	}
	
	/** Checks weather any user authenticated with the current session id
	* 
	*
    * @param void
	* @var boolean
	*/
	public function _authenticateUser(){
		
		$this->_checkUserSession();

	}
	
	/** Checks weather any user with the given id values is logged in or not. 
	*	If not returns false
	*	if he is logged in, then updates his details to userDetails using _verify and he will be the logged in user for the current page execution   
	* 
	*
    * @param User Id(int), User Key(string)
	* @var boolean
	*/
	public function _checkUserSession(){

        $return = false;
		

		if( 
			( 
				isset($_SESSION['user']) 
				&& isset($_SESSION['user']['idUser']) 
				&& isset($_SESSION['user']['statusLogged']) 
				&& $_SESSION['user']['statusLogged'] 
				&& !empty($_SESSION['user']['idUser'] ) 
			)
			){

        	$idUser = $_SESSION['user']['idUser'];	
				
            if( isset($_SESSION['user']['viewas']) ){

            	if( defined('QC_ADMIN') ){

					$_SESSION['user']['associate'] = false; 

            	}else{

	        		$idUser = $_SESSION['user']['viewas'];
					$_SESSION['user']['associate'] = true; 
					
            	}
				
            }
			
            // Getting session timeout values from the database     
            $timeOut = (int)Config::_get('login.session.timeout')*60;
            
            if($timeOut < 1 ){
                $timeOut = 365*24*60;
            }
    
            $timeCurrent = time();
            $timeLastAccess = $_SESSION['user']['lastAccess'];
            $timeExpire = $timeLastAccess + $timeOut;
    
            // Checking weather any active session records found
            if( $timeCurrent <= $timeExpire ){
                // Since given session exists and not expired, we have to verify the user as logged in by updating his details
                // $this->_verify($idUser) will do that.
                if( $this->_verify($idUser) ) {
                    $return = true;
                }
            }
		    
		}

        $return = Plugins::_runAction('users_check_user_session', $return);
		
		return $return;
	}

	/** Verifies the user with the given id as loggedin user for the current page execution
	* it check the users details and status and then confirms the user  
	* 
	* @Called from: _checkUserSession and _directLogin
	* 
    * @param Admin id.(int)
	* @var null
	*/
    private function _verify($idUser){

        $return = false;
	
		if( isset($_SESSION['user']['associate']) && $_SESSION['user']['associate']  ){
			
			$detailsUser = self::_getAssociateDetailsById($idUser);
		}else{
			
			$detailsUser = self::_getUserDetailsById($idUser);
		}
		
		// if the given id is not, valid or the user status is disabled, then we will not allow the user as logged in
		// status checking of the user here will be useful to identify, if the user is already logged in by the time he is blocked 
		if( $detailsUser && $detailsUser->statusUser){

			if( isset($_SESSION['user']['associate']) && $_SESSION['user']['associate'] ){
				
				$detailsUser->associateUser = true;
			}else{
				
				$detailsUser->associateUser = false;
			}

            // Finally the user passed all the stages inorder to be considered as logged in
            // So we are updating the user details to self::$userDetails
            // these details are used to confirm that the user is logged in from now on using the function $User::_userDetails() 
            // but for the admins to be considered as logged in, they need to pass few more stages and they wil be done at $User::_adminDetails()
            self::$userDetails = $detailsUser;
    
            // updating user last logged in time
            // this will be useful to track session timeout
            
            $_SESSION['user']['lastAccess'] = time();
			
            $return = true;
    
		}
        
        $return = Plugins::_runAction('users_verify', $return, $idUser);

		return $return;		
    }

	/** Adds Log Activity for given user
	* 
	*
    * @param Admin Id(int), Log Status(1/0)
	* @var null
	*/
	public function _addUserLogActivity($idUser,$logStatus,$replaceData = ''){
	        
	    global $Base;

        $logArray = $Base->_generateSelect('logactivity');
        if( !isset($logArray[$logStatus]) ) return false;

		// Query to insert the admin log activity
		$query	   = "insert into ".Config::_getTable('user_log_activity')." ( `idUser`,`statusLog`,`replaceData`,`timeLog`,`ipaddressLog`) values (:idUser, :statusLog,:replaceData, NOW(), :ipaddressLog ) ";
		$arrayBind[] = array("key" => ":idUser",    "value" => $idUser );
		$arrayBind[] = array("key" => ":statusLog",  "value" => $logStatus );
        $arrayBind[] = array("key" => ":replaceData",  "value" => $replaceData );
		$arrayBind[] = array("key" => ":ipaddressLog", "value" => $_SERVER['REMOTE_ADDR']);

		// Executing insert query
		Core::_runQuery($query, $arrayBind);

        Plugins::_runAction('users_add_user_log_activity', $idUser,$logStatus,$replaceData);

	}
	
	/** Returns list of users
	* 
	*
    * @param void
	* @var list of users Deails(array of object)
	*/
    public function _getUsers(){
    	
		$query	= "select * from ".Config::_getTable('users')." order by nameFirstUser asc";
		$listUsers = Core::_getAllRows($query, '');

        $listUsers = Plugins::_runAction('users_get_users', $listUsers);
        
        return $listUsers;
    }

	/** Returns currently logged in user details
	* 
	*
    * @param void
	* @var user deails(object)
	*/
    public static function _userDetails(){
        
        $detailsUser = self::$userDetails;
        
        $detailsUser = Plugins::_runAction('users_user_details', $detailsUser);
		
		return $detailsUser;

    }

    /** checks and returns the logged status of the current session
    * 
    *
    * @param void
    * @var boolean
    */
    public static function _isLogged(){
        
        $return = false;

        // checking weather the user is logged in as admin or not
        if( self :: _userDetails() ){

            $return = true;

        }        
        
        $return = Plugins::_runAction('users_islogged', $return);
        
        return $return;

    }

    /** checks weather user details for the given key if exists
    * 
    *
    * @param function name(string), $params(parameters)
    * @var mixed
    */
    public static function __callstatic($fun, $params){
        
        if( self :: _isLogged() ){

            $du = self :: _userDetails();
            
            if( isset($du -> $fun) ){

                return $du -> $fun;

            }

        }

    }

    /** checks weather user details for the given key if exists
    * 
    *
    * @param function name(string), $params(parameters)
    * @var mixed
    */
    public function __call($fun, $params){
        
        return self :: __callstatic($fun, $params);

    }

	/** Checks the existance of a user email
	* 
	*
    * @param User id.(int)
	* @var boolean
	*/
	public function _checkEmailExistance($emailUser){

        $return = false;

		$query		= "select * from ".Config::_getTable('users')." where `emailUser` = :emailUser ";
		$arrayBind[]= array("key" => ":emailUser", "value" =>  $emailUser );
		
		if( Core::_getRow($query, $arrayBind) ){
            $return = true;
		}

        $return = Plugins::_runAction('users_check_email_existance', $return,$emailUser);
        
		return $return;
	}
	public function _checkEmailExistanceAssociate($emailUser){
	
	    $return = false;

		$query		= "select * from ".Config::_getTable('associate')." where `emailUser` = :emailUser ";
		$arrayBind[]= array("key" => ":emailUser", "value" =>  $emailUser );
		
		if( Core::_getRow($query, $arrayBind) ){
            $return = true;
		}
	
		$return = Plugins::_runAction('users_check_email_existance', $return,$emailUser);
        
		return $return;
	}

	/** Prepares the user details
	* 
	*
    * @param User Details.(object)
	* @var object
	*/
	public function _prepareUserDetails($detailsUser){

        $oldDetailsUser = $detailsUser;

		if( $detailsUser ){

            $detailsUser->nameFullUser = $detailsUser->nameFirstUser.' '.$detailsUser->nameLastUser;
            $detailsUser->preferencesUser = $this->_prepareUserPreference($detailsUser->preferencesUser);
    
		}

        $detailsUser = Plugins::_runAction('users_prepare_user_details', $detailsUser, $oldDetailsUser);
		
		return $detailsUser;
	}

	/** Return user details from id
	* 
	*
    * @param User id.(int)
	* @var object
	*/
	public function _getUserDetailsById($idUser){

		$query		= "select * from ".Config::_getTable('users')."  where idUser = :idUser ";
		$arrayBind[]= array("key" => ":idUser", "value" =>  $idUser);

		$detailsUser = Core::_getRow($query, $arrayBind);
		
		if( $detailsUser )
		$detailsUser = $this->_prepareUserDetails($detailsUser);

        $detailsUser = Plugins::_runAction('users_get_user_details_by_id', $detailsUser, $idUser);

		return $detailsUser;
	}

	/** Returns user details by using email
	* 
	*
    * @param User email.(string)
	* @var object
	*/
	public function _getUserDetailsByEmail($emailUser){
	
		$query		= "select * from ".Config::_getTable('users')." where emailUser = :emailUser ";
		$arrayBind[]= array("key" => ":emailUser", "value" =>  $emailUser );

		$detailsUser = Core::_getRow($query, $arrayBind);
		
		if( $detailsUser )
		$detailsUser = $this->_prepareUserDetails($detailsUser);

        $detailsUser = Plugins::_runAction('users_get_user_details_by_email', $detailsUser, $emailUser);

		return $detailsUser;
	}
	
	public function _getAssociateDetailsByEmail($emailUser){
	
		$query		= "select * from ".Config::_getTable('associate')." where emailUser = :emailUser ";
		$arrayBind[]= array("key" => ":emailUser", "value" =>  $emailUser );

		$detailsUser = Core::_getRow($query, $arrayBind);
		
		if( $detailsUser )
		$detailsUser = $this->_prepareUserDetails($detailsUser);

        $detailsUser = Plugins::_runAction('users_get_user_details_by_email', $detailsUser, $emailUser);

		return $detailsUser;
	}
	
	public function _getAssociateDetailsById($idUser){
	
		$query		= "select * from ".Config::_getTable('associate')." where idUser = :idUser ";
		$arrayBind[]= array("key" => ":idUser", "value" =>  $idUser );

		$detailsUser = Core::_getRow($query, $arrayBind);
		
		if( $detailsUser )
		$detailsUser = $this->_prepareUserDetails($detailsUser);

        $detailsUser = Plugins::_runAction('users_get_user_details_by_email', $detailsUser, $emailUser);

		return $detailsUser;
	}
	
	
	/** Returns user details by using email
	* 
	*
    * @param User email.(string)
	* @var object
	*/
	public function _getFbUserDetailsByEmail($emailUser){
	
		$query		= "select * from ".Config::_getTable('users')." where emailUser = :emailUser and sourceUser = :sourceUser";
		$arrayBind[]= array("key" => ":emailUser", "value" =>  $emailUser );
		$arrayBind[]= array("key" => ":sourceUser", "value" =>  'facebook' );

		$detailsUser = Core::_getRow($query, $arrayBind);
		
		if( $detailsUser )
		$detailsUser = $this->_prepareUserDetails($detailsUser);

        $detailsUser = Plugins::_runAction('users_get_user_details_by_email', $detailsUser, $emailUser);

		return $detailsUser;
	}

    /** Return the no of active users
    * 
    *
    * @param void
    * @var null
    */
    public function _getActiveUserCount(){
    
        $query      = "select * from ".Config::_getTable('users')." where `statusUser` = :statusUser ";
		$arrayBind[]= array("key" => ":statusUser", "value" =>  1 );

        $countUsers =  Core::_getRowCount($query, $arrayBind);
		
        $countUsers = Plugins::_runAction('users_get_active_user_count', $countUsers);

        return $countUsers;				
    }
	
	/** Returns list of admin groups
	* 
	*
    * @param void
	* @var User Groups(array of object)
	*/
    public function _getUserGroups(){
    	
		$query	= "select * from ".Config::_getTable('user_groups')." order by nameGroup asc";
		$listGroups = Core::_getAllRows($query, '');

        $listGroups = Plugins::_runAction('users_get_user_groups', $listGroups);

        return $listGroups;
    }

	/** Returns the user group details
	* 
	*
    * @param Admin Group Id(int),
	* @var object
	*/
	public function _getUserGroupDetailsById($idGroup){
		
        if(isset($listUserGroups[$idGroup])){
            $detailsGroup = $listUserGroups[$idGroup];  
		}else{
        
            $query      = "select * from ".Config::_getTable('user_groups')." where idGroup = :idGroup ";
            $arrayBind[]= array("key" => ":idGroup", "value" =>  $idGroup);
    
            $detailsGroup = Core::_getRow($query, $arrayBind);
            
            $this->listUserGroups[$idGroup] = $detailsGroup;
		}

        $detailsGroup = Plugins::_runAction('users_get_user_group_details_by_id', $detailsGroup);
		
		return $detailsGroup;
	}
	
	/** Returns the user preferences details
	* 
	*
    * @param $preferencesUser(serilized string)
	* @var mixed(boolean/object)
	*/
	public function _prepareUserPreference($preferencesUser){
		
		if ($preferencesUser && strlen($preferencesUser) > 0) {
			$preferencesUser =  unserialize($preferencesUser);		
		}else{
			$preferencesUser = new stdClass;
		}

        $preferencesUser = Plugins::_runAction('users_prepare_user_preference', $preferencesUser);

		return $preferencesUser;
	}

	/** Returns the user preferences with the given key
	* 
	*
    * @param Key Preference(string)
	* @var mixed
	*/
	public function _getUserPreference($pathPreference){
		    
        if( !User::_userDetails() ) return;
		
		$preferencesUser = User:: preferencesUser();

		$seperator = '/';

		if( $pathPreference[0] == $seperator ){
			$pathPreference = substr($pathPreference, 1);
		} 
		if( substr($pathPreference, -1) == $seperator ){
			$pathPreference = substr($pathPreference, 0, -1);
		}
		
		if ( strpos($pathPreference, $seperator) === false) {
			
			if( isset($preferencesUser->$pathPreference->valuePref) ){
				return $preferencesUser->$pathPreference->valuePref;
			}else{
				return;
			}
		}else{
			
			$pathArray = explode($seperator,$pathPreference);
			
			foreach($pathArray as $currentKey){
				if( isset($preferencesUser->$currentKey) ){
					$preferencesUser = $preferencesUser->$currentKey;
				}else{
					return;
				}
			}

			if( !isset($preferencesUser->valuePref) ) return;
			
			return $preferencesUser->valuePref;
		}
	}
		
	/** updates user preferences with the given key
	* 
	*
    * @param Key Preference(string)
	* @var mixed
	*/
	public function _setUserPreference($pathPreference,$valuePreference){
		
		$preferencesUser = User:: preferencesUser();

		$seperator = '/';

		if( $pathPreference[0] == $seperator ){
			$pathPreference = substr($pathPreference, 1);
		} 
		if( substr($pathPreference, -1) == $seperator ){
			$pathPreference = substr($pathPreference, 0, -1);
		}
		
		if ( strpos($pathPreference, $seperator) === false) {
			$preferencesUser->$pathPreference = $valuePreference;
		}else{
			
			$pathArray = explode($seperator,$pathPreference);

			$activeNode = $preferencesUser;
			
			foreach($pathArray as $currentKey){
				
				if( !isset($activeNode->$currentKey) ){
					$activeNode->$currentKey = new stdClass;
				}
				$activeNode = $activeNode->$currentKey;
			}
			
			$activeNode->valuePref = $valuePreference;
			
			if ($preferencesUser) {
				$preferencesUser =  serialize($preferencesUser);		
			}
	
			// Query to update the login mode to normal
	        $query      = "update ".Config::_getTable('users')." set preferencesUser = :preferencesUser where `idUser`=:idUser ";
			$arrayBind[]= array("key" => ":preferencesUser", "value" => $preferencesUser);
			$arrayBind[]= array("key" => ":idUser", "value" => User:: idUser() );

	        // Executing delete query
	        Core::_runQuery($query, $arrayBind);
		}
		return;
	}
}
