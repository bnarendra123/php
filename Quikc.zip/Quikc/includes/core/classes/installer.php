<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * Installer class, contains functions related to installation process
 *
 *
 * @version 1.0
 * @http://www.quikc.org/
 */

class Installer {

	/**
	 * Construction for installer class
	 *
	 * @param void()
	 * @return null()
	 */
	public function __construct() {
	}

    /**
     * this will check and run the appropriative stage of the installation
     *
     * @param void()
     * @return boolean()
     */
    public function _runProcess() {
    	
		// Checking weather the config file exists or not
		if( !$this->_checkConfig() ) {
			
			// config file doesn't exists in the custom folder
			// now checking weather the config file exists in the core folder or not
			
			if( $this->_checkCoreConfig() ) {

				// creating the config file from core folder to the custome folder
				$this->_copyConfig();

			}
            
		}

		// After all initial processes, now checking weather we have config file or not
		// If yes, then we include that file and continue the process
		if( $this->_checkConfig() ) {
		    
			require $this->_getConfig();
            
		}		
        
    }

    /**
     * returns config file path  
     *
     * @param void()
     * @return string()
     */
    private function _getConfig() {
        
		return Config::_getDir() . '/includes/custom/lib/config.php';
        
    }

    /**
     * returns core config file path  
     *
     * @param void()
     * @return string()
     */
    private function _getCoreConfig() {
        
		return Config::_getDir() . '/includes/core/lib/config.php';
        
    }

    /**
     * this function will check weather config file exists or not  
     *
     * @param void()
     * @return boolean()
     */
    private function _checkConfig() {

		// checking if config file exists or not 
		
		if( file_exists($this->_getConfig()) ) {
		    
			return true;		
            
		}

		return false;
        
    }

    /**
     * this function will check weather config file exists or not in the core folder
     *
     * @param void()
     * @return boolean()
     */
    private function _checkCoreConfig() {

		// checking if config file exists or not 
		
		if( file_exists($this->_getCoreConfig()) ) {
		    
			return true;		
            
		}

		return false;
        
    }

    /**
     * this function will copy the config from core folder to the custom folder
     *
     * @param void()
     * @return boolean()
     */
    private function _copyConfig() {

		if( is_writable(dirname($this->_getConfig())) ) {

			if( copy($this->_getCoreConfig(), $this->_getConfig()) ) return true;
			
		}else{
		    
			die('Config folder not writable.');
            
		}

		return false;
        
    }
    
}

