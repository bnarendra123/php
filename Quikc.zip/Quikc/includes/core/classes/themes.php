<?php

defined('QC_VALID') or die('Restricted Access!');

/**
 * Themes class, contains functions related to themes
 *
 *
 * @version 1.0
 * @http://www.quikc.org/
 */

class Themes {

	/** Stores the information of the active theme
	 *
	 *
	 * @var Object strings
	 */
	private static $activeTheme = false;

	/** Stores metadata information like title, meta description, keywords etc
	 *
	 *
	 * @var Object strings
	 */
	private static $metaData = array();

	/**
	 * Contains currently visiting page information
	 *
	 * @var array of objects
	 */
	private $currentPageData = false;

	/**
	 * Construction for base
	 *
	 * @param void()
	 * @return null
	 */
	public function __construct() {
		
		$this->_updateActiveThemePath();
        
        Plugins::_runAction('themes_constructer');
        
	}


	/**
	 * Returns theme details with given id
	 *
	 * @param integer($idTheme)
	 * @return object($detailsTheme)
	 */
	public function _getThemeDetails($idTheme) {

		$query = " select * from " . Config::_getTable('themes') . " where idTheme = :idTheme";
		$arrayBind[] = array("key" => ":idTheme", "value" => $idTheme);
		$detailsTheme = Core::_getRow($query, $arrayBind);

        $detailsTheme = Plugins::_runAction('themes_get_theme_details', $detailsTheme);

		return $detailsTheme;

	}

	/**
	 * Returns theme details with given path
	 *
	 * @param integer($idTheme)
	 * @return object($detailsTheme)
	 */
	public function _getThemeDetailsByPath($pathTheme) {

		$query = " select * from " . Config::_getTable('themes') . " where pathTheme = :pathTheme";
		$arrayBind[] = array("key" => ":pathTheme", "value" => $pathTheme);
		$detailsTheme = Core::_getRow($query, $arrayBind);

        $detailsTheme = Plugins::_runAction('themes_get_theme_details_by_path', $detailsTheme);

		return $detailsTheme;

	}

	/**
	 * Returns active theme details
	 *
	 * @param void
	 * @return boolean
	 */
	public function _getActiveTheme() {

		if (!self::$activeTheme) {

			$query = " select * from " . Config::_getTable('themes') . " where statusTheme = :statusTheme";
			$arrayBind[] = array("key" => ":statusTheme", "value" => 1);
			$activeTheme = Core::_getRowCount($query, $arrayBind);

			if ($activeTheme != 1) {

				unset($arrayBind);
				$query = " update " . Config::_getTable('themes') . " set statusTheme = :statusTheme ";
				$arrayBind[] = array("key" => ":statusTheme", "value" => 0);
				Core::_runQuery($query, $arrayBind);

				unset($arrayBind);
				$query = " update " . Config::_getTable('themes') . " set statusTheme = :statusTheme limit 1 ";
				$arrayBind[] = array("key" => ":statusTheme", "value" => 1);
				Core::_runQuery($query, $arrayBind);

			}

			self::_setActiveTheme(Core::_getRow($query, $arrayBind));

		}

        self::$activeTheme = Plugins::_runAction('themes_get_active_theme', self::$activeTheme);

		return self::$activeTheme;

	}

	/**
	 * Sets active theme details
	 *
	 * @param object(theme details)
	 * @return boolean
	 */
	public function _setActiveTheme($detailsTheme) {
	    
		if(!$detailsTheme){

            return false;		    

		}

		self::$activeTheme = $detailsTheme;

        Plugins::_runAction('themes_set_active_theme', $detailsTheme);
        		
	}

	/**
	 * Updates the path of the template directory
	 *
	 * @param void
	 * @return boolean
	 */
	public function _updateActiveThemePath() {

		Config::_set('temp', '/templates/frontend/' . $this -> _getActiveTheme() -> pathTheme);

        Plugins::_runAction('themes_update_active_theme_path');

	}

    /**
     * Sets current page details
     *
     * @param object(page details)
     * @return boolean
     */
    public function _updateSiteSeo() {

        $this->_set('website.logo'              ,Config::_get('website.logo'));
        $this->_set('website.fav.icon'          ,Config::_get('website.fav.icon'));

    }

    /**
     * Sets current page details
     *
     * @param object(page details)
     * @return boolean
     */
    public function _updatePageSeo() {

        $detailsPage = $this -> _getCurrentPageDetails();
        
        // Setting page title
        $titlePage = $detailsPage -> namePage;

        if( $titlePage == '' ){
            
            $titlePage = Config::_get('website.title');

        }

        $titlePage = Plugins::_runAction('themes_update_page_seo_title',$titlePage);
        $this->_set('website.title' , $titlePage );


        // Setting page description
        $descriptionPage = $detailsPage -> descriptionPage;

        if( $descriptionPage == '' ){
            
            $descriptionPage = Config::_get('website.meta.description');

        }

        $descriptionPage = Plugins::_runAction('themes_update_page_seo_description',$descriptionPage);
        $this->_set('website.meta.description' , $descriptionPage );


        // Setting page keywords
        $keywordsPage = $detailsPage -> keywordsPage;

        if( $keywordsPage == '' ){
            
            $keywordsPage = Config::_get('website.meta.keywords');

        }

        $keywordsPage = Plugins::_runAction('themes_update_page_seo_keywords',$keywordsPage);
        $this->_set('website.meta.keywords' , $keywordsPage );


        // Setting page robots
        $robotsPage = $detailsPage -> robotsPage;

        if( $robotsPage == '' || $robotsPage == 'global' ){
            
            $robotsPage = Config::_get('website.robots');

        }

        $robotsPage = Plugins::_runAction('themes_update_page_seo_robots',$robotsPage);
        $this->_set('website.robots' , $robotsPage );

    }
 
    /**
     * Sets current admin page details
     *
     * @param string(page link)
     * @return null
     */
    public function _setCurrentAdminPage($linkPage) {
        
        $linkPage = Plugins::_runAction('themes_set_current_admin_page',$linkPage);

        $this -> currentAdminPageData = $linkPage;
        
        $this -> _updateSiteSeo();

    }

    /**
     * Returns current Admin page
     *
     * @param void
     * @return null
     */
    public function _getCurrentAdminPage() {

        $page = $this -> currentAdminPageData;

        $page = Plugins::_runAction('themes_get_current_admin_page',$page);

        return $page;
        
    }

	/**
	 * Sets current page details
	 *
	 * @param object(page details)
	 * @return boolean
	 */
	public function _setCurrentPage($linkPage) {
	    
        $linkPage = Plugins::_runAction('themes_set_current_page',$linkPage);

		$this -> currentPageData = $linkPage;

        $detailsPage = $this -> _getCurrentPageDetails();

        $this->_updateSiteSeo();
        $this->_updatePageSeo();

	}

	/**
	 * Returns current page
	 *
	 * @param object(page details)
	 * @return boolean
	 */
	public function _getCurrentPage() {

        $page = $this -> currentPageData;

        $page = Plugins::_runAction('themes_get_current_page',$page);

        return $page;
	    
	}

	/**
	 * Returns current page details
	 *
	 * @param object(page details)
	 * @return boolean
	 */
	public function _getCurrentPageDetails() {

		global $Cms;

		return $Cms->_getPageDetailsByLink($this -> _getCurrentPage());

	}

	/**
	 * Generates template file for the current page 
	 *
	 * @param $url(sting)
	 * @return null
	 */
	public function _generateCurrentPage() {
		
		global $Cms;
        
		if( isset($_GET['pg']) && $_GET['pg'] != '' ){

			$Page = $_GET['pg'];
	
			if($Cms->_checkLinkPage($Page)){

				$this->_setCurrentPage($Page);

			}

		}

		// If current page is not defined yet and there is a default page generated in the backend
		if( !$this->_getCurrentPage() && $Cms->_getDefaultPage() ){

			$Page = $Cms->_getDefaultPage();
			$this->_setCurrentPage($Page);

		}
		
		// Updating the theme of the current page as the theme for this page
		if( $this->_getCurrentPage() ){

			$detailsPage = $this->_getCurrentPageDetails();

			// 1. If current page theme value not equals to null
			// 2. theme value not equals to gloabal
			if( $detailsPage->themePage != '' && $detailsPage->themePage != 'global'){
	
				$detailsTheme = $this->_getThemeDetailsByPath($detailsPage->themePage);
	
				// If the given theme is valid
				if( $detailsTheme ){

					$pathTheme = $detailsPage->themePage;
					$this->_setActiveTheme($detailsTheme);
					$this->_updateActiveThemePath();

				}

			}

		}

        Plugins::_runAction('themes_generate_current_page');

	}

	/**
	 * Includes given file
	 *
	 * @param string($pathFile)
	 * @return null
	 */
	public function _inc($pathFile) {

		global $Editor, $Base, $User, $Admin, $Permissions, $Menus;

        $fullPathFile = $pathFile;

        if( !file_exists($pathFile) ){

            $fullPathFile = (defined('QC_ADMIN')?Config::_getDir('admin.temp'):Config::_getDir('temp')) .'/'. $pathFile;

        }

        $fullPathFile = Plugins::_runAction('themes_inc',$fullPathFile,$pathFile);

		if( file_exists($fullPathFile) ){

		    include_once $fullPathFile;

			return true;

		}

		return false;

	}

	/**
	 * Includes the template of the current page
	 *
	 * @param void
	 * @return null
	 */
	public function _incTemplate() {
		
		$pathTheme = $this->_getActiveTheme() -> pathTheme;

		if( $this->_getCurrentPage() ){

			$detailsPage = $this->_getCurrentPageDetails();
            
            $templateFile = 'templates/'.$detailsPage->templatePage.'.phtml';
                
            if( $detailsPage -> typePage == 'plugins' ){
    
                $templateFile = 'plugins/'.$detailsPage->pluginPage.'/templates/frontend/'.$templateFile;
    
            }

			
		}else{

			$templateFile = 'templates/default.phtml';

		}

        $templateFile = Plugins::_runAction('themes_inc_template',$templateFile);

		$this->_inc($templateFile);

	}

    /**
     * Includes the admin template for the current page
     *
     * @param void
     * @return null
     */
    public function _incAdminTemplate() {
        
        global $Admin;

        $templateFile = '';

        if( $this->_getCurrentAdminPage() ){

            $templateFile = 'templates/'.$this->_getCurrentAdminPage().'.phtml';

        }
        
        $pathFile = Config::_getDir('admin.temp').'/'. $templateFile;

        if( !file_exists($pathFile) || is_dir($pathFile) ){

            $templateFile = 'templates/default.phtml';

        }

        $templateFile = Plugins::_runAction('themes_inc_admin_template',$templateFile);

        $this->_inc($templateFile);

    }

	/**
	 * Return the list of templates for the given theme
	 *
	 * @param $theme(Theme Name)
	 * @return boolean
	 */
	public function _getTemplates($theme = false, $identifierPlugin = false) {

        $dirTemplates = '';
        
        if( $theme ){

            $dirTemplates = Config::_getDir() . '/templates/frontend/'.$theme.'/templates/';
            
        }else if( $identifierPlugin ){
            
            $dirTemplates = Config::_getDir() . '/plugins/'. $identifierPlugin.'/templates/frontend/templates/';
        }
                
        if( !file_exists($dirTemplates) || !is_dir($dirTemplates) ){

            return false;
            
        } 
        
        global $Base;

        $listTemplates = $Base -> _readDir($dirTemplates);
        $setTemplates = array();

        // retrieving the list of template files for the given theme
        foreach ($listTemplates as $template) {

            $fileInfo = pathinfo($template);
            $fileInfo = array_map('strtolower', $fileInfo);
            $relPath = substr($fileInfo['dirname'], strlen($dirTemplates . '/'));

            if( $fileInfo['extension'] == 'phtml' ){

                $pathFile = $fileInfo['basename'];
    
                //$pathFile = $relPath . '/' . $pathFile;
                if($relPath == ''){
                    
                    $setTemplates[$fileInfo['filename']] = $fileInfo['filename'];

                }
            }
        }
        
        $setTemplates = Plugins::_runAction('themes_get_templates',$setTemplates, $theme);
        
        return $setTemplates;

	}

	/**
	 * Converts the urls according to the settings 
	 *
	 * @param string($url)
	 * @return string($converted url)
	 */
	public function _url($idPage,$args = '') {
    
        if( (int)$idPage > 0){
            
            global $Cms;
            
            $url = $Cms->_getPageDetails($idPage)->fullLinkPage;
            
            if( $url == '' ){
                
                $Cms->_updateFullLinkPage($idPage);
                $url = $Cms->_getPageLink($idPage);

            }
            
        }else{
    
            $url = $idPage;
            
        }
    
        $oldUrl = $url;

		global $Base;
		
		$seoFriendly = $normal = array();
		
		if(is_array($args) && count($args) > 0){
			
			foreach($args as $key => $arg){
				
				$key = $Base->_prepareLink($key);
				$arg = $Base->_prepareLink($arg);

				if(!$arg){

					$seoFriendly[] = $key;
					$normal[] 	   = $key;

				}else{

					$seoFriendly[] = $key.'_'.$arg;
					$normal[] 	   = $key.'='.$arg;

				}

			}
			
		} 
		
		// If mod rewrite rule is not enabled, then changing the url
		if(!Config::_get('website.url.rewrite')){

			$url = 'index.php?pg='.$url.implode('&',$normal);

		}else{

            $url = $url;
			//$url = $url.'/'.implode('/',$seoFriendly);

		} 
		
		$url = Config::_getUrl().'/'.$url;

		// If the website is running in customize mode, then appending cmode to the url
		// if cmode is active, then only you can edit the website in cmode
		global $Editor;
		if( $Editor->_isCustomizeMode() ){

			$url .= '?cmode=true';			

		};

        $url = Plugins::_runAction('themes_url',$url, $oldUrl);
		
		return $url;

	}

	/**
	 * if mod reqrite rule is on, then it will converts the variables
	 * variables will be converted from pg=home/id/2/action/2 to pg=home&id=2&action=2  
	 *
	 * @param void
	 * @return mixed
	 */
	public function _rewriteUrl() {

        return;
        
        $getPrev = $_GET;
		
		if(Config::_get('website.url.rewrite')){
        
            extract($_GET);
            
            if(isset($pg) && $pg != ''){
                
                $_GET['pg_prev'] = $pg;
                
                $args = explode("/",$pg);
                
                $_GET['pg'] = array_shift($args);
                
                if( count($args) > 0){

                    foreach($args as $key => $value){
                        
                        $tmp = explode("_",$value);
                    
                        if(isset($tmp[1])){

                            $_GET[$tmp[0]] = $tmp[1];
                            
                        }else{

                            $_GET[$tmp[0]] = null;
                            
                        }
        
                    }

                }

            }

		}

        Plugins::_runAction('themes_rewrite_url',$getPrev);

	}

	/**
	 * Returns the meta value for the given key
	 *
	 * @param string($key)
	 * @return string($key)
	 */
	public function _get($key) {

	    $return = false;

		if(isset(self::$metaData[$key])){

            $return = self::$metaData[$key];

		}

        $return = Plugins::_runAction('themes_get',$return, $key);

		return $return;

	}

	/**
	 * Sets the meta value for the given key
	 *
	 * @param string($key),string($value)
	 * @return null
	 */
	public function _set($key,$value) {

        $return = Plugins::_runAction('themes_set', array($key, $value) );
        $key = $return[0];
        $value = $return[1];

		if($key != ''){

            self::$metaData[$key] = $value;

		}

	}

	/**
	 * Used to perform actions in the front end header
	 *
	 * @param void()
	 * @return null
	 */
	public function _header() {
		
		$headerLinks = $this->_generateActiveThemeFiles();

		if( is_array($headerLinks['css']) && count($headerLinks['css']) > 0 ){
			echo implode("\n",$headerLinks['css']);
			echo "\n";
		}

		if( is_array($headerLinks['js']) && count($headerLinks['js']) > 0 ){
			echo implode("\n",$headerLinks['js']);
			echo "\n";
		}
		
		Plugins::_runAction('header');
	}

	/**
	 * Used to perform actions in the front end footer
	 *
	 * @param void()
	 * @return null
	 */
	public function _footer() {

		Plugins::_runAction('footer');

	}

	/**
	 * Used to perform actions in the head
	 *
	 * @param void()
	 * @return null
	 */
	public function _headerAdmin() {

		Plugins::_runAction('admin_header');

	}

	/**
	 * Used to perform actions in the head
	 *
	 * @param void()
	 * @return null
	 */
	public function _footerAdmin() {

		Plugins::_runAction('admin_footer');

	}

	/**
	 * Generates css link from the given url 
	 *
	 * @param string($pathCss)
	 * @return string($generated css)
	 */
	public function _generateCssLink($pathCss) {

	    $return = '<link rel="stylesheet" type="text/css" media="all" href="'.$pathCss.'" />';

		$return = Plugins::_runAction('themes_generate_css_link',$return,$pathCss);

		return $return;
        
	}

	/**
	 *  Generates js link from the given url
	 *
	 * @param string($pathJs)
	 * @return string($generated Js)
	 */
	public function _generateJsLink($pathJs) {

        $return = '<script type="text/javascript" src="'.$pathJs.'"></script>';
	    
        $return = Plugins::_runAction('themes_generate_js_link',$return,$pathJs);
    
        return $return;
        
	}

	/**
	 * Returns theme details with given id
	 *
	 * @param integer($idTheme)
	 * @return object($detailsTheme)
	 */
	public function _generateActiveThemeFiles() {
		
		$generatedFiles = $this->_generateCustomizeEditorFiles();

        $generatedFiles = Plugins::_runAction('themes_generate_active_theme_files',$generatedFiles);
		
		return $generatedFiles;
        
	}

	/**
	 * returns the customize editor files
	 *
	 * @param integer($idTheme)
	 * @return object($detailsTheme)
	 */
	public function _generateCustomizeEditorFiles() {
		
        $generatedFiles = false;
        
		global $Editor;
		if( $Editor->_isCustomizeMode() ){

            $generatedFiles['css'][] = $this->_generateCssLink(Config::_getUrl('admin.temp')."/css/customize-editor.css");
            $generatedFiles['js'][] = "<script>window.jQuery || document.write('<script src=\"".Config::_getUrl('admin.temp')."/js/jquery-1.10.1.min.js\">\\x3C/script>')</script>";
            $generatedFiles['js'][] = $this->_generateJsLink(Config::_getUrl('admin.temp')."/js/customize-editor.js");
    
		}

        $generatedFiles = Plugins::_runAction('themes_generate_customize_editor_files',$generatedFiles);
		
		return $generatedFiles;
        
	}

	/**
	 * Update Themes in db
	 *
	 * @param void
	 * @return boolean
	 */
	public function _updateThemes() {

		// Templates directory
		$templateDirectory = Config::_getDir() . '/templates/frontend/';

		if ($handle = opendir($templateDirectory)) {

			/* Retriveing list of themes. */
			while (false !== ($pathTheme = readdir($handle))) {

				// Checking for valid directories
				if (is_dir($templateDirectory . '/' . $pathTheme) && $pathTheme != '.' && $pathTheme != '..') {

					// Checking weather the directory exists in the database or not
					unset($arrayBind);
					$query = " select * from " . Config::_getTable('themes') . " where pathTheme = :pathTheme ";
					$arrayBind[] = array("key" => ":pathTheme", "value" => $pathTheme);
					$countTheme = Core::_getRowCount($query, $arrayBind);

					if ($countTheme == 0) {

						unset($arrayBind);
						$query = " insert into " . Config::_getTable('themes') . " (nameTheme,pathTheme,statusTheme,dateAdditionTheme) 
                        values (:nameTheme,:pathTheme,:statusTheme,NOW()) ";
						$arrayBind[] = array("key" => ":nameTheme", "value" => $pathTheme);
						$arrayBind[] = array("key" => ":pathTheme", "value" => $pathTheme);
						$arrayBind[] = array("key" => ":statusTheme", "value" => 0);
						Core::_runQuery($query, $arrayBind);

					}

				}

			}

			closedir($handle);

		}

		// Deleting the invalid entries(Entries without a vlid theme directory) from the database
		$query = " select * from " . Config::_getTable('themes');
		$themes = Core::_getAllRows($query, '');
		foreach ($themes as $tmpTheme) {

			if (!is_dir($templateDirectory . '/' . $tmpTheme -> pathTheme)) {

				unset($arrayBind);
				$query = " delete from " . Config::_getTable('themes') . " where idTheme = :idTheme";
				$arrayBind[] = array("key" => ":idTheme", "value" => $tmpTheme -> idTheme);
				Core::_runQuery($query, $arrayBind);

			}
			
		}

		$activeTheme = $this -> _getActiveTheme();

        Plugins::_runAction('themes_update_themes');
		
		return true;

	}

	/**
	 * Returns developing theme details
	 *
	 * @param void
	 * @return boject
	 */
	public function _getDevelopingTheme() {

        $return = $this -> _getActiveTheme();

        $return = Plugins::_runAction('themes_get_developing_theme',$return);
	    
		return $return;
        
	}

	/**
	 * Creates new theme with the given name and status
	 *
	 * @param $nameTheme(string),$statusTheme(string)
	 * @return object
	 */
	public function _createTheme($nameTheme,$statusTheme){

        $return = false;
        		
		$templateDir = Config::_getDir() . '/templates/frontend/';
		$themePath = $templateDir.$nameTheme;

		if ( !file_exists($themePath) || !is_dir($themePath)){

            $sampleThemePath = Config::_getDir('themes.store') .'/themes/frontend/sample';
            $pathThemeNew = $templateDir . $nameTheme;
    
            global $Base;
    
            $Base -> _copyDir($sampleThemePath, $pathThemeNew);
            $this -> _updateThemes();
		    
            $return = true;
                
		}

        $return = Plugins::_runAction('themes_create_theme',$nameTheme,$statusTheme);
        
        return $return;
        
	}

	/**
	 * Copies the theme with given id to a new folder
	 *
	 * @param integer($idTheme)
	 * @return boolean
	 */
	public function _copyTheme($idTheme) {

        $return = false;

		$detailsTheme = $this -> _getThemeDetails($idTheme);

		if ($detailsTheme){

            $templateDir = Config::_getDir() . '/templates/frontend/';
            $pathThemeOld = $templateDir . $detailsTheme -> nameTheme;
            $pathThemeNew = $templateDir . $detailsTheme -> nameTheme . ' - copy ';
    
            global $Base;
            if (file_exists($pathThemeNew) && is_dir($pathThemeNew)) {
                $pathThemeNew = $templateDir . $detailsTheme -> nameTheme . ' - ' . $Base -> _generateRandomString(5);
            }
    
            $Base -> _copyDir($pathThemeOld, $pathThemeNew);
            $this -> _updateThemes();

            $return = true;
		    
		}
        
        $return = Plugins::_runAction('themes_copy_theme',$return,$idTheme);
        
        return $return;
        
	}

	/**
	 * Removes the theme with the given id
	 *
	 * @param integer($idTheme)
	 * @return boolean
	 */
	public function _deleteTheme($idTheme) {

		$idTheme = Plugins::_runAction('theme_delete_theme', $idTheme);

		$detailsTheme = $this -> _getThemeDetails($idTheme);

		if (!$detailsTheme) {

			die("Invalid Theme.");

		}

		if ($this -> _getActiveTheme() -> idTheme == $idTheme) {

			die("You can't delete active theme.");

		}

		$templateDirectory = Config::_getDir() . '/templates/frontend/';
		$pathTheme = $templateDirectory . $detailsTheme -> pathTheme;

		if (file_exists($pathTheme) && is_dir($pathTheme)) {

			global $Base;
			$Base -> _removeDir($pathTheme);

		}

		$query = " delete from " . Config::_getTable('cms_themes_files') . " where idTheme = :idTheme";
		$arrayBind[] = array("key" => ":idTheme", "value" => $idTheme);
		Core::_runQuery($query, $arrayBind);

		$this -> _updateThemes();
                
	}

	/**
	 * Returns theme details of the theme file with given id
	 *
	 * @param integer($idFile)
	 * @return object($detailsThemeFile)
	 */
	public function _getThemeFileDetails($idFile) {

		$query = " select * from " . Config::_getTable('cms_themes_files') . " where idFile = :idFile";
		$arrayBind[] = array("key" => ":idFile", "value" => $idFile);
		$detailsThemeFile = Core::_getRow($query, $arrayBind);

        $detailsThemeFile = Plugins::_runAction('theme_get_theme_file_details', $detailsThemeFile);

		return $detailsThemeFile;
        
	}

	/**
	 * Returns File contents of the given theme file
	 *
	 * @param string($pathFile),integer($idTheme)
	 * @return boolean/object($detailsThemeFile)
	 */
	public function _getThemeFileContent($pathFile, $idTheme = '') {

        $content = false;

		if ($idTheme == '') {

			$detailsTheme = $this -> _getDevelopingTheme();

		} else {

			$detailsTheme = $this -> _getThemeDetails($idTheme);

		}

		$fullPathFile = dirname(Config::_getDir('temp')) . '/' . $detailsTheme -> pathTheme . '/' . $pathFile;

		if (file_exists($fullPathFile) && is_file($fullPathFile)) {

			$content = file_get_contents($fullPathFile);
			
		}

        $content = Plugins::_runAction('theme_get_theme_file_content', $content, $fullPathFile, $pathFile, $idTheme);

		return $content;
        
	}

	/**
	 * Deletes theme file
	 *
	 * @param integer($idFile)
	 * @return object($detailsThemeFile)
	 */
	public function _deleteThemeFile($idFile) {

		$detailsFiles = $this -> _getThemeFileDetails($idFile);
		$detailsTheme = $this -> _getThemeDetails($detailsFiles -> idTheme);

		$pathFile = dirname(Config::_getDir('temp')) . '/' . $detailsTheme -> pathTheme . '/' . $detailsFiles -> pathFile;

        $pathFile = Plugins::_runAction('theme_delete_theme_file', $pathFile, $idFile);
        
        if( !$pathFile ){

            return false;

        }

		$query = "delete from " . Config::_getTable('cms_themes_files') . " where idFile = :primaryField";
		$arrayBind[] = array("key" => ":primaryField", "value" => $idFile);
		Core::_runQuery($query, $arrayBind);

		if (file_exists($pathFile)){

            unlink($pathFile);

		}

	}

	/**
	 * Returns array of allowed theme extensions
	 *
	 * @param void
	 * @return array
	 */
	public function _getAllowedExtensionsTheme() {

        $extensionsAllowed = array('css', 'js','phtml', 'jpg', 'jpeg', 'png', 'gif');
        
        $extensionsAllowed = Plugins::_runAction('theme_allowed_extensions', $extensionsAllowed);
        
		return $extensionsAllowed;

	}
	
	/**
	 * Returns the paths for the 
	 *
	 * @param void
	 * @return array
	 */
	public function _getPathExtensionsTheme() {

		$extPath =  array(
					'css' 	=> 'css',
					'js' 	=> 'js',
					'phtml' => 'pages',
					'jpeg' 	=> 'images',
					'jpg' 	=> 'images',
					'png' 	=> 'images',
					'gif' 	=> 'images',
					);

        $extPath = Plugins::_runAction('theme_path_extensions', $extPath);

        return $extPath;
        
	}

	/**
	 * Import theme files from zip to the given theme
	 *
	 * @param $idTheme(int),$pathFiles(string)
	 * @return mixed
	 */
	public function _importFiles($idTheme,$pathFiles) {

		global $Base;
		$messages = array();

		$detailsTheme = $this->_getThemeDetails($idTheme);
		$targetDir = dirname(Config::_getDir('temp')).'/'.$detailsTheme->pathTheme.'/';

		$allowedExtensions = $this->_getAllowedExtensionsTheme();
		$pathsExtensions = $this->_getPathExtensionsTheme();
		
		$zip = new ZipArchive;
		if ($zip -> open($pathFiles) === TRUE) {

			for ($i = 0; $i < $zip -> numFiles; $i++) {

				$filename = $zip -> getNameIndex($i);
				$fileInfo = pathinfo($filename);

				if ( isset($fileInfo['extension']) && in_array($fileInfo['extension'], $allowedExtensions)) {

					$targetFilePath = $targetDir.$pathsExtensions[$fileInfo['extension']].'/'.$fileInfo['basename'];

					if( file_exists($targetFilePath) && is_file($targetFilePath) ){

						$targetFilePath = $targetDir.$pathsExtensions[$fileInfo['extension']].'/'.$fileInfo['filename'].' - '. $Base -> _generateRandomString(5).'.'.$fileInfo['extension'];
						$messages[] = $fileInfo['basename'].' renamed.';

					}
					
			        copy("zip://".$pathFiles."#".$filename, $targetFilePath);
					$messages[] = $fileInfo['basename'].' imported.';

				}

			}

			$zip -> close();

		} else {

			$messages[] = "Failed to open the zip file";

		}

        $messages = Plugins::_runAction('theme_import_files', $messages,$idTheme,$pathFiles);

		$Base -> _removeDir($pathFiles);

		$this -> _updateThemes();

		return $messages;

	}

	/**
	 * Updates theme files
	 *
	 * @param void
	 * @return null
	 */
	public function _updateFiles() {

		global $Base;

		$detailsTheme = $this -> _getDevelopingTheme();
		$pathTheme = dirname(Config::_getDir('temp')) . '/' . $detailsTheme -> pathTheme;

		// list of the files saved in db
		$query = "select * from " . Config::_getTable('cms_themes_files') . " where idTheme = :idTheme ";
		$arrayBind[] = array("key" => ":idTheme", "value" => $detailsTheme -> idTheme);
		$listFilesDb = Core::_getAllRows($query, $arrayBind);

		$arrayFilesDb = array();
		foreach ($listFilesDb as $tmpFile) {

			$arrayFilesDb[] = $tmpFile -> pathFile;

		}

		// list of the files read from the server
		$listFiles = $Base -> _readDir($pathTheme);

		// updating missing files to database
		foreach ($listFiles as $currentFile) {

			$fileInfo = pathinfo($currentFile);
			$fileInfo = array_map('strtolower', $fileInfo);
			$relPath = substr($fileInfo['dirname'], strlen($pathTheme . '/'));

			$pathFile = $fileInfo['basename'];

			if($relPath != '')
			$pathFile = $relPath . '/' . $pathFile;

			// Inserting new files to database
			if (!in_array($pathFile, $arrayFilesDb) && in_array($fileInfo['extension'], $this->_getAllowedExtensionsTheme())) {

				$query = "insert into " . Config::_getTable('cms_themes_files') . " (`idTheme`,`nameFile`,`pathFile`,`typeFile`,`dateAdditionFile`) 
				values (:idTheme,:nameFile,:pathFile,:typeFile,NOW())";
				
				unset($arrayBind);
				$arrayBind[] = array("key" => ":idTheme", "value" => $detailsTheme -> idTheme);
				$arrayBind[] = array("key" => ":nameFile", "value" => $fileInfo['basename']);
				$arrayBind[] = array("key" => ":pathFile", "value" => $pathFile);
				$arrayBind[] = array("key" => ":typeFile", "value" => $fileInfo['extension']);
				Core::_runQuery($query, $arrayBind);

			}

		}

        Plugins::_runAction('theme_update_files');

	}

	/**
	 * Modify the path field for image fiels
	 *
	 * @param array
	 * @return null
	 */
	public function _listThemeImageFiles($listData) {

		$listData['displayFields']['pathFile']['type'] = 'text';
		$listData['displayFields']['pathFile']['display'] = '<img src="' . Config::_getUrl('temp') . '/:data" style="max-width:100px"/>';

        $listData = Plugins::_runAction('theme_list_image_files',$listData);

		return $listData;
		
	}

	/**
	 * Modify the list fields for the phtml fiels
	 *
	 * @param array
	 * @return null
	 */
	public function _listThemePhtmlFiles($listData) {
	        
        $listData = Plugins::_runAction('theme_list_phtml_files',$listData);

		return $listData;
        
	}

	/**
	 * Modify the path field for image fiels
	 *
	 * @param array($dataAction),int($primaryField),$result,$listElements
	 * @return null
	 */
	public function _listIncludeHeaderActions($dataAction, $primaryField, $result, $listElements) {

		$listData['displayFields']['pathFile']['type'] = 'text';
		$listData['displayFields']['pathFile']['display'] = '<img src="' . Config::_getUrl('temp') . '/:data" style="max-width:100px"/>';

        $listData = Plugins::_runAction('theme_include_header_actions',$listData,$dataAction, $primaryField, $result, $listElements);

		return $listData;
        
	}

}

