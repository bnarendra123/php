<?php
defined('QC_VALID') or die('Restricted Access!');

/**
 * Core class, used for database connection, executing database queries and returning the results.
 * All database queries will be processed from here. Please don't change unless critical
 *
 * @version 1.0
 * @http://www.quikc.org/
 */
class Core {

	/** Created database instances will be saved here
	 *
	 *
	 * @var object
	 */
	private $dbh;

	/** Contains the core class instance
	 *
	 *
	 * @var object
	 */
	private static $activeDb = NULL;

	/** Contains the core class instance
	 *
	 *
	 * @var object
	 */
	private static $instances = array();

	/** Contains the log of the database actions
	 *
	 *
	 * @var object
	 */
	private static $logCore = array();

	/** Constructer class of core. It will connect the database and saves the value in $dbh variable
	 *
	 *
	 * @param void
	 * @var null
	 */
	private function __construct($dbName) {

		$startTime = microtime(true);
		$startMemo = memory_get_usage();

		// Gathering the database variables
		$dsn = Config::_get('db.type') . ':host=' . Config::_get('db.host') . ';dbname=' . $dbName .
		//	   ';port='      . Config::_get('db.port') .
		';connect_timeout=15';

		// Gathering DB user from config
		$user = Config::_get('db.user');
		// Gathering DB password from config
		$password = Config::_get('db.pass');

		// Opening new database connection through pdo
		try {

			$this -> dbh = new PDO($dsn, $user, $password);
			$this -> dbh -> setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

			self::_addLogMessage($dbName, $startTime, $startMemo, 1, '', '', 'connect');

		} catch (PDOException $e) {

			die('Could not connect to the database.');
		}
        
	}

	/** Returns active database
	 *
	 *
	 * @param void
	 * @var string(database name)
	 */
	public static function _getDatabase() {

		if (self::$activeDb === NULL){

            self::_setDatabase();
		    
		}

		return self::$activeDb;

	}

	/** Sets the given database as active database
	 *
	 *
	 * @param string(database name)
	 * @var null
	 */
	public static function _setDatabase($dbName = '') {

		if ($dbName == ''){

            $dbName = Config::_get('db.name');
		    
		}

		self::$activeDb = $dbName;

	}

	/** Checks the database connection status and connets if there is not connection
	 *
	 *
	 * @param database name(string)
	 * @var Core class instance(object)
	 */
	private static function getInstance($dbName = '') {

		if ($dbName == ''){

            $dbName = self::_getDatabase();
		    
		}

		// Checking for the existing instances
		if (!isset(self::$instances[$dbName])) {

			// Getting the name of the class. Here it is Core
			$object = __CLASS__;
			// Starting new class object
			self::$instances[$dbName] = new $object($dbName);

		}

		return self::$instances[$dbName];

	}

	/** Adds the message to the $logCore
	 *
	 *
	 * @param string($message)
	 * @var null
	 */
	private static function _addLogMessage($dbName, $startTime, $startMemo, $status, $query = '', $arrayBind = array(), $type = '') {

		if ($dbName == ''){

            $dbName = self::_getDatabase();
		    
		}

		$executionTime = microtime(true) - $startTime;
		$executionMemo = memory_get_usage() - $startMemo;

		$infoDebugger = array();		

		$debugger = debug_backtrace();

		foreach($debugger as $b){

			if( isset($b['class']) && $b['class'] == 'Core' ){

                continue;			    

			}

            $string = '';

			if( isset($b['file']) ){
			    
				//str_replace(Config::_getDir(),'',$filename)
				$string = str_replace(Config::_getDir(),'',$b['file']);

			}
						
			if( isset($b['line']) ){
			    
				$string .= ' line: '.$b['line'].' ';
                
			}
			
			if( isset($b['class']) ){
			    
				$string .= $b['class'].$b['type'];
                
			}

			if( isset($b['function']) ){
			    
				$string .= $b['function'];
                
			} 

			$infoDebugger[] = $string;
			
			break;
            
		}

		self::$logCore['logs'][] = array(

										'database'	=> $dbName, 
										'time' 		=> $executionTime, 
										'memory' 	=> $executionMemo, 
										'status'	=> $status, 
										'type'		=> $type, 
										'query'		=> $query, 
										'arrayBind' => $arrayBind,
										'debuginfo' => implode('<br/>',$infoDebugger),

									);

		self::_updateLogCounter($type, $status, $executionTime, $executionMemo);

	}

	/** Updates executions timers
	 *
	 *
	 * @param string($message)
	 * @var null
	 */
	private static function _updateLogCounter($type, $status, $executionTime, $executionMemo) {

		self::_updateLogEntry('counter', $type . '_' . $status, 1);
		self::_updateLogEntry('counter', 'totalExexutions', 1);

		self::_updateLogEntry('timer', $type . '_' . $status, $executionTime);
		self::_updateLogEntry('memory', $type . '_' . $status, $executionMemo);

		if ($type != 'connect') {

			self::_updateLogEntry('timer', 'totalExexutions', $executionTime);
			self::_updateLogEntry('memory', 'totalExexutions', $executionMemo);

		}

	}

	/** Updates Log entry basing on the existed values
	 *
	 *
	 * @param string($message)
	 * @var null
	 */
	private static function _updateLogEntry($mainIndex, $subIndex, $currentValues) {

		if (!isset(self::$logCore[$mainIndex][$subIndex])){

            self::$logCore[$mainIndex][$subIndex] = $currentValues;
		    
		}else{

            self::$logCore[$mainIndex][$subIndex] += $currentValues;
		    
		}

	}

	/** Returns the $logCore array
	 *
	 *
	 * @param void
	 * @var array of arrays
	 */
	public static function _getLogMessage() {

		return self::$logCore;

	}

	/** returns the all the tables
	 *
	 *
	 * @param void()
	 * @var List of Tables(boject)
	 */
	public function _getAllTables() {

		// Query to retrieve tables
		$query = "show tables from " . Config::_get('db.name');
		$listTablesObj = self::_getAllRows($query, '');

		foreach ($listTablesObj as $tmp) {

			$table = 'Tables_in_' . Config::_get('db.name');
			$listTablesArray[] = $tmp -> $table;

		}

		return $listTablesArray;

	}

	/** returns the list of tables except the admin tables
	 *
	 *
	 * @param void()
	 * @var List of Tables(boject)
	 */
	public static function _getTables($includeAdmin = false) {

		// Query to retrieve tables
		$query = "show tables from `" . Config::_get('db.name') . "`";
		$listTablesObj = self::_getAllRows($query, '');

		foreach ($listTablesObj as $tmp) {

			$table = 'Tables_in_' . Config::_get('db.name');
			    
			// Checking for the admin tables
			global $Admin;

			if ( $includeAdmin || !$Admin -> _isAdminTables($tmp -> $table)) {

				$listTablesArray[] = $tmp -> $table;

			}

		}

		return $listTablesArray;

	}

	/** Checks weather the table exists in the database or not
	 *
	 *
	 * @param string(Table Name)
	 * @var boolean(true/false)
	 */
	public static function _checkTable($nameTable) {

		// Query to retrieve the table
		$query = "show tables like '$nameTable'";

		$countTables = self::_getRowCount($query, '');

		// Checking weather the table exists or not
		if ($countTables == 1) {

			return true;

		} else {

			return false;

		}

	}

	/** returns the list of table columns
	 *
	 *
	 * @param void($nameTable)
	 * @var List of Table columns(object)
	 */
	public static function _getTableColumns($nameTable,$columnTable=false) {

		// Query to retrieve tables
		$query = "show columns from `" . $nameTable . "`";
		
		if($columnTable){

			$query .= " like '$columnTable'";

			$listTablesColumns = self::_getRow($query, '');

		}else{

			$listTablesColumns = self::_getAllRows($query, '');

		}

		return $listTablesColumns;

	}

	/** Checks weather the table exists in the database or not
	 *
	 *
	 * @param string(Table Name)
	 * @var boolean(true/false)
	 */
	public static function _checkColumn($nameTable, $nameColumn) {

		// Query to retrieve the table
		$query = "show columns from `$nameTable` like '$nameColumn'";
		$countColumns = self::_getRow($query, '');

		// Checking weather the table exists or not
		if ( $countColumns != '') {

			return true;

		}
		
		return false;
        
	}

    /**
    * Returns the primary field of the table
    *
    * @param  $nameTable(string)
    * @return mixed
    */
    public static function _getTablePrimary($nameTable){

		$query = "show index from ".Config::_getTable($nameTable);
		$keys  = self::_getAllRows($query,'');

		foreach($keys as $key){

			if( strtolower($key->Key_name) == 'primary' ){

				return $key->Column_name;

			}

		}		
		
		return false;
        
    }
	/**
	 * returns the field prefix
	 *
	 * @param string(prefix.field)
	 * @return string(field)
	 */
	public static function _getFieldPrefix($field) {

		$fieldExploded = explode(".", $field);

		return $fieldExploded[0];

	}

	/**
	 * returns the converted field
	 *
	 * @param string(prefix.field)
	 * @return string(field)
	 */
	public static function _getField($field) {

		$fieldExploded = explode(".", $field);
		array_shift($fieldExploded);

		return implode(".", $fieldExploded);

	}

	/** Executes the database query
	 *
	 *
	 * @param sql query(string), bind variables array
	 * @var database object(object)
	 */
	private static function _execute($query, $arrayBind, $dbName) {

		// Getting database instance
		$core = self::getInstance($dbName);

		// Prepaing the query for execution
		$stmt = $core -> dbh -> prepare($query);

		if (!$stmt) {

			self::_logError();
			return false;

		}

		// Binding valid bind values to the database
		if (is_array($arrayBind) && count($arrayBind)) {

			foreach ($arrayBind as $bindValue) {

				if (isset($bindValue['type']) && $bindValue['type'] != '') {

					// Binding values with type. Types like int, string etc
					$stmt -> bindParam($bindValue['key'], $bindValue['value'], $bindValue['type']);

				} else {

					// Binding values without type
					$stmt -> bindParam($bindValue['key'], $bindValue['value']);

				}

			}

		}

		// Executing the query
		if ($stmt -> execute()) {

			// Return the statement if the query executed
			return $stmt;

		} else {

			self::_logError();
			// Return false if query not executed
			return false;

		}

	}

	/** Returns last insert row id
	 *
	 *
	 * @param database name(string)
	 * @var Last insert id(int)
	 */
	public static function _getLastInsertId($dbName = '') {

		$core = self::getInstance($dbName);
		// Prepaing the query for execution
		$idInsert = $core -> dbh -> lastInsertId();

		return $idInsert;

	}

	/** Fetches results from the valid database statements
	 *
	 *
	 * @param get type like single row, all rows etc(string), sql query (string), sql bind values (array), database name(string)
	 * @var database results(object)
	 */
	private static function _getFetch($getType, $query, $arrayBind, $dbName) {

		$startTime = microtime(true);
		$startMemo = memory_get_usage();

		// Executing the database query
		$stmt = self::_execute($query, $arrayBind, $dbName);

		if ($stmt) {

			// Fetcing the results for the valid statements
			$results = $stmt -> $getType(PDO::FETCH_OBJ);
			self::_addLogMessage($dbName, $startTime, $startMemo, 1, $query, $arrayBind, $getType);

		} else {

			self::_addLogMessage($dbName, $startTime, $startMemo, 0, $query, $arrayBind, $getType);
			// Returns false if not a valid statement
			
			return false;

		}

		return $results;

	}

	/** Fetches single row
	 *
	 *
	 * @param sql query (string), sql bind values (array), database name(string)
	 * @var database results(object)
	 */
	public static function _getRow($query, $arrayBind = array(), $dbName = '') {

		$results = self::_getFetch("fetch", $query, $arrayBind, $dbName);

		return $results;

	}

	/** Fetches all rows
	 *
	 *
	 * @param sql query (string), sql bind values (array), database name(string)
	 * @var database results(object)
	 */
	public static function _getAllRows($query, $arrayBind = array(), $dbName = '') {

		$results = self::_getFetch("fetchAll", $query, $arrayBind, $dbName);

		return $results;

	}

	/** Returns row count
	 *
	 *
	 * @param sql query (string), sql bind values (array), database name(string)
	 * @var database results(object)
	 */
	public static function _getRowCount($query, $arrayBind = array(), $dbName = '') {

		$count = 0;

		$query_exploded = explode(" from ", $query);

		if (count($query_exploded) > 1) {

			unset($query_exploded[0]);
			$query = 'select count(*) as row_count from ' . implode(" from ", $query_exploded);

			$result = self::_getRow($query, $arrayBind, $dbName);

			if (isset($result -> row_count)){

                $count = $result -> row_count;
			    
			}

		} else {

			$query_exploded = $query;
			$result = self::_getAllRows($query, $arrayBind);

			$count = count($result);
		}

		return $count;

	}

	/** Executes given query
	 *
	 *
	 * @param sql query (string), sql bind values (array), database name(string)
	 * @var database results(object)
	 */
	public static function _runQuery($query, $arrayBind, $dbName = '') {

		$startTime = microtime(true);
		$startMemo = memory_get_usage();

		// Executint the query
		$stmt = self::_execute($query, $arrayBind, $dbName);

		if ($stmt) {

			self::_addLogMessage($dbName, $startTime, $startMemo, 1, $query, $arrayBind, 'execute');
			// Returning true, if the executing completed successfully
			//$stmt->lastInsertId()
			return true;

		} else {

			self::_addLogMessage($dbName, $startTime, $startMemo, 0, $query, $arrayBind, 'execute');
			// Returning false, if the executing not completed successfully
			return false;

		}

	}

	/** Returns mysql query with replaced values
	 *
	 *
	 * @param sql query (string), sql bind values (array)
	 * @var database query(string);
	 */
	public static function _showQuery($query, $arrayBind = array()) {
	
		foreach($arrayBind as $bindVal){

	        $query = preg_replace('/'.$bindVal['key'].'/',"'".$bindVal['value']."'",$query);

		}
			
		return $query;

	}

	/** Returns recent error
	 *
	 *
	 * @param void
	 * @var string
	 */
	public static function _getError() {

		// Getting database instance
		$core = self::getInstance();

		// Executint the query
		return $core -> dbh -> errorInfo();

	}

	/** Returns recent error
	 *
	 *
	 * @param $error = false
	 * @var database results(object)
	 */
	public static function _logError($error = false) {

		if( !$error ){

			// Gets Latest Error
			$errors = self::_getError();
			$error = $errors[2];

		}

		error_log($error, 0);

	}

	/* Short Db function starts from here
	 <!-----------------------------------------------------------------------------------------------------------------------------------------
	 */

	/** Prepare query for short db
	 *
	 *
	 * @param $nameTable(string), $filters = array()
	 * @var array of strings
	 */
	public static function _prepareQuery($nameTable, $filters = array(), $sortBy = array()) {
		
		$query = "select * from ".Config::_getTable($nameTable);
		
		$whereArray = $arrayBind = $sortbyArray = array();
		
		if( is_array($filters) && count($filters) > 0){

			foreach($filters as $keyField => $valueField ){

				$whereArray[]= $keyField. " = :".$keyField;
				$arrayBind[]= array("key" => ":".$keyField, "value" =>  $valueField );

			}
			
			$query .= " where ".implode(' and ',$whereArray);

		}
		
		if( is_array($sortBy) && count($sortBy) > 0){

			foreach($sortBy as $keyField => $valueField ){

				if( !in_array($valueField, array('asc','desc')) ){

                    $valueField = 'asc';				    
                    
				} 

				$sortbyArray[]= $keyField. " ".$valueField;

			}
			
			$query .= " order by ".implode(' , ',$sortbyArray);
		}

		$generatedQuery = array("query" => $query, "arrayBind" => $arrayBind) ;
		
		return $generatedQuery;

	}

	/** Prepares query for fetch row and returns the output
	 *
	 *
	 * @param $nameTable, $filters = array(),
	 * @var database results(object)
	 */
	public static function _gR($nameTable, $filters = array(), $sortBy = array()) {

		$generatedQuery = self::_prepareQuery($nameTable, $filters, $sortBy);
		
		$results = self::_getRow($generatedQuery['query'], $generatedQuery['arrayBind']);
		
		return $results;

	}

	/** Prepares query for fetch all rows and returns the output
	 *
	 *
	 * @param $nameTable, $filters = array(),
	 * @var database results(object)
	 */
	public static function _gAR($nameTable, $filters = array(), $sortBy = array()) {

		$generatedQuery = self::_prepareQuery($nameTable, $filters, $sortBy);
		
		$results = self::_getAllRows($generatedQuery['query'], $generatedQuery['arrayBind']);
		
		return $results;

	}

	/** Prepares query for updating the row(s) and execute the query
	 *
	 *
	 * @param $nameTable, $filters = array(),
	 * @var boolean
	 */
	public static function _u($nameTable, $fileds = array(), $whereFields = array() ) {

		$query = "update ".Config::_getTable($nameTable). " set ";
		
		$updateArray = $whereArray = array();
		
		foreach($fileds as $keyField => $valueField){

			$updateArray[] = "$keyField = :$keyField ";
			$arrayBind[]= array("key" => ":$keyField", "value" =>  $valueField );

		}
		
		foreach($whereFields as $keyField => $valueField){

			$whereArray[] = "$keyField = :$keyField ";
			$arrayBind[]= array("key" => ":$keyField", "value" =>  $valueField );

		}
		
		$query .= " ".implode(' , ',$updateArray);
		$query .= " where ".implode(' and ',$whereArray);

		return self::_runQuery($query, $arrayBind);

	}
	
	/** Prepares query for inserting rows and executes the query
	 *
	 *
	 * @param $nameTable, $filters = array(),
	 * @var boolean
	 */
	public static function _i($nameTable, $fileds = array()) {
			
		$insertKeys  = array();
		$insertValues= array();
		
		foreach($fileds as $keyField => $valueField){

			$insertKeys[] = "$keyField";
			$insertValues[] = ":$keyField";
			$arrayBind[]= array("key" => ":$keyField", "value" =>  $valueField );

		}	
		
		$query = "insert into ".Config::_getTable($nameTable)." (".implode(",",$insertKeys).") values (".implode(",",$insertValues).")";
		
		if(self::_runQuery($query, $arrayBind)){

			return self::_getLastInsertId();

		}
			
		return false;

	}

    /** Prepares query for deleting rows and executes the query
     *
     *
     * @param $nameTable, $filters = array(),
     * @var boolean
     */
    public static function _d($nameTable, $filters = array()) {
            
        $whereArray  = $arrayBind = array();
        
        foreach($filters as $keyField => $valueField){

            $whereArray[] = "$keyField = :$keyField ";
            $arrayBind[]= array("key" => ":$keyField", "value" =>  $valueField );

        }
                
        $query = "delete from ".Config::_getTable($nameTable)." ";
        
        if( count($whereArray) > 0 ){
            
            $query .= " where ".implode(" and ",$whereArray);
            
        }
        
        if(self::_runQuery($query, $arrayBind)){

            return true;

        }
            
        return false;

    }

	/** Returns recent error
	 *
	 *
	 * @param sql query (string), sql bind values (array)
	 * @var database results(object)
	 */
	public static function _gE() {

		return self::_getError();

	}

}
