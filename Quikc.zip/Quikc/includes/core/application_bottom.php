<?php

defined('QC_VALID') or die('Restricted Access!');

if(file_exists(Config::_getDir().'/includes/custom/application_bottom.php')){

	include_once Config::_getDir().'/includes/custom/application_bottom.php';

}

$Themes->_incTemplate();

$Admin->_displayDeveloperModeActions();

