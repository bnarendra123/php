<?php

function blog_new_post_email_notifier($idSpecality,$idPost){
	
	$lu = Core::_gAR('users',array( 'specialityUser' => $idSpecality) );
	
	if( count($lu) )
	foreach($lu as $u){
		blog_new_post_email_notifier_single_user($u, $idPost);
	}

}

function blog_new_post_email_notifier_single_user($du,$idPost){
	
	$to = $du -> emailUser;
	$from = 'contact@drkart.net';
	
	$pd = blog_post_details($idPost);

	$subject = 'New Post Created';

	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	
	// More headers
	$headers .= 'From: '. $from.' ' . "\r\n" .
	    	   'Reply-To: '.$from.' ' . "\r\n";
			   			   
    $body = 'Dear '.$du -> nameFirstUser.' '.$du -> nameLastUser.'<br/><br/> 
    
    '.User::_userDetails() -> nameFirstUser.' '.User::_userDetails() -> nameLastUser.' created a new post <a href="'.blog_post_url($idPost).'">'.$pd -> titlePost.'</a> in your specality.';
	
	return mail($to, $subject, $body, $headers);
	
}

function blog_post_new_comment_email_notifier($idPost){

	$pd = blog_post_details($idPost);

	global $User;
	$ad = $User -> _getUserDetailsById($pd -> idUser);
	
	$to = $ad -> emailUser;
	$from = 'contact@drkart.net';
	
	$subject = 'Your post got a new comment';

	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	
	// More headers
	$headers .= 'From: '. $from.' ' . "\r\n" .
	    	   'Reply-To: '.$from.' ' . "\r\n";
			   			   
    $body = 'Dear '.$ad -> nameFirstUser.' '.$ad -> nameLastUser.'<br/><br/> 
    
    '.User::_userDetails() -> nameFirstUser.' '.User::_userDetails() -> nameLastUser.' commented on your post <a href="'.blog_post_url($idPost).'">'.$pd -> titlePost.'</a>.';
	
	return mail($to, $subject, $body, $headers);
	
}

function blog_user_thumbnail($idUser = false){
	return Config::_getUrl('temp').'/img/user-icon.png';
}
function blog_user_thumbnail_html($idUser = false){
	return '<img src="'.blog_user_thumbnail().'" style="width:50px;height:50px" />';
}

function blog_post_details($idPost){
	return Core::_gR('blog_posts', array('idPost' => $idPost) );
}

function blog_post_url($idPost){
	global $Themes;
	return  $Themes -> _url('blog/blog-post/').'?id='.$idPost;
}

function blog_date($date){
	return date("F j, Y H:i:s",strtotime($date));
}
function blog_post_comment_count($idPost){

    $query = 'select count(*) as counter from '.Config::_getTable('blog_post_comments').' where idPost = :idPost';
	$arrayBind[] = array("key" => ":idPost", "value" => $idPost);

	return Core::_getRow($query, $arrayBind) -> counter;
}

function blog_post_comments_lsit($idPost){

	global $User;
    $query = 'select * from '.Config::_getTable('blog_post_comments').' where idPost = :idPost order by dateCreated desc';
	$arrayBind[] = array("key" => ":idPost", "value" => $idPost);

	$lc = Core::_getAllRows($query, $arrayBind);
	
	foreach($lc as $i => $c){

		$ad = $User -> _getUserDetailsById($c -> idUser);

		$c->author_name = $ad -> nameFirstUser.' '.$ad -> nameLastUser;
		$c->formated_time = time_elapsed_string($c -> dateCreated);

		$lc[$i] = $c;

	}
	
	return $lc;
	
}

function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}

function short_description($desc,$len = 340){
	$desc = substr($desc, 0, $len);
	return substr($desc, 0, strrpos($desc, ' ')) . " ...";
}
