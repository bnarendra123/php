<?php
function _displayusername(){
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('users') . " where idUser = :idUser  ";
	$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser);

	return Core::_getAllRows($query, $arrayBind);
}
function _getProducts(){
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where `statusProduct` = :statusProduct";
	$arrayBind[] = array("key" => ":statusProduct", "value" => 1);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;

}
function _getBrands(){
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('our_brands') . " where `statusBrand` = :statusBrand";
	$arrayBind[] = array("key" => ":statusBrand", "value" => 1);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;

}
function _getCategories(){
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('categories') . " where `statusCategory` = :statusCategory and idParentCategory = :idParentCategory";
	$arrayBind[] = array("key" => ":statusCategory", "value" => 1);
	$arrayBind[] = array("key" => ":idParentCategory", "value" => 0);
	$results = Core::_getAllRows($query, $arrayBind);
	return $results;
}
function _getSubCategories($idParentCategory){
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('categories') . " where `statusCategory` = :statusCategory and idParentCategory = :idParentCategory";
	$arrayBind[] = array("key" => ":statusCategory", "value" => 1);
	$arrayBind[] = array("key" => ":idParentCategory", "value" => $idParentCategory);
	$results = Core::_getAllRows($query, $arrayBind);
	return $results;
}

function _getProductSliders(){
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where `statusProduct` = :statusProduct  LIMIT 5";
	$arrayBind[] = array("key" => ":statusProduct", "value" => 1);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;

}
function _getlimitProducts($changeValue){
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where `statusProduct` = :statusProduct  LIMIT $changeValue";
	$arrayBind[] = array("key" => ":statusProduct", "value" => 1);
	$results =Core::_getAllRows($query, $arrayBind);
	
	return $results;
}

function _getProduct($idProduct){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where idProduct = :idProduct and  `statusProduct` = :statusProduct";
	$arrayBind[] = array("key" => ":statusProduct", "value" => 1);
	$arrayBind[] = array("key" => ":idProduct", "value" => $idProduct);
	$results = Core::_getRow($query, $arrayBind);

	return $results;
	}

function _displayCartUser(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('cart') . " where idUser = :idUser  ";
	$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser);

	return Core::_getAllRows($query, $arrayBind);
}
function _displayCartSession(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('cart') . " where idSession = :idSession  ";
	$arrayBind[] = array('key' => ':idSession', 'value' => session_id());

	return Core::_getAllRows($query, $arrayBind);
}
function _checkCartItemExist($idProduct){

	$arrayBind[] = array('key' => ':idProduct', 'value' => $idProduct);
	if ( User::_userDetails() ){
		$idUser = User::_userDetails() -> idUser;
		$query = "select * from " . Config::_getTable('cart') . " where  idUser = :idUser and `idProduct` = :idProduct ";
		$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser);
	}else{
		$query ="select * from ".Config::_getTable('cart')." where idSession=:idSession and  idProduct= :idProduct  ";
		$arrayBind[] = array("key" => ":idSession", "value" => session_id());
	}

	return Core::_getRow($query,$arrayBind);
}
function _displaywishlist(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('wishlist') . " where idUser = :idUser";
	$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser);

	return Core::_getAllRows($query, $arrayBind);
}
function _getcategoryProducts($idCategory){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where `caregoryProduct` = :caregoryProduct and `statusProduct` = :statusProduct";
	$arrayBind[] = array("key" => ":statusProduct", "value" => 1);
	$arrayBind[] = array("key" => ":caregoryProduct", "value" => $idCategory);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;
}
function _getOrderDetails(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('chekout_items') . " where `idUser` = :idUser and `itemStatus` = :itemStatus";
	$arrayBind[] = array("key" => ":itemStatus", "value" => 1);
	$arrayBind[] = array("key" => ":idUser", "value" => User::_userDetails()->idUser);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;
}
function _getOrderList(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('checkout') . " where `checkoutStatus` = :checkoutStatus and `chekoutIdUser` = :chekoutIdUser";
	$arrayBind[] = array("key" => ":checkoutStatus", "value" => 1);
	$arrayBind[] = array("key" => ":chekoutIdUser", "value" =>  User::_userDetails()->idUser);
	$results = Core::_getAllRows($query, $arrayBind);
	return $results;
}

/*
function _searchKeyProduct($searchKey){	
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where nameProduct  LIKE '%".$searchKey."%' ";
	$result =Core::_getAllRows($query, $arrayBind);
	return $result;
}

function _searchKeyCategory($searchKey){	
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('categories') . " where nameCategory  LIKE '%".$searchKey."%' ";
	$result =Core::_getAllRows($query, $arrayBind);
	return $result;
}
function _searchKeyProduct($searchKey){	
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where nameProduct  LIKE '%".$searchKey."%' ";
	$result =Core::_getAllRows($query, $arrayBind);
	return $result;
}
function getProduct($idProduct){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where idProduct = :idProduct and  `statusProduct` = :statusProduct";
	$arrayBind[] = array("key" => ":statusProduct", "value" => 1);
	$arrayBind[] = array("key" => ":idProduct", "value" => $idProduct);
	$results = Core::_getRow($query, $arrayBind);

	return $results;
	}
function getusers(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('users') . " where idUser =:idUser and statusUser=:statusUser";
	$arrayBind[] = array("key" => ":statusUser", "value" => 1);
	$arrayBind[] = array('key' => ':idUser', 'value' =>User::_userDetails()->idUser);
	$results = Core::_getRow($query, $arrayBind);

	return $results;
	}

function getLatestProducts(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where `statusProduct` = :statusProduct limit 3";
	$arrayBind[] = array("key" => ":statusProduct", "value" => 1);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;

}
function slider(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('slider') . " where `isTourSliderItem` = :isTourSliderItem";
	$arrayBind[] = array("key" => ":isTourSliderItem", "value" => 1);

	return Core::_getAllRows($query, $arrayBind);
}
function smallSlider(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('slider') . " where `isTourSliderItem` = :isTourSliderItem";
	$arrayBind[] = array("key" => ":isTourSliderItem", "value" => 0);

	return Core::_getAllRows($query, $arrayBind);
}
function _checkCartItemExist($idProduct){

	$arrayBind[] = array('key' => ':idProduct', 'value' => $idProduct);
	if ( User::_userDetails() ){
		$idUser = User::_userDetails() -> idUser;
		$query = "select * from " . Config::_getTable('cart') . " where  idUser = :idUser and `idProduct` = :idProduct ";
		$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser);
	}else{
		$query ="select * from ".Config::_getTable('cart')." where idSession=:idSession and  idProduct= :idProduct  ";
		$arrayBind[] = array("key" => ":idSession", "value" => session_id());
	}

	return Core::_getRow($query,$arrayBind);
}

function _displaywishlist(){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('wishlist') . " where idUser = :idUser";
	$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser);

	return Core::_getAllRows($query, $arrayBind);
}
function _wishlist(){
	
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('wishlist') . " where idUser = :idUser and `idProduct` = :idProduct";
	$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser);
	$arrayBind[] = array('key' => ':idProduct', 'value' => $idProduct);
	$results = Core::_getRow($query, $arrayBind);

	return $results;
}
function _delectCart($idCart){

	$arrayBind = array();
	$sql = "delete from cart where (idUser = :idUser or idSession = :idSession) and `idCart` = :idCart ";
	$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser );
	$arrayBind[] = array('key' => ':idSession', 'value' => session_id());
	$arrayBind[] = array('key' => ':idCart', 'value' => $idCart);

	$res = Core::_runQuery($sql,$arrayBind);
}
function _getCategories(){
	
	$arrayBind = array();
	$query = "select * from " . Config::_getTable('categories') . " where `idParentCategory` = :idParentCategory and `statusCategory` = :statusCategory";
	$arrayBind[] = array("key" => ":idParentCategory", "value" => 0);
	$arrayBind[] = array("key" => ":statusCategory", "value" => 1);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;
}
function _getSubCategories($idParentCategory){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('categories') . " where `idParentCategory` = :idParentCategory and `statusCategory` = :statusCategory "  ;
	$arrayBind[] = array("key" => ":idParentCategory", "value" => $idParentCategory);
	$arrayBind[] = array("key" => ":statusCategory", "value" => 1);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;
}
function _getProducts($idCategory){

	$arrayBind = array();
	$query = "select * from " . Config::_getTable('products') . " where `caregoryProduct` = :caregoryProduct and `statusProduct` = :statusProduct";
	$arrayBind[] = array("key" => ":statusProduct", "value" => 1);
	$arrayBind[] = array("key" => ":caregoryProduct", "value" => $idCategory);
	$results = Core::_getAllRows($query, $arrayBind);
	
	return $results;
}*/


?>