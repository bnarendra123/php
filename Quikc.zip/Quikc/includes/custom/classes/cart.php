<?php
defined('QC_VALID') or die('Restricted Access!');

class Cart{
	
	private $detailsCart;
	
	
	public function __construct(){
		
		$this -> _loadCartItems();
		
	}
	
	public function _loadCartItems(){
		
		if( !User::_userDetails() ){
			$details['items'] = Core::_gAR( 'cart',array( 'sessionId' => session_id() ) );
		}else{
			$details['items'] = Core::_gAR( 'cart',array( 'idUser' => User::_userDetails() -> idUser ) );
		}

		$this -> detailsCart = $details;

	   $details['total'] = $this -> _calCartTotal();;
	   $this -> detailsCart = $details;
		
		
	}
	
	
	public function _getCartItems(){
		
		return $this -> detailsCart['items'];
		
	}

	public function _getCartTotal(){
		
		return $this -> detailsCart['total'];
		
	}

	public function _calCartTotal(){
		
		$details = $this -> _getCartItems();

		$cost = 0.0;
		
		foreach( $details as $detail ){
			
			$cost += getProductPriceDetailsById($detail -> idProduct,$detail -> idAssociate) -> actualPrice * $detail -> quantity;
			
		}

		return $cost;
		
	}
	
	public function _getCartItem($idProduct,$idAssociate){
		
		$details = $this -> _getCartItems();
		
		foreach( $details as $detail ){
			
			if($detail->idProduct == $idProduct && $detail->idAssociate == $idAssociate ){
				return $detail;
			}
			
		}
		return false;
		
	}
	
	public function _addCartItems($idProduct,$idAssociate,$quantity = false){
		
		$producDetails = getProductPriceDetailsById($idProduct,$idAssociate);
		
		if(!$producDetails ){
			return false;
		}
		
		if($this->_getCartItem($idProduct, $idAssociate)){
			
			if( $quantity == false ){
				$quantity = $this->_getCartItem($idProduct, $idAssociate)->quantity+1;
			}else{
				$quantity = $quantity;
			}

			if( $producDetails -> quantityInStock < $quantity ){
				return false;
			}
			
			
			$sql = "update cart set quantity = :quantity where idProduct = :idProduct and idAssociate = :idAssociate";
			
			$arrayBind[] = array('key' => ':idAssociate', 'value' => $idAssociate);
			$arrayBind[] = array('key' => ':quantity', 'value' => $quantity);
			$arrayBind[] = array('key' => ':idProduct', 'value' => $idProduct);
			
			if(Core::_runQuery($sql,$arrayBind)){
				return true;
			}
						
			
		}else{

			if( $producDetails -> quantityInStock < 1 ){
				return false;
			}
				
			if( User::_userDetails() ){
				$idUser = User::_userDetails()->idUser;
			}else{
				$idUser = 0;
			}	
			
			$arrayBind = array();

			$sql = "insert into cart (idUser,sessionId,idProduct,idAssociate,quantity) values (:idUser,:sessionId,:idProduct,:idAssociate,:quantity)";
			
			$arrayBind[] = array('key' => ':idUser', 'value' => $idUser );
			$arrayBind[] = array('key' => ':sessionId', 'value' => session_id() );
			$arrayBind[] = array('key' => ':idProduct', 'value' => $idProduct);
			$arrayBind[] = array('key' => ':idAssociate', 'value' => $idAssociate);
			$arrayBind[] = array('key' => ':quantity', 'value' => 1);
			
			$res = Core::_runQuery($sql,$arrayBind);
											
		}
		
		$this -> _loadCartItems();
	}
	
	public function _removeCartItem($idProduct,$idAssociate){
		
		
		if( User::_userDetails()->associateUser == true ){
			return 'you are not allowed to perform this operation';
		}
		
		if($this->_getCartItem($idProduct, $idAssociate)){
			
			$sql = "delete from cart where idProduct = :idProduct and idAssociate = :idAssociate and sessionId = :sessionId";
			
			$arrayBind[] = array('key' => ':idAssociate', 'value' => $idAssociate);
			$arrayBind[] = array('key' => ':idProduct', 'value' => $idProduct);
			$arrayBind[] = array('key' => ':sessionId', 'value' => session_id() );
			
			if(Core::_runQuery($sql,$arrayBind)){
				return true;
			}
			
		}else{
			die('fail');
		}
		
		$this -> _loadCartItems();
	}
	
	public function _shippingDetails(){
		
		if( isset($_SESSION['shipping'])  ){
			
			return (object)$_SESSION['shipping'];
				
		}else if( User::_userDetails() ){
			$details = getBuyerDetailsById( User::_userDetails()->idUser );
			$details->fullNameUser = $details->nameFirstUser.' '.$details->nameLastUser; 
			
			return $details;
		}else if( !isset($_SESSION['shipping']) && !User::_userDetails() ){
				
			$dteails = (object) array();
			
			$details->fullNameUser		= ''; 
			$details->mobilenoUser		= '';
			$details->emailUser			= '';
			$details->addressUser		= '';
			$details->cityUser			= '';
			$details->stateUser			= '';
			$details->countryUser		= '';
			$details->postalCodeUser	= '';
			
			return $details;
		}
		
	}

	public function _createOrder(){
		
		$total = $this -> _getCartTotal();
		$items = $this -> _getCartItems();
		
		if( !count($items) || $total <= 0 ){
			return false;
		}
		
		$arrayBind = array();
		
		$sql = "insert into orders (idUser,sessionId,countItems,totalOrder,orderedOn,paymentOrder,shippingOrder) values (:idUser,:sessionId,:countItems,:totalOrder,NOW(),:paymentOrder,:shippingOrder )";
		
		$arrayBind[] = array('key' => ':idUser',	 'value' => (User::_userDetails())?User::_userDetails()->idUser:'0' );
		$arrayBind[] = array('key' => ':sessionId',	 'value' => session_id() );
		$arrayBind[] = array('key' => ':countItems', 'value' => count($items) );
		$arrayBind[] = array('key' => ':totalOrder', 'value' => $total );
		$arrayBind[] = array('key' => ':paymentOrder', 'value' => '1' );
		$arrayBind[] = array('key' => ':shippingOrder', 'value' => '0' );
		
		if(Core::_runQuery($sql,$arrayBind )){
			
			$idOrder = Core::_getLastInsertId();
			
			foreach ($items as $item ) {
				
				$dp = getProductPriceDetailsById($item->idProduct,$item->idAssociate);
				$arrayBind = array();	
				$sql = "insert into order_items (idOrder,idProduct,idAssociate,quantity,createdOn,unitPrice,totalPrice ) values (:idOrder,:idProduct,:idAssociate,:quantity,NOW(),:unitPrice,:totalPrice )";
				
				$arrayBind[] = array('key' => ':idOrder',		 'value' => $idOrder );
				$arrayBind[] = array('key' => ':idProduct',		 'value' => $item->idProduct );
				$arrayBind[] = array('key' => ':idAssociate',	 'value' => $item->idAssociate );
				$arrayBind[] = array('key' => ':quantity',		 'value' => $item->quantity );

				$arrayBind[] = array('key' => ':unitPrice',		 'value' => $dp -> actualPrice );
				$arrayBind[] = array('key' => ':totalPrice',	 'value' => $dp -> actualPrice * $item->quantity );
								
				Core::_runQuery($sql,$arrayBind);
				
			}
			
			$arrayBind = array();
			
			$shippingDetails = $this->_shippingDetails();
			
			$sql = "insert into shipping_details ( 
											 idOrder,
											 nameFull,
											 mobileNumber,
											 email,
											 address,
											 city,
											 state,
											 country,
											 postalCode ) 
					values					(:idOrder,
											 :nameFull,
											 :mobileNumber,
											 :email,
											 :address,
											 :city,
											 :state,
											 :country,
											 :postalCode )";

			$arrayBind[] = array('key' => ':idOrder',		 'value' => $idOrder );
			$arrayBind[] = array('key' => ':nameFull',		 'value' => $shippingDetails->fullNameUser);
			$arrayBind[] = array('key' => ':mobileNumber',	 'value' => $shippingDetails->mobilenoUser );
			$arrayBind[] = array('key' => ':email',			 'value' => $shippingDetails->emailUser );
			$arrayBind[] = array('key' => ':address',		 'value' => $shippingDetails->addressUser );
			$arrayBind[] = array('key' => ':city',			 'value' => $shippingDetails->cityUser );
			$arrayBind[] = array('key' => ':state',			 'value' => $shippingDetails->stateUser );
			$arrayBind[] = array('key' => ':country',		 'value' => $shippingDetails->countryUser );
			$arrayBind[] = array('key' => ':postalCode',	 'value' => $shippingDetails->postalCodeUser );
			
			if(Core::_runQuery($sql,$arrayBind)){
				$this->_emptyCartItems();	
			}
			
			return true;
				
		}
		
	}
	
	public function _emptyCartItems(){
			
		$arrayBind = array();
		if( User::_userDetails() &&  User::_userDetails()->associateUser == FALSE ){
			$sql = "delete from cart where idUser = :idUser";
			$arrayBind[] = array('key' => ':idUser', 'value' => User::_userDetails()->idUser );	
		}else{
			$sql = "delete from cart where sessionId = :sessionId";
			$arrayBind[] = array('key' => ':sessionId', 'value' => session_id() );
		}
		
		if(Core::_runQuery($sql,$arrayBind)){
			return true;
		}else{
			return false;	
		}
		
	}


}

