<?php

defined('QC_VALID') or die('Restricted Access!');

require Config::_getDir() . '/includes/custom/functions/general.php';


if( !Ajax::_isAjax() && User::_userDetails() && !in_array($Themes -> _getCurrentPage(), array('logout') )) {

	$du = User::_userDetails();
	
	/*
	if( !$du -> emailVerified ){
						  include Config::_getDir().'/includes/custom/modules/pages/verify.php';
			$Themes->_inc('templates/verify.phtml');
			die();
		}*/
	
	
}

if( User::_userDetails() ->associateUser == true){
		
	if( !Ajax::_isAjax() && User::_userDetails() ->completedBankDetails == 0 && !in_array($Themes->_getCurrentPage(), array('my-account/') ) ){
		Base::_pageRedirect('/my-account/?bank-details');
	}
}


//require Config::_getDir() . '/plugins/facebook/fbconfig.php';


function _verifyEmail($du){
	
	$email = $du." aslkasdk askjdhkashd askd kaskaskdk asd  ";;
	
	
}
