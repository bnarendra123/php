<?php
defined('QC_VALID') or die('Restricted Access!');

if( $_POST ){
	
	
	extract($_POST);
	
	if( strlen($post_title) < 10 || strlen($post_description) < 50 ){
		die('No Input');
	}
	
	
	$imagePost = $htmlPost = $pdfPost = $videoPost = "";
	
	if( $_FILES['post_image']['name'] != '' ){
		
		$imagePost = Base :: _generateRandomString(10).'.'.pathinfo($_FILES['post_image']['name'], PATHINFO_EXTENSION);;
		move_uploaded_file($_FILES['post_image']['tmp_name'], Config::_getDir().'/media/images/blog/'.$imagePost );
		
	}

	if( $_FILES['post_html']['name'] != '' ){
		
		$htmlPost = Base :: _generateRandomString(10).'.'.pathinfo($_FILES['post_html']['name'], PATHINFO_EXTENSION);;
		move_uploaded_file($_FILES['post_html']['tmp_name'], Config::_getDir().'/media/htmls/blog/'.$htmlPost );
		
	}

	if( $_FILES['post_pdf']['name'] != '' ){
		
		$pdfPost = Base :: _generateRandomString(10).'.'.pathinfo($_FILES['post_pdf']['name'], PATHINFO_EXTENSION);;
		move_uploaded_file($_FILES['post_pdf']['tmp_name'], Config::_getDir().'/media/documents/blog/'.$pdfPost );
		
	}

	if( $_FILES['post_video']['name'] != '' ){
		
		$videoPost = Base :: _generateRandomString(10).'.'.pathinfo($_FILES['post_video']['name'], PATHINFO_EXTENSION);;
		move_uploaded_file($_FILES['post_video']['tmp_name'], Config::_getDir().'/media/videos/blog/'.$videoPost );
		
	}

	if( !isset($idPost) || $idPost == -1 ){

		$keys = array(
						'idUser'		=>	User::_userDetails()->idUser,
						'idSpecality'	=>	User::_userDetails()->specialityUser,
						'titlePost'		=>	$post_title,
						'contentPost'	=>	$post_description,
						'imagePost'		=>	$imagePost,
						'htmlPost'		=>	$htmlPost,
						'pdfPost'		=>	$pdfPost,
						'videoPost'		=>	$videoPost,
		
					);
	
		$idPost = Core::_i('blog_posts',$keys);
	
		if( $idPost ){
			blog_new_post_email_notifier(User::_userDetails()->specialityUser,$idPost);
		}
		
	}else{

		$keys = array(
						'titlePost'		=>	$post_title,
						'contentPost'	=>	$post_description,
					);

		if( $imagePost != '' ){
			$keys['imagePost'] = $imagePost;
		}
		if( $htmlPost != '' ){
			$keys['htmlPost'] = $htmlPost;
		}
		if( $pdfPost != '' ){
			$keys['pdfPost'] = $pdfPost;
		}
		if( $videoPost != '' ){
			$keys['videoPost'] = $videoPost;
		}

		$filters = array(
						'idUser'		=>	User::_userDetails()->idUser,
					);
	
		Core::_u('blog_posts',$keys,$filters);
	
	}
	
	
	Base :: _pageRedirect( $Themes -> _url('blog/')  );
	die();
	
	
}
