<?php
defined('QC_VALID') or die('Restricted Access!');
if( $_POST ){
	
	extract($_POST);
	
	if( strlen(trim($comment_text)) == 0 || trim($post_id) == ''  ){
		die('No Input');
	}

	$pd = blog_post_details($post_id);
	
	if( !$pd || $pd -> idSpecality != User::_userDetails()->specialityUser ){
		die('Invalid Post');
	}
	
	$keys = array(
					'idUser'		=>	User::_userDetails()->idUser,
					'idPost'		=>	$post_id,
					'content'		=>	$comment_text,
				);

	Core::_i('blog_post_comments',$keys);

	blog_post_new_comment_email_notifier($post_id);

	Base :: _pageRedirect( blog_post_url($post_id)  );
	die();
	
	
}
