<?php
defined('QC_VALID') or die('Restricted Access!');
extract($_POST);

if(isset($_POST) && isset($_POST['submit']) ){

	if(end($main_cat) == -1 ){
	 	$count = count($main_cat);
	 	$idCategory = $main_cat[$count-2]; 
	 }else{
	 	$idCategory = end($main_cat);
	 }
	
	if( user::_userDetails() && user::_userDetails()->associateUser == true  ){

		if($idProduct == '-1'){
			
		
			if($_FILES['product_image1']['name'] == '' || $_FILES['product_image2']['name'] == '' || $_FILES['product_image3']['name'] == '' ){
				die('please select product images');
			}
			
		}
		
		foreach($_FILES as $file){
			if($file['name'] != ''){
				$uploaddir = Config::_getDir().'/media/images/product-images/'.$product_code.'_'.$file['name'];
				if(!move_uploaded_file($file['tmp_name'], $uploaddir ) ){
					$errorCount++;
				}	
			}
			
		}
			
		if($idProduct == '-1'){
			
			$errorCount = 0;
			
			
			if( $errorCount <= 1 ){
	
				$arrayBind = array();
				$sql = "insert into product_details (idUser,
													 codeProduct,
													 titleProduct,
													 idCategory,
													 manufacturerProduct,
													 manufacturerPartNo,
													 packingProduct,
													 dimensionsProduct,
													 netWeightProduct,
													 colorProduct,
													 conditionProduct,
													 image1Product,
													 image2Product,
													 image3Product,
													 briefDescriptionProduct,
													 catlogProduct,
													 videoDemoProduct,
													 searchKeywords,
													 otherInformationProduct
													 ) 
								
											values (:idUser,
													:codeProduct,
													:titleProduct,
													:idCategory,
													:manufacturerProduct,
													:manufacturerPartNo,
													:packingProduct,
													:dimensionsProduct,
													:netWeightProduct,
													:colorProduct,
													:conditionProduct,
													:image1Product,
													:image2Product,
													:image3Product,
													:briefDescriptionProduct,
													:catlogProduct,
													:videoDemoProduct,
													:searchKeywords,
													:otherInformationProduct)";
													
				
				$arrayBind[] = array('key' => ':idUser',				 'value' => user::_userDetails()->idUser);
				$arrayBind[] = array('key' => ':codeProduct',			 'value' => $product_code);
				$arrayBind[] = array('key' => ':titleProduct',			 'value' => $product_title);
				$arrayBind[] = array('key' => ':idCategory',			 'value' => $idCategory);
				$arrayBind[] = array('key' => ':manufacturerProduct',	 'value' => $manufacturer);
				$arrayBind[] = array('key' => ':manufacturerPartNo',	 'value' => $manufacturer_partno);
				$arrayBind[] = array('key' => ':packingProduct',		 'value' => $packing_noof_units);
				$arrayBind[] = array('key' => ':dimensionsProduct',		 'value' => $dimensions);
				$arrayBind[] = array('key' => ':netWeightProduct',		 'value' => $net_weight);
				$arrayBind[] = array('key' => ':colorProduct',			 'value' => $color);
				$arrayBind[] = array('key' => ':conditionProduct',		 'value' => $condition);
				
				$arrayBind[] = array('key' => ':image1Product',			 'value' => $product_code.'_'.$_FILES['product_image1']['name']);
				$arrayBind[] = array('key' => ':image2Product',			 'value' => $product_code.'_'.$_FILES['product_image2']['name']);
				$arrayBind[] = array('key' => ':image3Product',			 'value' => $product_code.'_'.$_FILES['product_image3']['name']);
				
				$arrayBind[] = array('key' => ':briefDescriptionProduct','value' => $brief_description);
				$arrayBind[] = array('key' => ':catlogProduct',			 'value' => '');
				$arrayBind[] = array('key' => ':videoDemoProduct',		 'value' => $video_demo);
				$arrayBind[] = array('key' => ':searchKeywords',		 'value' => $search_key_words);
				$arrayBind[] = array('key' => ':otherInformationProduct','value' => $other_relevant_information);
				
				
				if(Core::_runQuery($sql,$arrayBind)){
				
					$idProduct = Core::_getLastInsertId();

					$arrayBind = array();
					
					$sql = "insert into product_price_details 
										(idProduct,
										 idUser,
										 actualPrice,
										 specialPrice,
										 specialPriceEndDate,
										 quantityInStock,
										 handdingTime,
										 shippingMethod,
										 createdOn
										 ) 
								values (:idProduct,
										:idUser,
										:actualPrice,
										:specialPrice,
										:specialPriceEndDate,
										:quantityInStock,
										:handdingTime,
										:shippingMethod,
										:createdOn
										
										)";
					$arrayBind[] = array('key' => ':idUser',			 'value' => user::_userDetails()->idUser );
					$arrayBind[] = array('key' => ':idProduct',			 'value' => $idProduct);
					$arrayBind[] = array('key' => ':actualPrice',		 'value' => $actual_price);
					$arrayBind[] = array('key' => ':specialPrice',		 'value' => $special_price);
					$arrayBind[] = array('key' => ':specialPriceEndDate','value' => $special_price_end_date);
					$arrayBind[] = array('key' => ':quantityInStock',	 'value' => $quantity_in_stock);
					$arrayBind[] = array('key' => ':handdingTime',		 'value' => $handing_time);
					$arrayBind[] = array('key' => ':shippingMethod',	 'value' => $shipping_method);
					$arrayBind[] = array('key' => ':createdOn',			 'value' => 'Now()');
					
					if(Core::_runQuery($sql,$arrayBind)){
						Base::_pageRedirect('/inventory/');
					}
						
				}
			}
		}else{
			
			$productDetails = getProductDetailsById($idProduct);
			
			if( $productDetails -> idUser == User::_userDetails()->idUser ){
				
				if($_FILES['product_image1']['name'] == ''){
					$img1 = $productDetails->image1Product;	
				}else{
					$img1 = $product_code.'_'.$_FILES['product_image1']['name'];
				}
				
				if($_FILES['product_image2']['name'] == ''){
					$img2 = $productDetails->image2Product;	
				}else{
					$img2 = $product_code.'_'.$_FILES['product_image2']['name'];
				}
				
				if($_FILES['product_image3']['name'] == ''){
					$img3 = $productDetails->image3Product;	
				}else{
					$img3 = $product_code.'_'.$_FILES['product_image3']['name'];
				}
				
				$arrayBind = array();
	
				$sql = "update product_details set 
								
								codeProduct					= :codeProduct,
								titleProduct				= :titleProduct,
								idCategory					= :idCategory,
								manufacturerProduct			= :manufacturerProduct,
								manufacturerPartNo			= :manufacturerPartNo,
								packingProduct				= :packingProduct,
								dimensionsProduct			= :dimensionsProduct,
								netWeightProduct			= :netWeightProduct,
								colorProduct				= :colorProduct,
								conditionProduct			= :conditionProduct,
								image1Product				= :image1Product,
								image2Product				= :image2Product,
								image3Product				= :image3Product,
								
								briefDescriptionProduct		= :briefDescriptionProduct,
								videoDemoProduct 			= :videoDemoProduct,
								searchKeywords 				= :searchKeywords,
								otherInformationProduct		= :otherInformationProduct
								
						where idProduct = :idProduct and idUser = :idUser";
						
				$arrayBind[] = array('key' => ':codeProduct',				 'value' => $product_code );
				$arrayBind[] = array('key' => ':titleProduct',				 'value' => $product_title );
				$arrayBind[] = array('key' => ':idCategory',				 'value' => $idCategory );
				
				$arrayBind[] = array('key' => ':manufacturerProduct',		 'value' => $manufacturer );
				$arrayBind[] = array('key' => ':manufacturerPartNo',		 'value' => $manufacturer_partno );
				$arrayBind[] = array('key' => ':packingProduct',			 'value' => $packing_noof_units );
				$arrayBind[] = array('key' => ':dimensionsProduct',			 'value' => $dimensions );
				$arrayBind[] = array('key' => ':netWeightProduct',			 'value' => $net_weight );
				$arrayBind[] = array('key' => ':colorProduct',				 'value' => $color );
				$arrayBind[] = array('key' => ':conditionProduct',			 'value' => $condition );
				
				$arrayBind[] = array('key' => ':image1Product',				 'value' => $img1 );
				$arrayBind[] = array('key' => ':image2Product',				 'value' => $img2 );
				$arrayBind[] = array('key' => ':image3Product',				 'value' => $img3 );
				
				$arrayBind[] = array('key' => ':briefDescriptionProduct',	 'value' => $brief_description );
				$arrayBind[] = array('key' => ':videoDemoProduct',			 'value' => $video_demo );
				$arrayBind[] = array('key' => ':searchKeywords',			 'value' => $search_key_words );
				$arrayBind[] = array('key' => ':otherInformationProduct',	 'value' => $other_relevant_information);
				
				$arrayBind[] = array('key' => ':idProduct',					 'value' => $idProduct);
				$arrayBind[] = array('key' => ':idUser',					 'value' => user::_userDetails()->idUser );
				
				Core::_runQuery($sql,$arrayBind);
			}

			$arrayBind = array();
			
			if( Core::_gR('product_price_details',array('idUser' => user::_userDetails()->idUser, 'idProduct' => $idProduct )) ){
				
				$sql = "update product_price_details set  
									 actualPrice =:actualPrice ,
									 specialPrice =:specialPrice,
									 specialPriceEndDate =:specialPriceEndDate,
									 quantityInStock =:quantityInStock,
									 handdingTime =:handdingTime,
									 shippingMethod =:shippingMethod
									 where idProduct = :idProduct and idUser = :idUser";
			}else{
				
				$sql = "insert into product_price_details 
									(idProduct,
									 idUser,
									 actualPrice,
									 specialPrice,
									 specialPriceEndDate,
									 quantityInStock,
									 handdingTime,
									 shippingMethod,
									 createdOn
									 ) 
							values (:idProduct,
									:idUser,
									:actualPrice,
									:specialPrice,
									:specialPriceEndDate,
									:quantityInStock,
									:handdingTime,
									:shippingMethod,
									NOW()
									
									)";
			}
			
			$arrayBind[] = array('key' => ':idUser',			 'value' => user::_userDetails()->idUser );
			$arrayBind[] = array('key' => ':idProduct',			 'value' => $idProduct);
			$arrayBind[] = array('key' => ':actualPrice',		 'value' => $actual_price);
			$arrayBind[] = array('key' => ':specialPrice',		 'value' => $special_price);
			
			$arrayBind[] = array('key' => ':specialPriceEndDate','value' => $special_price_end_date);
			
			$arrayBind[] = array('key' => ':quantityInStock',	 'value' => $quantity_in_stock);
			$arrayBind[] = array('key' => ':handdingTime',		 'value' => $handing_time);
			$arrayBind[] = array('key' => ':shippingMethod',	 'value' => $shipping_method);
			
			if(Core::_runQuery($sql,$arrayBind)){
				Base::_pageRedirect('/inventory/');
			}
		}
	}
		
}

