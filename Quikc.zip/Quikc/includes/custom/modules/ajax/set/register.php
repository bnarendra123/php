<?php

/*
if (isset($_POST)) {
	extract($_POST);
	if ($firstName == "") {
			die(' You did not enter a firstname');
		} elseif ($lastName == "") {
			die(' You did not enter a lastname.');
		} elseif ($email == "") {
			die('You did not enter a email.');
	
		} elseif (!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email)) {
			die('You did not enter a valid email.');
		
		} elseif ($password != $passwordUser) {
			die(' You did not match both password.');
		} else {
	
			if ($action = 'insert') {
				$arrayBind = array();
				$query = "select * from " . Config::_getTable('users') . " where emailUser = :email  ";
				$arrayBind[] = array('key' => ':email', 'value' => $email);
				
				if (Core::_getRow($query, $arrayBind)) {
					die('fail');
				} else {
					$arrayBind = array();
					$sql = "insert into users (passwordUser,nameFirstUser,nameLastUser,emailUser) values (:passwordUser,:nameFirstUser,:nameLastUser,:emailUser)";
					$arrayBind[] = array('key' => ':nameFirstUser', 'value' => $firstName);
					$arrayBind[] = array('key' => ':nameLastUser', 'value' => $lastName);
					$arrayBind[] = array('key' => ':emailUser', 'value' => $email);
					$arrayBind[] = array('key' => ':passwordUser', 'value' => md5($password));
				
					if (Core::_runQuery($sql, $arrayBind)) {
						die('ok');
					} else {
						die('fail');
					}
				}
			}
		}
/*

	
	if ($action = 'insert') {
					$arrayBind = array();
					$query = "select * from " . Config::_getTable('users') . " where emailUser = :email  ";
					$arrayBind[] = array('key' => ':email', 'value' => $email);
					if (Core::_getRow($query, $arrayBind)) {
						die('fail');
					} else {
						$arrayBind = array();
						$sql = "insert into users (passwordUser,nameFirstUser,nameLastUser,emailUser,genderUser) values (:passwordUser,:nameFirstUser,:nameLastUser,:emailUser,:genderUser)";
						$arrayBind[] = array('key' => ':nameFirstUser', 'value' => $fname);
						$arrayBind[] = array('key' => ':nameLastUser', 'value' => $lname);
						$arrayBind[] = array('key' => ':emailUser', 'value' => $email);
						$arrayBind[] = array('key' => ':genderUser', 'value' => $gender);
						$arrayBind[] = array('key' => ':passwordUser', 'value' => md5($password));
						if (Core::_runQuery($sql, $arrayBind)) {
							die('ok');
						} else {
							die('fail');
						}
					}
				}*/

	
/*}*/
if (isset($_POST)) {
	extract($_POST);
	if ($firstName == "") {
			die(' You did not enter a firstname');
		}  elseif ($email == "") {
			die('You did not enter a email.');
	
		} elseif (!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email)) {
			die('You did not enter a valid email.');
		
		} elseif ($password != $c_password) {
			die(' You did not match both password.');
		} else {
	
			if ($action = 'insert') {
				$arrayBind = array();
				$query = "select * from " . Config::_getTable('users') . " where emailUser = :email  ";
				$arrayBind[] = array('key' => ':email', 'value' => $email);
				
				if (Core::_getRow($query, $arrayBind)) {
					die('fail');
				} else {
					$arrayBind = array();
					$sql = "insert into users (passwordUser,nameFirstUser,emailUser) values (:passwordUser,:nameFirstUser,:emailUser)";
					$arrayBind[] = array('key' => ':nameFirstUser', 'value' => $firstName);
					$arrayBind[] = array('key' => ':emailUser', 'value' => $email);
					$arrayBind[] = array('key' => ':passwordUser', 'value' => md5($password));
					if (Core::_runQuery($sql, $arrayBind)) {
						die('ok');
					} else {
						die('fail');
					}
				}
			}
		}
}
