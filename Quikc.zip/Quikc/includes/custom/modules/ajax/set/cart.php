<?php
defined('QC_VALID') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if( $_POST ){
	extract($_POST);
	if( $action == 'delete' ){
			$arrayBind = array();
			$sql = "delete from cart where  `idCart` = :idCart ";
			$arrayBind[] = array('key' => ':idCart', 'value' => $idCart);
			if( Core::_runQuery($sql, $arrayBind) ){
				die('ok');
			}else{
				die('fail');
			}
		}
	
		
		if( $action == 'update' ){
			
					$arrayBind = array();
					$sql = "update cart set quntityCartProduct = :quntityCartProduct where `idCart` = :idCart ";
					$arrayBind[] = array('key' => ':idCart', 'value' => $idCart);
					$arrayBind[] = array('key' => ':quntityCartProduct', 'value' => $quntityCartProduct);
					if (Core::_runQuery($sql, $arrayBind)) {
						die('ok');
					} else {
						die('fail');
					}
		}
		$idUser = '';
		
		if( _checkCartItemExist($idProduct) ){
			if( Core::_getRow($query, $arrayBind) ){
				die('ok');
			} else {
				die('fail');
			}
		}else{
			$arrayBind[] = array('key' => ':idProduct', 'value' => $idProduct);
			$arrayBind[] = array('key' => ':quntityCartProduct', 'value' => 1);
			if ( User::_userDetails() ){
			$idUser = User::_userDetails() -> idUser;
				$sql = "insert into " . Config::_getTable('cart') . " (idProduct,idUser,quntityCartProduct,dateAddedcart) values (:idProduct,:idUser,:quntityCartProduct,now())";
				$arrayBind[] = array('key' => ':idUser', 'value' => $idUser);
			}else{
				$sql = "insert into " . Config::_getTable('cart') . " (idProduct,idSession,quntityCartProduct,dateAddedcart) values (:idProduct,:idSession,:quntityCartProduct,now())";
				$arrayBind[] = array('key' => ':idSession', 'value' => session_id());
			//echo Core::_showQuery($sql, $arrayBind);
			}if( Core::_runQuery($sql, $arrayBind) ){
				die('ok');
			} else {
				die('fail');
			}
		}
	
	}

?>