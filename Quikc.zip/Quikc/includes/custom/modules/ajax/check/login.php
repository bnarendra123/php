<?php							

defined('QC_VALID') or die('Restricted Access!');

if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){
  
	extract($_POST);

	$returnMessage = $User->_doLogin($loginemail,$loginpassword);

	// If conditions satisfied means, the user login is failed.
	// displaying the error message
	
	if( $returnMessage != 'ok' ){
		$Base->_convertError($processedForm['error'],false);
	}
		
	/*$_SESSION['NA'] = $pl;
	Core::_runQuery("insert into ab_pl (pl) values('".$pl."')",'');*/
	
	die($returnMessage);
}

