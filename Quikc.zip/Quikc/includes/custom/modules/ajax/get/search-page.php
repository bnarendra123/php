<?php
defined('QC_VALID') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

extract($_POST);

if($searchKey == 'empty'){
	unset($_SESSION['drkart']['searchKey']); 
	$products = getAllProductDetailsWithPriceDetails();	
}else{
	$_SESSION['drkart']['searchKey'] = $searchKey;
	$products = _getProductsBySearchKey($searchKey,$filter);
}

foreach($products as $product ){
	eproduct_box_layout_by_id($product->idProduct);
} 
?>

