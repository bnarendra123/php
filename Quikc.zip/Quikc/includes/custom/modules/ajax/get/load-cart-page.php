<?php
defined('QC_VALID') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

?>
<div class="row">
    <div class="col-md-8">
        <table class="table cart-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Name</th>
                    <th>QTY</th>
                    <th>Unit Price</th>
                    <th>Row Total</th>
                    <th>Remove</th>
                </tr>
            </thead>
            <tbody >
            	<?php
				global $Cart;
				$cartItems = $Cart->_getCartItems();
				if(count($cartItems) > 0){
					$subTotal = 0;	
					foreach($cartItems as $cartItem){
						$pd = getProductPriceDetailsById($cartItem->idProduct,$cartItem->idAssociate);
						$details = getProductDetailsById($cartItem->idProduct,$cartItem->idAssociate);
					?>
				    <tr id="cart_items_tab_<?php echo $cartItem->idProduct; ?>">
				        <td class="cart-item-image">
				            <a href="#">
				                <img src="<?php echo Config::_getUrl('temp'); ?>/img/70x70.png" alt="Image Alternative text" title="AMaze" />
				            </a>
				        </td>
				        <td><a href="<?php echo $Themes->_url('product/?id='.$details->idProduct); ?>"><?php echo $details->titleProduct; ?></a></td>
				        <td class="cart-item-quantity"><i class="fa fa-minus cart-item-minus"></i>
				            <input type="text" name="cart-quantity" class="cart-quantity" value="<?php echo $cartItem->quantity; ?>" onKeyPress= "_updateCart(this,<?php echo $cartItem->idProduct; ?>,<?php echo $cartItem->idAssociate; ?>)" /><i class="fa fa-plus cart-item-plus"></i>
				            <br><span class="success"></span>
				        </td>
				        <td><?php echo moneyFormatIndia($pd->actualPrice); ?></td>
				        <td><?php echo moneyFormatIndia( $pd->actualPrice * $cartItem->quantity ); ?></td>
				        <td class="cart-item-remove">
				            <a class="fa fa-times" href="javascript:removeFromCart(<?php echo $cartItem->idProduct; ?>,<?php echo $cartItem->idAssociate; ?>)"></a>
				        </td>
				    </tr>
					<?php
					$subTotal = $subTotal + ($pd->actualPrice * $cartItem->quantity);
					}	
				}else{
					?>
					<tr><td>Your cart Page is empty....!</td></tr>
					<?php
				}	
			?>
            </tbody>
        </table>	<a href="javascript:loadCartPage()" class="btn btn-primary">Update the cart</a>
    </div>
    <div class="col-md-3">
        <ul class="cart-total-list">
            <li><span>Sub Total</span><span><?php  echo ($subTotal !='' || $subTotal != 0)?moneyFormatIndia( $subTotal ):moneyFormatIndia( 0 ); ?></span>
            </li>
            <li><span>Shipping</span><span><?php echo moneyFormatIndia( 0.00 ) ?></span>
            </li>
            <li><span>Taxes</span><span><?php echo moneyFormatIndia( 0.00 ) ?></span>
            </li>
            <li><span>Total</span><span><?php  echo ($subTotal !='' || $subTotal != 0)?moneyFormatIndia( $subTotal ):moneyFormatIndia( 0 ); ?></span>
            </li>
        </ul>
        <a href="<?php echo $Themes->_url('checkout/'); ?>" class="btn btn-primary btn-lg">Checkout</a>
    </div>
</div>
<div class="gap"></div>
