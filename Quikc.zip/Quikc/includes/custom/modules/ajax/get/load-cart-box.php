<?php
defined('QC_VALID') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

extract($_POST);
global $Cart;
$cartItems = $Cart->_getCartItems();
?>
<ul class="shopping-cart-items">
    <?php
    $total = 0;
    foreach( $cartItems as $cartItem ){
    	$itemInfo = getProductDetailsById($cartItem->idProduct);
    ?>
    <li>
        <a href="<?php echo $Themes->_url('product/?id='.$cartItem->idProduct); ?>">
            <img src="<?php echo Config::_getUrl('img'); ?>/product-images/<?php echo $itemInfo->image1Product; ?>" alt="Image Alternative text" title="Gamer Chick" />
            <h5><?php echo $itemInfo->titleProduct; ?></h5><span class="shopping-cart-item-price"><?php echo moneyFormatIndia($itemInfo->leastPrice); ?></span>
        </a>
    </li>
    <?php
    $total = $total + ( $itemInfo->leastPrice * $cartItem->quantity);
	}
	?>
</ul>
<ul class="list-inline text-center">
	<li>Total : </li>
	<li><?php echo moneyFormatIndia($total); ?></li>
</ul>
<ul class="list-inline text-center">
    <li><a href="<?php echo $Themes->_url('view-cart/'); ?>"><i class="fa fa-shopping-cart"></i> View Cart</a>
    </li>
    <li><a href="#"><i class="fa fa-check-square"></i> Checkout</a>
    </li>
</ul>