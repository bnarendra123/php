<?php
defined('QC_VALID') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

extract($_POST);

eproduct_box_layout_by_id($idProduct,'quick-view');

die();
?>
