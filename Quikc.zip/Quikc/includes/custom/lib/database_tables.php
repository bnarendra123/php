<?php

defined('QC_VALID') or die('Restricted Access!');

