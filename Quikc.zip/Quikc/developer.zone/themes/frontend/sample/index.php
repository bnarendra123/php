<?php
die('Restricted Access');
