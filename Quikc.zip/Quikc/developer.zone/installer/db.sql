-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 03, 2014 at 07:23 AM
-- Server version: 5.5.27-log
-- PHP Version: 5.4.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `quikc`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_menus`
--

CREATE TABLE IF NOT EXISTS `admin_menus` (
  `idMenu` int(11) NOT NULL AUTO_INCREMENT,
  `titleMenu` varchar(100) NOT NULL,
  `linkMenu` varchar(100) NOT NULL,
  `createdById` varchar(100) NOT NULL,
  `createdByType` varchar(20) NOT NULL,
  `systemItem` tinyint(1) NOT NULL DEFAULT '0',
  `parentMenu` int(11) NOT NULL DEFAULT '0',
  `imageMenu` varchar(100) NOT NULL,
  `statusMenu` tinyint(1) NOT NULL DEFAULT '1',
  `orderMenu` int(5) NOT NULL,
  `dashboardMenu` tinyint(1) NOT NULL DEFAULT '1',
  `topMenu` tinyint(1) NOT NULL DEFAULT '0',
  `showSubMenus` tinyint(1) NOT NULL DEFAULT '0',
  `dateAdditionAdminMenu` datetime NOT NULL,
  `dateUpdationAdminMenu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idMenu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=260 ;

--
-- Dumping data for table `admin_menus`
--

INSERT INTO `admin_menus` (`idMenu`, `titleMenu`, `linkMenu`, `createdById`, `createdByType`, `systemItem`, `parentMenu`, `imageMenu`, `statusMenu`, `orderMenu`, `dashboardMenu`, `topMenu`, `showSubMenus`, `dateAdditionAdminMenu`, `dateUpdationAdminMenu`) VALUES
(1, 'Dashboard', 'dashboard', '1', 'user', 1, 0, 'dashboard-icon.png', 1, 0, 0, 1, 1, '2013-05-15 07:53:39', '2013-07-31 06:20:13'),
(2, 'Cms', '', '1', 'user', 1, 0, 'cms-icon.png', 1, 10, 0, 1, 1, '2013-05-15 07:53:39', '2013-07-31 06:22:29'),
(3, 'System', '', '1', 'user', 1, 0, 'system-icon.png', 1, 15, 0, 1, 1, '2013-05-15 07:53:39', '2013-07-31 06:18:35'),
(4, 'Plugins', '', '1', 'user', 1, 0, 'pluginsnew-icon.png', 1, 20, 0, 1, 1, '2013-05-28 03:26:46', '2013-07-31 06:17:35'),
(5, 'User Settings', '', '1', 'user', 1, 0, 'user-settings-icon.png', 1, 100, 0, 1, 1, '2013-05-15 07:53:39', '2013-07-31 06:16:12'),
(6, 'Themes', 'cmsthemes', '1', 'user', 1, 2, 'themes-icon.png', 1, 0, 0, 0, 1, '2013-05-15 07:53:39', '2013-07-31 06:12:11'),
(8, 'Pages', 'cmspages', '1', 'user', 1, 2, 'pages-icon.png', 1, 8, 0, 0, 0, '2013-05-15 07:53:39', '2013-07-31 06:17:19'),
(9, 'Mails', 'mails', '1', 'user', 1, 2, 'cmsmails-icon.png', 1, 13, 0, 0, 0, '2013-05-20 22:52:53', '2013-07-31 06:19:41'),
(10, 'Sets', 'cmssets', '1', 'user', 1, 2, 'cmssets-icon.png', 1, 17, 1, 0, 0, '2013-05-15 07:53:39', '2013-07-31 06:18:10'),
(11, 'Message Logs', 'cmsmessages', '1', 'user', 1, 2, 'logs-icon.png', 1, 18, 0, 0, 0, '2013-05-16 03:06:32', '2013-07-31 06:17:04'),
(12, 'Users', 'users', '1', 'user', 1, 0, 'admin-icon.png', 1, 15, 0, 1, 0, '2013-05-15 07:53:39', '2013-08-29 14:39:28'),
(13, 'Admin Menus', 'amenus', '1', 'user', 1, 3, 'menu-icon.png', 1, 0, 0, 0, 0, '2013-05-15 07:53:39', '2013-07-31 06:14:31'),
(14, 'Users Log Activity', 'user-logactivity', '1', 'user', 1, 12, 'logs-icon.png', 1, 10, 0, 0, 0, '2013-05-24 03:11:05', '2013-08-29 14:43:06'),
(15, 'Global Permissions', 'gpermissions', '1', 'user', 1, 3, 'permissions-icon.png', 1, 9, 0, 0, 0, '2013-05-15 07:53:39', '2013-07-31 06:21:19'),
(16, 'Configurations', 'configurations', '1', 'user', 1, 3, 'configurations-icon.png', 1, 25, 0, 0, 0, '2013-05-29 05:21:38', '2013-07-31 06:19:59'),
(17, 'Plugins', 'plugins', '1', 'user', 1, 4, 'plugins-icon.png', 1, 0, 1, 0, 0, '2013-06-10 00:58:23', '2013-07-31 06:17:27'),
(18, 'Add New Plugin', 'pluginsnew', '1', 'user', 1, 4, 'pluginsnew-icon.png', 1, 20, 0, 0, 0, '2013-05-30 03:41:11', '2013-08-24 02:15:53'),
(19, 'Edit Profile', 'user-profile', '1', 'user', 1, 5, 'edit-profile-icon.png', 1, 1, 0, 0, 0, '2013-05-15 07:53:39', '2013-08-29 03:43:49'),
(20, 'Change Password', 'user-password', '1', 'user', 1, 5, 'user-password-icon.png', 1, 2, 0, 0, 0, '2013-05-15 07:53:39', '2013-08-29 03:43:02'),
(21, 'Logs', 'user-logs', '1', 'user', 1, 5, 'logs-icon.png', 1, 3, 0, 0, 0, '2013-05-27 00:52:34', '2013-08-29 03:43:40'),
(23, 'Settings', '', '1', 'user', 1, 3, 'configurations-icon.png', 1, 15, 1, 0, 1, '2013-06-05 03:51:50', '2013-07-31 06:16:53'),
(24, 'Languages', 'languages', '1', 'user', 1, 9, 'timezones-icon.png', 0, 2, 0, 0, 0, '2013-05-15 07:53:39', '2013-10-14 21:53:31'),
(25, 'General Settings', 'settings-general', '1', 'user', 1, 23, 'configuration-settings-icon.png', 1, 1, 0, 0, 0, '2013-06-14 01:02:58', '2013-07-31 06:21:06'),
(26, 'Login Settings', 'settings-login', '1', 'user', 1, 23, 'login-settings-icon.png', 1, 10, 0, 0, 0, '2013-06-14 01:05:50', '2013-08-06 05:13:46'),
(27, 'Mail Settings', 'settings-mail', '1', 'user', 1, 23, 'mail-settings-icon.png', 1, 25, 0, 0, 0, '2013-06-14 01:07:04', '2013-08-06 05:14:06'),
(28, 'Cache Settings', 'settings-cache', '4', 'user', 1, 23, 'cache.png', 1, 15, 0, 0, 0, '2013-06-15 04:49:37', '2013-08-06 05:13:53'),
(29, 'Developer Settings', 'settings-developer', '1', 'user', 1, 23, 'developer-settings-icon.png', 1, 20, 0, 0, 0, '2013-06-15 23:27:09', '2013-08-06 05:13:58'),
(121, 'User Groups', 'user-groups', '1', 'user', 1, 12, 'admin-icon.png', 1, 5, 0, 0, 1, '2013-07-20 18:29:46', '2013-08-29 14:42:49'),
(150, 'Css Files', 'cmsthemes-css', '1', 'user', 1, 6, 'css-icon.png', 1, 5, 0, 0, 0, '2013-07-29 18:40:38', '2013-07-31 12:28:57'),
(153, 'Phtml Files', 'cmsthemes-phtml', '1', 'user', 1, 6, 'html-icon.png', 1, 20, 0, 0, 0, '2013-07-31 15:06:28', '2013-07-31 12:28:47'),
(154, 'Import Files to Theme', 'cmsthemes-import-files', '1', 'user', 0, 6, 'folder-file-import-icon.png', 1, 25, 0, 0, 1, '2013-08-01 13:10:23', '2013-08-01 04:10:23'),
(155, 'Metadata Settings', 'settings-metadata', '1', 'user', 0, 23, 'menu-icon.png', 1, 3, 0, 0, 0, '2013-08-06 14:14:16', '2013-08-06 05:15:11'),
(241, 'Widgets', 'widgets', '1', 'user', 0, 2, 'blocks-icon.png', 1, 5, 1, 0, 1, '2013-08-18 01:33:54', '2013-12-17 09:48:28'),
(242, 'Spaces', 'spaces', '1', 'user', 0, 2, 'pages-icon.png', 1, 7, 1, 0, 1, '2013-08-19 08:07:12', '2013-08-19 02:37:12'),
(243, 'Menus', 'menus', '1', 'user', 0, 2, 'menu-icon.png', 1, 15, 1, 0, 1, '2013-08-22 03:48:44', '2013-08-21 22:19:13'),
(244, 'Media', 'quikcmedia-media', 'quikcmedia', 'plugin', 0, 0, 'library-icon.png', 1, 10, 0, 1, 0, '2013-08-22 08:55:02', '2013-10-31 05:06:05'),
(245, 'Media Library', 'quikcmedia-media', 'quikcmedia', 'plugin', 0, 244, 'library-icon.png', 1, 10, 0, 0, 0, '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(246, 'Media Categories', 'quikcmedia-mediacategories', 'quikcmedia', 'plugin', 0, 244, 'menu-icon.png', 1, 10, 0, 0, 0, '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(247, 'Media Settings', 'quikcmedia-mediasettings', 'quikcmedia', 'plugin', 0, 244, 'configuration-settings-icon.png', 1, 15, 0, 0, 0, '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(248, 'Advanced Forms & Lists', 'quikcadvancedcms-', 'quikcadvancedcms', 'plugin', 0, 2, 'pages-icon.png', 1, 14, 1, 0, 1, '2013-08-27 04:51:09', '2013-10-14 00:05:08'),
(249, 'Lists', 'quikcadvancedcms-cmslists', 'quikcadvancedcms', 'plugin', 0, 248, 'list-icon.png', 1, 5, 0, 0, 0, '2013-08-27 04:51:09', '2013-08-26 23:21:09'),
(250, 'Forms', 'quikcadvancedcms-cmsforms', 'quikcadvancedcms', 'plugin', 0, 248, 'forms-icon.png', 1, 10, 0, 0, 0, '2013-08-27 04:51:09', '2013-08-26 23:21:09'),
(251, 'Quick Generate', 'quikcadvancedcms-qgenerate', 'quikcadvancedcms', 'plugin', 0, 248, 'no-image.png', 1, 15, 0, 0, 0, '2013-08-27 04:51:09', '2013-08-26 23:21:09'),
(252, 'Settings', 'quikcadvancedcms-', 'quikcadvancedcms', 'plugin', 0, 248, 'no-image.png', 1, 20, 0, 0, 1, '2013-08-27 04:51:09', '2013-08-26 23:21:09'),
(253, 'Lists', 'quikcadvancedcms-settings-lists', 'quikcadvancedcms', 'plugin', 0, 252, 'no-image.png', 1, 5, 0, 0, 0, '2013-08-27 04:51:09', '2013-12-28 13:22:30'),
(254, 'Forms', 'quikcadvancedcms-settings-forms', 'quikcadvancedcms', 'plugin', 0, 252, 'no-image.png', 1, 10, 0, 0, 0, '2013-08-27 04:51:09', '2013-08-26 23:21:09'),
(255, 'Samples', 'quikcadvancedcms-', 'quikcadvancedcms', 'plugin', 0, 248, 'no-image.png', 1, 50, 0, 0, 1, '2013-08-27 04:51:10', '2013-10-31 06:47:36'),
(256, 'Countries', 'quikcadvancedcms-countries', 'quikcadvancedcms', 'plugin', 0, 255, 'countries-icon.png', 1, 25, 0, 0, 0, '2013-08-27 04:51:10', '2013-10-31 07:30:29'),
(257, 'Time Zones', 'quikcadvancedcms-timezones', 'quikcadvancedcms', 'plugin', 0, 255, 'timezones-icon.png', 1, 26, 0, 0, 0, '2013-08-27 04:51:10', '2013-08-26 23:21:10'),
(259, 'Ip Restrictions', 'settings-ip', '1', 'user', 0, 23, 'configuration-settings-icon.png', 1, 6, 0, 0, 1, '2013-09-18 11:33:16', '2013-09-18 06:03:16');

-- --------------------------------------------------------

--
-- Table structure for table `admin_permissions`
--

CREATE TABLE IF NOT EXISTS `admin_permissions` (
  `idPermissions` int(11) NOT NULL AUTO_INCREMENT,
  `idGroup` int(11) NOT NULL,
  `idMenu` int(11) NOT NULL,
  `view` tinyint(1) NOT NULL DEFAULT '0',
  `create` tinyint(1) NOT NULL DEFAULT '0',
  `edit` tinyint(1) NOT NULL DEFAULT '0',
  `delete` tinyint(1) NOT NULL DEFAULT '0',
  `dateUpdationAdminPermissions` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idPermissions`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=147 ;

--
-- Dumping data for table `admin_permissions`
--

INSERT INTO `admin_permissions` (`idPermissions`, `idGroup`, `idMenu`, `view`, `create`, `edit`, `delete`, `dateUpdationAdminPermissions`) VALUES
(1, 0, 1, 1, 1, 1, 1, '2013-10-06 19:37:02'),
(2, 0, 12, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(3, 0, 6, 0, 0, 0, 0, '2013-09-21 04:43:40'),
(4, 0, 13, 0, 0, 0, 0, '2013-09-21 04:43:40'),
(5, 0, 25, 0, 0, 0, 0, '2013-09-21 04:43:40'),
(6, 0, 19, 1, 1, 1, 1, '2013-07-24 11:20:20'),
(7, 0, 24, 0, 0, 0, 0, '2013-09-21 04:43:40'),
(8, 0, 26, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(9, 0, 20, 1, 1, 1, 1, '2013-06-20 01:46:48'),
(10, 0, 21, 1, 1, 1, 1, '2013-07-24 11:20:21'),
(11, 0, 14, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(12, 0, 28, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(13, 0, 7, 1, 1, 1, 1, '2013-06-20 01:46:48'),
(14, 0, 29, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(15, 0, 8, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(16, 0, 15, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(17, 0, 2, 0, 0, 0, 0, '2013-06-20 01:46:48'),
(18, 0, 27, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(19, 0, 9, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(20, 0, 3, 0, 0, 0, 0, '2013-06-20 01:46:48'),
(21, 0, 23, 0, 0, 0, 0, '2013-06-20 01:46:48'),
(22, 0, 10, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(23, 0, 11, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(24, 0, 4, 0, 0, 0, 0, '2013-06-20 01:46:49'),
(25, 0, 16, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(26, 0, 5, 0, 0, 0, 0, '2013-06-20 01:46:49'),
(27, 3, 1, 0, 0, 0, 0, '2013-10-06 19:36:57'),
(28, 3, 13, 1, 0, 0, 1, '2013-07-20 11:38:05'),
(29, 3, 12, 1, 0, 1, 0, '2013-07-20 11:38:05'),
(30, 3, 6, 1, 0, 1, 0, '2013-07-20 11:38:05'),
(31, 3, 57, 1, 1, 0, 0, '2013-07-20 11:38:05'),
(32, 3, 19, 1, 1, 0, 0, '2013-07-20 11:38:05'),
(33, 3, 64, 1, 0, 0, 0, '2013-07-20 11:38:05'),
(34, 3, 25, 1, 0, 0, 0, '2013-07-20 11:38:06'),
(35, 3, 20, 1, 1, 0, 0, '2013-07-24 11:15:09'),
(36, 3, 26, 1, 1, 1, 0, '2013-07-24 11:15:09'),
(37, 3, 24, 1, 1, 1, 1, '2013-07-24 11:15:09'),
(38, 3, 58, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(39, 3, 21, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(40, 3, 14, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(41, 3, 28, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(42, 3, 66, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(43, 3, 63, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(44, 3, 7, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(45, 3, 29, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(46, 3, 121, 0, 0, 0, 0, '2013-07-24 11:17:32'),
(47, 3, 8, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(48, 3, 15, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(49, 3, 27, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(50, 3, 114, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(51, 3, 2, 0, 0, 0, 0, '2013-07-20 11:37:09'),
(52, 3, 113, 0, 0, 0, 0, '2013-07-20 11:37:09'),
(53, 3, 115, 0, 0, 0, 0, '2013-07-20 11:38:06'),
(54, 3, 9, 0, 0, 0, 0, '2013-07-20 11:38:07'),
(55, 3, 117, 0, 0, 0, 0, '2013-07-20 11:38:07'),
(56, 3, 3, 0, 0, 0, 0, '2013-07-20 11:37:09'),
(57, 3, 23, 0, 0, 0, 0, '2013-07-20 11:37:09'),
(58, 3, 118, 1, 1, 1, 1, '2013-07-21 14:01:28'),
(59, 3, 116, 0, 0, 0, 0, '2013-07-20 11:38:07'),
(60, 3, 10, 1, 1, 1, 1, '2013-08-23 21:17:51'),
(61, 3, 11, 0, 0, 0, 0, '2013-07-20 11:38:07'),
(62, 3, 4, 0, 0, 0, 0, '2013-07-20 11:37:10'),
(63, 3, 16, 0, 0, 0, 0, '2013-07-20 11:38:07'),
(64, 3, 119, 0, 0, 0, 0, '2013-07-20 11:38:07'),
(65, 3, 120, 0, 0, 0, 0, '2013-07-20 11:38:07'),
(66, 3, 5, 0, 0, 0, 0, '2013-07-20 11:37:10'),
(67, 0, 57, 1, 1, 1, 1, '2013-07-24 11:20:20'),
(68, 0, 64, 1, 1, 1, 1, '2013-07-24 11:20:20'),
(69, 0, 58, 1, 1, 1, 1, '2013-07-24 11:20:21'),
(70, 0, 66, 1, 1, 1, 1, '2013-07-24 11:20:21'),
(71, 0, 63, 1, 1, 1, 1, '2013-07-24 11:20:21'),
(72, 0, 121, 0, 0, 0, 0, '2013-09-21 04:43:40'),
(73, 0, 114, 0, 0, 0, 0, '2013-07-20 12:12:43'),
(74, 0, 113, 0, 0, 0, 0, '2013-07-20 12:12:43'),
(75, 0, 115, 0, 0, 0, 0, '2013-07-20 12:12:43'),
(76, 0, 117, 0, 0, 0, 0, '2013-07-20 12:12:43'),
(77, 0, 118, 0, 0, 0, 0, '2013-07-20 12:12:43'),
(78, 0, 116, 0, 0, 0, 0, '2013-07-20 12:12:43'),
(79, 0, 119, 0, 0, 0, 0, '2013-07-20 12:12:43'),
(80, 0, 120, 0, 0, 0, 0, '2013-07-20 12:12:43'),
(81, 3, 144, 0, 0, 0, 0, '2013-07-24 11:15:09'),
(82, 3, 143, 0, 0, 0, 0, '2013-07-24 11:15:09'),
(83, 3, 142, 0, 0, 0, 0, '2013-07-24 11:15:09'),
(84, 3, 138, 0, 0, 0, 0, '2013-07-24 11:15:09'),
(85, 3, 139, 0, 0, 0, 0, '2013-07-24 11:15:09'),
(86, 3, 145, 0, 0, 0, 0, '2013-07-24 11:15:09'),
(87, 3, 140, 0, 0, 0, 0, '2013-07-24 11:15:09'),
(88, 3, 141, 0, 0, 0, 0, '2013-07-24 11:15:09'),
(89, 0, 144, 1, 1, 1, 1, '2013-07-24 11:20:21'),
(90, 0, 143, 1, 1, 1, 1, '2013-07-24 11:20:21'),
(91, 0, 142, 0, 0, 0, 0, '2013-07-24 11:20:21'),
(92, 0, 138, 1, 1, 1, 1, '2013-07-24 11:20:21'),
(93, 0, 139, 1, 1, 1, 1, '2013-07-24 11:20:22'),
(94, 0, 145, 1, 1, 1, 1, '2013-07-24 11:20:22'),
(95, 0, 140, 1, 1, 1, 1, '2013-07-24 11:20:22'),
(96, 0, 141, 1, 1, 1, 1, '2013-07-24 11:20:22'),
(97, 0, 155, 0, 0, 0, 0, '2013-08-20 02:32:02'),
(98, 0, 241, 0, 0, 0, 0, '2013-08-20 02:32:02'),
(99, 0, 150, 0, 0, 0, 0, '2013-08-20 02:32:02'),
(100, 0, 232, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(101, 0, 228, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(102, 0, 242, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(103, 0, 156, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(104, 0, 225, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(105, 0, 224, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(106, 0, 229, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(107, 0, 151, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(108, 0, 240, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(109, 0, 223, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(110, 0, 233, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(111, 0, 227, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(112, 0, 230, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(113, 0, 152, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(114, 0, 226, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(115, 0, 153, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(116, 0, 231, 0, 0, 0, 0, '2013-08-20 02:32:03'),
(117, 0, 235, 0, 0, 0, 0, '2013-08-20 02:32:04'),
(118, 0, 154, 0, 0, 0, 0, '2013-08-20 02:32:04'),
(119, 0, 236, 0, 0, 0, 0, '2013-08-20 02:32:04'),
(120, 0, 234, 0, 0, 0, 0, '2013-08-20 02:32:04'),
(121, 5, 1, 0, 0, 0, 0, '2013-08-20 02:32:28'),
(122, 4, 1, 0, 0, 0, 0, '2013-08-20 02:32:28'),
(123, 5, 10, 0, 0, 0, 0, '2013-08-23 21:17:51'),
(124, 4, 10, 0, 0, 0, 0, '2013-08-23 21:17:51'),
(125, 0, 249, 0, 0, 0, 0, '2013-09-21 04:43:40'),
(126, 0, 253, 0, 0, 0, 0, '2013-09-21 04:43:40'),
(127, 0, 259, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(128, 0, 254, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(129, 0, 244, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(130, 0, 245, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(131, 0, 246, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(132, 0, 258, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(133, 0, 250, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(134, 0, 248, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(135, 0, 247, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(136, 0, 243, 0, 0, 0, 0, '2013-09-21 04:43:41'),
(137, 0, 251, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(138, 0, 252, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(139, 0, 256, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(140, 0, 257, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(141, 0, 255, 0, 0, 0, 0, '2013-09-21 04:43:42'),
(142, 9, 1, 0, 0, 0, 0, '2013-10-06 19:36:57'),
(143, 10, 1, 0, 0, 0, 0, '2013-10-06 19:36:57'),
(144, 6, 1, 0, 0, 0, 0, '2013-10-06 19:36:57'),
(145, 8, 1, 0, 0, 0, 0, '2013-10-06 19:36:57'),
(146, 7, 1, 0, 0, 0, 0, '2013-10-06 19:36:57');

-- --------------------------------------------------------

--
-- Table structure for table `cms_forms`
--

CREATE TABLE IF NOT EXISTS `cms_forms` (
  `idForm` int(11) NOT NULL AUTO_INCREMENT,
  `nameForm` varchar(100) NOT NULL,
  `linkForm` varchar(100) NOT NULL,
  `primaryFieldForm` varchar(100) NOT NULL,
  `displayTitleFieldForm` varchar(100) NOT NULL,
  `whereForm` varchar(500) NOT NULL DEFAULT '0',
  `onSuccessForm` varchar(500) NOT NULL,
  `onCloseForm` varchar(500) NOT NULL,
  `statusForm` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionForm` datetime NOT NULL,
  `dateUpdationForm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idForm`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `cms_forms`
--

INSERT INTO `cms_forms` (`idForm`, `nameForm`, `linkForm`, `primaryFieldForm`, `displayTitleFieldForm`, `whereForm`, `onSuccessForm`, `onCloseForm`, `statusForm`, `dateAdditionForm`, `dateUpdationForm`) VALUES
(1, 'Countries', 'quikcadvancedcms-countries', 'c.idCountry', 'c.countryCode', '', '', '', 1, '2013-08-27 04:51:10', '2013-12-30 10:10:42'),
(2, 'TimeZones', 'quikcadvancedcms-timezones', 't.idTimezone', 't.titleZone', '', '', 'javascript:LoadList(''get/list/:THIS_LINK'','':DATA_FILTER'')', 1, '2013-08-27 04:51:10', '2013-12-30 07:35:28');

-- --------------------------------------------------------

--
-- Table structure for table `cms_forms_fields`
--

CREATE TABLE IF NOT EXISTS `cms_forms_fields` (
  `idField` int(11) NOT NULL AUTO_INCREMENT,
  `idForm` int(11) NOT NULL,
  `fieldForm` varchar(100) NOT NULL,
  `titleFieldForm` varchar(100) NOT NULL,
  `typesFieldForm` varchar(100) NOT NULL,
  `setsFieldForm` varchar(100) NOT NULL,
  `orderFieldForm` int(5) NOT NULL,
  `defaultvalueFieldForm` varchar(500) NOT NULL,
  `additionalcssFieldForm` varchar(500) NOT NULL,
  `requiredFieldForm` tinyint(1) NOT NULL,
  `databasefieldFieldForm` tinyint(1) NOT NULL,
  `uniqueFieldForm` tinyint(1) NOT NULL,
  PRIMARY KEY (`idField`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=172 ;

--
-- Dumping data for table `cms_forms_fields`
--

INSERT INTO `cms_forms_fields` (`idField`, `idForm`, `fieldForm`, `titleFieldForm`, `typesFieldForm`, `setsFieldForm`, `orderFieldForm`, `defaultvalueFieldForm`, `additionalcssFieldForm`, `requiredFieldForm`, `databasefieldFieldForm`, `uniqueFieldForm`) VALUES
(94, 2, 't.keyZone', 'KeyZone', 'text', '', 0, '', '', 1, 1, 0),
(95, 2, 't.titleZone', 'TitleZone', 'text', '', 0, '', '', 1, 1, 0),
(96, 2, '', '', 'button', '', 0, 'proceed', 'class=&quot;submit-btn&quot;', 0, 1, 0),
(163, 1, 'c.countryCode', 'Country Code', 'text', '', 1, '', '', 1, 1, 1),
(164, 1, 'c.countryName', 'Country Name', 'text', '', 2, '', '', 1, 1, 0),
(165, 1, 'c.currencyCode', 'Currency Code', 'text', '', 3, '', '', 0, 1, 0),
(166, 1, 'c.population', 'Population', 'text', '', 4, '', '', 0, 1, 0),
(167, 1, 'c.fipsCode', 'Fips Code', 'text', '', 5, '', '', 0, 1, 0),
(168, 1, 'c.continentName', 'Continent Name', 'text', '', 7, '', '', 0, 1, 0),
(169, 1, '', '', 'button', '', 10, 'Update', 'class="submit-btn"', 0, 0, 0),
(170, 1, 'cd.description', 'Description', 'text', '', 8, '', '', 1, 1, 0),
(171, 1, 'cd.another', 'Another', 'text', '', 9, '', '', 1, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cms_forms_tables`
--

CREATE TABLE IF NOT EXISTS `cms_forms_tables` (
  `idTable` int(11) NOT NULL AUTO_INCREMENT,
  `idForm` int(11) NOT NULL,
  `tableForm` varchar(200) NOT NULL,
  `identifierTableForm` varchar(50) NOT NULL,
  `joinTypeTable` varchar(100) NOT NULL,
  `joinOnTable` varchar(200) NOT NULL,
  `multiLanguageField` varchar(200) NOT NULL,
  PRIMARY KEY (`idTable`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `cms_forms_tables`
--

INSERT INTO `cms_forms_tables` (`idTable`, `idForm`, `tableForm`, `identifierTableForm`, `joinTypeTable`, `joinOnTable`, `multiLanguageField`) VALUES
(18, 2, 'time_zones', 't', '', '', ''),
(29, 1, 'countries', 'c', '', '', ''),
(30, 1, 'countries_desc', 'cd', 'join', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cms_lists`
--

CREATE TABLE IF NOT EXISTS `cms_lists` (
  `idList` int(11) NOT NULL AUTO_INCREMENT,
  `nameList` varchar(100) NOT NULL,
  `linkList` varchar(100) NOT NULL,
  `whereList` varchar(500) NOT NULL DEFAULT '0',
  `sortByFieldList` varchar(200) NOT NULL,
  `sortOrderFieldList` varchar(200) NOT NULL,
  `primaryFieldList` varchar(200) NOT NULL,
  `statusFieldList` varchar(200) NOT NULL,
  `multiLanguageFieldList` varchar(200) NOT NULL,
  `pagePaginationList` int(11) DEFAULT NULL,
  `rowsPaginationList` int(11) DEFAULT NULL,
  `pagesPaginationList` int(11) DEFAULT NULL,
  `actionsList` varchar(200) NOT NULL,
  `editActionLink` varchar(200) NOT NULL,
  `statusList` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionList` datetime NOT NULL,
  `dateUpdationList` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idList`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cms_lists`
--

INSERT INTO `cms_lists` (`idList`, `nameList`, `linkList`, `whereList`, `sortByFieldList`, `sortOrderFieldList`, `primaryFieldList`, `statusFieldList`, `multiLanguageFieldList`, `pagePaginationList`, `rowsPaginationList`, `pagesPaginationList`, `actionsList`, `editActionLink`, `statusList`, `dateAdditionList`, `dateUpdationList`) VALUES
(1, 'Countries', 'quikcadvancedcms-countries', '', 'c.countryName', 'asc', 'c.idCountry', '', '', 0, 15, 0, 'edit-delete', '', 0, '2013-08-27 04:51:10', '2013-12-30 08:26:08'),
(2, 'Timezones', 'quikcadvancedcms-timezones', '', 't.titleZone', 'asc', 't.idTimezone', '', '', 0, 15, 0, 'status-edit-delete', '', 0, '2013-08-27 04:51:10', '2013-12-30 07:34:24'),
(3, 'sainath', 'sainath', '', '', 'asc', 'cms_forms.idForm', 'cms_forms.statusForm', '', 0, 0, 0, 'status-edit-delete', '', 1, '2013-12-28 12:44:57', '2013-12-28 07:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `cms_lists_fields`
--

CREATE TABLE IF NOT EXISTS `cms_lists_fields` (
  `idField` int(11) NOT NULL AUTO_INCREMENT,
  `idList` int(11) NOT NULL,
  `fieldList` varchar(100) NOT NULL,
  `titleFieldList` varchar(100) NOT NULL,
  `displayFieldList` varchar(1000) NOT NULL DEFAULT ':data',
  `typesFieldList` varchar(100) NOT NULL,
  `setsFieldList` varchar(100) NOT NULL,
  `orderFieldList` int(5) NOT NULL,
  `showFieldList` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idField`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=138 ;

--
-- Dumping data for table `cms_lists_fields`
--

INSERT INTO `cms_lists_fields` (`idField`, `idList`, `fieldList`, `titleFieldList`, `displayFieldList`, `typesFieldList`, `setsFieldList`, `orderFieldList`, `showFieldList`) VALUES
(33, 2, 't.keyZone', 'Key', ':data', 'text', '', 0, 1),
(34, 2, 't.titleZone', 'Title', ':data', 'text', '', 0, 1),
(35, 2, 't.timeCreated', 'Created On', ':data', 'date', '', 0, 1),
(36, 2, 't.timeUpdated', 'Updated On', ':data', 'date', '', 0, 1),
(113, 3, 'cms_forms.idForm', 'Id Form', ':data', 'text', '', 5, 1),
(114, 3, 'cms_forms.nameForm', 'Name Form', ':data', 'text', '', 10, 1),
(115, 3, 'cms_forms.linkForm', 'Link Form', ':data', 'text', '', 15, 1),
(116, 3, 'cms_forms.primaryFieldForm', 'Primary Field Form', ':data', 'text', '', 20, 1),
(117, 3, 'cms_forms.displayTitleFieldForm', 'Display Title Field Form', ':data', 'text', '', 25, 1),
(118, 3, 'cms_forms.whereForm', 'Where Form', ':data', 'text', '', 30, 1),
(119, 3, 'cms_forms.onSuccessForm', 'On Success Form', ':data', 'text', '', 35, 1),
(120, 3, 'cms_forms.onCloseForm', 'On Close Form', ':data', 'text', '', 40, 1),
(121, 3, 'cms_forms.statusForm', 'Status Form', ':data', 'select', 'status', 45, 1),
(122, 3, 'cms_forms.dateAdditionForm', 'Date Addition Form', ':data', 'date', '', 50, 1),
(123, 3, 'cms_forms.dateUpdationForm', 'Date Updation Form', ':data', 'date', '', 55, 1),
(131, 1, 'c.idCountry', 'Country Id', 'id#:data', 'text', '', 1, 1),
(132, 1, 'c.countryCode', 'Country Code', ':data', 'text', '', 2, 1),
(133, 1, 'c.countryName', 'Country Name', ':data', 'text', '', 3, 1),
(134, 1, 'c.currencyCode', 'Country Currenty', ':data', 'text', '', 4, 1),
(135, 1, 'c.capital', 'Country Capital', ':data', 'text', '', 5, 1),
(136, 1, 'c.continentName', 'Continent Name', ':data', 'text', '', 6, 0),
(137, 1, 'c.continent', 'Continent Code', ':data', 'text', '', 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cms_lists_tables`
--

CREATE TABLE IF NOT EXISTS `cms_lists_tables` (
  `idTable` int(11) NOT NULL AUTO_INCREMENT,
  `idList` int(11) NOT NULL,
  `tableList` varchar(200) NOT NULL,
  `identifierTableList` varchar(50) NOT NULL,
  `joinTypeTable` varchar(100) NOT NULL,
  `joinOnTable` varchar(200) NOT NULL,
  PRIMARY KEY (`idTable`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `cms_lists_tables`
--

INSERT INTO `cms_lists_tables` (`idTable`, `idList`, `tableList`, `identifierTableList`, `joinTypeTable`, `joinOnTable`) VALUES
(6, 2, 'time_zones', 't', '', ''),
(17, 3, 'cms_forms', 'cms_forms', '', ''),
(19, 1, 'countries', 'c', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cms_messages_log`
--

CREATE TABLE IF NOT EXISTS `cms_messages_log` (
  `idMessage` int(11) NOT NULL AUTO_INCREMENT,
  `keyMessage` varchar(100) NOT NULL,
  `contentMessage` varchar(500) NOT NULL,
  `statusMessage` tinyint(1) NOT NULL,
  `createdById` varchar(100) NOT NULL,
  `createdByType` varchar(100) NOT NULL,
  `dateAdditionMessage` datetime NOT NULL,
  `dateUpdationMessage` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idMessage`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=219 ;

--
-- Dumping data for table `cms_messages_log`
--

INSERT INTO `cms_messages_log` (`idMessage`, `keyMessage`, `contentMessage`, `statusMessage`, `createdById`, `createdByType`, `dateAdditionMessage`, `dateUpdationMessage`) VALUES
(1, 'lists.create.new.button', 'Create New', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(2, 'lists.filter.search.in', 'Search In', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(3, 'lists.filter.sort.by', 'Sort By', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(4, 'lists.pagination.per.page', 'Per Page', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(5, 'lists.pagination.page', 'Page:', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(6, 'lists.no.records', 'No Records Found', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(7, 'lists.pagination.go', 'Go', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(8, 'lists.filter.go', 'Go', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(9, 'lists.filter.placeholder.query', 'Query', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(10, 'general.no.permissions', 'You don''t have enough permissions', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(11, 'lists.admin.table.action.status', 'Default Status action can''t be performed for this table :TABLE_NAME', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(12, 'lists.admin.table.action.delete', 'Default delete action can''t be performed because of admin tables :TABLE_NAME', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(13, 'forms.link.close', 'Close', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(14, 'lists.invalid.list', 'Invalid List :LIST_LINK', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(15, 'lists.disabled.list', 'List :LIST_NAME disabled', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(16, 'forms.disabled.form', 'Form :FORM_NAME disabled', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(17, 'forms.label.creating.new', 'Creating New :FORM_NAME', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(18, 'forms.label.editing', 'Editing :FORM_NAME', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(19, 'forms.invalid.form', 'Invalid Form :FORM_LINK', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(20, 'forms.validation.empty.field', 'Please Enter :FIELD_NAME', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(21, 'forms.validation.invalid.email', 'Please Enter Valid :FIELD_NAME', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(22, 'lists.pagination.previous', 'Previous', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(23, 'lists.pagination.next', 'Next', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(24, 'lists.superadministrator.amenus.title', 'Admin Menus', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(25, 'forms.amenus.disable.system.menu', 'Can''t change the status of System Menu '':MENU_TITLE''', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(26, 'lists.superadministrator.ausers.title', 'Admins', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(27, 'lists.categories.title', 'Categories', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(28, 'lists.cms.blocks.title', 'Blocks', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(29, 'lists.cms.forms.title', 'Forms', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(30, 'lists.cms.lists.title', 'Lists', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(31, 'lists.cms.pages.title', 'Pages', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(32, 'lists.cms.sets.title', 'Sets', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(33, 'lists.cms.themes.title', 'Themes', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(35, 'lists.superadministrator.languages.title', 'Languages', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(36, 'forms.amenus.delete.system.menu', 'Can''t delete System Menus  '':MENU_TITLE''', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(37, 'forms.validation.email.exists', 'Email already Exists.', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(38, 'forms.validation.superadmin.email', 'Atleast one super admin should present.', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(39, 'forms.validation.superadmin.email.delete', 'Can''t delete super admins.', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(40, 'forms.validation.superadmin.permissions', 'You don''t have enough Permissions or Atleast one active super admin should present', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(41, 'forms.validation.themes.status', 'You can''t deactivate your theme. Please active another theme and this theme will be deactivated automatically', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(42, 'forms.validation.languages.actvation', 'Default language can''t be deactivated . You can only select other languages as your default language.', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(43, 'forms.cms.lists.title', 'Lists', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(44, 'forms.validation.lists.link.exists', 'List Link '':LINK_LIST''  already exists', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(45, 'forms.validation.lists.valid.identifier', 'Please add valid table identifier for the Column '':IDENTIFIER_TITLE''', 1, '1', 'user', '2013-06-01 06:12:15', '2013-08-27 23:55:38'),
(46, 'forms.cms.lists.list.name', 'List Name', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(47, 'forms.cms.lists.list.link', 'List Link', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(48, 'forms.cms.lists.list.tables', 'List Tables', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(49, 'forms.cms.lists.tables.add.more', 'Add More', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(50, 'forms.cms.lists.where.query', 'Where Query', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(51, 'forms.cms.lists.fields.display', 'Fields to Display', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(52, 'forms.cms.lists.fields.add.more', 'Add New Field', 1, '1', 'user', '2013-06-01 06:12:15', '2013-07-20 09:14:50'),
(53, 'forms.cms.lists.default.sortby', 'Default Sortby', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(54, 'general.descending', 'Descending', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(55, 'general.ascending', 'Ascending', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(56, 'forms.cms.lists.placeholder.field.sortby', 'Field Name', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(57, 'forms.cms.lists.placeholder.field.primary', 'Primary Field', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(58, 'forms.cms.lists.placeholder.field.status', 'Status Field', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(59, 'forms.cms.lists.placeholder.field.multi.language', 'Multi Language Field', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(60, 'forms.cms.lists.field.primary', 'Primary', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(61, 'forms.cms.lists.field.status', 'Status', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(62, 'forms.cms.lists.field.multi.language', 'Language', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(63, 'forms.cms.lists.fields', 'Fields', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(64, 'forms.cms.lists.pagination.options', 'Pagination Options', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(65, 'forms.cms.lists.pagination.pages', 'Pages', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(66, 'forms.cms.lists.pagination.rows', 'Rows', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(67, 'forms.cms.lists.pagination.page', 'Page', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(68, 'forms.cms.lists.placeholder.pagination.page', 'Default Page No', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(69, 'forms.cms.lists.placeholder.pagination.rows', 'Rows Per Page', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(70, 'forms.cms.lists.placeholder.pagination.pages', 'No of Pages', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(71, 'forms.cms.lists.actions', 'Actions', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(72, 'forms.cms.lists.save.list', 'Save List', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(73, 'forms.cms.lists.placeholder.table.identifier', 'Table Identifier', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(74, 'forms.cms.lists.placeholder.table.join.on', 'Join On', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(75, 'forms.cms.lists.placeholder.field', 'Field', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(76, 'forms.cms.lists.placeholder.field.title', 'Field Title', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(77, 'forms.cms.lists.placeholder.field.order', 'Order', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(78, 'forms.cms.lists.field.type', 'Type:', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(79, 'forms.cms.lists.error.empty.list.name', 'Please Enter List Name', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(80, 'forms.cms.lists.error.empty.list.link', 'Please Enter List Link', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(81, 'forms.cms.lists.error.no.tables', 'Please Enter Atleast one Table', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(82, 'forms.cms.lists.error.no.display.fields', 'Please Enter The fields to display', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(84, 'forms.superadministrator.adminmenus.title', 'New Admin Menu', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(85, 'forms.settings.profile.title', 'Edit Your Profile', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(86, 'forms.settings.password.title', 'Change Password', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(87, 'forms.superadministrator.adminusers.title', 'New Admin User', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(89, 'forms.categories.title', 'Create New Category', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(90, 'forms.cms.blocks.title', 'New Block', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(91, 'forms.cms.pages.title', 'New Page', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(92, 'forms.administrator.login.title', 'Administrator - Login', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(93, 'forms.superadministrator.languages.title', 'New Language', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(94, 'mails.empty.from', 'Enter from address', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(95, 'mails.empty.subject', 'Enter subject of the mail', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(96, 'mails.empty.body', 'Enter body of the mail', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(97, 'mails.invalid.from', 'Enter valid from address', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(98, 'mails.empty.to', 'Enter atleast one to address', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(99, 'mails.invalid.to', 'Enter valid To address', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(100, 'forms.validation.loginuser.status', 'Can''t change the status of Current User', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(101, 'forms.validation.loginuser.delete', 'Can''t delete Current User', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(102, 'lists.superadministrator.alogactivity.title', 'Admin Log Activity', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(103, 'forms.validation.lists.databasetable.exists', 'Table :TABLE_NAME doesnot exist in the database', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(104, 'forms.validation.lists.multiple.table.entry', 'Table :MULTIPLE_TABLE entered multiple times', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(105, 'forms.validation.lists.multiple.identifier.entry', 'Table identifier :MULTIPLE_IDENTIFIER entered multiple times', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(106, 'forms.validation.lists.column.exist.table', 'Column :COLUMN_NAME doesnot exist in the Table :COLUMN_TABLE', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(107, 'forms.cms.forms.error.empty.form.name', 'Please Enter Form Name', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(108, 'forms.cms.forms.error.empty.form.link', 'Please Enter Form Link', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(109, 'forms.cms.forms.validate.form.link.exists', 'Form Link :FORM_LINK already exists', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(110, 'forms.settings.lists.validate.new.password.match', 'New password didn''t match.', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(111, 'forms.settings.lists.validate.password', 'Your password should contain atleast One letter, One caps, One number, One symbol and inbetween 8 to 20 characters.', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(112, 'forms.settings.lists.validate.old.password.match', 'Your old password didn''t match', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(113, 'forms.tables.count', 'No of tables must be less than 100', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(114, 'forms.error.email.password', 'Invalid Email or Password', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(115, 'forms.validate.account.disabled', 'Your account has been disabled', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(116, 'forms.error.validate.captcha', 'Wrong Security Code', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(117, 'forms.cms.sets.error.empty.set.name', 'Please Enter Set Name', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(118, 'forms.cms.sets.error.empty.set.link', 'Please Enter Set Link', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(119, 'forms.validation.sets.link.exists', 'Set Link :LINK_SET already exists', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(120, 'forms.cms.sets.error.empty.key.field', 'Please Enter Key Field', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(121, 'forms.cms.sets.error.empty.display.field', 'Please Enter Display Field', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(122, 'forms.cms.sets.error.empty.option', 'Please Enter Atlease one Option', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(123, 'lists.plugins.title', 'Plugins', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(124, 'lists.filter.Searchin', 'Search in:', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(125, 'lists.filter.Sortby', 'Sort By', 1, '1', 'user', '2013-06-01 06:12:15', '2013-05-30 07:42:15'),
(130, 'lists.cms.messagelogs.title', 'Message Logs', 1, '1', 'user', '2013-06-01 06:53:46', '2013-05-30 08:37:30'),
(131, 'forms.cms.messagelogs.title', 'New Message', 1, '1', 'user', '2013-06-01 06:54:40', '2013-05-30 08:37:36'),
(133, 'lists.cms.countries.title', 'Countries', 1, '7', 'user', '2013-06-04 22:27:22', '2013-06-02 23:57:22'),
(134, 'forms.cms.mails.title', 'Creating New Mail', 1, '7', 'user', '2013-06-04 22:52:11', '2013-06-03 00:22:11'),
(135, 'forms.cms.countries.title', 'New Country', 1, '7', 'user', '2013-06-04 22:28:42', '2013-06-02 23:58:42'),
(136, 'lists.cms.mails.title', 'Mails', 1, '7', 'user', '2013-06-04 22:52:54', '2013-06-03 00:22:54'),
(137, 'forms.superadministrator.config.title', 'Creating New Configuration', 1, '7', 'user', '2013-06-04 23:59:54', '2013-06-03 01:29:54'),
(138, 'lists.superadministrator.config.title', 'Configurations', 1, '7', 'user', '2013-06-05 00:00:42', '2013-06-03 01:30:42'),
(139, 'forms.login.super.admin.only', 'Only Super Admins are allowed to login', 1, '1', 'user', '2013-06-14 03:17:47', '2013-06-12 04:47:47'),
(216, 'lists.media.categories.title', 'Media Categories', 1, 'quikcmedia', 'plugin', '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(215, 'lists.media.categories.cms.title', 'Media Categories', 1, 'quikcmedia', 'plugin', '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(214, 'forms.validation.invalid.date', 'Please Enter Valid :FIELD_NAME', 1, '1', 'user', '2013-08-16 05:32:40', '2013-08-16 00:03:04'),
(217, 'lists.media.title', 'Media', 1, 'quikcmedia', 'plugin', '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(218, 'lists.export', 'Export', 1, '1', 'user', '2013-10-14 05:39:14', '2013-10-14 00:09:14');

-- --------------------------------------------------------

--
-- Table structure for table `cms_pages`
--

CREATE TABLE IF NOT EXISTS `cms_pages` (
  `idPage` int(11) NOT NULL AUTO_INCREMENT,
  `namePage` varchar(100) NOT NULL,
  `linkPage` varchar(500) NOT NULL,
  `themePage` varchar(200) NOT NULL,
  `templatePage` varchar(200) NOT NULL,
  `requireLogin` tinyint(1) NOT NULL DEFAULT '0',
  `defaultPage` tinyint(1) NOT NULL DEFAULT '0',
  `descriptionPage` varchar(500) NOT NULL,
  `robotsPage` varchar(20) NOT NULL,
  `statusPage` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionPage` datetime NOT NULL,
  `dateUpdationPage` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idPage`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cms_pages`
--

INSERT INTO `cms_pages` (`idPage`, `namePage`, `linkPage`, `themePage`, `templatePage`, `requireLogin`, `defaultPage`, `descriptionPage`, `robotsPage`, `statusPage`, `dateAdditionPage`, `dateUpdationPage`) VALUES
(1, 'Welcome Page', 'welcome-page', 'global', 'contact', 0, 0, '', 'global', 0, '2013-04-22 12:59:45', '2013-12-21 07:27:26'),
(2, 'Default', 'default', 'global', 'default', 0, 1, 'default page meta description', 'global', 1, '2013-06-19 13:45:21', '2013-08-28 22:18:11'),
(3, 'Privacy', 'privacy', 'global', 'privacy', 1, 0, '', 'noindex, follow', 1, '2013-08-06 04:16:48', '2013-12-27 06:41:56'),
(4, 'Services', 'services', 'global', 'services', 0, 0, '', 'global', 1, '2013-08-24 19:16:55', '2013-08-28 22:18:32');

-- --------------------------------------------------------

--
-- Table structure for table `cms_sets`
--

CREATE TABLE IF NOT EXISTS `cms_sets` (
  `idSet` int(11) NOT NULL AUTO_INCREMENT,
  `linkSet` varchar(100) NOT NULL,
  `nameSet` varchar(100) NOT NULL,
  `databaseSet` tinyint(1) NOT NULL,
  `whereSet` varchar(500) NOT NULL,
  `keyFieldSet` varchar(100) NOT NULL,
  `displayFieldSet` varchar(100) NOT NULL,
  `sortFieldSet` varchar(100) NOT NULL,
  `sortOrderFieldSet` varchar(50) NOT NULL,
  `nestedFieldSet` varchar(100) NOT NULL,
  `nestedStartSet` varchar(100) NOT NULL,
  `groupbyFieldSet` varchar(100) NOT NULL,
  `statusSet` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionSet` datetime NOT NULL,
  `dateUpdationSet` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idSet`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `cms_sets`
--

INSERT INTO `cms_sets` (`idSet`, `linkSet`, `nameSet`, `databaseSet`, `whereSet`, `keyFieldSet`, `displayFieldSet`, `sortFieldSet`, `sortOrderFieldSet`, `nestedFieldSet`, `nestedStartSet`, `groupbyFieldSet`, `statusSet`, `dateAdditionSet`, `dateUpdationSet`) VALUES
(1, 'gender', 'Gender', 0, '', '', '', '', '', '', '', '', 1, '2013-05-15 00:00:00', '2013-05-14 02:44:31'),
(2, 'countries', 'Countries', 1, '', 'c.countryCode', 'c.countryName', 'c.countryName', 'asc', '', '', '', 1, '2013-05-16 00:07:48', '2013-07-24 15:58:28'),
(3, 'yesno', 'Yes No', 0, '', '', '', '', '', '', '', '', 1, '2013-05-16 00:09:27', '2013-05-14 02:43:22'),
(4, 'status', 'Status', 0, '', '', '', '', '', '', '', '', 1, '2013-05-16 00:10:02', '2013-05-14 02:43:05'),
(5, 'timezones', 'Time Zones', 1, '', 't.keyZone', 't.titleZone', '', '', '', '', '', 1, '2013-05-16 00:12:14', '2013-05-14 02:43:15'),
(6, 'months', 'Months', 0, '', '', '', '', '', '', '', '', 1, '2013-05-16 01:12:43', '2013-05-14 02:42:43'),
(7, 'weeks', 'Weeks', 0, '', '', '', '', '', '', '', '', 1, '2013-05-16 03:37:29', '2013-05-14 05:07:29'),
(8, 'maritalstatus', 'Marital Status', 0, '', '', '', '', '', '', '', '', 1, '2013-05-16 03:41:09', '2013-05-14 05:11:09'),
(10, 'logactivity', 'Admin Log Activity', 0, '', 'al.id', 'al.status', '', '', '', '', '', 1, '2013-05-24 03:39:39', '2013-05-25 04:28:44'),
(11, 'adminmodes', 'Admin Login Modes', 0, '', '', '', '', '', '', '', '', 1, '2013-06-06 23:16:22', '2013-06-20 01:47:39'),
(14, 'media', 'Media', 0, '', '', '', '', '', '', '', '', 1, '2013-07-17 14:08:58', '2013-07-28 02:15:38'),
(15, 'file', 'File', 0, '', '', '', '', '', '', '', '', 1, '2013-07-17 14:10:57', '2013-07-17 05:10:57'),
(16, 'mailservers', 'Mailer Lists', 0, '', '', '', '', '', '', '', '', 1, '2013-07-25 17:21:43', '2013-07-25 10:41:24'),
(17, 'cacheservers', 'Cache Server', 0, '', '', '', '', '', '', '', '', 1, '2013-07-28 11:03:26', '2013-07-28 02:32:40'),
(21, 'themes', 'Themes', 1, '', 'ct.pathTheme', 'ct.nameTheme', 'ct.nameTheme', 'asc', '', '', '', 1, '2013-07-30 03:41:44', '2013-08-23 21:12:09'),
(22, 'robots', 'Robots', 0, '', '', '', '', '', '', '', '', 1, '2013-08-06 14:26:02', '2013-08-06 05:26:02'),
(23, 'categories', 'categories', 1, '', 'mc.idCategory', 'mc.nameCategory', 'mc.nameCategory', 'asc', '', '', '', 1, '2013-08-12 09:29:35', '2013-08-12 03:59:35'),
(24, 'widgets', 'widgets', 1, '', 'w.idWidget', 'w.titleWidget', 'w.titleWidget', 'asc', '', '', '', 1, '2013-08-19 09:00:43', '2013-08-19 03:30:43'),
(25, 'pages', 'Pages', 1, '', 'cp.idPage', 'cp.namePage', 'cp.namePage', 'asc', '', '', '', 1, '2013-08-25 05:27:35', '2013-08-24 23:57:35'),
(26, 'spaces', 'Spaces', 1, '', 's.idSpace', 's.titleSpace', 's.titleSpace', 'asc', '', '', '', 1, '2013-08-25 05:28:55', '2013-08-24 23:58:55'),
(27, 'menus', 'Menus', 1, 'm.statusMenu =  1', 'm.idMenu', 'm.titleMenu', 'm.titleMenu', 'asc', '', '', '', 1, '2013-10-21 03:45:35', '2013-10-20 22:15:35');

-- --------------------------------------------------------

--
-- Table structure for table `cms_sets_options`
--

CREATE TABLE IF NOT EXISTS `cms_sets_options` (
  `idOption` int(11) NOT NULL AUTO_INCREMENT,
  `idSet` int(11) NOT NULL,
  `keyOption` varchar(100) NOT NULL,
  `titleOption` varchar(100) NOT NULL,
  `statusOption` tinyint(1) NOT NULL DEFAULT '1',
  `orderOption` int(5) NOT NULL,
  PRIMARY KEY (`idOption`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=275 ;

--
-- Dumping data for table `cms_sets_options`
--

INSERT INTO `cms_sets_options` (`idOption`, `idSet`, `keyOption`, `titleOption`, `statusOption`, `orderOption`) VALUES
(1, 6, '1', 'January', 1, 1),
(2, 6, '2', 'February', 1, 2),
(3, 6, '3', 'March', 1, 3),
(4, 6, '4', 'April', 1, 4),
(5, 6, '5', 'May', 1, 5),
(6, 6, '6', 'June', 1, 6),
(7, 6, '7', 'July', 1, 7),
(8, 6, '8', 'August', 1, 8),
(9, 6, '9', 'September', 1, 9),
(10, 6, '10', 'Octomber', 1, 10),
(11, 6, '11', 'November', 1, 11),
(12, 6, '12', 'December', 1, 12),
(13, 4, '1', 'Enable', 1, 0),
(14, 4, '0', 'Disable', 1, 1),
(24, 8, '1', 'Married', 1, 1),
(25, 8, '2', 'Unmarried', 1, 2),
(26, 1, '0', 'Female', 1, 0),
(27, 1, '1', 'Male', 1, 1),
(28, 11, '0', 'Admin Mode', 1, 0),
(29, 11, '1', 'Developer Mode', 1, 0),
(87, 15, '0', 'xls', 1, 1),
(88, 15, '1', 'doc', 1, 2),
(197, 16, 'defaultphpmailer', 'Default Php Mail', 1, 1),
(199, 10, '0', 'Login failed', 1, 1),
(200, 10, '1', 'Logged in ', 1, 2),
(201, 10, '2', 'Logged out ', 1, 3),
(202, 10, '3', 'Updated '':data'' profile ', 1, 4),
(203, 10, '4', 'Updated '':data'' password', 1, 5),
(204, 10, '5', 'Admin menu '':data'' created', 1, 6),
(205, 10, '29', 'Admin menu '':data'' deleted', 1, 7),
(206, 10, '6', 'Admin menu '':data'' updated ', 1, 7),
(207, 10, '27', 'Admin menu '':data'' enabled', 1, 7),
(208, 10, '28', 'Admin menu '':data'' disabled', 1, 7),
(209, 10, '26', 'Admin menu '':data'' status changed', 1, 7),
(210, 10, '7', 'Backup '':data'' created', 1, 8),
(211, 10, '8', 'Backup name '':data'' updated', 1, 9),
(212, 10, '9', 'Backup '':data'' deleted', 1, 10),
(213, 10, '48', 'Failed attempt to download the backup '':data'' (No file exists)', 1, 11),
(214, 10, '10', 'Backup '':data'' downloaded', 1, 11),
(215, 10, '47', 'Failed attempt to download the backup '':data'' (Restricted Access)', 1, 11),
(216, 10, '11', 'Gallery image uploaded', 1, 12),
(217, 10, '12', 'Gallery image updated', 1, 13),
(218, 10, '13', 'Gallery image deleted', 1, 14),
(219, 10, '14', 'Created admin account '':data''', 1, 15),
(220, 10, '15', 'Updated admin account '':data''', 1, 16),
(221, 10, '16', ' admin account '':data'' status changed', 1, 17),
(222, 10, '17', 'Deleted admin account '':data''', 1, 18),
(223, 10, '18', 'Created List ', 1, 19),
(224, 10, '19', 'Updated List', 1, 20),
(225, 10, '20', 'Updated List Status', 1, 21),
(226, 10, '21', 'Deleted List', 1, 22),
(227, 10, '22', 'Created Form', 1, 23),
(228, 10, '23', 'Updated Form', 1, 24),
(229, 10, '24', 'Updated Form Status', 1, 25),
(230, 10, '25', 'Deleted Form', 1, 26),
(231, 10, '30', 'Gallery Category '':data'' Created', 1, 27),
(232, 10, '31', 'Gallery Category '':data'' Updated', 1, 28),
(233, 10, '32', 'Gallery Category'':data'' status changed', 1, 29),
(234, 10, '33', 'Gallery Category '':data'' Deleted', 1, 30),
(235, 10, '34', 'Language '':data'' Created', 1, 31),
(236, 10, '35', 'Language '':data'' Updated', 1, 32),
(237, 10, '36', 'Language '':data'' Deleted', 1, 33),
(238, 10, '37', 'Language '':data'' Status Changed', 1, 34),
(239, 10, '38', 'Language '':data'' disabled', 1, 35),
(240, 10, '39', 'Language '':data'' Enabled', 1, 36),
(241, 10, '40', 'Global Permissions Updated', 1, 37),
(242, 10, '41', 'Categories '':data'' Created', 1, 38),
(243, 10, '42', 'Categories '':data'' Updated', 1, 39),
(244, 10, '43', 'Plugin '':data'' Status Changed', 1, 40),
(245, 10, '44', 'Plugin '':data'' Enabled', 1, 41),
(246, 10, '45', 'Plugin '':data'' Disabled', 1, 42),
(247, 10, '46', 'Plugin '':data'' Updated', 1, 43),
(248, 10, '49', 'New Admin Group '':data'' Created', 1, 44),
(249, 10, '50', 'Admin Group '':data'' Updated', 1, 45),
(250, 10, '51', 'Admin Group '':data'' Enabled', 1, 46),
(251, 10, '52', 'Admin Group '':data'' Disabled', 1, 47),
(252, 10, '53', 'Admin Group '':data'' Status changed', 1, 48),
(253, 10, '54', 'Admin Group '':data'' Deleted', 1, 49),
(256, 7, '1', 'Monday', 1, 1),
(257, 7, '2', 'Tuesday', 1, 2),
(258, 7, '3', 'Wednesday', 1, 3),
(259, 7, '4', 'Thursday', 1, 4),
(260, 7, '5', 'Friday', 1, 5),
(261, 7, '6', 'Saturday', 1, 6),
(262, 7, '7', 'Sunday', 1, 7),
(263, 14, '0', 'jpeg', 1, 1),
(264, 14, '1', 'jpg', 1, 2),
(265, 14, '2', 'gif', 1, 3),
(266, 14, '3', 'png', 1, 4),
(268, 17, 'defaultcache', 'Default Cache(File Cache)', 1, 0),
(269, 22, 'index, follow', 'Index and Follow', 1, 1),
(270, 22, 'index, nofollow', 'Index but not Follow', 1, 5),
(271, 22, 'noindex, follow', 'Not Index but Follow', 1, 10),
(272, 22, 'noindex, nofollow', 'Not Index and Not Follow', 1, 15),
(273, 3, '0', 'No', 1, 1),
(274, 3, '1', 'Yes', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_sets_tables`
--

CREATE TABLE IF NOT EXISTS `cms_sets_tables` (
  `idTable` int(11) NOT NULL AUTO_INCREMENT,
  `idSet` int(11) NOT NULL,
  `tableSet` varchar(200) NOT NULL,
  `identifierTableSet` varchar(50) NOT NULL,
  `joinTypeTable` varchar(100) NOT NULL,
  `joinOnTable` varchar(200) NOT NULL,
  `multiLanguageField` varchar(200) NOT NULL,
  PRIMARY KEY (`idTable`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `cms_sets_tables`
--

INSERT INTO `cms_sets_tables` (`idTable`, `idSet`, `tableSet`, `identifierTableSet`, `joinTypeTable`, `joinOnTable`, `multiLanguageField`) VALUES
(1, 5, 'time_zones', 't', '', '', ''),
(7, 2, 'countries', 'c', '', '', ''),
(22, 23, 'media_categories', 'mc', '', '', ''),
(23, 24, 'widgets', 'w', '', '', ''),
(27, 21, 'cms_themes', 'ct', '', '', ''),
(29, 26, 'spaces', 's', '', '', ''),
(30, 25, 'cms_pages', 'cp', '', '', ''),
(31, 27, 'menus', 'm', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cms_themes`
--

CREATE TABLE IF NOT EXISTS `cms_themes` (
  `idTheme` int(11) NOT NULL AUTO_INCREMENT,
  `nameTheme` varchar(100) NOT NULL,
  `pathTheme` varchar(500) NOT NULL,
  `statusTheme` tinyint(1) NOT NULL DEFAULT '0',
  `dateAdditionTheme` datetime NOT NULL,
  `dateUpdationTheme` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idTheme`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=78 ;

--
-- Dumping data for table `cms_themes`
--

INSERT INTO `cms_themes` (`idTheme`, `nameTheme`, `pathTheme`, `statusTheme`, `dateAdditionTheme`, `dateUpdationTheme`) VALUES
(72, 'default', 'default', 0, '2013-07-29 13:02:54', '2013-08-07 04:30:36'),
(75, 'greefies', 'greefies', 1, '2013-08-04 00:55:00', '2013-08-28 16:15:27'),
(77, 'kallyas', 'kallyas', 0, '2013-08-07 13:29:46', '2013-08-28 16:15:27');

-- --------------------------------------------------------

--
-- Table structure for table `cms_themes_files`
--

CREATE TABLE IF NOT EXISTS `cms_themes_files` (
  `idFile` int(11) NOT NULL AUTO_INCREMENT,
  `idTheme` int(11) NOT NULL,
  `nameFile` varchar(100) NOT NULL,
  `pathFile` varchar(500) NOT NULL,
  `typeFile` varchar(20) NOT NULL,
  `dateAdditionFile` datetime NOT NULL,
  `dateUpdationFile` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idFile`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `cms_themes_files`
--

INSERT INTO `cms_themes_files` (`idFile`, `idTheme`, `nameFile`, `pathFile`, `typeFile`, `dateAdditionFile`, `dateUpdationFile`) VALUES
(1, 75, 'style.css', 'css/style.css', 'css', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(2, 75, 'footer.phtml', 'elements/footer.phtml', 'phtml', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(3, 75, 'header.phtml', 'elements/header.phtml', 'phtml', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(4, 75, 'leftsidebar.phtml', 'elements/leftsidebar.phtml', 'phtml', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(5, 75, 'arrow.gif', 'images/arrow.gif', 'gif', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(6, 75, 'arrowmain0.gif', 'images/arrowmain0.gif', 'gif', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(7, 75, 'arrowmain1.gif', 'images/arrowmain1.gif', 'gif', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(8, 75, 'arrowsub.png', 'images/arrowsub.png', 'png', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(9, 75, 'box_icon.gif', 'images/box_icon.gif', 'gif', '2013-12-23 18:11:02', '2013-12-23 12:41:02'),
(10, 75, 'bullet.gif', 'images/bullet.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(11, 75, 'clock.gif', 'images/clock.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(12, 75, 'clock.png', 'images/clock.png', 'png', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(13, 75, 'contact_icon.gif', 'images/contact_icon.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(14, 75, 'contact_info_bg.gif', 'images/contact_info_bg.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(15, 75, 'footer_logo.gif', 'images/footer_logo.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(16, 75, 'green_box_bg.gif', 'images/green_box_bg.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(17, 75, 'hsep.png', 'images/hsep.png', 'png', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(18, 75, 'left_content_bg.gif', 'images/left_content_bg.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(19, 75, 'left_nav_arrow.gif', 'images/left_nav_arrow.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(20, 75, 'logo.gif', 'images/logo.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(21, 75, 'mainbk.png', 'images/mainbk.png', 'png', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(22, 75, 'menu_arrow.gif', 'images/menu_arrow.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(23, 75, 'news_icon.gif', 'images/news_icon.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(24, 75, 'orange_bullet.gif', 'images/orange_bullet.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(25, 75, 'phone_icon.gif', 'images/phone_icon.gif', 'gif', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(26, 75, 'pic1.jpg', 'images/pic1.jpg', 'jpg', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(27, 75, 'pic2.jpg', 'images/pic2.jpg', 'jpg', '2013-12-23 18:11:03', '2013-12-23 12:41:03'),
(28, 75, 'pic3.jpg', 'images/pic3.jpg', 'jpg', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(29, 75, 'read_more_bg.gif', 'images/read_more_bg.gif', 'gif', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(30, 75, 'read_more_bg_white.gif', 'images/read_more_bg_white.gif', 'gif', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(31, 75, 'right_nav.gif', 'images/right_nav.gif', 'gif', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(32, 75, 'right_nav_a.gif', 'images/right_nav_a.gif', 'gif', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(33, 75, 'search.gif', 'images/search.gif', 'gif', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(34, 75, 'search_box_bg.gif', 'images/search_box_bg.gif', 'gif', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(35, 75, 'testimonials_icon.gif', 'images/testimonials_icon.gif', 'gif', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(36, 75, 'jquery-1.10.1.min.js', 'js/jquery-1.10.1.min.js', 'js', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(37, 75, 'contact.phtml', 'templates/contact.phtml', 'phtml', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(38, 75, 'default.phtml', 'templates/default.phtml', 'phtml', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(39, 75, 'privacy.phtml', 'templates/privacy.phtml', 'phtml', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(40, 75, 'services.phtml', 'templates/services.phtml', 'phtml', '2013-12-23 18:11:04', '2013-12-23 12:41:04'),
(41, 75, 'site-offline.phtml', 'templates/site-offline.phtml', 'phtml', '2013-12-23 18:11:04', '2013-12-23 12:41:04');

-- --------------------------------------------------------

--
-- Table structure for table `configuration`
--

CREATE TABLE IF NOT EXISTS `configuration` (
  `idConfig` int(11) NOT NULL AUTO_INCREMENT,
  `keyConfig` varchar(100) NOT NULL,
  `valueConfig` longtext NOT NULL,
  `statusConfig` tinyint(1) NOT NULL DEFAULT '1',
  `systemItem` tinyint(4) NOT NULL DEFAULT '1',
  `createdById` varchar(100) NOT NULL,
  `createdByType` varchar(20) NOT NULL,
  `dateAdditionConfig` datetime NOT NULL,
  `dateUpdationConfig` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idConfig`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=131 ;

--
-- Dumping data for table `configuration`
--

INSERT INTO `configuration` (`idConfig`, `keyConfig`, `valueConfig`, `statusConfig`, `systemItem`, `createdById`, `createdByType`, `dateAdditionConfig`, `dateUpdationConfig`) VALUES
(1, 'developer.mode', '1', 1, 1, '', '', '0000-00-00 00:00:00', '2013-11-29 07:09:29'),
(2, 'logs.errors', '/developer.zone/logs/errors.log', 1, 1, '', '', '0000-00-00 00:00:00', '2013-07-25 04:42:41'),
(3, 'cache.enabled', '1', 1, 1, '', '', '0000-00-00 00:00:00', '2013-10-13 23:04:40'),
(125, 'media.sets.doc', 'xls,doc', 1, 1, 'quikcmedia', 'plugin', '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(5, 'cache.path', '/developer.zone/cache', 1, 1, '', '', '0000-00-00 00:00:00', '2013-07-25 04:41:55'),
(6, 'email.default', 'info@confianza.co.in', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-03 06:51:24'),
(7, 'admin', '/administrator', 1, 1, '', '', '0000-00-00 00:00:00', '2013-05-27 07:55:30'),
(8, 'admin.temp', '/templates/backend/default', 1, 1, '', '', '0000-00-00 00:00:00', '2013-05-27 07:55:30'),
(9, 'img', '/media/images', 1, 1, '', '', '0000-00-00 00:00:00', '2013-05-27 07:56:37'),
(10, 'doc', '/media/documents', 1, 1, '', '', '0000-00-00 00:00:00', '2013-05-27 07:57:02'),
(11, 'vid', '/media/videos', 1, 1, '', '', '0000-00-00 00:00:00', '2013-05-27 07:57:14'),
(12, 'plugins', '/plugins', 1, 1, '', '', '0000-00-00 00:00:00', '2013-05-27 07:57:48'),
(13, 'backup', '/backups', 1, 1, '', '', '0000-00-00 00:00:00', '2013-05-27 07:58:09'),
(14, 'backup.errors', '/backups/errors', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-03 05:10:44'),
(15, 'backup.files', '/backups/files', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-03 05:10:44'),
(16, 'backup.sql', '/backups/database', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-03 05:10:44'),
(17, 'plugins.store', '/developer.zone/plugins', 1, 1, '', '', '0000-00-00 00:00:00', '2013-08-01 04:01:42'),
(18, 'backend', '/backend', 1, 1, '', '', '0000-00-00 00:00:00', '2013-05-29 09:49:35'),
(19, 'website.title', 'Quikc', 1, 1, '', '', '2013-06-05 11:45:59', '2013-10-06 21:35:09'),
(20, 'login.invalid.attempts', '2', 1, 1, '', '', '2013-06-14 01:52:22', '2013-06-12 04:21:37'),
(21, 'login.session.timeout', '600', 1, 1, '', '', '2013-06-14 02:03:26', '2013-10-06 21:37:50'),
(22, 'login.invalid.show.captcha', '1', 1, 1, '', '', '2013-06-14 02:07:46', '2013-06-12 03:48:40'),
(23, 'login.invalid.send.mail', '1', 1, 1, '', '', '2013-06-14 02:07:58', '2013-06-12 03:48:40'),
(24, 'login.allow.only.super.admins', '', 1, 1, '', '', '2013-06-14 03:12:44', '2013-12-13 11:52:14'),
(25, 'mail.from.address', 'info@confianza.co.in', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-13 01:03:30'),
(26, 'mail.from.name', 'Confianza Technologies', 1, 1, '', '', '0000-00-00 00:00:00', '2013-09-21 06:57:01'),
(27, 'mail.smtp.authentication', '', 1, 1, '', '', '0000-00-00 00:00:00', '2013-09-21 06:57:01'),
(28, 'mail.smtp.security', '', 1, 1, '', '', '0000-00-00 00:00:00', '2013-09-21 06:57:01'),
(29, 'mail.smtp.host', '', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-13 01:03:30'),
(30, 'mail.smtp.username', '', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-13 01:03:30'),
(31, 'mail.smtp.password', '', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-13 01:03:30'),
(32, 'mail.smtp.port', '', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-13 01:03:30'),
(33, 'cache.time.limit', '1000', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-20 14:33:42'),
(34, 'website.logo', 'confianza-logo.png', 1, 1, '', '', '0000-00-00 00:00:00', '2013-09-21 04:38:31'),
(36, 'developer.mode.super.admins.only', '', 1, 1, '', '', '2013-06-16 01:59:24', '2013-08-29 14:34:11'),
(37, 'developer.mode.login.reset', '', 1, 1, '', '', '2013-06-16 01:59:38', '2013-12-03 08:34:38'),
(38, 'developer.mode.global', '', 1, 1, '', '', '2013-06-16 04:16:43', '2013-11-29 06:36:10'),
(39, 'developer.mode.display.helper', '1', 1, 1, '', '', '2013-06-16 05:59:37', '2013-08-25 03:44:00'),
(40, 'website.offline', '', 1, 1, '', '', '2013-06-17 00:04:21', '2013-10-06 21:35:34'),
(41, 'developer.mode.caching', '1', 1, 1, '', '', '2013-06-21 11:36:46', '2013-08-05 19:26:04'),
(42, 'cache.file.extension', 'cache', 1, 1, '', '', '0000-00-00 00:00:00', '2013-06-22 14:40:39'),
(124, 'media.sets.vid', 'flv,mp4', 1, 1, 'quikcmedia', 'plugin', '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(123, 'media.sets.img', 'jpeg,jpg,png,gif', 1, 1, 'quikcmedia', 'plugin', '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(51, 'media.allow.upload', '1', 1, 1, '1', 'user', '2013-07-16 12:23:55', '2013-10-13 23:46:05'),
(52, 'media.max.file.size', '20', 1, 1, '1', 'user', '2013-07-16 12:23:55', '2013-07-18 06:50:53'),
(122, 'media.allowed.types', 'jpeg,jpg,png,gif,flv,mp4', 1, 1, 'quikcmedia', 'plugin', '2013-08-22 08:55:02', '2013-08-22 03:25:02'),
(74, 'mail.send.server', 'defaultphpmailer', 1, 1, '1', 'user', '2013-07-25 19:43:00', '2013-07-26 05:51:14'),
(79, 'themes.store', '/developer.zone/themes', 1, 1, '', '', '2013-08-01 13:01:59', '2013-08-01 04:01:59'),
(86, 'website.fav.icon', 'confianza-logo.png', 1, 1, '1', 'user', '2013-08-06 18:02:57', '2013-09-21 04:38:31'),
(80, 'website.offline.message', 'You Are Not Allowed to View This Page', 1, 1, '1', 'user', '2013-08-06 12:27:21', '2013-09-21 04:39:02'),
(81, 'website.offline.image', 'confianza-logo.png', 1, 1, '1', 'user', '2013-08-06 12:30:25', '2013-09-21 04:39:02'),
(82, 'website.meta.description', 'Quikc cms', 1, 1, '1', 'user', '2013-08-06 14:49:32', '2013-08-27 21:24:44'),
(83, 'website.meta.keywords', 'Quikc cms, Quikc, cms', 1, 1, '1', 'user', '2013-08-06 14:49:32', '2013-08-06 05:56:47'),
(84, 'website.robots', 'index, follow', 1, 1, '1', 'user', '2013-08-06 14:49:32', '2013-08-06 09:01:35'),
(85, 'website.timezone', 'Asia/Kolkata', 1, 1, '1', 'user', '2013-08-06 14:57:00', '2013-08-06 05:57:00'),
(87, 'website.url.rewrite', '1', 1, 1, '1', 'user', '2013-08-06 19:06:55', '2013-08-06 11:18:02'),
(88, 'cache.server', 'defaultcache', 1, 1, '1', 'user', '2013-08-08 18:42:17', '2013-08-08 09:42:17'),
(89, 'quikc.advanced.lists.advanced.code.options.status', '1', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 20:21:56'),
(90, 'quikc.advanced.lists.default.actions', 'status,edit,delete', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 16:29:13'),
(91, 'quikc.advanced.lists.import.not.valid.fields', 'text,mediumtext,longtext,blob', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 17:22:15'),
(92, 'quikc.advanced.lists.import.date.types', 'datetime,timestamp,date', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 16:29:33'),
(93, 'quikc.advanced.lists.import.date.lables', '', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 16:28:20'),
(94, 'quikc.advanced.lists.import.image.types', '', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 16:28:20'),
(95, 'quikc.advanced.lists.import.image.lables', 'image,path', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 16:29:51'),
(96, 'quikc.advanced.lists.import.status.types', '', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 16:28:20'),
(97, 'quikc.advanced.lists.import.status.lables', 'status', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 17:20:57'),
(98, 'quikc.advanced.lists.import.select.types', 'tinyint(1)', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 16:30:23'),
(99, 'quikc.advanced.lists.import.select.lables', '', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 16:28:20'),
(100, 'quikc.advanced.lists.import.select.default', 'yesno', 1, 1, '1', 'user', '2013-08-14 21:58:20', '2013-08-14 17:23:36'),
(101, 'quikc.advanced.forms.advanced.code.options.status', '1', 1, 1, '1', 'user', '2013-08-15 01:24:57', '2013-08-14 20:20:56'),
(102, 'quikc.advanced.forms.import.not.valid.fields', '', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 20:26:47'),
(103, 'quikc.advanced.forms.import.email.types', '', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:54:58'),
(104, 'quikc.advanced.forms.import.email.lables', 'email', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 20:00:04'),
(105, 'quikc.advanced.forms.import.textarea.types', 'content', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-26 23:21:10'),
(106, 'quikc.advanced.forms.import.textarea.lables', 'content', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:57:24'),
(107, 'quikc.advanced.forms.import.date.types', 'datetime,timestamp,date', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:58:04'),
(108, 'quikc.advanced.forms.import.date.lables', 'date', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:58:04'),
(109, 'quikc.advanced.forms.import.image.types', '', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:58:20'),
(110, 'quikc.advanced.forms.import.image.lables', 'image,path', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:58:20'),
(111, 'quikc.advanced.forms.import.video.types', '', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:54:58'),
(112, 'quikc.advanced.forms.import.video.lables', 'vidoe', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:58:20'),
(113, 'quikc.advanced.forms.import.status.types', '', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:54:58'),
(114, 'quikc.advanced.forms.import.status.lables', 'status', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:58:39'),
(115, 'quikc.advanced.forms.import.select.types', 'tinyint(1)', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:58:39'),
(116, 'quikc.advanced.forms.import.select.lables', '', 1, 1, '1', 'user', '2013-08-15 01:24:58', '2013-08-14 19:54:58'),
(117, 'quikc.advanced.forms.import.select.default', 'yesno', 1, 1, '1', 'user', '2013-08-15 01:25:21', '2013-08-14 20:01:13'),
(126, 'website.ips.all', '', 1, 1, '1', 'user', '2013-09-18 12:17:34', '2013-09-18 07:45:59'),
(127, 'website.ips.block', '', 1, 1, '1', 'user', '2013-09-18 12:17:34', '2013-09-18 07:48:23'),
(128, 'website.ips.allow', '', 1, 1, '1', 'user', '2013-09-18 12:17:34', '2013-10-06 21:37:40'),
(129, 'website.ips.block.message.offline', '1', 1, 1, '1', 'user', '2013-09-18 12:46:14', '2013-09-18 07:47:06'),
(130, 'website.ips.block.message', 'You are Blocked', 1, 1, '1', 'user', '2013-09-18 12:46:14', '2013-09-18 07:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `idCountry` int(5) NOT NULL AUTO_INCREMENT,
  `countryCode` char(2) NOT NULL DEFAULT '',
  `countryName` varchar(45) NOT NULL DEFAULT '',
  `currencyCode` char(3) DEFAULT NULL,
  `population` varchar(20) DEFAULT NULL,
  `fipsCode` char(2) DEFAULT NULL,
  `isoNumeric` char(4) DEFAULT NULL,
  `north` varchar(30) DEFAULT NULL,
  `south` varchar(30) DEFAULT NULL,
  `east` varchar(30) DEFAULT NULL,
  `west` varchar(30) DEFAULT NULL,
  `capital` varchar(30) DEFAULT NULL,
  `continentName` varchar(15) DEFAULT NULL,
  `continent` char(2) DEFAULT NULL,
  `areaInSqKm` varchar(20) DEFAULT NULL,
  `languages` varchar(30) DEFAULT NULL,
  `isoAlpha3` char(3) DEFAULT NULL,
  `geonameId` int(10) DEFAULT NULL,
  PRIMARY KEY (`idCountry`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=260 ;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`idCountry`, `countryCode`, `countryName`, `currencyCode`, `population`, `fipsCode`, `isoNumeric`, `north`, `south`, `east`, `west`, `capital`, `continentName`, `continent`, `areaInSqKm`, `languages`, `isoAlpha3`, `geonameId`) VALUES
(1, 'AD', 'Andorrah', 'EUR', '84000', 'AN', '020', '42.65604389629997', '42.42849259876837', '1.7865427778319827', '1.4071867141112762', 'Andorra la Vella', 'Europe', 'EU', '468.0', 'ca', 'AND', 3041565),
(2, 'AE', 'United Arab Emirates', 'AED', '4975593', 'AE', '784', '26.08415985107422', '22.633329391479492', '56.38166046142578', '51.58332824707031', 'Abu Dhabi', 'Asia', 'AS', '82880.0', 'ar-AE,fa,en,hi,ur', 'ARE', 290557),
(4, 'AG', 'Antigua and Barbuda', 'XCD', '86754', 'AC', '028', '17.729387', '16.996979', '-61.672421', '-61.906425', 'St. John''s', 'North America', 'NA', '443.0', 'en-AG', 'ATG', 3576396),
(5, 'AI', 'Anguilla', 'XCD', '13254', 'AV', '660', '18.283424', '18.166815', '-62.971359', '-63.172901', 'The Valley', 'North America', 'NA', '102.0', 'en-AI', 'AIA', 3573511),
(6, 'AL', 'Albania', 'ALL', '2986952', 'AL', '008', '42.665611', '39.648361', '21.068472', '19.293972', 'Tirana', 'Europe', 'EU', '28748.0', 'sq,el', 'ALB', 783754),
(7, 'AM', 'Armenia', 'AMD', '2968000', 'AM', '051', '41.301834', '38.830528', '46.772435045159995', '43.44978', 'Yerevan', 'Asia', 'AS', '29800.0', 'hy', 'ARM', 174982),
(8, 'AO', 'Angola', 'AOA', '13068161', 'AO', '024', '-4.376826', '-18.042076', '24.082119', '11.679219', 'Luanda', 'Africa', 'AF', '1246700.0', 'pt-AO', 'AGO', 3351879),
(9, 'AQ', 'Antarctica', '', '0', 'AY', '010', '-60.515533', '-89.9999', '179.9999', '-179.9999', '', 'Antarctica', 'AN', '1.4E7', '', 'ATA', 6697173),
(10, 'AR', 'Argentina', 'ARS', '41343201', 'AR', '032', '-21.781277', '-55.061314', '-53.591835', '-73.58297', 'Buenos Aires', 'South America', 'SA', '2766890.0', 'es-AR,en,it,de,fr,gn', 'ARG', 3865483),
(11, 'AS', 'American Samoa', 'USD', '57881', 'AQ', '016', '-11.0497', '-14.382478', '-169.416077', '-171.091888', 'Pago Pago', 'Oceania', 'OC', '199.0', 'en-AS,sm,to', 'ASM', 5880801),
(12, 'AT', 'Austria', 'EUR', '8205000', 'AU', '040', '49.017056', '46.378029', '17.162722', '9.535916', 'Vienna', 'Europe', 'EU', '83858.0', 'de-AT,hr,hu,sl', 'AUT', 2782113),
(13, 'AU', 'Australia', 'AUD', '21515754', 'AS', '036', '-10.062805', '-43.64397', '153.639252', '112.911057', 'Canberra', 'Oceania', 'OC', '7686850.0', 'en-AU', 'AUS', 2077456),
(14, 'AW', 'Aruba', 'AWG', '71566', 'AA', '533', '12.623718127152925', '12.411707706190716', '-69.86575120104982', '-70.0644737196045', 'Oranjestad', 'North America', 'NA', '193.0', 'nl-AW,es,en', 'ABW', 3577279),
(15, 'AX', 'Aland', 'EUR', '26711', '', '248', '60.488861', '59.90675', '21.011862', '19.317694', 'Mariehamn', 'Europe', 'EU', '', 'sv-AX', 'ALA', 661882),
(16, 'AZ', 'Azerbaijan', 'AZN', '8303512', 'AJ', '031', '41.90564', '38.38915252685547', '50.370083', '44.774113', 'Baku', 'Asia', 'AS', '86600.0', 'az,ru,hy', 'AZE', 587116),
(17, 'BA', 'Bosnia and Herzegovina', 'BAM', '4590000', 'BK', '070', '45.239193', '42.546112', '19.622223', '15.718945', 'Sarajevo', 'Europe', 'EU', '51129.0', 'bs,hr-BA,sr-BA', 'BIH', 3277605),
(18, 'BB', 'Barbados', 'BBD', '285653', 'BB', '052', '13.327257', '13.039844', '-59.420376', '-59.648922', 'Bridgetown', 'North America', 'NA', '431.0', 'en-BB', 'BRB', 3374084),
(19, 'BD', 'Bangladesh', 'BDT', '156118464', 'BG', '050', '26.631945', '20.743334', '92.673668', '88.028336', 'Dhaka', 'Asia', 'AS', '144000.0', 'bn-BD,en', 'BGD', 1210997),
(20, 'BE', 'Belgium', 'EUR', '10403000', 'BE', '056', '51.505444', '49.49361', '6.403861', '2.546944', 'Brussels', 'Europe', 'EU', '30510.0', 'nl-BE,fr-BE,de-BE', 'BEL', 2802361),
(21, 'BF', 'Burkina Faso', 'XOF', '16241811', 'UV', '854', '15.082593', '9.401108', '2.405395', '-5.518916', 'Ouagadougou', 'Africa', 'AF', '274200.0', 'fr-BF', 'BFA', 2361809),
(22, 'BG', 'Bulgaria', 'BGN', '7148785', 'BU', '100', '44.21764', '41.242084', '28.612167', '22.371166', 'Sofia', 'Europe', 'EU', '110910.0', 'bg,tr-BG', 'BGR', 732800),
(23, 'BH', 'Bahrain', 'BHD', '738004', 'BA', '048', '26.282583', '25.796862', '50.664471', '50.45414', 'Manama', 'Asia', 'AS', '665.0', 'ar-BH,en,fa,ur', 'BHR', 290291),
(24, 'BI', 'Burundi', 'BIF', '9863117', 'BY', '108', '-2.310123', '-4.465713', '30.847729', '28.993061', 'Bujumbura', 'Africa', 'AF', '27830.0', 'fr-BI,rn', 'BDI', 433561),
(25, 'BJ', 'Benin', 'XOF', '9056010', 'BN', '204', '12.418347', '6.225748', '3.851701', '0.774575', 'Porto-Novo', 'Africa', 'AF', '112620.0', 'fr-BJ', 'BEN', 2395170),
(26, 'BL', 'Saint Barthelemy', 'EUR', '8450', 'TB', '652', '17.928808791949283', '17.878183227405575', '-62.788983372985854', '-62.8739118253784', 'Gustavia', 'North America', 'NA', '21.0', 'fr', 'BLM', 3578476),
(27, 'BM', 'Bermuda', 'BMD', '65365', 'BD', '060', '32.393833', '32.246639', '-64.651993', '-64.89605', 'Hamilton', 'North America', 'NA', '53.0', 'en-BM,pt', 'BMU', 3573345),
(28, 'BN', 'Brunei', 'BND', '395027', 'BX', '096', '5.047167', '4.003083', '115.359444', '114.071442', 'Bandar Seri Begawan', 'Asia', 'AS', '5770.0', 'ms-BN,en-BN', 'BRN', 1820814),
(29, 'BO', 'Bolivia', 'BOB', '9947418', 'BL', '068', '-9.680567', '-22.896133', '-57.45809600000001', '-69.640762', 'Sucre', 'South America', 'SA', '1098580.0', 'es-BO,qu,ay', 'BOL', 3923057),
(30, 'BQ', 'Bonaire', 'USD', '18012', '', '535', '12.304535', '12.017149', '-68.192307', '-68.416458', '', 'North America', 'NA', '', 'nl,pap,en', 'BES', 7626844),
(31, 'BR', 'Brazil', 'BRL', '201103330', 'BR', '076', '5.264877', '-33.750706', '-32.392998', '-73.985535', 'Bras&amp;amp;amp;iacute;lia', 'South America', 'SA', '8511965.0', 'pt-BR,es,en,fr', 'BRA', 3469034),
(32, 'BS', 'Bahamas', 'BSD', '301790', 'BF', '044', '26.919243', '22.852743', '-74.423874', '-78.995911', 'Nassau', 'North America', 'NA', '13940.0', 'en-BS', 'BHS', 3572887),
(33, 'BT', 'Bhutan', 'BTN', '699847', 'BT', '064', '28.323778', '26.70764', '92.125191', '88.75972', 'Thimphu', 'Asia', 'AS', '47000.0', 'dz', 'BTN', 1252634),
(34, 'BV', 'Bouvet Island', 'NOK', '0', 'BV', '074', '-54.400322', '-54.462383', '3.487976', '3.335499', '', 'Antarctica', 'AN', '', '', 'BVT', 3371123),
(35, 'BW', 'Botswana', 'BWP', '2029307', 'BC', '072', '-17.780813', '-26.907246', '29.360781', '19.999535', 'Gaborone', 'Africa', 'AF', '600370.0', 'en-BW,tn-BW', 'BWA', 933860),
(36, 'BY', 'Belarus', 'BYR', '9685000', 'BO', '112', '56.165806', '51.256416', '32.770805', '23.176889', 'Minsk', 'Europe', 'EU', '207600.0', 'be,ru', 'BLR', 630336),
(37, 'BZ', 'Belize', 'BZD', '314522', 'BH', '084', '18.496557', '15.8893', '-87.776985', '-89.224815', 'Belmopan', 'North America', 'NA', '22966.0', 'en-BZ,es', 'BLZ', 3582678),
(38, 'CA', 'Canada', 'CAD', '33679000', 'CA', '124', '83.110626', '41.67598', '-52.636291', '-141', 'Ottawa', 'North America', 'NA', '9984670.0', 'en-CA,fr-CA,iu', 'CAN', 6251999),
(39, 'CC', 'Cocos [Keeling] Islands', 'AUD', '628', 'CK', '166', '-12.072459094', '-12.208725839', '96.929489344', '96.816941408', 'West Island', 'Asia', 'AS', '14.0', 'ms-CC,en', 'CCK', 1547376),
(40, 'CD', 'Congo', 'CDF', '70916439', 'CG', '180', '5.386098', '-13.455675', '31.305912', '12.204144', 'Kinshasa', 'Africa', 'AF', '2345410.0', 'fr-CD,ln,kg', 'COD', 203312),
(41, 'CF', 'Central African Republic', 'XAF', '4844927', 'CT', '140', '11.007569', '2.220514', '27.463421', '14.420097', 'Bangui', 'Africa', 'AF', '622984.0', 'fr-CF,sg,ln,kg', 'CAF', 239880),
(42, 'CG', 'Republic of the Congo', 'XAF', '3039126', 'CF', '178', '3.703082', '-5.027223', '18.649839', '11.205009', 'Brazzaville', 'Africa', 'AF', '342000.0', 'fr-CG,kg,ln-CG', 'COG', 2260494),
(43, 'CH', 'Switzerland', 'CHF', '7581000', 'SZ', '756', '47.805332', '45.825695', '10.491472', '5.957472', 'Berne', 'Europe', 'EU', '41290.0', 'de-CH,fr-CH,it-CH,rm', 'CHE', 2658434),
(44, 'CI', 'Ivory Coast', 'XOF', '21058798', 'IV', '384', '10.736642', '4.357067', '-2.494897', '-8.599302', 'Yamoussoukro', 'Africa', 'AF', '322460.0', 'fr-CI', 'CIV', 2287781),
(45, 'CK', 'Cook Islands', 'NZD', '21388', 'CW', '184', '-10.023114', '-21.944164', '-157.312134', '-161.093658', 'Avarua', 'Oceania', 'OC', '240.0', 'en-CK,mi', 'COK', 1899402),
(46, 'CL', 'Chile', 'CLP', '16746491', 'CI', '152', '-17.507553', '-55.916348', '-66.417557', '-80.785851', 'Santiago', 'South America', 'SA', '756950.0', 'es-CL', 'CHL', 3895114),
(47, 'CM', 'Cameroon', 'XAF', '19294149', 'CM', '120', '13.078056', '1.652548', '16.192116', '8.494763', 'Yaound&amp;amp;amp;eacute;', 'Africa', 'AF', '475440.0', 'en-CM,fr-CM', 'CMR', 2233387),
(48, 'CN', 'China', 'CNY', '1330044000', 'CH', '156', '53.56086', '15.775416', '134.773911', '73.557693', 'Beijing', 'Asia', 'AS', '9596960.0', 'zh-CN,yue,wuu,dta,ug,za', 'CHN', 1814991),
(49, 'CO', 'Colombia', 'COP', '44205293', 'CO', '170', '13.380502', '-4.225869', '-66.869835', '-81.728111', 'Bogot&amp;amp;amp;aacute;', 'South America', 'SA', '1138910.0', 'es-CO', 'COL', 3686110),
(50, 'CR', 'Costa Rica', 'CRC', '4516220', 'CS', '188', '11.216819', '8.032975', '-82.555992', '-85.950623', 'San Jos&amp;amp;amp;eacute;', 'North America', 'NA', '51100.0', 'es-CR,en', 'CRI', 3624060),
(51, 'CU', 'Cuba', 'CUP', '11423000', 'CU', '192', '23.226042', '19.828083', '-74.131775', '-84.957428', 'Havana', 'North America', 'NA', '110860.0', 'es-CU', 'CUB', 3562981),
(52, 'CV', 'Cape Verde', 'CVE', '508659', 'CV', '132', '17.197178', '14.808022', '-22.669443', '-25.358747', 'Praia', 'Africa', 'AF', '4033.0', 'pt-CV', 'CPV', 3374766),
(53, 'CW', 'Curacao', 'ANG', '141766', 'UC', '531', '12.385672', '12.032745', '-68.733948', '-69.157204', 'Willemstad', 'North America', 'NA', '', 'nl,pap', 'CUW', 7626836),
(54, 'CX', 'Christmas Island', 'AUD', '1500', 'KT', '162', '-10.412356007', '-10.5704829995', '105.712596992', '105.533276992', 'The Settlement', 'Asia', 'AS', '135.0', 'en,zh,ms-CC', 'CXR', 2078138),
(55, 'CY', 'Cyprus', 'EUR', '1102677', 'CY', '196', '35.701527', '34.6332846722908', '34.59791599999994', '32.27308300000004', 'Nicosia', 'Europe', 'EU', '9250.0', 'el-CY,tr-CY,en', 'CYP', 146669),
(56, 'CZ', 'Czechia', 'CZK', '10476000', 'EZ', '203', '51.058887', '48.542915', '18.860111', '12.096194', 'Prague', 'Europe', 'EU', '78866.0', 'cs,sk', 'CZE', 3077311),
(57, 'DE', 'Germany', 'EUR', '81802257', 'GM', '276', '55.055637', '47.275776', '15.039889', '5.865639', 'Berlin', 'Europe', 'EU', '357021.0', 'de', 'DEU', 2921044),
(58, 'DJ', 'Djibouti', 'DJF', '740528', 'DJ', '262', '12.706833', '10.909917', '43.416973', '41.773472', 'Djibouti', 'Africa', 'AF', '23000.0', 'fr-DJ,ar,so-DJ,aa', 'DJI', 223816),
(59, 'DK', 'Denmark', 'DKK', '5484000', 'DA', '208', '57.748417', '54.562389', '15.158834', '8.075611', 'Copenhagen', 'Europe', 'EU', '43094.0', 'da-DK,en,fo,de-DK', 'DNK', 2623032),
(60, 'DM', 'Dominica', 'XCD', '72813', 'DO', '212', '15.631809', '15.20169', '-61.244152', '-61.484108', 'Roseau', 'North America', 'NA', '754.0', 'en-DM', 'DMA', 3575830),
(61, 'DO', 'Dominican Republic', 'DOP', '9823821', 'DR', '214', '19.929859', '17.543159', '-68.32', '-72.003487', 'Santo Domingo', 'North America', 'NA', '48730.0', 'es-DO', 'DOM', 3508796),
(62, 'DZ', 'Algeria', 'DZD', '34586184', 'AG', '012', '37.093723', '18.960028', '11.979548', '-8.673868', 'Algiers', 'Africa', 'AF', '2381740.0', 'ar-DZ', 'DZA', 2589581),
(63, 'EC', 'Ecuador', 'USD', '14790608', 'EC', '218', '1.43902', '-4.998823', '-75.184586', '-81.078598', 'Quito', 'South America', 'SA', '283560.0', 'es-EC', 'ECU', 3658394),
(64, 'EE', 'Estonia', 'EUR', '1291170', 'EN', '233', '59.676224', '57.516193', '28.209972', '21.837584', 'Tallinn', 'Europe', 'EU', '45226.0', 'et,ru', 'EST', 453733),
(65, 'EG', 'Egypt', 'EGP', '80471869', 'EG', '818', '31.667334', '21.725389', '35.794861', '24.698111', 'Cairo', 'Africa', 'AF', '1001450.0', 'ar-EG,en,fr', 'EGY', 357994),
(66, 'EH', 'Western Sahara', 'MAD', '273008', 'WI', '732', '27.669674', '20.774158', '-8.670276', '-17.103182', 'El Aai&amp;amp;amp;uacute;n', 'Africa', 'AF', '266000.0', 'ar,mey', 'ESH', 2461445),
(67, 'ER', 'Eritrea', 'ERN', '5792984', 'ER', '232', '18.003084', '12.359555', '43.13464', '36.438778', 'Asmara', 'Africa', 'AF', '121320.0', 'aa-ER,ar,tig,kun,ti-ER', 'ERI', 338010),
(68, 'ES', 'Spain', 'EUR', '46505963', 'SP', '724', '43.791721', '36.000332', '4.315389', '-9.290778', 'Madrid', 'Europe', 'EU', '504782.0', 'es-ES,ca,gl,eu,oc', 'ESP', 2510769),
(69, 'ET', 'Ethiopia', 'ETB', '88013491', 'ET', '231', '14.89375', '3.402422', '47.986179', '32.999939', 'Addis Ababa', 'Africa', 'AF', '1127127.0', 'am,en-ET,om-ET,ti-ET,so-ET,sid', 'ETH', 337996),
(70, 'FI', 'Finland', 'EUR', '5244000', 'FI', '246', '70.096054', '59.808777', '31.580944', '20.556944', 'Helsinki', 'Europe', 'EU', '337030.0', 'fi-FI,sv-FI,smn', 'FIN', 660013),
(71, 'FJ', 'Fiji', 'FJD', '875983', 'FJ', '242', '-12.480111', '-20.67597', '-178.424438', '177.129334', 'Suva', 'Oceania', 'OC', '18270.0', 'en-FJ,fj', 'FJI', 2205218),
(72, 'FK', 'Falkland Islands', 'FKP', '2638', 'FK', '238', '-51.24065', '-52.360512', '-57.712486', '-61.345192', 'Stanley', 'South America', 'SA', '12173.0', 'en-FK', 'FLK', 3474414),
(73, 'FM', 'Micronesia', 'USD', '107708', 'FM', '583', '10.08904', '1.02629', '163.03717', '137.33648', 'Palikir', 'Oceania', 'OC', '702.0', 'en-FM,chk,pon,yap,kos,uli,woe,', 'FSM', 2081918),
(74, 'FO', 'Faroe Islands', 'DKK', '48228', 'FO', '234', '62.400749', '61.394943', '-6.399583', '-7.458', 'T&amp;amp;amp;oacute;rshavn', 'Europe', 'EU', '1399.0', 'fo,da-FO', 'FRO', 2622320),
(75, 'FR', 'France', 'EUR', '64768389', 'FR', '250', '51.092804', '41.371582', '9.561556', '-5.142222', 'Paris', 'Europe', 'EU', '547030.0', 'fr-FR,frp,br,co,ca,eu,oc', 'FRA', 3017382),
(76, 'GA', 'Gabon', 'XAF', '1545255', 'GB', '266', '2.322612', '-3.978806', '14.502347', '8.695471', 'Libreville', 'Africa', 'AF', '267667.0', 'fr-GA', 'GAB', 2400553),
(77, 'GB', 'United Kingdom', 'GBP', '62348447', 'UK', '826', '59.360249', '49.906193', '1.759', '-8.623555', 'London', 'Europe', 'EU', '244820.0', 'en-GB,cy-GB,gd', 'GBR', 2635167),
(78, 'GD', 'Grenada', 'XCD', '107818', 'GJ', '308', '12.318283928171299', '11.986893', '-61.57676970108031', '-61.802344', 'St. George''s', 'North America', 'NA', '344.0', 'en-GD', 'GRD', 3580239),
(79, 'GE', 'Georgia', 'GEL', '4630000', 'GG', '268', '43.586498', '41.053196', '46.725971', '40.010139', 'Tbilisi', 'Asia', 'AS', '69700.0', 'ka,ru,hy,az', 'GEO', 614540),
(80, 'GF', 'French Guiana', 'EUR', '195506', 'FG', '254', '5.776496', '2.127094', '-51.613949', '-54.542511', 'Cayenne', 'South America', 'SA', '91000.0', 'fr-GF', 'GUF', 3381670),
(81, 'GG', 'Guernsey', 'GBP', '65228', 'GK', '831', '49.738609', '49.412777', '-2.163889', '-2.682472', 'St Peter Port', 'Europe', 'EU', '78.0', 'en,fr', 'GGY', 3042362),
(82, 'GH', 'Ghana', 'GHS', '24339838', 'GH', '288', '11.173301', '4.736723', '1.191781', '-3.25542', 'Accra', 'Africa', 'AF', '239460.0', 'en-GH,ak,ee,tw', 'GHA', 2300660),
(83, 'GI', 'Gibraltar', 'GIP', '27884', 'GI', '292', '36.155439135670726', '36.10903070140248', '-5.338285164001491', '-5.36626149743654', 'Gibraltar', 'Europe', 'EU', '6.5', 'en-GI,es,it,pt', 'GIB', 2411586),
(84, 'GL', 'Greenland', 'DKK', '56375', 'GL', '304', '83.627357', '59.777401', '-11.312319', '-73.04203', 'Nuuk', 'North America', 'NA', '2166086.0', 'kl,da-GL,en', 'GRL', 3425505),
(85, 'GM', 'Gambia', 'GMD', '1593256', 'GA', '270', '13.826571', '13.064252', '-13.797793', '-16.825079', 'Banjul', 'Africa', 'AF', '11300.0', 'en-GM,mnk,wof,wo,ff', 'GMB', 2413451),
(86, 'GN', 'Guinea', 'GNF', '10324025', 'GV', '324', '12.67622', '7.193553', '-7.641071', '-14.926619', 'Conakry', 'Africa', 'AF', '245857.0', 'fr-GN', 'GIN', 2420477),
(87, 'GP', 'Guadeloupe', 'EUR', '443000', 'GP', '312', '16.516848', '15.867565', '-61', '-61.544765', 'Basse-Terre', 'North America', 'NA', '1780.0', 'fr-GP', 'GLP', 3579143),
(88, 'GQ', 'Equatorial Guinea', 'XAF', '1014999', 'EK', '226', '2.346989', '0.92086', '11.335724', '9.346865', 'Malabo', 'Africa', 'AF', '28051.0', 'es-GQ,fr', 'GNQ', 2309096),
(89, 'GR', 'Greece', 'EUR', '11000000', 'GR', '300', '41.7484999849641', '34.8020663391466', '28.2470831714347', '19.3736035624134', 'Athens', 'Europe', 'EU', '131940.0', 'el-GR,en,fr', 'GRC', 390903),
(90, 'GS', 'South Georgia and the South Sandwich Islands', 'GBP', '30', 'SX', '239', '-53.970467', '-59.479259', '-26.229326', '-38.021175', 'Grytviken', 'Antarctica', 'AN', '3903.0', 'en', 'SGS', 3474415),
(91, 'GT', 'Guatemala', 'GTQ', '13550440', 'GT', '320', '17.81522', '13.737302', '-88.223198', '-92.23629', 'Guatemala City', 'North America', 'NA', '108890.0', 'es-GT', 'GTM', 3595528),
(92, 'GU', 'Guam', 'USD', '159358', 'GQ', '316', '13.652333', '13.240611', '144.953979', '144.619247', 'Hag&amp;amp;amp;aring;t&amp;am', 'Oceania', 'OC', '549.0', 'en-GU,ch-GU', 'GUM', 4043988),
(93, 'GW', 'Guinea-Bissau', 'XOF', '1565126', 'PU', '624', '12.680789', '10.924265', '-13.636522', '-16.717535', 'Bissau', 'Africa', 'AF', '36120.0', 'pt-GW,pov', 'GNB', 2372248),
(94, 'GY', 'Guyana', 'GYD', '748486', 'GY', '328', '8.557567', '1.17508', '-56.480251', '-61.384762', 'Georgetown', 'South America', 'SA', '214970.0', 'en-GY', 'GUY', 3378535),
(95, 'HK', 'Hong Kong', 'HKD', '6898686', 'HK', '344', '22.559778', '22.15325', '114.434753', '113.837753', 'Hong Kong', 'Asia', 'AS', '1092.0', 'zh-HK,yue,zh,en', 'HKG', 1819730),
(96, 'HM', 'Heard Island and McDonald Islands', 'AUD', '0', 'HM', '334', '-52.909416', '-53.192001', '73.859146', '72.596535', '', 'Antarctica', 'AN', '412.0', '', 'HMD', 1547314),
(97, 'HN', 'Honduras', 'HNL', '7989415', 'HO', '340', '16.510256', '12.982411', '-83.155403', '-89.350792', 'Tegucigalpa', 'North America', 'NA', '112090.0', 'es-HN', 'HND', 3608932),
(98, 'HR', 'Croatia', 'HRK', '4491000', 'HR', '191', '46.53875', '42.43589', '19.427389', '13.493222', 'Zagreb', 'Europe', 'EU', '56542.0', 'hr-HR,sr', 'HRV', 3202326),
(99, 'HT', 'Haiti', 'HTG', '9648924', 'HA', '332', '20.08782', '18.021032', '-71.613358', '-74.478584', 'Port-au-Prince', 'North America', 'NA', '27750.0', 'ht,fr-HT', 'HTI', 3723988),
(100, 'HU', 'Hungary', 'HUF', '9930000', 'HU', '348', '48.585667', '45.74361', '22.906', '16.111889', 'Budapest', 'Europe', 'EU', '93030.0', 'hu-HU', 'HUN', 719819),
(101, 'ID', 'Indonesia', 'IDR', '242968342', 'ID', '360', '5.904417', '-10.941861', '141.021805', '95.009331', 'Jakarta', 'Asia', 'AS', '1919440.0', 'id,en,nl,jv', 'IDN', 1643084),
(102, 'IE', 'Ireland', 'EUR', '4622917', 'EI', '372', '55.387917', '51.451584', '-6.002389', '-10.478556', 'Dublin', 'Europe', 'EU', '70280.0', 'en-IE,ga-IE', 'IRL', 2963597),
(103, 'IL', 'Israel', 'ILS', '7353985', 'IS', '376', '33.340137', '29.496639', '35.876804', '34.270278754419145', '', 'Asia', 'AS', '20770.0', 'he,ar-IL,en-IL,', 'ISR', 294640),
(104, 'IM', 'Isle of Man', 'GBP', '75049', 'IM', '833', '54.419724', '54.055916', '-4.3115', '-4.798722', 'Douglas', 'Europe', 'EU', '572.0', 'en,gv', 'IMN', 3042225),
(105, 'IN', 'India', 'INR', '1173108018', 'IN', '356', '35.504223', '6.747139', '97.403305', '68.186691', 'New Delhi', 'Asia', 'AS', '3287590.0', 'en-IN,hi,bn,te,mr,ta,ur,gu,kn,', 'IND', 1269750),
(106, 'IO', 'British Indian Ocean Territory', 'USD', '4000', 'IO', '086', '-5.268333', '-7.438028', '72.493164', '71.259972', '', 'Asia', 'AS', '60.0', 'en-IO', 'IOT', 1282588),
(107, 'IQ', 'Iraq', 'IQD', '29671605', 'IZ', '368', '37.378029', '29.069445', '48.575916', '38.795887', 'Baghdad', 'Asia', 'AS', '437072.0', 'ar-IQ,ku,hy', 'IRQ', 99237),
(108, 'IR', 'Iran', 'IRR', '76923300', 'IR', '364', '39.777222', '25.064083', '63.317471', '44.047279', 'Tehran', 'Asia', 'AS', '1648000.0', 'fa-IR,ku', 'IRN', 130758),
(109, 'IS', 'Iceland', 'ISK', '308910', 'IC', '352', '66.53463', '63.393253', '-13.495815', '-24.546524', 'Reykjavik', 'Europe', 'EU', '103000.0', 'is,en,de,da,sv,no', 'ISL', 2629691),
(110, 'IT', 'Italy', 'EUR', '60340328', 'IT', '380', '47.095196', '36.652779', '18.513445', '6.614889', 'Rome', 'Europe', 'EU', '301230.0', 'it-IT,de-IT,fr-IT,sc,ca,co,sl', 'ITA', 3175395),
(111, 'JE', 'Jersey', 'GBP', '90812', 'JE', '832', '49.265057', '49.169834', '-2.022083', '-2.260028', 'Saint Helier', 'Europe', 'EU', '116.0', 'en,pt', 'JEY', 3042142),
(112, 'JM', 'Jamaica', 'JMD', '2847232', 'JM', '388', '18.526976', '17.703554', '-76.180321', '-78.366638', 'Kingston', 'North America', 'NA', '10991.0', 'en-JM', 'JAM', 3489940),
(113, 'JO', 'Jordan', 'JOD', '6407085', 'JO', '400', '33.367668', '29.185888', '39.301167', '34.959999', 'Amman', 'Asia', 'AS', '92300.0', 'ar-JO,en', 'JOR', 248816),
(114, 'JP', 'Japan', 'JPY', '127288000', 'JA', '392', '45.52314', '24.249472', '145.820892', '122.93853', 'Tokyo', 'Asia', 'AS', '377835.0', 'ja', 'JPN', 1861060),
(115, 'KE', 'Kenya', 'KES', '40046566', 'KE', '404', '5.019938', '-4.678047', '41.899078', '33.908859', 'Nairobi', 'Africa', 'AF', '582650.0', 'en-KE,sw-KE', 'KEN', 192950),
(116, 'KG', 'Kyrgyzstan', 'KGS', '5508626', 'KG', '417', '43.238224', '39.172832', '80.283165', '69.276611', 'Bishkek', 'Asia', 'AS', '198500.0', 'ky,uz,ru', 'KGZ', 1527747),
(117, 'KH', 'Cambodia', 'KHR', '14453680', 'CB', '116', '14.686417', '10.409083', '107.627724', '102.339996', 'Phnom Penh', 'Asia', 'AS', '181040.0', 'km,fr,en', 'KHM', 1831722),
(118, 'KI', 'Kiribati', 'AUD', '92533', 'KR', '296', '4.71957', '-11.437038', '-150.215347', '169.556137', 'Tarawa', 'Oceania', 'OC', '811.0', 'en-KI,gil', 'KIR', 4030945),
(119, 'KM', 'Comoros', 'KMF', '773407', 'CN', '174', '-11.362381', '-12.387857', '44.538223', '43.21579', 'Moroni', 'Africa', 'AF', '2170.0', 'ar,fr-KM', 'COM', 921929),
(120, 'KN', 'Saint Kitts and Nevis', 'XCD', '49898', 'SC', '659', '17.420118', '17.095343', '-62.543266', '-62.86956', 'Basseterre', 'North America', 'NA', '261.0', 'en-KN', 'KNA', 3575174),
(121, 'KP', 'North Korea', 'KPW', '22912177', 'KN', '408', '43.006054', '37.673332', '130.674866', '124.315887', 'Pyongyang', 'Asia', 'AS', '120540.0', 'ko-KP', 'PRK', 1873107),
(122, 'KR', 'South Korea', 'KRW', '48422644', 'KS', '410', '38.612446', '33.190945', '129.584671', '125.887108', 'Seoul', 'Asia', 'AS', '98480.0', 'ko-KR,en', 'KOR', 1835841),
(123, 'KW', 'Kuwait', 'KWD', '2789132', 'KU', '414', '30.095945', '28.524611', '48.431473', '46.555557', 'Kuwait City', 'Asia', 'AS', '17820.0', 'ar-KW,en', 'KWT', 285570),
(124, 'KY', 'Cayman Islands', 'KYD', '44270', 'CJ', '136', '19.7617', '19.263029', '-79.727272', '-81.432777', 'George Town', 'North America', 'NA', '262.0', 'en-KY', 'CYM', 3580718),
(125, 'KZ', 'Kazakhstan', 'KZT', '15340000', 'KZ', '398', '55.451195', '40.936333', '87.312668', '46.491859', 'Astana', 'Asia', 'AS', '2717300.0', 'kk,ru', 'KAZ', 1522867),
(126, 'LA', 'Laos', 'LAK', '6368162', 'LA', '418', '22.500389', '13.910027', '107.697029', '100.093056', 'Vientiane', 'Asia', 'AS', '236800.0', 'lo,fr,en', 'LAO', 1655842),
(127, 'LB', 'Lebanon', 'LBP', '4125247', 'LE', '422', '34.691418', '33.05386', '36.639194', '35.114277', 'Beirut', 'Asia', 'AS', '10400.0', 'ar-LB,fr-LB,en,hy', 'LBN', 272103),
(128, 'LC', 'Saint Lucia', 'XCD', '160922', 'ST', '662', '14.103245', '13.704778', '-60.874203', '-61.07415', 'Castries', 'North America', 'NA', '616.0', 'en-LC', 'LCA', 3576468),
(129, 'LI', 'Liechtenstein', 'CHF', '35000', 'LS', '438', '47.273529', '47.055862', '9.632195', '9.477805', 'Vaduz', 'Europe', 'EU', '160.0', 'de-LI', 'LIE', 3042058),
(130, 'LK', 'Sri Lanka', 'LKR', '21513990', 'CE', '144', '9.831361', '5.916833', '81.881279', '79.652916', 'Colombo', 'Asia', 'AS', '65610.0', 'si,ta,en', 'LKA', 1227603),
(131, 'LR', 'Liberia', 'LRD', '3685076', 'LI', '430', '8.551791', '4.353057', '-7.365113', '-11.492083', 'Monrovia', 'Africa', 'AF', '111370.0', 'en-LR', 'LBR', 2275384),
(132, 'LS', 'Lesotho', 'LSL', '1919552', 'LT', '426', '-28.572058', '-30.668964', '29.465761', '27.029068', 'Maseru', 'Africa', 'AF', '30355.0', 'en-LS,st,zu,xh', 'LSO', 932692),
(133, 'LT', 'Lithuania', 'LTL', '3565000', 'LH', '440', '56.446918', '53.901306', '26.871944', '20.941528', 'Vilnius', 'Europe', 'EU', '65200.0', 'lt,ru,pl', 'LTU', 597427),
(134, 'LU', 'Luxembourg', 'EUR', '497538', 'LU', '442', '50.184944', '49.446583', '6.528472', '5.734556', 'Luxembourg', 'Europe', 'EU', '2586.0', 'lb,de-LU,fr-LU', 'LUX', 2960313),
(135, 'LV', 'Latvia', 'LVL', '2217969', 'LG', '428', '58.082306', '55.668861', '28.241167', '20.974277', 'Riga', 'Europe', 'EU', '64589.0', 'lv,ru,lt', 'LVA', 458258),
(136, 'LY', 'Libya', 'LYD', '6461454', 'LY', '434', '33.168999', '19.508045', '25.150612', '9.38702', 'Tripoli', 'Africa', 'AF', '1759540.0', 'ar-LY,it,en', 'LBY', 2215636),
(137, 'MA', 'Morocco', 'MAD', '31627428', 'MO', '504', '35.9224966985384', '27.662115', '-0.991750000000025', '-13.168586', 'Rabat', 'Africa', 'AF', '446550.0', 'ar-MA,fr', 'MAR', 2542007),
(138, 'MC', 'Monaco', 'EUR', '32965', 'MN', '492', '43.75196717037228', '43.72472839869377', '7.439939260482788', '7.408962249755859', 'Monaco', 'Europe', 'EU', '1.95', 'fr-MC,en,it', 'MCO', 2993457),
(139, 'MD', 'Moldova', 'MDL', '4324000', 'MD', '498', '48.490166', '45.468887', '30.135445', '26.618944', 'Chi?in?u', 'Europe', 'EU', '33843.0', 'ro,ru,gag,tr', 'MDA', 617790),
(140, 'ME', 'Montenegro', 'EUR', '666730', 'MJ', '499', '43.570137', '41.850166', '20.358833', '18.461306', 'Podgorica', 'Europe', 'EU', '14026.0', 'sr,hu,bs,sq,hr,rom', 'MNE', 3194884),
(141, 'MF', 'Saint Martin', 'EUR', '35925', 'RN', '663', '18.130354', '18.052231', '-63.012993', '-63.152767', 'Marigot', 'North America', 'NA', '53.0', 'fr', 'MAF', 3578421),
(142, 'MG', 'Madagascar', 'MGA', '21281844', 'MA', '450', '-11.945433', '-25.608952', '50.48378', '43.224876', 'Antananarivo', 'Africa', 'AF', '587040.0', 'fr-MG,mg', 'MDG', 1062947),
(143, 'MH', 'Marshall Islands', 'USD', '65859', 'RM', '584', '14.62', '5.587639', '171.931808', '165.524918', 'Majuro', 'Oceania', 'OC', '181.3', 'mh,en-MH', 'MHL', 2080185),
(144, 'MK', 'Macedonia', 'MKD', '2061000', 'MK', '807', '42.361805', '40.860195', '23.038139', '20.464695', 'Skopje', 'Europe', 'EU', '25333.0', 'mk,sq,tr,rmm,sr', 'MKD', 718075),
(145, 'ML', 'Mali', 'XOF', '13796354', 'ML', '466', '25.000002', '10.159513', '4.244968', '-12.242614', 'Bamako', 'Africa', 'AF', '1240000.0', 'fr-ML,bm', 'MLI', 2453866),
(146, 'MM', 'Myanmar [Burma]', 'MMK', '53414374', 'BM', '104', '28.543249', '9.784583', '101.176781', '92.189278', 'Nay Pyi Taw', 'Asia', 'AS', '678500.0', 'my', 'MMR', 1327865),
(147, 'MN', 'Mongolia', 'MNT', '3086918', 'MG', '496', '52.154251', '41.567638', '119.924309', '87.749664', 'Ulan Bator', 'Asia', 'AS', '1565000.0', 'mn,ru', 'MNG', 2029969),
(148, 'MO', 'Macao', 'MOP', '449198', 'MC', '446', '22.222334', '22.180389', '113.565834', '113.528946', 'Macao', 'Asia', 'AS', '254.0', 'zh,zh-MO,pt', 'MAC', 1821275),
(149, 'MP', 'Northern Mariana Islands', 'USD', '53883', 'CQ', '580', '20.55344', '14.11023', '146.06528', '144.88626', 'Saipan', 'Oceania', 'OC', '477.0', 'fil,tl,zh,ch-MP,en-MP', 'MNP', 4041468),
(150, 'MQ', 'Martinique', 'EUR', '432900', 'MB', '474', '14.878819', '14.392262', '-60.81551', '-61.230118', 'Fort-de-France', 'North America', 'NA', '1100.0', 'fr-MQ', 'MTQ', 3570311),
(151, 'MR', 'Mauritania', 'MRO', '3205060', 'MR', '478', '27.298073', '14.715547', '-4.827674', '-17.066521', 'Nouakchott', 'Africa', 'AF', '1030700.0', 'ar-MR,fuc,snk,fr,mey,wo', 'MRT', 2378080),
(152, 'MS', 'Montserrat', 'XCD', '9341', 'MH', '500', '16.824060205313184', '16.674768935441556', '-62.144100129608205', '-62.24138237036129', 'Plymouth', 'North America', 'NA', '102.0', 'en-MS', 'MSR', 3578097),
(153, 'MT', 'Malta', 'EUR', '403000', 'MT', '470', '36.082027', '35.810276', '14.577639', '14.191584', 'Valletta', 'Europe', 'EU', '316.0', 'mt,en-MT', 'MLT', 2562770),
(154, 'MU', 'Mauritius', 'MUR', '1294104', 'MP', '480', '-10.319255', '-20.525717', '63.500179', '56.512718', 'Port Louis', 'Africa', 'AF', '2040.0', 'en-MU,bho,fr', 'MUS', 934292),
(155, 'MV', 'Maldives', 'MVR', '395650', 'MV', '462', '7.098361', '-0.692694', '73.637276', '72.693222', 'Mal&amp;amp;amp;eacute;', 'Asia', 'AS', '300.0', 'dv,en', 'MDV', 1282028),
(156, 'MW', 'Malawi', 'MWK', '15447500', 'MI', '454', '-9.367541', '-17.125', '35.916821', '32.67395', 'Lilongwe', 'Africa', 'AF', '118480.0', 'ny,yao,tum,swk', 'MWI', 927384),
(157, 'MX', 'Mexico', 'MXN', '112468855', 'MX', '484', '32.716759', '14.532866', '-86.703392', '-118.453949', 'Mexico City', 'North America', 'NA', '1972550.0', 'es-MX', 'MEX', 3996063),
(158, 'MY', 'Malaysia', 'MYR', '28274729', 'MY', '458', '7.363417', '0.855222', '119.267502', '99.643448', 'Kuala Lumpur', 'Asia', 'AS', '329750.0', 'ms-MY,en,zh,ta,te,ml,pa,th', 'MYS', 1733045),
(159, 'MZ', 'Mozambique', 'MZN', '22061451', 'MZ', '508', '-10.471883', '-26.868685', '40.842995', '30.217319', 'Maputo', 'Africa', 'AF', '801590.0', 'pt-MZ,vmw', 'MOZ', 1036973),
(160, 'NA', 'Namibia', 'NAD', '2128471', 'WA', '516', '-16.959894', '-28.97143', '25.256701', '11.71563', 'Windhoek', 'Africa', 'AF', '825418.0', 'en-NA,af,de,hz,naq', 'NAM', 3355338),
(161, 'NC', 'New Caledonia', 'XPF', '216494', 'NC', '540', '-19.549778', '-22.698', '168.129135', '163.564667', 'Noumea', 'Oceania', 'OC', '19060.0', 'fr-NC', 'NCL', 2139685),
(162, 'NE', 'Niger', 'XOF', '15878271', 'NG', '562', '23.525026', '11.696975', '15.995643', '0.16625', 'Niamey', 'Africa', 'AF', '1267000.0', 'fr-NE,ha,kr,dje', 'NER', 2440476),
(163, 'NF', 'Norfolk Island', 'AUD', '1828', 'NF', '574', '-28.995170686948427', '-29.063076742954735', '167.99773740209957', '167.91543230151365', 'Kingston', 'Oceania', 'OC', '34.6', 'en-NF', 'NFK', 2155115),
(164, 'NG', 'Nigeria', 'NGN', '154000000', 'NI', '566', '13.892007', '4.277144', '14.680073', '2.668432', 'Abuja', 'Africa', 'AF', '923768.0', 'en-NG,ha,yo,ig,ff', 'NGA', 2328926),
(165, 'NI', 'Nicaragua', 'NIO', '5995928', 'NU', '558', '15.025909', '10.707543', '-82.738289', '-87.690308', 'Managua', 'North America', 'NA', '129494.0', 'es-NI,en', 'NIC', 3617476),
(166, 'NL', 'Netherlands', 'EUR', '16645000', 'NL', '528', '53.512196', '50.753918', '7.227944', '3.362556', 'Amsterdam', 'Europe', 'EU', '41526.0', 'nl-NL,fy-NL', 'NLD', 2750405),
(167, 'NO', 'Norway', 'NOK', '5009150', 'NO', '578', '71.18811', '57.977917', '31.078052520751953', '4.650167', 'Oslo', 'Europe', 'EU', '324220.0', 'no,nb,nn,se,fi', 'NOR', 3144096),
(168, 'NP', 'Nepal', 'NPR', '28951852', 'NP', '524', '30.43339', '26.356722', '88.199333', '80.056274', 'Kathmandu', 'Asia', 'AS', '140800.0', 'ne,en', 'NPL', 1282988),
(169, 'NR', 'Nauru', 'AUD', '10065', 'NR', '520', '-0.504306', '-0.552333', '166.945282', '166.899033', '', 'Oceania', 'OC', '21.0', 'na,en-NR', 'NRU', 2110425),
(170, 'NU', 'Niue', 'NZD', '2166', 'NE', '570', '-18.951069', '-19.152193', '-169.775177', '-169.951004', 'Alofi', 'Oceania', 'OC', '260.0', 'niu,en-NU', 'NIU', 4036232),
(171, 'NZ', 'New Zealand', 'NZD', '4252277', 'NZ', '554', '-34.389668', '-47.286026', '-180', '166.7155', 'Wellington', 'Oceania', 'OC', '268680.0', 'en-NZ,mi', 'NZL', 2186224),
(172, 'OM', 'Oman', 'OMR', '2967717', 'MU', '512', '26.387972', '16.64575', '59.836582', '51.882', 'Muscat', 'Asia', 'AS', '212460.0', 'ar-OM,en,bal,ur', 'OMN', 286963),
(173, 'PA', 'Panama', 'PAB', '3410676', 'PM', '591', '9.637514', '7.197906', '-77.17411', '-83.051445', 'Panama City', 'North America', 'NA', '78200.0', 'es-PA,en', 'PAN', 3703430),
(174, 'PE', 'Peru', 'PEN', '29907003', 'PE', '604', '-0.012977', '-18.349728', '-68.677986', '-81.326744', 'Lima', 'South America', 'SA', '1285220.0', 'es-PE,qu,ay', 'PER', 3932488),
(175, 'PF', 'French Polynesia', 'XPF', '270485', 'FP', '258', '-7.903573', '-27.653572', '-134.929825', '-152.877167', 'Papeete', 'Oceania', 'OC', '4167.0', 'fr-PF,ty', 'PYF', 4030656),
(176, 'PG', 'Papua New Guinea', 'PGK', '6064515', 'PP', '598', '-1.318639', '-11.657861', '155.96344', '140.842865', 'Port Moresby', 'Oceania', 'OC', '462840.0', 'en-PG,ho,meu,tpi', 'PNG', 2088628),
(177, 'PH', 'Philippines', 'PHP', '99900177', 'RP', '608', '21.120611', '4.643306', '126.601524', '116.931557', 'Manila', 'Asia', 'AS', '300000.0', 'tl,en-PH,fil', 'PHL', 1694008),
(178, 'PK', 'Pakistan', 'PKR', '184404791', 'PK', '586', '37.097', '23.786722', '77.840919', '60.878613', 'Islamabad', 'Asia', 'AS', '803940.0', 'ur-PK,en-PK,pa,sd,ps,brh', 'PAK', 1168579),
(179, 'PL', 'Poland', 'PLN', '38500000', 'PL', '616', '54.839138', '49.006363', '24.150749', '14.123', 'Warsaw', 'Europe', 'EU', '312685.0', 'pl', 'POL', 798544),
(180, 'PM', 'Saint Pierre and Miquelon', 'EUR', '7012', 'SB', '666', '47.146286', '46.786041', '-56.252991', '-56.420658', 'Saint-Pierre', 'North America', 'NA', '242.0', 'fr-PM', 'SPM', 3424932),
(181, 'PN', 'Pitcairn Islands', 'NZD', '46', 'PC', '612', '-24.315865', '-24.672565', '-124.77285', '-128.346436', 'Adamstown', 'Oceania', 'OC', '47.0', 'en-PN', 'PCN', 4030699),
(182, 'PR', 'Puerto Rico', 'USD', '3916632', 'RQ', '630', '18.520166', '17.926405', '-65.242737', '-67.942726', 'San Juan', 'North America', 'NA', '9104.0', 'en-PR,es-PR', 'PRI', 4566966),
(183, 'PS', 'Palestine', 'ILS', '3800000', 'WE', '275', '32.54638671875', '31.216541290283203', '35.5732955932617', '34.21665954589844', '', 'Asia', 'AS', '5970.0', 'ar-PS', 'PSE', 6254930),
(184, 'PT', 'Portugal', 'EUR', '10676000', 'PO', '620', '42.145638', '36.96125', '-6.182694', '-9.495944', 'Lisbon', 'Europe', 'EU', '92391.0', 'pt-PT,mwl', 'PRT', 2264397),
(185, 'PW', 'Palau', 'USD', '19907', 'PS', '585', '8.46966', '2.8036', '134.72307', '131.11788', 'Melekeok - Palau State Capital', 'Oceania', 'OC', '458.0', 'pau,sov,en-PW,tox,ja,fil,zh', 'PLW', 1559582),
(186, 'PY', 'Paraguay', 'PYG', '6375830', 'PA', '600', '-19.294041', '-27.608738', '-54.259354', '-62.647076', 'Asunci&amp;amp;amp;oacute;n', 'South America', 'SA', '406750.0', 'es-PY,gn', 'PRY', 3437598),
(187, 'QA', 'Qatar', 'QAR', '840926', 'QA', '634', '26.154722', '24.482944', '51.636639', '50.757221', 'Doha', 'Asia', 'AS', '11437.0', 'ar-QA,es', 'QAT', 289688),
(188, 'RE', 'Reunion', 'EUR', '776948', 'RE', '638', '-20.856855', '-21.372211', '55.845039', '55.219086', 'Saint-Denis', 'Africa', 'AF', '2517.0', 'fr-RE', 'REU', 935317),
(189, 'RO', 'Romania', 'RON', '21959278', 'RO', '642', '48.266945', '43.627304', '29.691055', '20.269972', 'Bucharest', 'Europe', 'EU', '237500.0', 'ro,hu,rom', 'ROU', 798549),
(190, 'RS', 'Serbia', 'RSD', '7344847', 'RI', '688', '46.18138885498047', '42.232215881347656', '23.00499725341797', '18.817020416259766', 'Belgrade', 'Europe', 'EU', '88361.0', 'sr,hu,bs,rom', 'SRB', 6290252),
(191, 'RU', 'Russia', 'RUB', '140702000', 'RS', '643', '81.857361', '41.188862', '-169.05', '19.25', 'Moscow', 'Europe', 'EU', '1.71E7', 'ru,tt,xal,cau,ady,kv,ce,tyv,cv', 'RUS', 2017370),
(192, 'RW', 'Rwanda', 'RWF', '11055976', 'RW', '646', '-1.053481', '-2.840679', '30.895958', '28.856794', 'Kigali', 'Africa', 'AF', '26338.0', 'rw,en-RW,fr-RW,sw', 'RWA', 49518),
(193, 'SA', 'Saudi Arabia', 'SAR', '25731776', 'SA', '682', '32.158333', '15.61425', '55.666584', '34.495693', 'Riyadh', 'Asia', 'AS', '1960582.0', 'ar-SA', 'SAU', 102358),
(194, 'SB', 'Solomon Islands', 'SBD', '559198', 'BP', '090', '-6.589611', '-11.850555', '166.980865', '155.508606', 'Honiara', 'Oceania', 'OC', '28450.0', 'en-SB,tpi', 'SLB', 2103350),
(195, 'SC', 'Seychelles', 'SCR', '88340', 'SE', '690', '-4.283717', '-9.753867', '56.279507', '46.204769', 'Victoria', 'Africa', 'AF', '455.0', 'en-SC,fr-SC', 'SYC', 241170),
(196, 'SD', 'Sudan', 'SDG', '35000000', 'SU', '729', '22.232219696044922', '8.684720993041992', '38.60749816894531', '21.827774047851562', 'Khartoum', 'Africa', 'AF', '1861484.0', 'ar-SD,en,fia', 'SDN', 366755),
(197, 'SE', 'Sweden', 'SEK', '9045000', 'SW', '752', '69.0625', '55.337112', '24.156292483918484', '11.118694', 'Stockholm', 'Europe', 'EU', '449964.0', 'sv-SE,se,sma,fi-SE', 'SWE', 2661886),
(198, 'SG', 'Singapore', 'SGD', '4701069', 'SN', '702', '1.471278', '1.258556', '104.007469', '103.638275', 'Singapore', 'Asia', 'AS', '692.7', 'cmn,en-SG,ms-SG,ta-SG,zh-SG', 'SGP', 1880251),
(199, 'SH', 'Saint Helena', 'SHP', '7460', 'SH', '654', '-7.887815', '-16.019543', '-5.638753', '-14.42123', 'Jamestown', 'Africa', 'AF', '410.0', 'en-SH', 'SHN', 3370751),
(200, 'SI', 'Slovenia', 'EUR', '2007000', 'SI', '705', '46.877918', '45.413139', '16.566', '13.383083', 'Ljubljana', 'Europe', 'EU', '20273.0', 'sl,sh', 'SVN', 3190538),
(201, 'SJ', 'Svalbard and Jan Mayen', 'NOK', '2550', 'SV', '744', '80.762085', '79.220306', '33.287334', '17.699389', 'Longyearbyen', 'Europe', 'EU', '62049.0', 'no,ru', 'SJM', 607072),
(202, 'SK', 'Slovakia', 'EUR', '5455000', 'LO', '703', '49.603168', '47.728111', '22.570444', '16.84775', 'Bratislava', 'Europe', 'EU', '48845.0', 'sk,hu', 'SVK', 3057568),
(203, 'SL', 'Sierra Leone', 'SLL', '5245695', 'SL', '694', '10', '6.929611', '-10.284238', '-13.307631', 'Freetown', 'Africa', 'AF', '71740.0', 'en-SL,men,tem', 'SLE', 2403846),
(204, 'SM', 'San Marino', 'EUR', '31477', 'SM', '674', '43.99223730851663', '43.8937092171425', '12.51653186779788', '12.403538978820734', 'San Marino', 'Europe', 'EU', '61.2', 'it-SM', 'SMR', 3168068),
(205, 'SN', 'Senegal', 'XOF', '12323252', 'SG', '686', '16.691633', '12.307275', '-11.355887', '-17.535236', 'Dakar', 'Africa', 'AF', '196190.0', 'fr-SN,wo,fuc,mnk', 'SEN', 2245662),
(206, 'SO', 'Somalia', 'SOS', '10112453', 'SO', '706', '11.979166', '-1.674868', '51.412636', '40.986595', 'Mogadishu', 'Africa', 'AF', '637657.0', 'so-SO,ar-SO,it,en-SO', 'SOM', 51537),
(207, 'SR', 'Suriname', 'SRD', '492829', 'NS', '740', '6.004546', '1.831145', '-53.977493', '-58.086563', 'Paramaribo', 'South America', 'SA', '163270.0', 'nl-SR,en,srn,hns,jv', 'SUR', 3382998),
(208, 'SS', 'South Sudan', 'SSP', '8260490', 'OD', '728', '12.219148635864258', '3.493394374847412', '35.9405517578125', '24.140274047851562', 'Juba', 'Africa', 'AF', '644329.0', 'en', 'SSD', 7909807),
(209, 'ST', 'Sao Tome and Principe', 'STD', '175808', 'TP', '678', '1.701323', '0.024766', '7.466374', '6.47017', 'Sao Tome', 'Africa', 'AF', '1001.0', 'pt-ST', 'STP', 2410758),
(210, 'SV', 'El Salvador', 'USD', '6052064', 'ES', '222', '14.445067', '13.148679', '-87.692162', '-90.128662', 'San Salvador', 'North America', 'NA', '21040.0', 'es-SV', 'SLV', 3585968),
(211, 'SX', 'Sint Maarten', 'ANG', '37429', 'NN', '534', '18.070248', '18.011692', '-63.012993', '-63.144039', 'Philipsburg', 'North America', 'NA', '', 'nl,en', 'SXM', 7609695),
(212, 'SY', 'Syria', 'SYP', '22198110', 'SY', '760', '37.319138', '32.310665', '42.385029', '35.727222', 'Damascus', 'Asia', 'AS', '185180.0', 'ar-SY,ku,hy,arc,fr,en', 'SYR', 163843),
(213, 'SZ', 'Swaziland', 'SZL', '1354051', 'WZ', '748', '-25.719648', '-27.317101', '32.13726', '30.794107', 'Mbabane', 'Africa', 'AF', '17363.0', 'en-SZ,ss-SZ', 'SWZ', 934841),
(214, 'TC', 'Turks and Caicos Islands', 'USD', '20556', 'TK', '796', '21.961878', '21.422626', '-71.123642', '-72.483871', 'Cockburn Town', 'North America', 'NA', '430.0', 'en-TC', 'TCA', 3576916),
(215, 'TD', 'Chad', 'XAF', '10543464', 'CD', '148', '23.450369', '7.441068', '24.002661', '13.473475', 'N''Djamena', 'Africa', 'AF', '1284000.0', 'fr-TD,ar-TD,sre', 'TCD', 2434508),
(216, 'TF', 'French Southern Territories', 'EUR', '140', 'FS', '260', '-37.790722', '-49.735184', '77.598808', '50.170258', 'Port-aux-Fran&amp;amp;amp;cced', 'Antarctica', 'AN', '7829.0', 'fr', 'ATF', 1546748),
(217, 'TG', 'Togo', 'XOF', '6587239', 'TO', '768', '11.138977', '6.104417', '1.806693', '-0.147324', 'Lom&amp;amp;amp;eacute;', 'Africa', 'AF', '56785.0', 'fr-TG,ee,hna,kbp,dag,ha', 'TGO', 2363686),
(218, 'TH', 'Thailand', 'THB', '67089500', 'TH', '764', '20.463194', '5.61', '105.639389', '97.345642', 'Bangkok', 'Asia', 'AS', '514000.0', 'th,en', 'THA', 1605651),
(219, 'TJ', 'Tajikistan', 'TJS', '7487489', 'TI', '762', '41.042252', '36.674137', '75.137222', '67.387138', 'Dushanbe', 'Asia', 'AS', '143100.0', 'tg,ru', 'TJK', 1220409),
(220, 'TK', 'Tokelau', 'NZD', '1466', 'TL', '772', '-8.553613662719727', '-9.381111145019531', '-171.21142578125', '-172.50033569335938', '', 'Oceania', 'OC', '10.0', 'tkl,en-TK', 'TKL', 4031074),
(221, 'TL', 'East Timor', 'USD', '1154625', 'TT', '626', '-8.135833740234375', '-9.463626861572266', '127.30859375', '124.04609680175781', 'Dili', 'Oceania', 'OC', '15007.0', 'tet,pt-TL,id,en', 'TLS', 1966436),
(222, 'TM', 'Turkmenistan', 'TMT', '4940916', 'TX', '795', '42.795555', '35.141083', '66.684303', '52.441444', 'Ashgabat', 'Asia', 'AS', '488100.0', 'tk,ru,uz', 'TKM', 1218197),
(223, 'TN', 'Tunisia', 'TND', '10589025', 'TS', '788', '37.543915', '30.240417', '11.598278', '7.524833', 'Tunis', 'Africa', 'AF', '163610.0', 'ar-TN,fr', 'TUN', 2464461),
(224, 'TO', 'Tonga', 'TOP', '122580', 'TN', '776', '-15.562988', '-21.455057', '-173.907578', '-175.682266', 'Nuku''alofa', 'Oceania', 'OC', '748.0', 'to,en-TO', 'TON', 4032283),
(225, 'TR', 'Turkey', 'TRY', '77804122', 'TU', '792', '42.107613', '35.815418', '44.834999', '25.668501', 'Ankara', 'Asia', 'AS', '780580.0', 'tr-TR,ku,diq,az,av', 'TUR', 298795),
(226, 'TT', 'Trinidad and Tobago', 'TTD', '1228691', 'TD', '780', '11.338342', '10.036105', '-60.517933', '-61.923771', 'Port of Spain', 'North America', 'NA', '5128.0', 'en-TT,hns,fr,es,zh', 'TTO', 3573591),
(227, 'TV', 'Tuvalu', 'AUD', '10472', 'TV', '798', '-5.641972', '-10.801169', '179.863281', '176.064865', 'Funafuti', 'Oceania', 'OC', '26.0', 'tvl,en,sm,gil', 'TUV', 2110297),
(228, 'TW', 'Taiwan', 'TWD', '22894384', 'TW', '158', '25.29825', '21.901806', '122.000443', '119.534691', 'Taipei', 'Asia', 'AS', '35980.0', 'zh-TW,zh,nan,hak', 'TWN', 1668284),
(229, 'TZ', 'Tanzania', 'TZS', '41892895', 'TZ', '834', '-0.990736', '-11.745696', '40.443222', '29.327168', 'Dodoma', 'Africa', 'AF', '945087.0', 'sw-TZ,en,ar', 'TZA', 149590),
(230, 'UA', 'Ukraine', 'UAH', '45415596', 'UP', '804', '52.369362', '44.390415', '40.20739', '22.128889', 'Kyiv', 'Europe', 'EU', '603700.0', 'uk,ru-UA,rom,pl,hu', 'UKR', 690791),
(231, 'UG', 'Uganda', 'UGX', '33398682', 'UG', '800', '4.214427', '-1.48405', '35.036049', '29.573252', 'Kampala', 'Africa', 'AF', '236040.0', 'en-UG,lg,sw,ar', 'UGA', 226074),
(232, 'UM', 'U.S. Minor Outlying Islands', 'USD', '0', '', '581', '28.219814', '-0.389006', '166.654526', '-177.392029', '', 'Oceania', 'OC', '0.0', 'en-UM', 'UMI', 5854968),
(233, 'US', 'United States', 'USD', '310232863', 'US', '840', '49.388611', '24.544245', '-66.954811', '-124.733253', 'Washington', 'North America', 'NA', '9629091.0', 'en-US,es-US,haw,fr', 'USA', 6252001),
(234, 'UY', 'Uruguay', 'UYU', '3477000', 'UY', '858', '-30.082224', '-34.980816', '-53.073933', '-58.442722', 'Montevideo', 'South America', 'SA', '176220.0', 'es-UY', 'URY', 3439705),
(235, 'UZ', 'Uzbekistan', 'UZS', '27865738', 'UZ', '860', '45.575001', '37.184444', '73.132278', '55.996639', 'Tashkent', 'Asia', 'AS', '447400.0', 'uz,ru,tg', 'UZB', 1512440),
(236, 'VA', 'Vatican City', 'EUR', '921', 'VT', '336', '41.90743830885576', '41.90027960306854', '12.45837546629481', '12.44570678169205', 'Vatican', 'Europe', 'EU', '0.44', 'la,it,fr', 'VAT', 3164670),
(237, 'VC', 'Saint Vincent and the Grenadines', 'XCD', '104217', 'VC', '670', '13.377834', '12.583984810969037', '-61.11388', '-61.46090317727658', 'Kingstown', 'North America', 'NA', '389.0', 'en-VC,fr', 'VCT', 3577815),
(238, 'VE', 'Venezuela', 'VEF', '27223228', 'VE', '862', '12.201903', '0.626311', '-59.80378', '-73.354073', 'Caracas', 'South America', 'SA', '912050.0', 'es-VE', 'VEN', 3625428),
(239, 'VG', 'British Virgin Islands', 'USD', '21730', 'VI', '092', '18.757221', '18.38998', '-64.268768', '-64.715363', 'Road Town', 'North America', 'NA', '153.0', 'en-VG', 'VGB', 3577718),
(240, 'VI', 'U.S. Virgin Islands', 'USD', '108708', 'VQ', '850', '18.391747', '17.681725', '-64.565178', '-65.038231', 'Charlotte Amalie', 'North America', 'NA', '352.0', 'en-VI', 'VIR', 4796775),
(241, 'VN', 'Vietnam', 'VND', '89571130', 'VM', '704', '23.388834', '8.559611', '109.464638', '102.148224', 'Hanoi', 'Asia', 'AS', '329560.0', 'vi,en,fr,zh,km', 'VNM', 1562822),
(242, 'VU', 'Vanuatu', 'VUV', '221552', 'NH', '548', '-13.073444', '-20.248945', '169.904785', '166.524979', 'Port Vila', 'Oceania', 'OC', '12200.0', 'bi,en-VU,fr-VU', 'VUT', 2134431),
(243, 'WF', 'Wallis and Futuna', 'XPF', '16025', 'WF', '876', '-13.214251', '-14.3286', '-176.128784', '-178.206787', 'Mata-Utu', 'Oceania', 'OC', '274.0', 'wls,fud,fr-WF', 'WLF', 4034749),
(244, 'WS', 'Samoa', 'WST', '192001', 'WS', '882', '-13.432207', '-14.040939', '-171.415741', '-172.798599', 'Apia', 'Oceania', 'OC', '2944.0', 'sm,en-WS', 'WSM', 4034894),
(245, 'XK', 'Kosovo', 'EUR', '1800000', 'KV', '0', '43.2682495807952', '41.856369601859925', '21.80335088694943', '19.977481504492914', 'Pristina', 'Europe', 'EU', '', 'sq,sr', 'XKX', 831053),
(246, 'YE', 'Yemen', 'YER', '23495361', 'YM', '887', '18.9999989031009', '12.1110910264462', '54.5305388163283', '42.5325394314234', 'Sanaa', 'Asia', 'AS', '527970.0', 'ar-YE', 'YEM', 69543),
(247, 'YT', 'Mayotte', 'EUR', '159042', 'MF', '175', '-12.648891', '-13.000132', '45.29295', '45.03796', 'Mamoutzou', 'Africa', 'AF', '374.0', 'fr-YT', 'MYT', 1024031),
(248, 'ZA', 'South Africa', 'ZAR', '49000000', 'SF', '710', '-22.126612', '-34.839828', '32.895973', '16.458021', 'Pretoria', 'Africa', 'AF', '1219912.0', 'zu,xh,af,nso,en-ZA,tn,st,ts,ss', 'ZAF', 953987),
(249, 'ZM', 'Zambia', 'ZMK', '13460305', 'ZA', '894', '-8.22436', '-18.079473', '33.705704', '21.999371', 'Lusaka', 'Africa', 'AF', '752614.0', 'en-ZM,bem,loz,lun,lue,ny,toi', 'ZMB', 895949),
(250, 'ZW', 'Zimbabwe', 'ZWL', '11651858', 'ZI', '716', '-15.608835', '-22.417738', '33.056305', '25.237028', 'Harare', 'Africa', 'AF', '390580.0', 'en-ZW,sn,nr,nd', 'ZWE', 878675);

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `idLanguage` int(11) NOT NULL AUTO_INCREMENT,
  `nameLanguage` varchar(32) CHARACTER SET utf8 NOT NULL,
  `codeLanguage` varchar(4) CHARACTER SET utf8 NOT NULL,
  `defaultLanguage` tinyint(1) NOT NULL DEFAULT '0',
  `statusLanguage` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionLanguage` datetime NOT NULL,
  `dateUpdationLanguage` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idLanguage`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`idLanguage`, `nameLanguage`, `codeLanguage`, `defaultLanguage`, `statusLanguage`, `dateAdditionLanguage`, `dateUpdationLanguage`) VALUES
(1, 'English ', 'EN', 1, 1, '2013-05-15 07:35:55', '2013-05-25 05:25:49'),
(2, '&amp;amp;agrave;&amp;amp;deg;&am', 'TL', 0, 1, '2013-05-15 07:35:55', '2013-05-30 01:37:31'),
(3, '&amp;amp;agrave;&amp;amp;reg;&am', 'TL', 0, 1, '2013-05-15 07:35:55', '2013-05-19 07:57:18'),
(4, 'Hindi', 'hn', 0, 0, '2013-05-15 07:35:55', '2013-05-30 01:45:18');

-- --------------------------------------------------------

--
-- Table structure for table `mails`
--

CREATE TABLE IF NOT EXISTS `mails` (
  `idMail` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(200) NOT NULL,
  `replyTo` varchar(200) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `link` varchar(200) NOT NULL,
  `statusMail` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idMail`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `mails`
--

INSERT INTO `mails` (`idMail`, `from`, `replyTo`, `subject`, `body`, `link`, `statusMail`) VALUES
(1, '', '', '[:User:] - Registration success', '&amp;amp;lt;p&amp;amp;gt;&amp;amp;lt;strong&amp;amp;gt;Dear [:User:],&amp;amp;lt;/strong&amp;amp;gt;&amp;amp;lt;/p&amp;amp;gt;\n&amp;amp;lt;p&amp;amp;gt;&amp;amp;amp;nbsp;&amp;amp;lt;/p&amp;amp;gt;\n&amp;amp;lt;p&amp;amp;gt;Your registration with us success.&amp;amp;lt;/p&amp;amp;gt;\n&amp;amp;lt;p&amp;amp;gt;&amp;amp;amp;nbsp;&amp;amp;lt;/p&amp;amp;gt;\n&amp;amp;lt;p&amp;amp;gt;Regards&amp;amp;lt;/p&amp;amp;gt;\n&amp;amp;lt;p&amp;amp;gt;Confianza Technologies, Hyderabad.&amp;amp;lt;/p&amp;amp;gt;\n&amp;amp;lt;p&amp;amp;gt;&amp;amp;amp;nbsp;&amp;amp;lt;/p&amp;amp;gt;', 'register', 1),
(2, '', '', '[:User:] - Password changed successfully', '&amp;amp;lt;p&amp;amp;gt;kljhklmlk&amp;amp;lt;/p&amp;amp;gt;', 'password_change', 1),
(3, '', '', 'Getting back to the cms account', '&amp;amp;lt;p&amp;amp;gt;&amp;amp;lt;em&amp;amp;gt;&amp;amp;lt;strong&amp;amp;gt;&amp;amp;lt;img src=&amp;amp;quot;http://confianza.co.in/templates/frontend/default/images/my_logo2.png&amp;amp;quot; alt=&amp;amp;quot;&amp;amp;quot; width=&amp;amp;quot;431&amp;amp;quot; height=&amp;amp;quot;72&amp;amp;quot; /&amp;amp;gt;&amp;amp;lt;/strong&amp;amp;gt;&amp;amp;lt;/em&amp;amp;gt;&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;&amp;amp;lt;em&amp;amp;gt;&amp;amp;lt;strong&amp;amp;gt;Hello [:AdminUser:]&amp;amp;lt;/strong&amp;amp;gt;&amp;amp;lt;/em&amp;amp;gt;&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;&amp;amp;lt;br /&amp;amp;gt;&amp;amp;lt;br /&amp;amp;gt;You attempted to log in to cms account with wrong password.&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;Please check your log in details clearly and try.&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;&amp;amp;amp;nbsp;or&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;Reset your password &amp;amp;lt;a href=&amp;amp;quot;http://www.confianza.me/uno/administrator/&amp;amp;quot;&amp;amp;gt;here&amp;amp;lt;/a&amp;amp;gt;&amp;amp;amp;nbsp;&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;&amp;amp;amp;nbsp;&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;&amp;amp;lt;strong&amp;amp;gt;&amp;amp;lt;span style=&amp;amp;quot;text-decoration: underline;&amp;amp;quot;&amp;amp;gt;Regards&amp;amp;lt;/span&amp;amp;gt;&amp;amp;lt;/strong&amp;amp;gt;&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;Confianza technologies&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p style=&amp;amp;quot;padding-left: 30px;&amp;amp;quot;&amp;amp;gt;&amp;amp;lt;a href=&amp;amp;quot;http://www.facebook.com/confianza&amp;amp;quot;&amp;amp;gt;facebook&amp;amp;lt;/a&amp;amp;gt;, &amp;amp;lt;a href=&amp;amp;quot;http://www.linkedin.com&amp;amp;quot;&amp;amp;gt;LInkedin&amp;amp;lt;/a&amp;amp;gt;&amp;amp;lt;/p&amp;amp;gt;', 'frequent_login_attempts', 1),
(4, '', '', 'newsletter mail', '&amp;amp;lt;p&amp;amp;gt;This is test newsletter mail&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p&amp;amp;gt;&amp;amp;amp;nbsp;&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p&amp;amp;gt;Regards&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p&amp;amp;gt;Confianza CMS &amp;amp;amp;amp;copy 2013&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p&amp;amp;gt;confianza technologies, hyderabad&amp;amp;lt;/p&amp;amp;gt;\r\n&amp;amp;lt;p&amp;amp;gt;&amp;amp;amp;nbsp;&amp;amp;lt;/p&amp;amp;gt;', 'newsletter', 1),
(5, '', '', 'Reset Password', '<p>Dear&nbsp;[:User:],</p>\n<p>&nbsp;</p>\n<p>Please click on the following link to reset your password. [:link]</p>\n<p>&nbsp;</p>\n<p>Regards</p>\n<p>Quikc</p>\n<p>&nbsp;</p>', 'forgot_email', 1);

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `idMedia` int(11) NOT NULL AUTO_INCREMENT,
  `pathMedia` varchar(500) NOT NULL,
  `nameMedia` varchar(100) DEFAULT NULL,
  `idCategory` int(11) DEFAULT NULL,
  `typeMedia` varchar(50) DEFAULT NULL,
  `widthMedia` int(5) DEFAULT NULL,
  `heightMedia` int(5) DEFAULT NULL,
  `sizeMedia` int(11) DEFAULT NULL,
  `uses` int(11) DEFAULT NULL,
  `starred` tinyint(1) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `Updatedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idMedia`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`idMedia`, `pathMedia`, `nameMedia`, `idCategory`, `typeMedia`, `widthMedia`, `heightMedia`, `sizeMedia`, `uses`, `starred`, `time`, `Updatedtime`) VALUES
(1, '2z6f4xz89a_website-offline.jpg', 'website-offline', 1, 'jpg', 172, 152, 3156, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(2, 'Office-Customer-Female-Light-icon.png', 'Office-Customer-Female-Light-icon', 1, 'png', 256, 256, 42540, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(3, 'Permissions-icon.png', 'Permissions-icon', 1, 'png', 128, 128, 9125, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(4, 'Person-Female-Light-icon.png', 'Person-Female-Light-icon', 1, 'png', 256, 256, 31697, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(5, 'Places-user-identity-icon.png', 'Places-user-identity-icon', 1, 'png', 256, 256, 30894, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(6, 'aboutus.jpg', 'aboutus', 1, 'jpg', 1199, 550, 88152, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(7, 'actions-window-close-icon.png', 'actions-window-close-icon', 1, 'png', 256, 256, 39321, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(8, 'admin-icon.png', 'admin-icon', 1, 'png', 128, 128, 22821, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(9, 'backup-icon.png', 'backup-icon', 1, 'png', 128, 128, 10644, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(10, 'blocks-icon.png', 'blocks-icon', 1, 'png', 128, 128, 8613, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(11, 'cache.png', 'cache', 1, 'png', 128, 128, 20759, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(12, 'cms-icon.png', 'cms-icon', 1, 'png', 128, 128, 16977, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(13, 'cmsmails-icon.png', 'cmsmails-icon', 1, 'png', 128, 128, 6486, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(14, 'cmssets-icon.png', 'cmssets-icon', 1, 'png', 128, 128, 5958, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(15, 'confianza-logo.png', 'confianza-logo', 1, 'png', 93, 86, 11687, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(16, 'confianza16.png', 'confianza16', 1, 'png', 16, 16, 1150, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(17, 'configuration-settings-icon.png', 'configuration-settings-icon', 1, 'png', 128, 128, 20298, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(18, 'configurations-icon.png', 'configurations-icon', 1, 'png', 128, 128, 11633, NULL, NULL, '2013-08-22 08:57:13', '2013-08-22 03:27:13'),
(19, 'copy-icon.png', 'copy-icon', 1, 'png', 128, 128, 5395, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(20, 'countries-icon.png', 'countries-icon', 1, 'png', 128, 128, 27205, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(22, 'css-icon.png', 'css-icon', 1, 'png', 128, 128, 9092, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(23, 'dashboard-icon.png', 'dashboard-icon', 1, 'png', 256, 256, 30102, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(24, 'developer-settings-icon.png', 'developer-settings-icon', 1, 'png', 128, 128, 12749, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(25, 'edit-profile-icon.png', 'edit-profile-icon', 1, 'png', 128, 128, 12564, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(27, 'folder-file-import-icon.png', 'folder-file-import-icon', 1, 'png', 128, 128, 13555, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(28, 'forms-icon.png', 'forms-icon', 1, 'png', 128, 128, 21636, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(30, 'html-icon.png', 'html-icon', 1, 'png', 128, 128, 7826, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(31, 'java-icon.png', 'java-icon', 1, 'png', 128, 128, 8425, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(32, 'labels-icon.png', 'labels-icon', 1, 'png', 128, 128, 13042, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(33, 'library-icon.png', 'library-icon', 1, 'png', 128, 128, 6756, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(34, 'list-icon.png', 'list-icon', 1, 'png', 128, 128, 6222, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(35, 'login-settings-icon.png', 'login-settings-icon', 1, 'png', 128, 128, 14865, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(36, 'logs-icon.png', 'logs-icon', 1, 'png', 128, 128, 10324, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(37, 'mail-settings-icon.png', 'mail-settings-icon', 1, 'png', 128, 128, 9687, NULL, NULL, '2013-08-22 08:57:14', '2013-08-22 03:27:14'),
(38, 'menu-icon.png', 'menu-icon', 1, 'png', 128, 128, 10533, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(39, 'pages-icon.png', 'pages-icon', 1, 'png', 128, 128, 10721, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(40, 'plugins-icon.png', 'plugins-icon', 1, 'png', 128, 128, 16084, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(41, 'pluginsnew-icon.png', 'pluginsnew-icon', 1, 'png', 128, 128, 19715, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(43, 'system-icon.png', 'system-icon', 1, 'png', 128, 128, 6020, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(44, 'themes-icon.png', 'themes-icon', 1, 'png', 128, 128, 25793, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(45, 'timezones-icon.png', 'timezones-icon', 1, 'png', 128, 128, 19661, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(46, 'user-female-icon.png', 'user-female-icon', 1, 'png', 256, 256, 55634, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(47, 'user-icon.png', 'user-icon', 1, 'png', 256, 256, 42633, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(48, 'user-male-icon.png', 'user-male-icon', 1, 'png', 256, 256, 43610, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(49, 'user-password-icon.png', 'user-password-icon', 1, 'png', 128, 128, 15517, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15'),
(50, 'user-settings-icon.png', 'user-settings-icon', 1, 'png', 128, 128, 14931, NULL, NULL, '2013-08-22 08:57:15', '2013-08-22 03:27:15');

-- --------------------------------------------------------

--
-- Table structure for table `media_categories`
--

CREATE TABLE IF NOT EXISTS `media_categories` (
  `idCategory` int(11) NOT NULL AUTO_INCREMENT,
  `nameCategory` varchar(300) NOT NULL,
  `statusCategory` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionMediaCategory` datetime NOT NULL,
  `dateUpdationMediaCategory` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idCategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `media_categories`
--

INSERT INTO `media_categories` (`idCategory`, `nameCategory`, `statusCategory`, `dateAdditionMediaCategory`, `dateUpdationMediaCategory`) VALUES
(1, 'Images', 1, '2013-08-22 08:55:02', '2013-10-13 23:32:13'),
(2, 'Videos', 1, '2013-08-22 08:55:02', '2013-10-13 23:32:13'),
(3, 'Documents', 1, '2013-08-22 08:55:02', '2013-10-13 23:32:58');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `idMenu` bigint(20) NOT NULL AUTO_INCREMENT,
  `classMenu` varchar(100) NOT NULL,
  `titleMenu` varchar(48) NOT NULL,
  `descriptionMenu` varchar(255) NOT NULL,
  `statusMenu` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionMenu` datetime NOT NULL,
  `dateUpdationMenu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idMenu`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`idMenu`, `classMenu`, `titleMenu`, `descriptionMenu`, `statusMenu`, `dateAdditionMenu`, `dateUpdationMenu`) VALUES
(1, 'first_menu', 'First Menu', 'first menu description', 1, '2013-08-22 04:01:04', '2013-12-16 10:59:53');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE IF NOT EXISTS `menu_items` (
  `idMenuItem` bigint(20) NOT NULL AUTO_INCREMENT,
  `idMenu` bigint(20) NOT NULL,
  `titleMenuItem` varchar(255) NOT NULL,
  `imageMenuItem` varchar(255) NOT NULL,
  `linkMenuItem` varchar(1024) NOT NULL,
  `linkTypeMenuItem` varchar(16) NOT NULL,
  `idLinkTypeMenuItem` varchar(255) NOT NULL,
  `parentMenuItem` bigint(20) NOT NULL,
  `orderMenuItem` int(5) NOT NULL,
  `statusMenuItem` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionMenuItem` int(11) NOT NULL,
  `dateUpdationMenuItem` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idMenuItem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`idMenuItem`, `idMenu`, `titleMenuItem`, `imageMenuItem`, `linkMenuItem`, `linkTypeMenuItem`, `idLinkTypeMenuItem`, `parentMenuItem`, `orderMenuItem`, `statusMenuItem`, `dateAdditionMenuItem`, `dateUpdationMenuItem`) VALUES
(1, 1, 'First Menu Item', '', '', '', '', 3, 0, 1, 0, '2013-12-16 06:37:10'),
(2, 1, 'First Creation', 'pluginsnew-icon.png', '', '1', '1', 0, 1, 1, 2013, '2013-12-16 06:37:15'),
(3, 1, 'Privacy', 'user-female-icon.png', '', '1', '3', 4, 0, 1, 2013, '2013-12-14 07:45:36'),
(4, 1, 'Default', 'plugins-icon.png', '', '1', '2', 0, 0, 1, 2013, '2013-12-02 08:45:41'),
(5, 1, 'External LInk', '', 'https://snt149.mail.live.com/default.aspx?id=64855#n=1270751777&fid=1', '2', '', 0, 2, 1, 2013, '2013-12-16 11:45:57'),
(6, 1, 'new menu item', '', '', '1', '4', 5, 0, 1, 2013, '2013-12-16 11:45:57'),
(7, 1, 'new testing', '', '', '1', '4', 3, 1, 1, 2013, '2013-12-17 09:26:29');

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

CREATE TABLE IF NOT EXISTS `plugins` (
  `idPlugin` int(11) NOT NULL AUTO_INCREMENT,
  `namePlugin` varchar(100) NOT NULL,
  `identifierPlugin` varchar(100) NOT NULL,
  `statusPlugin` tinyint(1) NOT NULL DEFAULT '0',
  `autoLoadPlugin` tinyint(1) NOT NULL DEFAULT '0',
  `dateAdditionPlugin` datetime NOT NULL,
  `dateInstallationPlugin` datetime NOT NULL,
  `dateUpdationPlugin` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `versionPlugin` varchar(20) NOT NULL,
  `authorPlugin` varchar(100) NOT NULL,
  `urlPlugin` varchar(200) NOT NULL,
  PRIMARY KEY (`idPlugin`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `plugins`
--

INSERT INTO `plugins` (`idPlugin`, `namePlugin`, `identifierPlugin`, `statusPlugin`, `autoLoadPlugin`, `dateAdditionPlugin`, `dateInstallationPlugin`, `dateUpdationPlugin`, `versionPlugin`, `authorPlugin`, `urlPlugin`) VALUES
(55, 'Tiny Mice', 'tinymice', 1, 1, '2013-08-17 02:19:25', '2013-08-17 02:19:25', '2013-08-25 13:19:55', '1.0.0', 'Quikc', 'http://www.quikc.org/'),
(56, 'Phpthumb', 'phpthumb', 0, 1, '2013-08-17 02:19:30', '2013-08-17 02:19:30', '2013-09-21 04:59:29', '1.0.0', 'Quikc', 'http://www.quikc.org/'),
(60, 'Media Plugin', 'quikcmedia', 1, 1, '2013-08-22 08:55:02', '2013-08-22 08:55:02', '2013-08-22 03:25:02', '1.0.0', 'Quikc', 'http://www.quikc.org/'),
(61, 'Advanced Cms(Dynamic Lists, Forms)', 'quikcadvancedcms', 1, 1, '2013-08-27 04:51:09', '2013-08-27 04:51:09', '2013-10-03 13:36:38', '1.0.0', 'Quikc', 'http://www.quikc.org/'),
(62, 'Date Picker', 'datepicker', 1, 1, '2013-08-27 17:27:58', '2013-08-27 17:27:58', '2013-08-27 11:57:58', '1.0.0', 'Quikc', 'http://www.quikc.org/');

-- --------------------------------------------------------

--
-- Table structure for table `relations`
--

CREATE TABLE IF NOT EXISTS `relations` (
  `idRelation` bigint(20) NOT NULL AUTO_INCREMENT,
  `idFrom` text NOT NULL,
  `idTo` text NOT NULL,
  `typeRelation` varchar(500) NOT NULL,
  `fieldAdditional1` text NOT NULL,
  `fieldAdditional2` text NOT NULL,
  `fieldAdditional3` text NOT NULL,
  `dateAdditionRelation` datetime NOT NULL,
  `dateUpdationRelation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idRelation`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=705 ;

--
-- Dumping data for table `relations`
--

INSERT INTO `relations` (`idRelation`, `idFrom`, `idTo`, `typeRelation`, `fieldAdditional1`, `fieldAdditional2`, `fieldAdditional3`, `dateAdditionRelation`, `dateUpdationRelation`) VALUES
(451, '2', '9', 'space_to_widget', '1', '', '', '2013-10-13 14:29:14', '2013-10-13 08:59:14'),
(464, '4', '1', 'space_to_widget', '1', '', '', '2013-10-15 15:16:02', '2013-10-15 09:46:02'),
(608, '3', '2', 'space_to_widget', '1', '', '', '2013-10-15 15:30:04', '2013-10-15 10:00:04'),
(664, '1', '24', 'space_to_widget', '1', '', '', '2013-12-17 13:38:43', '2013-12-17 08:08:43'),
(704, '5', '21', 'space_to_widget', '1', '', '', '2013-12-17 13:39:58', '2013-12-17 08:09:58');

-- --------------------------------------------------------

--
-- Table structure for table `spaces`
--

CREATE TABLE IF NOT EXISTS `spaces` (
  `idSpace` bigint(20) NOT NULL AUTO_INCREMENT,
  `titleSpace` varchar(500) NOT NULL,
  `idPage` bigint(20) NOT NULL,
  `globalSpace` tinyint(1) NOT NULL DEFAULT '0',
  `systemItem` tinyint(1) NOT NULL DEFAULT '0',
  `statusSpace` tinyint(1) NOT NULL DEFAULT '1',
  `createdById` varchar(100) NOT NULL,
  `createdByType` varchar(20) NOT NULL,
  `dateAdditionSpace` datetime NOT NULL,
  `dateUpdationSpace` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idSpace`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `spaces`
--

INSERT INTO `spaces` (`idSpace`, `titleSpace`, `idPage`, `globalSpace`, `systemItem`, `statusSpace`, `createdById`, `createdByType`, `dateAdditionSpace`, `dateUpdationSpace`) VALUES
(1, 'Main Menu', 2, 1, 0, 1, '', '', '2013-08-25 02:28:06', '2013-08-25 20:58:03'),
(2, 'Header Left', 2, 1, 0, 1, '', '', '2013-08-25 02:28:06', '2013-08-25 21:22:35'),
(3, 'Header Middle', 2, 1, 0, 1, '', '', '2013-08-25 02:28:06', '2013-08-25 20:58:03'),
(4, 'Header Right', 2, 1, 0, 1, '', '', '2013-08-25 02:28:06', '2013-08-25 20:58:03'),
(5, 'Header Logo', 2, 1, 0, 1, '', '', '2013-08-26 04:32:39', '2013-08-25 23:02:39');

-- --------------------------------------------------------

--
-- Table structure for table `time_zones`
--

CREATE TABLE IF NOT EXISTS `time_zones` (
  `idTimezone` int(50) NOT NULL AUTO_INCREMENT,
  `keyZone` varchar(100) NOT NULL,
  `titleZone` varchar(150) NOT NULL,
  `image` varchar(100) NOT NULL,
  `timeCreated` datetime NOT NULL,
  `timeUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idTimezone`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=254 ;

--
-- Dumping data for table `time_zones`
--

INSERT INTO `time_zones` (`idTimezone`, `keyZone`, `titleZone`, `image`, `timeCreated`, `timeUpdated`) VALUES
(127, 'Kwajalein', '(GMT-12:00) International Date Line West', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(128, 'Pacific/Midway', '(GMT-11:00) Midway Island', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(129, 'Pacific/Samoa', '(GMT-11:00) Samoa', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(130, 'Pacific/Honolulu', '(GMT-10:00) Hawaii', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(131, 'America/Anchorage', '(GMT-09:00) Alaska', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(132, 'America/Los_Angeles', '(GMT-08:00) Pacific Time (US &amp;amp; Canada)', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(133, 'America/Tijuana', '(GMT-08:00) Tijuana, Baja California', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(134, 'America/Denver', '(GMT-07:00) Mountain Time (US &amp;amp; Canada)', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(135, 'America/Chihuahua', '(GMT-07:00) Chihuahua', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(136, 'America/Mazatlan', '(GMT-07:00) Mazatlan', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(137, 'America/Phoenix', '(GMT-07:00) Arizona', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(138, 'America/Regina', '(GMT-06:00) Saskatchewan', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(139, 'America/Tegucigalpa', '(GMT-06:00) Central America', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(140, 'America/Chicago', '(GMT-06:00) Central Time (US &amp;amp; Canada)', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(141, 'America/Mexico_City', '(GMT-06:00) Mexico City', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(142, 'America/Monterrey', '(GMT-06:00) Monterrey', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(143, 'America/New_York', '(GMT-05:00) Eastern Time (US &amp;amp; Canada)', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(144, 'America/Bogota', '(GMT-05:00) Bogota', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(145, 'America/Lima', '(GMT-05:00) Lima', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(146, 'America/Rio_Branco', '(GMT-05:00) Rio Branco', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(147, 'America/Indiana/Indianapolis', '(GMT-05:00) Indiana (East)', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(148, 'America/Caracas', '(GMT-04:30) Caracas', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(149, 'America/Halifax', '(GMT-04:00) Atlantic Time (Canada)', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(150, 'America/Manaus', '(GMT-04:00) Manaus', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(151, 'America/Santiago', '(GMT-04:00) Santiago', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(152, 'America/La_Paz', '(GMT-04:00) La Paz', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(153, 'America/St_Johns', '(GMT-03:30) Newfoundland', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(154, 'America/Argentina/Buenos_Aires', '(GMT-03:00) Georgetown', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(155, 'America/Sao_Paulo', '(GMT-03:00) Brasilia', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(156, 'America/Godthab', '(GMT-03:00) Greenland', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(157, 'America/Montevideo', '(GMT-03:00) Montevideo', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(158, 'Atlantic/South_Georgia', '(GMT-02:00) Mid-Atlantic', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(159, 'Atlantic/Azores', '(GMT-01:00) Azores', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(160, 'Atlantic/Cape_Verde', '(GMT-01:00) Cape Verde Is.', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(161, 'Europe/Dublin', '(GMT) Dublin', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(162, 'Europe/Lisbon', '(GMT) Lisbon', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(163, 'Europe/London', '(GMT) London', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(164, 'Africa/Monrovia', '(GMT) Monrovia', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(165, 'Atlantic/Reykjavik', '(GMT) Reykjavik', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(166, 'Africa/Casablanca', '(GMT) Casablanca', '', '2013-05-15 05:59:16', '2013-08-27 22:56:59'),
(167, 'Europe/Belgrade', '(GMT+01:00) Belgrade', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(168, 'Europe/Bratislava', '(GMT+01:00) Bratislava', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(169, 'Europe/Budapest', '(GMT+01:00) Budapest', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(170, 'Europe/Ljubljana', '(GMT+01:00) Ljubljana', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(171, 'Europe/Prague', '(GMT+01:00) Prague', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(172, 'Europe/Sarajevo', '(GMT+01:00) Sarajevo', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(173, 'Europe/Skopje', '(GMT+01:00) Skopje', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(174, 'Europe/Warsaw', '(GMT+01:00) Warsaw', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(175, 'Europe/Zagreb', '(GMT+01:00) Zagreb', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(176, 'Europe/Brussels', '(GMT+01:00) Brussels', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(177, 'Europe/Copenhagen', '(GMT+01:00) Copenhagen', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(178, 'Europe/Madrid', '(GMT+01:00) Madrid', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(179, 'Europe/Paris', '(GMT+01:00) Paris', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(180, 'Africa/Algiers', '(GMT+01:00) West Central Africa', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(181, 'Europe/Amsterdam', '(GMT+01:00) Amsterdam', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(182, 'Europe/Berlin', '(GMT+01:00) Berlin', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(183, 'Europe/Rome', '(GMT+01:00) Rome', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(184, 'Europe/Stockholm', '(GMT+01:00) Stockholm', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(185, 'Europe/Vienna', '(GMT+01:00) Vienna', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(186, 'Europe/Minsk', '(GMT+02:00) Minsk', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(187, 'Africa/Cairo', '(GMT+02:00) Cairo', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(188, 'Europe/Helsinki', '(GMT+02:00) Helsinki', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(189, 'Europe/Riga', '(GMT+02:00) Riga', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(190, 'Europe/Sofia', '(GMT+02:00) Sofia', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(191, 'Europe/Tallinn', '(GMT+02:00) Tallinn', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(192, 'Europe/Vilnius', '(GMT+02:00) Vilnius', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(193, 'Europe/Athens', '(GMT+02:00) Athens', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(194, 'Europe/Bucharest', '(GMT+02:00) Bucharest', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(195, 'Europe/Istanbul', '(GMT+02:00) Istanbul', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(196, 'Asia/Jerusalem', '(GMT+02:00) Jerusalem', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(197, 'Asia/Amman', '(GMT+02:00) Amman', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(198, 'Asia/Beirut', '(GMT+02:00) Beirut', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(199, 'Africa/Windhoek', '(GMT+02:00) Windhoek', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(200, 'Africa/Harare', '(GMT+02:00) Harare', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(201, 'Asia/Kuwait', '(GMT+03:00) Kuwait', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(202, 'Asia/Riyadh', '(GMT+03:00) Riyadh', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(203, 'Asia/Baghdad', '(GMT+03:00) Baghdad', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(204, 'Africa/Nairobi', '(GMT+03:00) Nairobi', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(205, 'Asia/Tbilisi', '(GMT+03:00) Tbilisi', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(206, 'Europe/Moscow', '(GMT+03:00) Moscow', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(207, 'Europe/Volgograd', '(GMT+03:00) Volgograd', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(208, 'Asia/Tehran', '(GMT+03:30) Tehran', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(209, 'Asia/Muscat', '(GMT+04:00) Muscat', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(210, 'Asia/Baku', '(GMT+04:00) Baku', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(211, 'Asia/Yerevan', '(GMT+04:00) Yerevan', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(212, 'Asia/Yekaterinburg', '(GMT+05:00) Ekaterinburg', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(213, 'Asia/Karachi', '(GMT+05:00) Karachi', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(214, 'Asia/Tashkent', '(GMT+05:00) Tashkent', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(215, 'Asia/Kolkata', '(GMT+05:30) Calcutta', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(216, 'Asia/Colombo', '(GMT+05:30) Sri Jayawardenepura', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(217, 'Asia/Katmandu', '(GMT+05:45) Kathmandu', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(218, 'Asia/Dhaka', '(GMT+06:00) Dhaka', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(219, 'Asia/Almaty', '(GMT+06:00) Almaty', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(220, 'Asia/Novosibirsk', '(GMT+06:00) Novosibirsk', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(221, 'Asia/Rangoon', '(GMT+06:30) Yangon (Rangoon)', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(222, 'Asia/Krasnoyarsk', '(GMT+07:00) Krasnoyarsk', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(223, 'Asia/Bangkok', '(GMT+07:00) Bangkok', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(224, 'Asia/Jakarta', '(GMT+07:00) Jakarta', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(225, 'Asia/Brunei', '(GMT+08:00) Beijing', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(226, 'Asia/Chongqing', '(GMT+08:00) Chongqing', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(227, 'Asia/Hong_Kong', '(GMT+08:00) Hong Kong', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(228, 'Asia/Urumqi', '(GMT+08:00) Urumqi', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(229, 'Asia/Irkutsk', '(GMT+08:00) Irkutsk', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(230, 'Asia/Ulaanbaatar', '(GMT+08:00) Ulaan Bataar', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(231, 'Asia/Kuala_Lumpur', '(GMT+08:00) Kuala Lumpur', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(232, 'Asia/Singapore', '(GMT+08:00) Singapore', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(233, 'Asia/Taipei', '(GMT+08:00) Taipei', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(234, 'Australia/Perth', '(GMT+08:00) Perth', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(235, 'Asia/Seoul', '(GMT+09:00) Seoul', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(236, 'Asia/Tokyo', '(GMT+09:00) Tokyo', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(237, 'Asia/Yakutsk', '(GMT+09:00) Yakutsk', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(238, 'Australia/Darwin', '(GMT+09:30) Darwin', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(239, 'Australia/Adelaide', '(GMT+09:30) Adelaide', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(240, 'Australia/Canberra', '(GMT+10:00) Canberra', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(241, 'Australia/Melbourne', '(GMT+10:00) Melbourne', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(242, 'Australia/Sydney', '(GMT+10:00) Sydney', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(243, 'Australia/Brisbane', '(GMT+10:00) Brisbane', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(244, 'Australia/Hobart', '(GMT+10:00) Hobart', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(245, 'Asia/Vladivostok', '(GMT+10:00) Vladivostok', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(246, 'Pacific/Guam', '(GMT+10:00) Guam', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(247, 'Pacific/Port_Moresby', '(GMT+10:00) Port Moresby', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(248, 'Asia/Magadan', '(GMT+11:00) Magadan', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(249, 'Pacific/Fiji', '(GMT+12:00) Fiji', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(250, 'Asia/Kamchatka', '(GMT+12:00) Kamchatka', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(251, 'Pacific/Auckland', '(GMT+12:00) Auckland', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45'),
(252, 'Pacific/Tongatapu', '(GMT+13:00) Nukualofa', '', '2013-05-15 05:59:16', '2013-05-13 21:20:45');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `idUser` int(11) NOT NULL AUTO_INCREMENT,
  `adminUser` tinyint(1) NOT NULL DEFAULT '0',
  `superUser` tinyint(1) NOT NULL DEFAULT '0',
  `groupsUser` varchar(100) NOT NULL,
  `passwordUser` varchar(500) NOT NULL,
  `nameFirstUser` varchar(30) NOT NULL,
  `nameLastUser` varchar(30) NOT NULL,
  `emailUser` varchar(75) NOT NULL,
  `imageUser` varchar(100) NOT NULL,
  `countryUser` varchar(100) NOT NULL,
  `timezoneUser` varchar(100) NOT NULL DEFAULT 'Europe/London',
  `genderUser` char(10) NOT NULL,
  `mobilenoUser` varchar(100) NOT NULL,
  `loginModeUser` tinyint(1) NOT NULL,
  `isCaptchaUser` tinyint(1) NOT NULL DEFAULT '0',
  `attemptsFailureUser` int(3) NOT NULL,
  `dateLastAttemptUser` datetime NOT NULL,
  `statusUser` tinyint(1) NOT NULL DEFAULT '1',
  `preferencesUser` text NOT NULL,
  `dateAdditionUser` datetime NOT NULL,
  `dateUpdationUser` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idUser`),
  UNIQUE KEY `email` (`emailUser`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idUser`, `adminUser`, `superUser`, `groupsUser`, `passwordUser`, `nameFirstUser`, `nameLastUser`, `emailUser`, `imageUser`, `countryUser`, `timezoneUser`, `genderUser`, `mobilenoUser`, `loginModeUser`, `isCaptchaUser`, `attemptsFailureUser`, `dateLastAttemptUser`, `statusUser`, `preferencesUser`, `dateAdditionUser`, `dateUpdationUser`) VALUES
(1, 1, 1, '3', '0e7517141fb53f21ee439b355b5a1d0a', 'Sainath', 'Kotha', 'sainathkotha@confianza.co.in', 'user-icon.png', 'IN', 'Asia/Kolkata', '1', '7702286781/82', 1, 0, 0, '2013-09-22 10:12:15', 1, 'O:8:"stdClass":1:{s:5:"admin";O:8:"stdClass":3:{s:8:"searchme";O:8:"stdClass":1:{s:11:"preferences";O:8:"stdClass":2:{s:9:"valuePref";a:7:{i:0;a:2:{s:5:"title";s:10:"first save";s:5:"items";a:3:{s:6:"amenus";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}s:8:"cmspages";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}s:4:"user";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}}}i:1;a:2:{s:5:"title";s:11:"second save";s:5:"items";a:3:{s:6:"amenus";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}s:8:"cmspages";a:2:{s:6:"active";s:5:"false";s:4:"rows";s:2:"10";}s:4:"user";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:2:"15";}}}i:2;a:2:{s:5:"title";s:10:"only pages";s:5:"items";a:3:{s:6:"amenus";a:2:{s:6:"active";s:5:"false";s:4:"rows";s:1:"1";}s:8:"cmspages";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:2:"20";}s:4:"user";a:2:{s:6:"active";s:5:"false";s:4:"rows";s:1:"3";}}}i:4;a:2:{s:5:"title";s:10:"only menus";s:5:"items";a:3:{s:6:"amenus";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:2:"25";}s:8:"cmspages";a:2:{s:6:"active";s:5:"false";s:4:"rows";s:1:"5";}s:5:"users";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}}}i:5;a:2:{s:5:"title";s:10:"only users";s:5:"items";a:3:{s:6:"amenus";a:2:{s:6:"active";s:5:"false";s:4:"rows";s:1:"5";}s:8:"cmspages";a:2:{s:6:"active";s:5:"false";s:4:"rows";s:1:"5";}s:5:"users";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}}}i:6;a:2:{s:5:"title";s:7:"new one";s:5:"items";a:3:{s:6:"amenus";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}s:8:"cmspages";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}s:5:"users";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}}}i:7;a:2:{s:5:"title";s:7:"asdasda";s:5:"items";a:3:{s:6:"amenus";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}s:8:"cmspages";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}s:5:"users";a:2:{s:6:"active";s:4:"true";s:4:"rows";s:1:"5";}}}}s:7:"default";O:8:"stdClass":1:{s:9:"valuePref";i:-1;}}}s:9:"ajax-menu";O:8:"stdClass":1:{s:9:"valuePref";s:5:"false";}s:5:"lists";O:8:"stdClass":2:{s:5:"users";O:8:"stdClass":1:{s:11:"preferences";O:8:"stdClass":1:{s:9:"valuePref";a:1:{i:12;a:2:{s:5:"title";s:10:"sainath ko";s:7:"urlList";a:29:{s:14:"idsFieldFilter";s:11:"SKk4r,XXs6L";s:14:"idsFieldSortBy";s:11:"exAvk,Lrhim";s:10:"textPageNo";s:0:"";s:7:"perPage";s:2:"10";s:14:"filterLanguage";s:1:"0";s:17:"filterField_SKk4r";s:13:"namefirstuser";s:17:"filterQuery_SKk4r";s:7:"sainath";s:20:"filterPosition_SKk4r";s:0:"";s:17:"filterField_XXs6L";s:12:"namelastuser";s:17:"filterQuery_XXs6L";s:5:"kotha";s:20:"filterPosition_XXs6L";s:0:"";s:17:"sortbyField_exAvk";s:13:"namefirstuser";s:17:"sortbyOrder_exAvk";s:3:"asc";s:17:"sortbyField_Lrhim";s:12:"namelastuser";s:17:"sortbyOrder_Lrhim";s:3:"asc";s:20:"display_field_idUser";s:3:"1,0";s:27:"display_field_nameFirstUser";s:3:"1,1";s:26:"display_field_nameLastUser";s:3:"1,2";s:24:"display_field_genderUser";s:3:"1,3";s:23:"display_field_emailUser";s:3:"1,4";s:25:"display_field_countryUser";s:3:"1,5";s:23:"display_field_imageUser";s:3:"1,6";s:21:"display_field_actions";s:3:"1,7";s:23:"display_field_superUser";s:3:"0,8";s:30:"display_field_dateAdditionUser";s:3:"0,9";s:30:"display_field_dateUpdationUser";s:4:"0,10";s:26:"display_field_timezoneUser";s:4:"0,11";s:23:"display_field_adminUser";s:4:"0,12";s:21:"display_manage_fields";s:4:"true";}}}}}s:6:"amenus";O:8:"stdClass":1:{s:11:"preferences";O:8:"stdClass":2:{s:7:"default";O:8:"stdClass":1:{s:9:"valuePref";s:1:"0";}s:9:"valuePref";a:1:{i:0;a:2:{s:5:"title";s:7:"testing";s:7:"urlList";a:30:{s:14:"idsFieldFilter";s:11:"I2RIi,ZIosB";s:14:"idsFieldSortBy";s:5:"feWh7";s:10:"textPageNo";s:0:"";s:7:"perPage";s:2:"10";s:14:"filterLanguage";s:1:"0";s:18:"selectListTemplate";s:1:"0";s:17:"filterField_I2RIi";s:9:"titlemenu";s:17:"filterQuery_I2RIi";s:1:"a";s:20:"filterPosition_I2RIi";s:0:"";s:17:"filterField_ZIosB";s:8:"linkmenu";s:17:"filterQuery_ZIosB";s:1:"a";s:20:"filterPosition_ZIosB";s:0:"";s:17:"sortbyField_feWh7";s:9:"titlemenu";s:17:"sortbyOrder_feWh7";s:3:"asc";s:20:"display_field_idMenu";s:3:"0,0";s:23:"display_field_titleMenu";s:3:"1,1";s:22:"display_field_linkMenu";s:3:"1,2";s:24:"display_field_parentMenu";s:3:"1,3";s:23:"display_field_imageMenu";s:3:"1,4";s:23:"display_field_orderMenu";s:3:"0,5";s:24:"display_field_systemItem";s:3:"0,6";s:27:"display_field_dashboardMenu";s:3:"1,7";s:21:"display_field_topMenu";s:3:"1,8";s:26:"display_field_showSubMenus";s:3:"0,9";s:23:"display_field_createdBy";s:4:"0,10";s:35:"display_field_dateAdditionAdminMenu";s:4:"0,11";s:35:"display_field_dateUpdationAdminMenu";s:4:"0,12";s:21:"display_field_actions";s:4:"1,13";s:21:"display_manage_fields";s:4:"true";s:16:"display_template";s:4:"true";}}}}}}}}', '2013-05-15 07:33:50', '2014-01-02 04:52:12');

-- --------------------------------------------------------

--
-- Table structure for table `user_groups`
--

CREATE TABLE IF NOT EXISTS `user_groups` (
  `idGroup` int(11) NOT NULL AUTO_INCREMENT,
  `nameGroup` varchar(100) NOT NULL,
  `statusGroup` tinyint(1) NOT NULL,
  `dateAdditionGroup` datetime NOT NULL,
  `dateUpdationGroup` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idGroup`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_groups`
--

INSERT INTO `user_groups` (`idGroup`, `nameGroup`, `statusGroup`, `dateAdditionGroup`, `dateUpdationGroup`) VALUES
(3, 'Admin', 1, '2013-07-20 19:01:07', '2013-09-21 06:57:51');

-- --------------------------------------------------------

--
-- Table structure for table `user_log_activity`
--

CREATE TABLE IF NOT EXISTS `user_log_activity` (
  `idLog` int(11) NOT NULL AUTO_INCREMENT,
  `idUser` int(11) NOT NULL,
  `ipaddressLog` varchar(100) NOT NULL,
  `timeLog` datetime NOT NULL,
  `statusLog` int(3) NOT NULL,
  `replaceData` varchar(500) NOT NULL,
  PRIMARY KEY (`idLog`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=886 ;

--
-- Dumping data for table `user_log_activity`
--

INSERT INTO `user_log_activity` (`idLog`, `idUser`, `ipaddressLog`, `timeLog`, `statusLog`, `replaceData`) VALUES
(712, 1, '127.0.0.1', '2013-08-28 03:14:17', 49, 'Admin'),
(713, 1, '127.0.0.1', '2013-08-28 03:14:25', 54, 'Admin'),
(714, 1, '127.0.0.1', '2013-08-28 03:42:01', 19, ''),
(715, 1, '127.0.0.1', '2013-08-28 03:56:04', 19, ''),
(716, 1, '127.0.0.1', '2013-08-28 04:03:07', 23, ''),
(717, 1, '127.0.0.1', '2013-08-28 04:15:14', 23, ''),
(718, 1, '127.0.0.1', '2013-08-28 04:16:53', 19, ''),
(719, 1, '127.0.0.1', '2013-08-28 04:27:43', 2, ''),
(720, 1, '127.0.0.1', '2013-08-28 04:27:48', 1, ''),
(721, 1, '127.0.0.1', '2013-08-28 04:31:30', 23, ''),
(722, 1, '127.0.0.1', '2013-08-28 04:31:55', 23, ''),
(723, 1, '127.0.0.1', '2013-08-28 04:32:08', 23, ''),
(724, 1, '127.0.0.1', '2013-08-28 04:32:21', 23, ''),
(725, 1, '127.0.0.1', '2013-08-28 04:32:33', 23, ''),
(726, 1, '127.0.0.1', '2013-08-28 04:32:44', 23, ''),
(727, 1, '127.0.0.1', '2013-08-28 04:33:38', 23, ''),
(728, 1, '127.0.0.1', '2013-08-28 04:33:43', 23, ''),
(729, 1, '127.0.0.1', '2013-08-28 04:34:08', 23, ''),
(730, 1, '127.0.0.1', '2013-08-28 04:37:10', 23, ''),
(731, 1, '127.0.0.1', '2013-08-28 05:09:42', 23, ''),
(732, 1, '127.0.0.1', '2013-08-28 05:15:24', 19, ''),
(733, 1, '127.0.0.1', '2013-08-28 05:15:32', 19, ''),
(734, 1, '127.0.0.1', '2013-08-28 05:16:59', 19, ''),
(735, 1, '127.0.0.1', '2013-08-28 05:17:29', 23, ''),
(736, 1, '127.0.0.1', '2013-08-28 05:22:30', 19, ''),
(737, 1, '127.0.0.1', '2013-08-28 05:22:52', 19, ''),
(738, 1, '127.0.0.1', '2013-08-28 05:26:27', 26, 'Ios Slider'),
(739, 1, '127.0.0.1', '2013-08-28 05:26:29', 26, 'Ios Slider'),
(740, 1, '127.0.0.1', '2013-08-28 05:28:05', 20, ''),
(741, 1, '127.0.0.1', '2013-08-28 05:28:06', 20, ''),
(742, 1, '127.0.0.1', '2013-08-28 08:02:21', 23, ''),
(743, 1, '127.0.0.1', '2013-08-28 08:16:35', 23, ''),
(744, 1, '127.0.0.1', '2013-08-28 09:43:40', 1, ''),
(745, 1, '127.0.0.1', '2013-08-28 21:35:50', 1, ''),
(746, 1, '127.0.0.1', '2013-08-28 23:03:13', 1, ''),
(747, 1, '127.0.0.1', '2013-08-29 03:36:07', 1, ''),
(748, 1, '127.0.0.1', '2013-08-29 05:22:12', 6, 'Users'),
(749, 1, '127.0.0.1', '2013-08-29 05:22:28', 6, 'User Groups'),
(750, 1, '127.0.0.1', '2013-10-03 19:06:37', 45, 'Advanced Cms(Dynamic Lists, Forms)'),
(751, 1, '127.0.0.1', '2013-10-03 19:06:38', 44, 'Advanced Cms(Dynamic Lists, Forms)'),
(752, 1, '127.0.0.1', '2013-10-07 01:01:20', 40, ''),
(753, 1, '127.0.0.1', '2013-10-07 01:06:52', 40, ''),
(754, 1, '127.0.0.1', '2013-10-07 01:06:57', 40, ''),
(755, 1, '127.0.0.1', '2013-10-07 01:07:02', 40, ''),
(756, 1, '127.0.0.1', '2013-10-13 14:38:39', 11, ''),
(757, 1, '127.0.0.1', '2013-10-13 14:39:54', 19, ''),
(758, 1, '127.0.0.1', '2013-10-13 14:40:14', 23, ''),
(759, 1, '127.0.0.1', '2013-10-13 14:43:08', 23, ''),
(760, 1, '127.0.0.1', '2013-10-13 14:43:32', 23, ''),
(761, 1, '127.0.0.1', '2013-10-13 14:44:48', 23, ''),
(762, 1, '127.0.0.1', '2013-10-13 14:45:11', 23, ''),
(763, 1, '127.0.0.1', '2013-10-13 14:45:57', 23, ''),
(764, 1, '127.0.0.1', '2013-10-13 15:10:00', 23, ''),
(765, 1, '127.0.0.1', '2013-10-14 05:16:11', 11, ''),
(766, 1, '127.0.0.1', '2013-10-14 05:16:18', 13, ''),
(767, 1, '127.0.0.1', '2013-10-14 05:16:20', 13, ''),
(768, 1, '127.0.0.1', '2013-10-14 05:35:08', 6, 'Advanced Forms & Lists'),
(769, 1, '127.0.0.1', '2013-10-14 06:06:32', 54, 'Accountant'),
(770, 1, '127.0.0.1', '2013-10-14 06:06:32', 54, 'Board Member'),
(771, 1, '127.0.0.1', '2013-10-14 06:06:32', 54, 'Employee'),
(772, 1, '127.0.0.1', '2013-10-14 06:06:32', 54, 'Marketing'),
(773, 1, '127.0.0.1', '2013-10-14 06:06:32', 54, 'Team Lead'),
(774, 1, '127.0.0.1', '2013-10-15 03:22:42', 13, ''),
(775, 1, '127.0.0.1', '2013-10-15 03:23:19', 6, 'Languages'),
(776, 1, '127.0.0.1', '2013-10-15 03:23:24', 6, 'Languages'),
(777, 1, '127.0.0.1', '2013-10-15 03:23:31', 6, 'Languages'),
(778, 1, '127.0.0.1', '2013-10-23 09:15:33', 6, 'Dashboard'),
(779, 1, '127.0.0.1', '2013-10-23 09:15:35', 6, 'Dashboard'),
(780, 1, '127.0.0.1', '2013-10-23 09:15:37', 6, 'Dashboard'),
(781, 1, '127.0.0.1', '2013-10-23 09:15:37', 6, 'Dashboard'),
(782, 1, '127.0.0.1', '2013-10-23 09:15:38', 6, 'Dashboard'),
(783, 1, '127.0.0.1', '2013-10-23 09:15:39', 6, 'Dashboard'),
(784, 1, '127.0.0.1', '2013-10-23 09:15:39', 6, 'Dashboard'),
(785, 1, '127.0.0.1', '2013-10-23 09:15:40', 6, 'Dashboard'),
(786, 1, '127.0.0.1', '2013-10-23 09:15:40', 6, 'Dashboard'),
(787, 1, '127.0.0.1', '2013-10-23 09:15:41', 6, 'Dashboard'),
(788, 1, '127.0.0.1', '2013-10-23 09:15:41', 6, 'Dashboard'),
(789, 1, '127.0.0.1', '2013-10-23 09:15:42', 6, 'Dashboard'),
(790, 1, '127.0.0.1', '2013-10-23 09:15:46', 6, 'Dashboard'),
(791, 1, '127.0.0.1', '2013-10-23 09:15:47', 6, 'Dashboard'),
(792, 1, '127.0.0.1', '2013-10-23 09:15:47', 6, 'Dashboard'),
(793, 1, '127.0.0.1', '2013-10-23 09:15:48', 6, 'Dashboard'),
(794, 1, '127.0.0.1', '2013-10-23 09:15:49', 6, 'Dashboard'),
(795, 1, '127.0.0.1', '2013-10-23 09:15:50', 6, 'Dashboard'),
(796, 1, '127.0.0.1', '2013-10-23 09:15:51', 6, 'Dashboard'),
(797, 1, '127.0.0.1', '2013-10-23 09:15:51', 6, 'Dashboard'),
(798, 1, '127.0.0.1', '2013-10-23 09:15:52', 6, 'Dashboard'),
(799, 1, '127.0.0.1', '2013-10-23 09:15:57', 6, 'Dashboard'),
(800, 1, '127.0.0.1', '2013-10-23 09:15:57', 6, 'Dashboard'),
(801, 1, '127.0.0.1', '2013-10-23 09:16:01', 6, 'Dashboard'),
(802, 1, '127.0.0.1', '2013-10-23 09:16:03', 6, 'Dashboard'),
(803, 1, '127.0.0.1', '2013-10-23 09:16:03', 6, 'Dashboard'),
(804, 1, '127.0.0.1', '2013-10-23 09:16:04', 6, 'Dashboard'),
(805, 1, '127.0.0.1', '2013-10-23 09:16:04', 6, 'Dashboard'),
(806, 1, '127.0.0.1', '2013-10-23 09:16:05', 6, 'Dashboard'),
(807, 1, '127.0.0.1', '2013-10-23 09:16:05', 6, 'Dashboard'),
(808, 1, '127.0.0.1', '2013-10-23 09:16:05', 6, 'Dashboard'),
(809, 1, '127.0.0.1', '2013-10-23 09:16:06', 6, 'Dashboard'),
(810, 1, '127.0.0.1', '2013-10-23 09:16:06', 6, 'Dashboard'),
(811, 1, '127.0.0.1', '2013-10-23 09:17:49', 6, 'Dashboard'),
(812, 1, '127.0.0.1', '2013-10-23 09:23:36', 6, 'Dashboard'),
(813, 1, '127.0.0.1', '2013-10-23 09:23:37', 6, 'Dashboard'),
(814, 1, '127.0.0.1', '2013-10-23 09:23:38', 6, 'Dashboard'),
(815, 1, '127.0.0.1', '2013-10-23 09:23:38', 6, 'Dashboard'),
(816, 1, '127.0.0.1', '2013-10-23 09:23:39', 6, 'Dashboard'),
(817, 1, '127.0.0.1', '2013-10-23 09:23:39', 6, 'Dashboard'),
(818, 1, '127.0.0.1', '2013-10-23 09:23:40', 6, 'Dashboard'),
(819, 1, '127.0.0.1', '2013-10-23 09:23:40', 6, 'Dashboard'),
(820, 1, '127.0.0.1', '2013-10-23 09:23:40', 6, 'Dashboard'),
(821, 1, '127.0.0.1', '2013-10-23 09:23:41', 6, 'Dashboard'),
(822, 1, '127.0.0.1', '2013-10-23 09:23:41', 6, 'Dashboard'),
(823, 1, '127.0.0.1', '2013-10-23 09:23:42', 6, 'Dashboard'),
(824, 1, '127.0.0.1', '2013-10-23 09:24:24', 6, 'Dashboard'),
(825, 1, '127.0.0.1', '2013-10-23 09:26:38', 6, 'Dashboard'),
(826, 1, '127.0.0.1', '2013-10-23 09:26:39', 6, 'Dashboard'),
(827, 1, '127.0.0.1', '2013-10-23 09:26:48', 6, 'Dashboard'),
(828, 1, '127.0.0.1', '2013-10-31 08:20:56', 20, ''),
(829, 1, '127.0.0.1', '2013-10-31 08:21:13', 20, ''),
(830, 1, '127.0.0.1', '2013-10-31 10:30:30', 26, 'Media'),
(831, 1, '127.0.0.1', '2013-10-31 10:30:39', 26, 'Media'),
(832, 1, '127.0.0.1', '2013-10-31 10:36:01', 26, 'Media'),
(833, 1, '127.0.0.1', '2013-10-31 10:36:05', 26, 'Media'),
(834, 1, '127.0.0.1', '2013-10-31 11:40:31', 26, 'Countries'),
(835, 1, '127.0.0.1', '2013-10-31 11:40:39', 26, 'Countries'),
(836, 1, '127.0.0.1', '2013-10-31 11:49:36', 26, 'Samples'),
(837, 1, '127.0.0.1', '2013-10-31 11:49:59', 26, 'Samples'),
(838, 1, '127.0.0.1', '2013-10-31 11:51:32', 26, 'Samples'),
(839, 1, '127.0.0.1', '2013-10-31 11:51:35', 26, 'Samples'),
(840, 1, '127.0.0.1', '2013-10-31 11:53:06', 26, 'Samples'),
(841, 1, '127.0.0.1', '2013-10-31 11:53:08', 26, 'Samples'),
(842, 1, '127.0.0.1', '2013-10-31 11:55:02', 26, 'Samples'),
(843, 1, '127.0.0.1', '2013-10-31 11:55:08', 26, 'Samples'),
(844, 1, '127.0.0.1', '2013-10-31 12:16:09', 26, 'Samples'),
(845, 1, '127.0.0.1', '2013-10-31 12:16:13', 26, 'Samples'),
(846, 1, '127.0.0.1', '2013-10-31 12:17:22', 26, 'Samples'),
(847, 1, '127.0.0.1', '2013-10-31 12:17:23', 26, 'Samples'),
(848, 1, '127.0.0.1', '2013-10-31 12:17:29', 6, 'Samples1'),
(849, 1, '127.0.0.1', '2013-10-31 12:17:36', 6, 'Samples'),
(850, 1, '127.0.0.1', '2013-10-31 12:18:04', 5, 'testing'),
(851, 1, '127.0.0.1', '2013-10-31 12:21:07', 29, 'testing'),
(852, 1, '127.0.0.1', '2013-10-31 13:00:25', 26, 'Countries'),
(853, 1, '127.0.0.1', '2013-10-31 13:00:26', 26, 'Countries'),
(854, 1, '127.0.0.1', '2013-10-31 13:00:28', 26, 'Countries'),
(855, 1, '127.0.0.1', '2013-10-31 13:00:29', 26, 'Countries'),
(856, 8, '127.0.0.1', '2013-12-17 15:18:17', 26, 'Widgets'),
(857, 8, '127.0.0.1', '2013-12-17 15:18:28', 26, 'Widgets'),
(858, 8, '127.0.0.1', '2013-12-23 15:11:21', 29, 'Js Files'),
(859, 8, '127.0.0.1', '2013-12-23 15:12:44', 29, 'Image Files'),
(860, 8, '127.0.0.1', '2013-12-28 12:44:58', 18, ''),
(861, 8, '127.0.0.1', '2013-12-28 12:47:22', 20, ''),
(862, 8, '127.0.0.1', '2013-12-28 12:48:10', 20, ''),
(863, 8, '127.0.0.1', '2013-12-28 15:25:51', 20, ''),
(864, 8, '127.0.0.1', '2013-12-28 15:26:04', 20, ''),
(865, 8, '127.0.0.1', '2013-12-28 15:26:09', 20, ''),
(866, 8, '127.0.0.1', '2013-12-28 18:52:29', 26, 'Lists'),
(867, 8, '127.0.0.1', '2013-12-28 18:52:30', 26, 'Lists'),
(868, 1, '127.0.0.1', '2013-12-29 12:21:22', 24, ''),
(869, 1, '127.0.0.1', '2013-12-29 12:21:23', 24, ''),
(870, 1, '127.0.0.1', '2013-12-29 12:23:41', 20, ''),
(871, 1, '127.0.0.1', '2013-12-29 12:23:42', 20, ''),
(872, 1, '127.0.0.1', '2013-12-29 12:23:43', 20, ''),
(873, 1, '127.0.0.1', '2013-12-29 12:24:22', 24, ''),
(874, 1, '127.0.0.1', '2013-12-29 12:24:22', 24, ''),
(875, 1, '127.0.0.1', '2013-12-29 12:58:55', 24, ''),
(876, 1, '127.0.0.1', '2013-12-29 13:19:44', 23, ''),
(877, 1, '127.0.0.1', '2013-12-29 13:24:26', 24, ''),
(878, 1, '127.0.0.1', '2013-12-29 13:31:02', 24, ''),
(879, 1, '127.0.0.1', '2013-12-29 13:34:37', 24, ''),
(880, 1, '127.0.0.1', '2013-12-29 13:34:39', 24, ''),
(881, 1, '127.0.0.1', '2013-12-30 01:09:18', 23, ''),
(882, 1, '127.0.0.1', '2013-12-30 01:09:29', 23, ''),
(883, 1, '127.0.0.1', '2013-12-30 13:38:27', 19, ''),
(884, 1, '127.0.0.1', '2013-12-30 13:51:05', 19, ''),
(885, 1, '127.0.0.1', '2013-12-30 13:55:14', 20, '');

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `idWidget` bigint(20) NOT NULL AUTO_INCREMENT,
  `titleWidget` varchar(500) NOT NULL,
  `defaultOptionsWidget` longtext NOT NULL,
  `pathWidget` text NOT NULL,
  `systemItem` tinyint(1) NOT NULL DEFAULT '0',
  `statusWidget` tinyint(1) NOT NULL DEFAULT '1',
  `createdById` varchar(100) NOT NULL,
  `createdByType` varchar(20) NOT NULL,
  `dateAdditionWidget` datetime NOT NULL,
  `dateUpdationWidget` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idWidget`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`idWidget`, `titleWidget`, `defaultOptionsWidget`, `pathWidget`, `systemItem`, `statusWidget`, `createdById`, `createdByType`, `dateAdditionWidget`, `dateUpdationWidget`) VALUES
(1, 'Content', '', 'widgets/content', 1, 1, '1', 'user', '2013-08-01 00:00:00', '2013-08-27 14:26:33'),
(2, 'Image', '', 'widgets/image', 1, 1, '1', 'user', '2013-08-20 00:00:00', '2013-08-25 13:22:16'),
(6, 'Pages', '', 'widgets/pages', 0, 1, '1', 'user', '2013-08-25 18:55:02', '2013-08-25 13:25:35'),
(7, 'Menus', '', 'widgets/menus', 0, 1, '1', 'user', '2013-10-21 03:28:53', '2013-10-20 21:58:53');

-- --------------------------------------------------------

--
-- Table structure for table `widget_items`
--

CREATE TABLE IF NOT EXISTS `widget_items` (
  `idWidgetItem` bigint(20) NOT NULL AUTO_INCREMENT,
  `idWidget` bigint(20) NOT NULL,
  `titleWidgetItem` varchar(500) NOT NULL,
  `optionsWidgetItem` longtext NOT NULL,
  `idSpace` bigint(20) NOT NULL,
  `globalWidgetItem` tinyint(1) NOT NULL,
  `systemItem` tinyint(1) NOT NULL DEFAULT '0',
  `statusWidgetItem` tinyint(1) NOT NULL DEFAULT '1',
  `createdById` varchar(100) NOT NULL,
  `createdByType` varchar(20) NOT NULL,
  `dateAdditionWidgetItem` datetime NOT NULL,
  `dateUpdationWidgetItem` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idWidgetItem`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `widget_items`
--

INSERT INTO `widget_items` (`idWidgetItem`, `idWidget`, `titleWidgetItem`, `optionsWidgetItem`, `idSpace`, `globalWidgetItem`, `systemItem`, `statusWidgetItem`, `createdById`, `createdByType`, `dateAdditionWidgetItem`, `dateUpdationWidgetItem`) VALUES
(1, 1, '', 'O:8:"stdClass":1:{s:11:"contentHtml";s:387:"<ul>\n<li><a title="" href="home.html">Lorem ipsum dolor sit amet cons</a></li>\n<li><a title="" href="services.html">Lorem ipsum dolor sit amet cons</a></li>\n<li><a class="current" title="" href="#">Lorem ipsum dolor sit amet cons</a></li>\n<li><a title="" href="#">Lorem ipsum dolor sit amet cons</a></li>\n<li><a title="" href="contact.html">Lorem ipsum dolor sit amet cons</a></li>\n</ul>";}', 4, 0, 0, 1, '1', 'user', '2013-08-25 05:09:00', '2013-08-24 23:43:43'),
(2, 1, '', 'O:8:"stdClass":1:{s:11:"contentHtml";s:635:"<div class="text_content">\n<h1>What is your biological clock?1</h1>\n<p class="green">"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed&nbsp; do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim&nbsp; ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut&nbsp; aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit&nbsp; in voluptate velit esse cillum dolore eu fugiat nulla pariatur.&nbsp; Excepteur sint occaecat cupidatat non proident, sunt in culpa qui&nbsp; officia deserunt mollit anim id est laborum."</p>\n<div class="read_more"><a href="#">read more</a></div>\n</div>";}', 3, 0, 0, 1, '1', 'user', '2013-08-25 05:14:12', '2013-11-29 06:33:14'),
(3, 1, '', 'O:8:"stdClass":1:{s:11:"contentHtml";s:273:"<ul>\n<li><a class="current" title="" href="home.html">home</a></li>\n<li><a title="" href="services.html">services</a></li>\n<li><a title="" href="#">clients</a></li>\n<li><a title="" href="#">testimonials</a></li>\n<li><a title="" href="contact.html">contact us</a></li>\n</ul>";}', 1, 0, 0, 1, '1', 'user', '2013-08-25 05:14:44', '2013-08-24 23:44:44'),
(9, 2, 'header_left', 'O:8:"stdClass":8:{s:5:"image";s:15:"system-icon.png";s:10:"hoverImage";s:18:"timezones-icon.png";s:8:"typeLink";s:1:"2";s:8:"pageLink";s:0:"";s:12:"externalLink";s:0:"";s:7:"altText";s:0:"";s:10:"widthImage";s:0:"";s:11:"heightImage";s:0:"";}', 2, 0, 0, 1, '1', 'user', '2013-08-25 22:59:44', '2013-10-06 21:38:31'),
(18, 2, '', 'O:8:"stdClass":8:{s:5:"image";s:19:"pluginsnew-icon.png";s:10:"hoverImage";s:27:"folder-file-import-icon.png";s:8:"typeLink";s:0:"";s:8:"pageLink";s:0:"";s:12:"externalLink";s:0:"";s:7:"altText";s:0:"";s:10:"widthImage";s:0:"";s:11:"heightImage";s:0:"";}', 4, 0, 0, 1, '1', 'user', '2013-10-03 18:57:25', '2013-10-03 13:27:25'),
(21, 2, 'second logo', 'O:8:"stdClass":8:{s:5:"image";s:13:"java-icon.png";s:10:"hoverImage";s:14:"pages-icon.png";s:8:"typeLink";s:1:"1";s:8:"pageLink";s:1:"3";s:12:"externalLink";s:0:"";s:7:"altText";s:0:"";s:10:"widthImage";s:3:"100";s:11:"heightImage";s:3:"100";}', 5, 0, 0, 1, '1', 'user', '2013-11-29 12:02:16', '2013-11-29 06:32:43'),
(24, 7, 'menu', 'O:8:"stdClass":1:{s:12:"menuSelected";s:1:"1";}', 1, 0, 0, 1, '8', 'user', '2013-12-14 12:54:16', '2013-12-14 07:24:16'),
(25, 7, 'yy', 'O:8:"stdClass":1:{s:12:"menuSelected";s:1:"1";}', 5, 0, 0, 1, '8', 'user', '2013-12-14 12:59:39', '2013-12-14 07:29:39');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
