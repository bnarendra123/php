<?php
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
                  
$pluginConfig = array(
				'identifier' =>   'phpthumb',
				'version'    =>   '1.0.0',                      
				'install-type'=>  'full',                      
				'name'       =>   'Phpthumb',                      
				'url'        =>   'http://www.quikc.org/',                      
				'description'=>   'This plugin allows you to resize images using phpthumbs',                      
				'author'     =>   'Quikc',                      
				'author-url' =>   'http://www.quikc.org/',                      
				'auto-load'  =>   true,                    
				);
