<?php                           
defined('QC_VALID') or die('Restricted Access!');

require_once Config::_getDir('current.plugin').'/includes/functions/general.php';

Plugins::_hookAction('display_php_thumbs','phpthumbs_create');