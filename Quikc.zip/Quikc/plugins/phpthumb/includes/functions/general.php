<?php

function phpthumbs_create($str,$src,$width,$height){

    $noAvailImage = Config::_getUrl('current.plugin')."/includes/apis/phpThumb/phpThumb.php?src=".Config::_getUrl('admin.temp').'/images/no_image_available.gif';
    
    if( $src == '' ){
        // No image Image 
        $str = $noAvailImage;
    }else{
        $str = Config::_getUrl('current.plugin')."/includes/apis/phpThumb/phpThumb.php?src=".Config::_getUrl('img').'/'.$src;
    }
    // Checking for the file in system or in the database
    if( !file_exists(Config::_getDir('img').'/'.$src) ){
        $str = $noAvailImage;
    }        
    $ext = pathinfo(Config::_getDir('img').'/'.$src , PATHINFO_EXTENSION);

	if(in_array(strtolower($ext),array("mp4","flv")) ){
		
    	$str = Config::_getUrl('current.plugin')."/includes/apis/phpThumb/phpThumb.php?src=".Config::_getUrl('img').'/video-icon.jpg';
		
    }
    
    if( !in_array(strtolower($ext),array("png","gif")) ){
        // Upading image width
        if( $width != '' ) $str .= "&amp;w=".$width;        
        // Upading image height
        if( $height != '' ) $str .= "&amp;h=".$height;            
    }
    
    return $str;
};
