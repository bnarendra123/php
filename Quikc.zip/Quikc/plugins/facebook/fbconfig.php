<?php
require Config::_getDir().'/plugins/facebook/facebook.php';

function getFacebookLoginUrl(){

	$facebook = new Facebook(array(
	  'appId'  => Config::_get('fb.app.id'),
	  'secret' => Config::_get('fb.app.secret'),
	));
	
	$fb_user = $facebook->getUser();
	
	if ($fb_user) {
	
		try {
			$fb_profile = $facebook->api('/me');
		} catch (FacebookApiException $e) {
			$fb_user = NULL;
			$facebook->destroySession();
		}
		
	}
	
	if (!$fb_user) {
		
		return $facebook->getLoginUrl(array('scope' => 'email,user_status,publish_stream,offline_access,publish_actions,photo_upload,status_update,share_item',
												 'redirect_uri' => Config::_getUrl().'/excludes/fblogin.php' ));										 
												 
	}

}



