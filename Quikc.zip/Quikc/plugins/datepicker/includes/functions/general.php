<?php
defined('QC_VALID') or die('Restricted Access!');

function datepicker_header(){
?>    
	<link type="text/css" rel="stylesheet" href="<?php echo Config::_getUrl('current.plugin')?>/templates/backend/css/ui.daterangepicker.css" />
	<script type="text/javascript" src="<?php echo Config::_getUrl('current.plugin')?>/templates/backend/js/date.js"></script>
	<script type="text/javascript" src="<?php echo Config::_getUrl('current.plugin')?>/templates/backend/js/daterangepicker.jQuery.compressed.js"></script>
	<script>
		$(document).ready(function(){
			var datepicker_function = window.datepicker;
			window.datepicker = function(id){
				$('#'+id).daterangepicker({arrows: true});
			}
		});
		function activateDatePicker(){
			$("input[type=date]").focus(function(){
			    $(this).daterangepicker({arrows: true});
			});
		}
	</script>
<?php
}

