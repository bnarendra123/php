<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( file_exists(Config::_getDir('current.plugin').'/backend/includes/modules/ajax/get/list/'.$pagePlugin.'.php')){
	$loadPage = 'pageLoad("'.Config::_get('current.plugin').'/backend/includes/modules/ajax/get/list/'.$pagePlugin.'")';
}else if( file_exists(Config::_getDir('current.plugin').'/backend/includes/modules/ajax/get/edit/'.$pagePlugin.'.php')){
	$loadPage = 'generateEditor("'.Config::_get('current.plugin').'/backend/includes/modules/ajax/get/edit/'.$pagePlugin.'","edit")';
}
