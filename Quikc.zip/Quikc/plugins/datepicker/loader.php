<?php                           
defined('QC_VALID') or die('Restricted Access!');

require_once Config::_getDir('current.plugin').'/includes/functions/general.php';

Plugins::_hookAction('generate_form_generate_date_field','datepicker_form_date_filed');
Plugins::_hookAction('generate_form_end','datepicker_form_js');

if(defined('QC_ADMIN') ){

	Plugins::_hookAction('admin_header','datepicker_header');
    
}else{
	Plugins::_hookAction('header','datepicker_header');
	
}
