<?php

defined('QC_VALID') or die('Restricted Access!');

/**
* Extended Widgets class, used for handling dynamic widgets 
* This class handles actions that are related dynamic widgets
*
* @version 1.0
* @http://www.quikc.org/
*/

class DynamicWidgets extends Widgets{

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /**
    * Contains the details of the forms based on its link
    *
    * @var Object
    */
    private $retrievedWidgetData;

    /** Checks the object instance status and creates if there is not instance
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
            
        }
        
        return self::$instance;

    }

    /* General Form related functions ends here    
    <!-----------------------------------------------------------------------------------------------------------------------------------------
    */
            
    /**
    * Check weather the forms page with the given page exists or not
    *
    * @param  string(page)
    * @return boolean
    */
    public function _generateListWidgets($listData){
    	
        $pathFile = Config::_get('current.plugin').'/backend/includes/modules/ajax/';
        
        $listData['noCreate']   = false;
        $listData['editorUrl']  = $pathFile .'get/edit/widgets';
        $listData['submitLink'] = $pathFile .'set/widgets';
		
		return $listData;
        
	}

    /**
    * Check weather the forms page with the given page exists or not
    *
    * @param  string(page)
    * @return boolean
    */
    public function _manageSpaceItems($listSpaceWidgetItems,$idSpace,$idRandomForm){
       
       $listData = $this -> _generateListWidgets(array());
       ?>
        <script>
            $(document).ready(function(){
                var gh = '';
                gh = gh + '<a href="javascript:generateEditor(\'<?php echo $listData['editorUrl'] ?>\',\'\',\'create\',-1,function(){manageSpace(<?php echo $idSpace; ?>)})" style="float:right">';
                gh = gh + ' Create New Widget';
                gh = gh + '</a><br/>';
                
                $("#conteinerWidgetItems_<?php echo $idRandomForm; ?>").prepend(gh);
            })
        </script>
       <?php
        
    }

    /**
    * if the widget is a dynamice widget then add the list of fields
    *
    * @param $detailsWidget(object),$idPathWidget(int)
    * @return $detailsWidget(object)
    */
    public function _updateWidgetDetails($detailsWidget,$idPathWidget){
        
        if( $detailsWidget->typeWidget == 'dynamic' &&  !isset($detailsWidget->fields) ){

            $query  = " select * from ".Config::_getTable('widgets_fields')." where idWidget = :idWidget order by orderFieldWidget asc ";
            $arrayBind[]= array("key" => ":idWidget", "value" => $detailsWidget->idWidget);
            $listFields = Core::_getAllRows($query,$arrayBind);
            
            $detailsWidget->fields = $listFields;

            Cache::_getInstance() -> _setCache('widgets_' . $detailsWidget->idWidget, $detailsWidget);
            $this -> retrievedWidgets[$detailsWidget -> idWidget] = $detailsWidget;

        }
        
        return $detailsWidget;
    
    }

    /**
    * deletes the fields of the widget
    *
    * @param int(Id Widget)
    * @return int(Id Widget)
    */
    public function _deleteWidget($idWidget){

        $query = "delete from ".Config::_getTable('widgets_fields')." where idWidget = :idWidget ";
        $arrayBind[]= array("key" => ":idWidget"  , "value" => $idWidget);
        Core::_runQuery($query, $arrayBind);
        
        return $idWidget;

    }

    /**
    * if the widget is a dynamice widget then add the list of fields
    *
    * @param $detailsWidget(object),$idPathWidget(int)
    * @return $detailsWidget(object)
    */
    public function _includeFormFieldsFormWidgetItems($formFields, $formPath, $idWidget){
        
        $detailsWidget = parent::_getWidgetDetails($idWidget);
        
        if( $detailsWidget->typeWidget == 'dynamic' ){

            $listFields = $detailsWidget -> fields;
            
            foreach($listFields as $field){
                
                $formFields[] = array(
                                        "id"    => $field->keyFieldWidget, 
                                        "label" => $field->titleFieldWidget,
                                        "type"  => $field->typesFieldWidget,  
                                        "set"   => $field->setsFieldWidget,
                                        "req"   => $field->requiredFieldWidget,
                                        "value" => $field->defaultvalueFieldWidget, 
                                        "additional" => $field->additionalcssFieldWidget,
                                    );

            }

        }
        
        return $formFields;
    
    }

    /**
     * displays widget details
     *
     * @param int(idWidget id)
     * @return none
     */
    public function _displayDynamicWidget($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace=false) {

        if ( $detailsWidget -> typeWidget ==  'dynamic' ) {

            if ( $detailsWidget -> typeDisplayWidget ==  '' ||  $detailsWidget -> typeDisplayWidget ==  'auto' ) {

                $displayContentWidget = $this -> _displayDynamicWidgetAuto($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace);

            }else if( $detailsWidget -> typeDisplayWidget ==  'html' ){

                $displayContentWidget = $this -> _displayDynamicWidgetHtml($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace);

            }else if( $detailsWidget -> typeDisplayWidget ==  'php' ){

                $displayContentWidget = $this -> _displayDynamicWidgetPhp($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace);

            }else if( $detailsWidget -> typeDisplayWidget ==  'file' ){

                $displayContentWidget = $this -> _displayDynamicWidgetFile($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace);

            }

        }

        return $displayContentWidget;

    }

    /**
     * generates dynamic widget from the given html code
     *
     * @param  $displayContentWidget(string),$detailsWidget(string),$idWidgetitem(string),$idSpace(string)
     * @return $displayContentWidget(string)
     */
    public function _displayDynamicWidgetHtml($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace) {
        
        $generatedHtml = $detailsWidget -> htmlCodeWidget;

        foreach( $detailsWidget -> fields as $field ){

            $searchFor = "[:".$field -> keyFieldWidget."]";
            $replaceWith = $detailsWidget -> options -> {$field -> keyFieldWidget};

            if( strtolower($field -> typesFieldWidget) == 'media' ){

                global $Base;
                $replaceWith = $Base->_displayPhpthumb($replaceWith);

            }elseif( strtolower($field -> typesFieldWidget) == 'date' ){

                $replaceWith = $this -> _generateDateData($replaceWith, $field);

            }else if( strtolower($field -> typesFieldWidget) == 'select' ) {

                $replaceWith = $this -> _generateSelectData($replaceWith, $field);

            }

            $generatedHtml = str_replace($searchFor, $replaceWith, $generatedHtml);

        }

        return $generatedHtml;
    }
    
    /**
     * generates dynamic widget from the given php code
     *
     * @param  $displayContentWidget(string),$detailsWidget(string),$idWidgetitem(string),$idSpace(string)
     * @return $displayContentWidget(string)
     */
    public function _displayDynamicWidgetPhp($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace) {
        
        global $Base, $Cms, $Editor, $Plugins, $Themes, $Validate ; 

        $pathFile = Config::_getDir('current.plugin')."/backend/includes/modules/generated/widgets/".$detailsWidget->idWidget."/view.php";

        $displayContentWidget = '';

        if (file_exists($pathFile)) {

            ob_start();         
            include $pathFile;
            $displayContentWidget = ob_get_clean();

        }


        return $displayContentWidget;
    }
    
    
    /**
     * includes the php file in the given path for the dynamic widget
     *
     * @param  $displayContentWidget(string),$detailsWidget(string),$idWidgetitem(string),$idSpace(string)
     * @return $displayContentWidget(string)
     */
    public function _displayDynamicWidgetFile($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace) {
        
        global $Base, $Cms, $Editor, $Plugins, $Themes, $Validate ; 

        $pathFile = Config::_getDir()."/".$detailsWidget->pathDisplayFileWidget;

        $displayContentWidget = '';

        if (file_exists($pathFile)) {

            ob_start();         
            include $pathFile;
            $displayContentWidget = ob_get_clean();

        }


        return $displayContentWidget;
    }
    
    /**
     * generates dynamic widget automatically
     *
     * @param  $displayContentWidget(string),$detailsWidget(string),$idWidgetitem(string),$idSpace(string)
     * @return $displayContentWidget(string)
     */
    public function _displayDynamicWidgetAuto($displayContentWidget,$detailsWidget,$detailsItem,$idWidgetitem,$idSpace) {

        global $Base;

        // Applying classes to the widget display

        // Adding classes to the main div of the widget

        // Adding default calss dynamicWidget. All Widgets generated dynamically will have this class
        // can be used to apply css to all dynamic widgets
        $classes = "dynamicWidget ";

        // Adding calss dynamicWidget_".$detailsWidget -> idWidget. All widget items generated using a single widget type will have the same class
        // Can be used to style widgets of the same widget type
        $classes .= " dynamicWidget_".$detailsWidget -> idWidget;

        // Adding calss dynamicWidget_".$detailsWidget -> titleWidget. All widget items generated using a single widget type will have the same class
        // Can be used to style widgets of the same widget type
        $classes .= " dynamicWidget_".$Base -> _prepareLink($detailsWidget -> titleWidget);

        // Now adding class dynamicWidgetItem_".$detailsWidget -> idWidgetItem. Only widget items of the current widget entry have this class
        // can be used to apply css to the current widget item only
        $classes .= " dynamicWidgetItem_".$detailsWidget -> idWidgetItem;
        
        if( $detailsWidget -> titleWidgetItem != '' ){

            // Now adding class dynamicWidgetItem_$detailsWidget -> titleWidgetItem to the widget item. Only widget items of the current widget entry have this class
            // can be used to apply css to the current widget item only
            $classes .= " dynamicWidgetItem_".$Base -> _prepareLink($detailsWidget -> titleWidgetItem);

        }

        $displayContentWidget .= '<div class="'.$classes.'">';

        foreach( $detailsWidget -> fields as $field ){

            if( method_exists($this, '_generate'.$field -> typesFieldWidget.'Data' ) && isset($detailsWidget -> options -> {$field -> keyFieldWidget}) ){

                // Adding default calss dynamicWidgetItem. All widget items generated dynamically will have this class
                // can be used to apply css to all dynamic widget items
                $classes = "dynamicWidgetItem ";

                // Adding calss dynamicWidgetItem_$field -> typesFieldWidget. All Widgets items with same field type will have this class
                // can be used to apply css to all dynamic widget items of the same type like text, media etc
                $classes .= " dynamicWidgetItem_".$field -> typesFieldWidget;

                // Adding calss dynamicWidgetItem_$field -> keyFieldWidget. Since all widget fields in the same widget item have different keys, this will be unique for the given widget item entry 
                // can be used to apply css to individual widget item fields
                $classes .= " dynamicWidgetItem_".$field -> keyFieldWidget;

                $htmlContent  = '';
                $htmlContent .= '<div class="'.$classes.'">';
                $htmlContent .=     $this -> {'_generate'.$field -> typesFieldWidget.'Data'}($detailsWidget -> options -> {$field -> keyFieldWidget}, $field) ;
                $htmlContent .= '</div>';

                $displayContentWidget .= $htmlContent;

            }

        }

        $displayContentWidget .= '</dv>';

        return $displayContentWidget;

    }

    /**
     * generates the text field
     *
     * @param  string(value to display),array(elements attributes)
     * @return string
     */
    public function _generateTextData($detailsOption, $detailsField) {

        $generatedData = $detailsOption;

        return $generatedData;

    }

    /**
     * generates the date field
     *
     * @param  string(value to display),array(elements attributes)
     * @return string
     */
    public function _generateTextareaData($detailsOption, $detailsField) {

        $generatedData = $detailsOption;

        return $generatedData;

    }

    /**
     * displays date widget field
     *
     * @param  string(value to display),array(elements attributes)
     * @return string
     */
    public function _generateDateData($detailsOption, $detailsField) {

        global $Base;

        $timezoneUser = '';

        if( !is_null( User :: timezoneUser() ) ){

            $timezoneUser = User :: timezoneUser();
            
        }

        // Converting the date to the currently logged in user tmezone
        $generatedData = $Base -> _convertTimeZone( $detailsOption, $timezoneUser );

        return $generatedData;

    }

    /**
     * displays image widget field
     *
     * @param  integer(pathImage),array(elements attributes)
     * @return string(image)
     */
    public function _generateMediaData($detailsOption, $detailsField) {

        $generatedData = '';

        if( $detailsOption != ''){

            global $Base;
    
            $generatedData = '<img src="'.$Base->_displayPhpthumb($detailsOption).'" />';
            
        }

        return $generatedData;

    }

    /**
     * displays select widget field
     *
     * @param  string($detailsOption),array(elements attributes)
     * @return string
     */
    public function _generateSelectData($detailsOption, $detailsField) {

        global $Base;

        $listSelect = $Base -> _generateSelect($detailsField->keyFieldWidget);

        if (!isset($listSelect[$detailsOption])){

            $listSelect[$detailsOption] = 'Not Found';
            
        }

        $valueField = $listSelect[$detailsOption];

        $generatedData = $valueField;
        
        return $generatedData;

    }
	
}
