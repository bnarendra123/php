<?php

defined('QC_VALID') or die('Restricted Access!');

require_once Config::_getDir('current.plugin').'/includes/classes/widgets.php';
$dynamicWidgets = new DynamicWidgets;

// Hoot points to add fields created by dynamic fields to the forms
Plugins::_hookAction('widgets_get_widget_details'           , array($dynamicWidgets,'_updateWidgetDetails'));
Plugins::_hookAction('widgets_get_widget_details_by_path'   , array($dynamicWidgets,'_updateWidgetDetails'));

// Hoot point to display dynamci widgets
Plugins::_hookAction('widgets_display_widget_content'       , array($dynamicWidgets,'_displayDynamicWidget'));

if( defined('QC_ADMIN') ){
    
    require_once Config::_getDir('current.plugin').'/backend/includes/lib/database_tables.php';
    require_once Config::_getDir('current.plugin').'/backend/includes/functions/general.php';
    require_once Config::_getDir('current.plugin').'/backend/includes/classes/lists.php';
    require_once Config::_getDir('current.plugin').'/backend/includes/classes/forms.php';

    $dynamicLists   = new DynamicLists;
    $dynamicForms   = new DynamicForms;

	Plugins::_hookAction('ajax_no_page_found'	, 'dynamicAjaxPage');
	Plugins::_hookAction('check_lists_page'		, array($dynamicLists,'_checkListsPage'));
	Plugins::_hookAction('generate_list_start'	, array($dynamicLists,'_generateList'));
	Plugins::_hookAction('check_forms_page'		, array($dynamicForms,'_checkFormsPage'));
	Plugins::_hookAction('generate_form_start'	, array($dynamicForms,'_generateForm'));

    // Hook point to add create new button and also to direct the edit, create, status, delete pages to plugin page
    Plugins::_hookAction('list_widgets'         , array($dynamicWidgets,'_generateListWidgets'));

    // Hook point to add create new widget button to manage space items forms
    Plugins::_hookAction('spaces_items_completed', array($dynamicWidgets,'_manageSpaceItems'));


    // Hook point to notify when a widget called to delete
    // This is used to delete fields created by dynamic widgets
    Plugins::_hookAction('widgets_delete'       , array($dynamicWidgets,'_deleteWidget'));

    // Hook point to add fields to dynamically created widget items
    Plugins::_hookAction('form_widgets_items_include_widget_form_fields'   , array($dynamicWidgets,'_includeFormFieldsFormWidgetItems'));

}else{
    
}

