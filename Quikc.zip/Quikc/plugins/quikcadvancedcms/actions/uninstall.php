<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$query[]  = "drop table if exists ".Config::_getTable('cms_lists');
$query[]  = "drop table if exists ".Config::_getTable('cms_lists_fields');
$query[]  = "drop table if exists ".Config::_getTable('cms_lists_tables');

$query[]  = "drop table if exists ".Config::_getTable('cms_forms');
$query[]  = "drop table if exists ".Config::_getTable('cms_forms_fields');
$query[]  = "drop table if exists ".Config::_getTable('cms_forms_tables');

$this->_executePluginDatabase($query);
