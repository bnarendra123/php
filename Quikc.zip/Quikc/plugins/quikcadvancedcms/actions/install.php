<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

/*
 * Admin Menu Generation Starts here
 */

$cmsMenuId = 2;

// Main Menu under Cms Tab
$idMainMenu = $this->_addPluginMenu(array("titleMenu" => "Advanced Forms & Lists","linkMenu" => "","imageMenu" => "no-image.png" ,"parentMenu" => $cmsMenuId,"statusMenu" => '1',"orderMenu"=> 14,"dashboardMenu"=>'1',"topMenu"=>'0',"showSubMenus"=>'1'));

	// Sub Menus 
	$idListMenu = $this->_addPluginMenu(array("titleMenu" => "Lists","linkMenu" => "cmslists","imageMenu" => "list-icon.png" ,"parentMenu" => $idMainMenu,"statusMenu" => '1',"orderMenu"=> 5,"dashboardMenu"=>'0',"topMenu"=>'0'));
	$idFormMenu = $this->_addPluginMenu(array("titleMenu" => "Forms","linkMenu" => "cmsforms","imageMenu" => "forms-icon.png","parentMenu" => $idMainMenu,"statusMenu" => '1',"orderMenu"=> 10,"dashboardMenu"=>'0',"topMenu"=>'0'));
	
	$idFormMenu = $this->_addPluginMenu(array("titleMenu" => "Quick Generate","linkMenu" => "qgenerate","imageMenu" => "no-image.png","parentMenu" => $idMainMenu,"statusMenu" => '1',"orderMenu"=> 15,"dashboardMenu"=>'0',"topMenu"=>'0'));
	
	$idSettingsMenu = $this->_addPluginMenu(array("titleMenu" => "Settings","linkMenu" => "","imageMenu" => "no-image.png","parentMenu" => $idMainMenu,"statusMenu" => '1',"orderMenu"=> 20,"dashboardMenu"=>'0',"topMenu"=>'0',"showSubMenus"=>'1'));
	
		// Sub Menus under settings menu
		$idListSMenu = $this->_addPluginMenu(array("titleMenu" => "Lists","linkMenu" => "settings-lists","imageMenu" => "no-image.png","parentMenu" => $idSettingsMenu,"statusMenu" => '1',"orderMenu"=> 5,"dashboardMenu"=>'0',"topMenu"=>'0'));
		$idFormSMenu = $this->_addPluginMenu(array("titleMenu" => "Forms","linkMenu" => "settings-forms","imageMenu" => "no-image.png","parentMenu" => $idSettingsMenu,"statusMenu" => '1',"orderMenu"=> 10,"dashboardMenu"=>'0',"topMenu"=>'0'));
	
	
	$idSampleMenu = $this->_addPluginMenu(array("titleMenu" => "Samples","linkMenu" => "","imageMenu" => "no-image.png","parentMenu" => $idMainMenu,"statusMenu" => '1',"orderMenu"=> 50,"dashboardMenu"=>0,"topMenu"=>0,"showSubMenus"=>1));
	
		// Sub Menus under samples menu
		$idMainMenu = $this->_addPluginMenu(array("titleMenu" => "Countries" ,"linkMenu" => "countries","imageMenu" => "countries-icon.png","parentMenu" => $idSampleMenu,"statusMenu" => '1',"orderMenu"=> 25,"dashboardMenu"=>0,"topMenu"=>0));
		$idMainMenu = $this->_addPluginMenu(array("titleMenu" => "Time Zones","linkMenu" => "timezones","imageMenu" => "timezones-icon.png","parentMenu" => $idSampleMenu,"statusMenu" => '1',"orderMenu"=> 26,"dashboardMenu"=>0,"topMenu"=>0));

/*
 * Admin Menu Generation Ends here
 */

 
/*
 * Config Key Generation starts here
 */ 

// Config Keys for lists
$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.advanced.code.options.status' ,"valueConfig"=>"1"		,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.not.valid.fields' ,"valueConfig"=>"text,mediumtext,longtext,blob"	,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.date.types' ,"valueConfig"=>"datetime,timestamp,date"	,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.date.lables',"valueConfig"=>""						,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.image.types' ,"valueConfig"=>""			,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.image.lables',"valueConfig"=>"image,path"	,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.status.types' ,"valueConfig"=>""			,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.status.lables' ,"valueConfig"=>"status"	,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.select.types'  ,"valueConfig"=>"tinyint(1)"	,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.select.lables' ,"valueConfig"=>""				,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.lists.import.select.default',"valueConfig"=>"yesno"		,"statusConfig"=>"1","systemItem"=>"1"));


// Config Keys for Forms
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.advanced.code.options.status'	,"valueConfig"=>"1"	,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.not.valid.fields' 		,"valueConfig"=>""	,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.email.types' 	,"valueConfig"=>""				,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.email.lables' ,"valueConfig"=>"email"			,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.textarea.types' ,"valueConfig"=>"text,mediumtext,longtext,blob"	,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.textarea.types' ,"valueConfig"=>"content"							,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.date.types'	,"valueConfig"=>"datetime,timestamp,date"	,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.date.lables'	,"valueConfig"=>"date"						,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.image.types'	,"valueConfig"=>""				,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.image.lables'	,"valueConfig"=>"image,path"	,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.video.types'	,"valueConfig"=>""				,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.video.lables'	,"valueConfig"=>"vidoe"			,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.status.types'	,"valueConfig"=>""				,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.status.lables',"valueConfig"=>"status"		,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.select.types'		,"valueConfig"=>"tinyint(1)"	,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.select.lables'	,"valueConfig"=>""				,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>'quikc.advanced.forms.import.select.default'	,"valueConfig"=>"yesno"			,"statusConfig"=>"1","systemItem"=>"1"));

/*
 * Config Key Generation ends here
 */ 



$query[] = "CREATE TABLE IF NOT EXISTS `".Config::_getTable('cms_lists')."` (
 `idList` int(11) NOT NULL AUTO_INCREMENT,
 `nameList` varchar(100) NOT NULL,
 `linkList` varchar(100) NOT NULL,
 `whereList` varchar(500) NOT NULL DEFAULT '0',
 `sortByFieldList` varchar(200) NOT NULL,
 `sortOrderFieldList` varchar(200) NOT NULL,
 `primaryFieldList` varchar(200) NOT NULL,
 `statusFieldList` varchar(200) NOT NULL,
 `multiLanguageFieldList` varchar(200) NOT NULL,
 `pagePaginationList` int(11) DEFAULT NULL,
 `rowsPaginationList` int(11) DEFAULT NULL,
 `pagesPaginationList` int(11) DEFAULT NULL,
 `actionsList` varchar(200) NOT NULL,
 `editActionLink` varchar(200) NOT NULL,
 `statusList` tinyint(1) NOT NULL DEFAULT '1',
 `dateAdditionList` datetime NOT NULL,
 `dateUpdationList` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`idList`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$query[] = "INSERT INTO `".Config::_getTable('cms_lists')."` (`idList`, `nameList`, `linkList`, `whereList`, `sortByFieldList`, `sortOrderFieldList`, `primaryFieldList`, `statusFieldList`, `multiLanguageFieldList`, `pagePaginationList`, `rowsPaginationList`, `pagesPaginationList`, `actionsList`, `statusList`, `dateAdditionList`, `dateUpdationList`) VALUES
(1, 'Countries', '".$this->_getWorkingPluginDetails()->identifierPlugin."-countries', '', 'c.countryName', 'asc', 'c.idCountry', '', '', 0, 15, 0, 'edit-delete', 1, NOW(), NOW()),
(2, 'Timezones', '".$this->_getWorkingPluginDetails()->identifierPlugin."-timezones', '', 't.titleZone', 'asc', 't.idTimezone', '', '', 0, 15, 0, 'status-edit-delete', 1, NOW(), NOW());";


$query[] = "CREATE TABLE `".Config::_getTable('cms_lists_fields')."` (
 `idField` int(11) NOT NULL AUTO_INCREMENT,
 `idList` int(11) NOT NULL,
 `fieldList` varchar(100) NOT NULL,
 `titleFieldList` varchar(100) NOT NULL,
 `typesFieldList` varchar(100) NOT NULL,
 `setsFieldList` varchar(100) NOT NULL,
 `orderFieldList` int(5) NOT NULL,
 PRIMARY KEY (`idField`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$query[] = "INSERT INTO `".Config::_getTable('cms_lists_fields')."` (`idField`, `idList`, `fieldList`, `titleFieldList`, `typesFieldList`, `setsFieldList`, `orderFieldList`) VALUES
('', 1, 'c.idCountry', 'Country Id', 'text', '', 0),
('', 1, 'c.countryCode', 'Country Code', 'text', '', 0),
('', 1, 'c.countryName', 'Country Name', 'text', '', 0),
('', 1, 'c.currencyCode', 'Country Currenty', 'text', '', 0),
('', 1, 'c.capital', 'Country Capital', 'text', '', 0),
('', 1, 'c.continentName', 'Continent Name', 'text', '', 0),
('', 1, 'c.continent', 'Continent Code', 'text', '', 0),
('', 1, 'c.population', 'Population', 'text', '', 0),
('', 2, 't.keyZone', 'Key', 'text', '', 0),
('', 2, 't.titleZone', 'Title', 'text', '', 0),
('', 2, 't.timeCreated', 'Created On', 'date', '', 0),
('', 2, 't.timeUpdated', 'Updated On', 'date', '', 0);";

$query[] = "CREATE TABLE `".Config::_getTable('cms_lists_tables')."` (
 `idTable` int(11) NOT NULL AUTO_INCREMENT,
 `idList` int(11) NOT NULL,
 `tableList` varchar(200) NOT NULL,
 `identifierTableList` varchar(50) NOT NULL,
 `joinTypeTable` varchar(100) NOT NULL,
 `joinOnTable` varchar(200) NOT NULL,
 PRIMARY KEY (`idTable`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$query[] = "INSERT INTO `".Config::_getTable('cms_lists_tables')."` (`idTable`, `idList`, `tableList`, `identifierTableList`, `joinTypeTable`, `joinOnTable`) VALUES
('', 1, '".Config::_getTable('countries')."', 'c', '', ''),
('', 2, '".Config::_getTable('time_zones')."', 't', '', '');";

$query[] = "CREATE TABLE IF NOT EXISTS `".Config::_getTable('cms_forms')."` (
  `idForm` int(11) NOT NULL AUTO_INCREMENT,
  `nameForm` varchar(100) NOT NULL,
  `linkForm` varchar(100) NOT NULL,
  `primaryFieldForm` varchar(100) NOT NULL,
  `displayTitleFieldForm` varchar(100) NOT NULL,
  `whereForm` varchar(500) NOT NULL DEFAULT '0',
  `onSuccessForm` varchar(500) NOT NULL,
  `statusForm` tinyint(1) NOT NULL DEFAULT '1',
  `dateAdditionForm` datetime NOT NULL,
  `dateUpdationForm` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idForm`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ;";

$query[] = "INSERT INTO `cms_forms` (`idForm`, `nameForm`, `linkForm`, `primaryFieldForm`, `whereForm`, `onSuccessForm`, `statusForm`, `dateAdditionForm`, `dateUpdationForm`) VALUES
(1, 'Countries', '".$this->_getWorkingPluginDetails()->identifierPlugin."-countries', 'c.idCountry','c.countryName', '', '', 1, NOW(), NOW()),
(2, 'TimeZones', '".$this->_getWorkingPluginDetails()->identifierPlugin."-timezones', 't.idTimezone','t.titleZone', '','', 1,NOW(), NOW());";

$query[] = "CREATE TABLE IF NOT EXISTS `".Config::_getTable('cms_forms_fields')."` (
  `idField` int(11) NOT NULL AUTO_INCREMENT,
  `idForm` int(11) NOT NULL,
  `fieldForm` varchar(100) NOT NULL,
  `titleFieldForm` varchar(100) NOT NULL,
  `typesFieldForm` varchar(100) NOT NULL,
  `setsFieldForm` varchar(100) NOT NULL,
  `orderFieldForm` int(5) NOT NULL,
  `defaultvalueFieldForm` varchar(500) NOT NULL,
  `additionalcssFieldForm` varchar(500) NOT NULL,
  `requiredFieldForm` tinyint(1) NOT NULL,
  `databasefieldFieldForm` tinyint(1) NOT NULL,
  `uniqueFieldForm` tinyint(1) NOT NULL,
  PRIMARY KEY (`idField`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ;";

$query[] = "INSERT INTO `".Config::_getTable('cms_forms_fields')."` (`idField`, `idForm`, `fieldForm`, `titleFieldForm`, `typesFieldForm`, `setsFieldForm`, `orderFieldForm`, `defaultvalueFieldForm`, `additionalcssFieldForm`, `requiredFieldForm`, `databasefieldFieldForm`, `uniqueFieldForm`) VALUES
('', 1, 'c.countryCode', 'Country Code', 'text', '', 0, '', '', 1, 1, 1),
('', 1, 'c.countryName', 'Country Name', 'text', '', 0, '', '', 1, 1, 0),
('', 1, 'c.currencyCode', 'Country Currenty', 'text', '', 0, '', '', 0, 1, 0),
('', 1, 'c.capital', 'Country Capital', 'text', '', 0, '', '', 0, 1, 0),
('', 1, 'c.continentName', 'Continent Name', 'text', '', 0, '', '', 0, 1, 0),
('', 1, 'c.continent', 'Continent Code', 'text', '', 0, '', '', 0, 1, 0),
('', 1, 'c.population', 'Population', 'text', '', 0, '', '', 0, 1, 0),
('', 1, '', '', 'button', '', 0, 'Update', 'class=\"submit-btn\"', 0, 0, 0),
('', 2, 't.keyZone', 'KeyZone', 'text', '', 0, '', '', 1, 1, 0),
('', 2, 't.titleZone', 'TitleZone', 'text', '', 0, '', '', 1, 1, 0),
('', 2, '', '', 'button', '', 0, 'proceed', 'class=\"submit-btn\"', 0, 1, 0);";

$query[] = "CREATE TABLE IF NOT EXISTS `".Config::_getTable('cms_forms_tables')."` (
  `idTable` int(11) NOT NULL AUTO_INCREMENT,
  `idForm` int(11) NOT NULL,
  `tableForm` varchar(200) NOT NULL,
  `identifierTableForm` varchar(50) NOT NULL,
  `joinTypeTable` varchar(100) NOT NULL,
  `joinOnTable` varchar(200) NOT NULL,
  `multiLanguageField` varchar(200) NOT NULL,
  PRIMARY KEY (`idTable`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 ;";

$query[] = "INSERT INTO `".Config::_getTable('cms_forms_tables')."` (`idTable`, `idForm`, `tableForm`, `identifierTableForm`, `joinTypeTable`, `joinOnTable`, `multiLanguageField`) VALUES
('', 1, '".Config::_getTable('countries')."', 'c', '', '', ''),
('', 2, '".Config::_getTable('time_zones')."', 't', '', '', '');";

$this->_executePluginDatabase($query);
