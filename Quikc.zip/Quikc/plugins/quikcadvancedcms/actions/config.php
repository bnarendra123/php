<?php
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
                  
$pluginConfig = array(
				'identifier' =>   'quikcadvancedcms',
				'version'    =>   '1.0.0',
				'install-type'=>  'full',
				'name'       =>   'Advanced Cms(Dynamic Lists, Forms)',
				'url'        =>   'http://www.quikc.org/',
				'description'=>   'This plugin allows you to implement implement dynamic lists',
				'author'     =>   'Quikc',
				'author-url' =>   'http://www.quikc.org/',
				'auto-load'  =>   true,
				);
