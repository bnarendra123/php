<?php
defined('QC_VALID') or die('Restricted Access!');

function dynamicAjaxPage($Action){
    global $Lists, $Forms, $Permissions, $Base;

    $actionSplitter = explode("/",$Action);
    //Generating the appropriate file if file doesnot exists

    //Generating the list if the requested url is like get/list/LIST_NAME
    if( $actionSplitter[0] == 'get' && $actionSplitter[1] == 'list' && isset($actionSplitter[2]) && $Lists->_checkListsPage($actionSplitter[2]) ){

		$dynamicLists = new DynamicLists;
		$detailsLists = $dynamicLists->_getListDetailsByLink($actionSplitter[2]);

		$checkPermissions = true;
		
		$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/".$detailsLists->idList."/list_before_start.php";
		if( $dynamicLists->_allowAdvancedCode() && file_exists($filePath)){
			include $filePath;
		}
    	
		if( $checkPermissions && !$Permissions->_checkPagePermission($Action,'view') ){
			$Base->_accessRestricted();
		}
		
        echo $Lists->_generateList($actionSplitter[2]);
		
		$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/".$detailsLists->idList."/list_after_call.php";
		if( $dynamicLists->_allowAdvancedCode() && file_exists($filePath)){
			include $filePath;
		}
		
    }

    if(isset($_POST['do'])) 
        $do = $_POST['do'];
    else
        $do = '';

    //Generating the default list actions if the requested url is like set/LIST_NAME. Used to process STATUS_CHANGE and DELETE
    if( $actionSplitter[0] == 'set' && isset($actionSplitter[1]) && $Lists->_checkListsPage($actionSplitter[1]) && in_array($do,array('status','delete'))){
        // For auto generating the required values for the lists generated from the database
        $dynamicLists = new DynamicLists;
        $dynamicLists->_processListActions($actionSplitter[1]);
    } 
    
    //Generating the form if the requested url is like get/edit/FORM_NAME
    if( $actionSplitter[0] == 'get' && $actionSplitter[1] == 'edit' && isset($actionSplitter[2]) && $Forms->_checkFormsPage($actionSplitter[2]) ){
    	
		$dynamicForms = new DynamicForms;
		$detailsForms = $dynamicForms->_getFormDetailsByLink($actionSplitter[2]);

		$checkPermissions = true;
		
		$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/forms/".$detailsForms->idForm."/form_before_start.php";
		if( $dynamicForms->_allowAdvancedCode() && file_exists($filePath)){
			include $filePath;
		}
    	
		if( $checkPermissions && !$Permissions->_checkPagePermission($Action,'view') ){
			$Base->_accessRestricted();
		}
		
        echo $Forms->_generateForm($actionSplitter[2],'');
		
		$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/forms/".$detailsForms->idForm."/form_after_call.php";
		if( $dynamicForms->_allowAdvancedCode() && file_exists($filePath)){
			include $filePath;
		}
		
    }

    //Generating the default form actions if the requested url is like set/FORM_NAME. Used to process CREATE and UPDATE
    if( $actionSplitter[0] == 'set' && isset($actionSplitter[1]) && $Forms->_checkFormsPage($actionSplitter[1]) && $do == 'edit' ){
        $dynamicForms = new DynamicForms;
        $dynamicForms->_processFormActions($actionSplitter[1]);
    }
    
}

