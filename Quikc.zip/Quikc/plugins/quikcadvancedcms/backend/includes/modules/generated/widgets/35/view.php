<h2><?php echo $detailsWidget->options->headding; ?></h2>
<img src="<?php echo $Base -> _displayPhpthumb( $detailsWidget->options->headerimage ); ?>" />
<p><?php echo $detailsWidget->options->content; ?></p>
<img src="<?php echo $Base -> _displayPhpthumb( $detailsWidget->options->footerimage); ?>" />

<?php
        $listSelect = $Base -> _generateSelect('gender');
        $valueField = $listSelect[$detailsWidget->options ->gender];
?>
<p><?php echo $valueField ?></p>

<?php
        if( isset( User :: timezoneUser() ) ){
            $timezoneUser = User :: _timezoneUser();
        }
        $valueDate= $Base -> _convertTimeZone( $detailsWidget->options ->date, $timezoneUser );
?>
<p><?php echo $valueDate; ?></p>