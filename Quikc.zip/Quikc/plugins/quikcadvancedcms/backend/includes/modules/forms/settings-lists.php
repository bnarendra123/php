<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "quikcadvancedlistsadvancedcodeoptionsstatus",  "type" => "select",	"label" => "Allow Advanced Code Options","req" => true ,"value" => "", "additional" => '',"set" => "yesno",
"postFieldLable"=>'<span  class="fieldhelp" title="Enable/disables Advanced code options for lists." />');


$formFields[] = array("id" => "quikcadvancedlistsnotvalidimport","type" => "text",  "label" => "Import Not Allowed Field Types","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');


$formFields[] = array("id" => "quikcadvancedlistsimportdatetypes","type" => "text",  "label" => "Import Date Field Types","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');

$formFields[] = array("id" => "quikcadvancedlistsimportdatelables","type" => "text",  "label" => "Import Date Field Lables","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');


$formFields[] = array("id" => "quikcadvancedlistsimportimagetypes","type" => "text",  "label" => "Import Image Field Types","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');

$formFields[] = array("id" => "quikcadvancedlistsimportimagelables","type" => "text",  "label" => "Import Image Field Lables","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');


$formFields[] = array("id" => "quikcadvancedlistsimportstatustypes","type" => "text",  "label" => "Import Status Field Types","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');

$formFields[] = array("id" => "quikcadvancedlistsimportstatuslables","type" => "text",  "label" => "Import Status Field Lables","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');


$formFields[] = array("id" => "quikcadvancedlistsimportselecttypes","type" => "text",  "label" => "Import Select Field Types","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');

$formFields[] = array("id" => "quikcadvancedlistsimportselectlables","type" => "text",  "label" => "Import Select Field Lables","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');

$formFields[] = array("id" => "quikcadvancedlistsimportselectdefault","type" => "Select",  "label" => "Import Default Select ","req" => true ,"value" => "", "additional" => '',"set" => array($Cms->_getListSets(),'linkSet','nameSet'),
"postFieldLable"=>'<span class="fieldhelp" title=" List of default actions." />');


$formFields[] = array("id" => "", "type" => "Button", "label" => "", "req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "quikcAdvancedLists", 
	"name" 		  	=> "Advanced Lists - Settings :", 
	"primaryFiled"  => "idSystemconfig", 
	"url" 		    => Config::_get('current.plugin').'/backend/includes/modules/ajax/set/'.$Base->_getFileName(__FILE__), 
	"success" 	    => "message_reporting('message_:FORM_ID','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 
