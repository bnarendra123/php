<?php echo "\n"; ?>
		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);
		<?php
		foreach($detailsForm->fields as $field){
	        // Validating if unique field option is selected
	        if($field->uniqueFieldForm == 1){
	            $fieldUnique = Core::_getField($field->fieldForm);
				echo "\n";
        ?>
        $query  = " select * from ".Config::_getTable('<?php echo $fieldsList[Core::_getFieldPrefix($field->fieldForm)]['table'] ?>')." where `<?php echo $fieldUnique ?>` = :field and `<?php echo Core::_getField($detailsForm->primaryFieldForm) ?>` != :formPrimaryField ";
        unset($arrayBind);
        $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
        $arrayBind[]= array("key" => ":field", "value" => $<?php echo $fieldUnique; ?>);

        if( Core::_getRowCount($query,$arrayBind) != 0){
            $processedForm['error'][] = '<?php echo $field->titleFieldForm; ?> already exists';
        }
        <?php 
	        }
		}
		echo "\n";
		?>
        if( count($processedForm['error']) != 0 ){      
            $Base->_convertError($processedForm['error'],false);
        }

        $fields = $processedForm['fields'];

        if($formPrimaryField == -1){
    
            if( !$Permissions->_checkPagePermission('<?php echo $formDetails['filename'] ?>','create') ){
                $Base->_accessRestricted();
            }
			<?php
			$i = 0;
	        // Executing the querys for each table                
	        foreach($fieldsList as $tables):

	        	$listFields = array();
				
	            // if the field is not a database field, then skipping further process and continuing to the next entry
				if(!isset($tables['table'])) continue;
	            // Retrieving the list of fields
	            
		            foreach($tables['fields'] as $fields):
		                // Field id
		                $field = $fields['id']; 
			            $listFields[] = $field;
						
		                // md5 encrypting for the password fields, if they are not null
		                if( strtolower($fields['type']) == 'password' && $$field != '' ): ?>
            <?php echo $$field ?>= md5(<?php echo $$field?>);
			            <?php endif; ?>
		            <?php endforeach; ?>

    		$insertKeys = $insertValues = $arrayBind = array();
            $tableFields = array('<?php echo implode("','",$listFields) ?>');
            foreach($tableFields as $field){
            	if( !in_array($field,$fields) ) continue;
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            <?php if( $i != 0 ): ?>
            	
			$insertKeys[] = '<?php echo Core::_getField($detailsForm->primaryFieldForm) ?>';
            $insertValues[]= ":formPrimaryField";
            $arrayBind[]= array("key" => ":formPrimaryField", "value" => $formPrimaryField);
			<?php endif; ?>
            
            $query = "insert into ".Config::_getTable('<?php echo $tables['table']; ?>')." (".implode(",",$insertKeys).") values (".implode(",",$insertValues).")";
			<?php if($i == 0): ?>	
           	if(Core::_runQuery($query, $arrayBind)){
				$formPrimaryField = Core::_getLastInsertId();
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
            <?php else: ?>	
        	Core::_runQuery($query, $arrayBind);
        	<?php endif; ?>
        <?php $i++ ?>
		<?php endforeach; ?>

        }else{
    
            if( !$Permissions->_checkPagePermission('<?php echo $formDetails['filename'] ?>','edit') ){
                $Base->_accessRestricted();
            }

			<?php
			$i = 0;
	        // Executing the querys for each table                
	        foreach($fieldsList as $tables):

	        	$listFields = array();
				
	            // if the field is not a database field, then skipping further process and continuing to the next entry
				if(!isset($tables['table'])) continue;
	            // Retrieving the list of fields
	            
		            foreach($tables['fields'] as $fields):
		                // Field id
		                $field = $fields['id']; 
			            $listFields[] = $field;
						
		                // md5 encrypting for the password fields, if they are not null
		                if( strtolower($fields['type']) == 'password' && $$field != '' ): ?>
            <?php echo $$field ?>= md5(<?php echo $$field?>);
			            <?php endif; ?>
		            <?php endforeach; ?>

    		$setpPart = $arrayBind = array();
            $tableFields = array('<?php echo implode("','",$listFields) ?>');
            foreach($tableFields as $field){
            	if( !in_array($field,$fields) ) continue;
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            	
            $arrayBind[]= array("key" => ":formPrimaryField", "value" => $formPrimaryField);
            
            $query  = "update ".Config::_getTable('<?php echo $detailsForm->tables[0]->tableForm; ?>')." set ".implode(",",$setpPart)." where <?php echo Core::_getField($detailsForm->primaryFieldForm); ?> = :formPrimaryField";

			// Count greater than 0 means atleast 1 element for this table exists in the current form
			// This will be useful in cases like quickedit etc
            if( count($setpPart) > 0 ){
	        	Core::_runQuery($query, $arrayBind);
            }
        <?php $i++ ?>
		<?php endforeach; ?>
        }

		