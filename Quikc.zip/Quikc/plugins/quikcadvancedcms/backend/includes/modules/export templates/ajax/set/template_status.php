
		if( !$Permissions->_checkPagePermission('<?php echo $listDetails['filename'] ?>','edit') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!<?php echo $fieldStatus; ?>";
        }

        // Status change query
        $query  = "update ".Config::_getTable('<?php echo $table ?>')." set <?php echo $fieldStatus; ?> = ".$changeToField." where `<?php echo $fieldPrimary ?>` = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
        }
        
		