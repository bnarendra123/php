<?php echo "<?php \n" ?>

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    $do = $_POST['do'];
	
	if($do == 'edit'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// Form edit action starts here

		// Form edit action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }else if($do == 'status'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// List status action starts here

		// List status action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }else if($do == 'delete'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// List delete action starts here

		// List delete action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }
    die($messageDie);
}
		