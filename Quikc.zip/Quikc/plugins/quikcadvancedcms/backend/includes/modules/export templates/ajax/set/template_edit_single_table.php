<?php echo "\n"; ?>
		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);
		<?php
		foreach($detailsForm->fields as $field){
	        // Validating if unique field option is selected
	        if($field->uniqueFieldForm == 1){
	            $fieldUnique = Core::_getField($field->fieldForm);
				echo "\n";
        ?>
        $query  = " select * from ".Config::_getTable('<?php echo $fieldsList[Core::_getFieldPrefix($field->fieldForm)]['table'] ?>')." where `<?php echo $fieldUnique ?>` = :field and `<?php echo Core::_getField($detailsForm->primaryFieldForm) ?>` != :formPrimaryField ";
        unset($arrayBind);
        $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
        $arrayBind[]= array("key" => ":field", "value" => $<?php echo $fieldUnique; ?>);

        if( Core::_getRowCount($query,$arrayBind) != 0){
            $processedForm['error'][] = '<?php echo $field->titleFieldForm; ?> already exists';
        }
        <?php 
	        }
		}
		echo "\n";
		?>
        if( count($processedForm['error']) != 0 ){      
            $Base->_convertError($processedForm['error'],false);
        }

        $fields = $processedForm['fields'];

        unset($arrayBind);
		
        if($formPrimaryField == -1){
    
            if( !$Permissions->_checkPagePermission('<?php echo $formDetails['filename'] ?>','create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fields as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('<?php echo $detailsForm->tables[0]->tableForm; ?>')." (".implode(",",$insertKeys).") values (".implode(",",$insertValues).")";

           if(Core::_runQuery($query, $arrayBind)){
				$formPrimaryField = Core::_getLastInsertId();
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }else{
    
            if( !$Permissions->_checkPagePermission('<?php echo $formDetails['filename'] ?>','edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('<?php echo $detailsForm->tables[0]->tableForm; ?>')." set ".implode(",",$setpPart)." where <?php echo Core::_getField($detailsForm->primaryFieldForm); ?> = :formPrimaryField";
            $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
    
           if(!Core::_runQuery($query, $arrayBind)){
				$Base->_convertError(array("Save Filed"),false);  
            }
        }

		