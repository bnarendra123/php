<?php echo "<?php \n" ?>

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

<?php
	$displayFields = '';
	foreach($listDetails['displayFields'] as $detailsField){
		$displayFields .= $this->_generateField($detailsField);
	}
?>
<?php echo $displayFields." \n " ?>

$listData = array( 
	"sql" 			=> "<?php echo $listDetails['sql'] ?>",
	"where" 		=> "<?php echo $listDetails['where'] ?>", 
	"arrayBind" 	=> "<?php echo $listDetails['arrayBind'] ?>",
	"sortby" 		=> "<?php echo $listDetails['sortby'] ?>", 
	"order" 		=> "<?php echo $listDetails['order'] ?>", 
	"headding" 		=> "<?php echo $listDetails['headding'] ?>", 
	"primaryField" 	=> "<?php echo $listDetails['primaryField'] ?>", 
	"statusField" 	=> "<?php echo $listDetails['statusField'] ?>",
	"editorUrl" 	=> "<?php echo $listDetails['editorUrl'] ?>",
	"submitLink" 	=> "<?php echo $listDetails['submitLink'] ?>",
//  Fields from here are same for all (in general)
    "multiActions"  => <?php echo $this->_generateBoolean($listDetails['multiActions']) ?>, 
	"multiLanguages"=> <?php echo $this->_generateBoolean($listDetails['multiLanguages'],false) ?>, 
	"displayFields" => $displayFields, 
	"page" 			=> "<?php echo $listDetails['page'] ?>", 
	"perpage" 		=> "<?php echo $listDetails['perpage'] ?>", 
	"displaypages" 	=> "<?php echo $listDetails['displaypages'] ?>", 
	"filename" 		=> "<?php echo $listDetails['filename'] ?>", 
);
		
