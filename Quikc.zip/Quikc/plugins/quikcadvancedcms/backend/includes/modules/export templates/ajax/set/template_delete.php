
		if( !$Permissions->_checkPagePermission('<?php echo $listDetails['filename'] ?>','delete') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
		
        // Exploding to get the ids
        $idArray = explode(",",$id);

        foreach($idArray as $tmpId){

            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);

            <?php 
            foreach($tablesList as $tmpTable): 
			 if( Core::_checkColumn($tmpTable,$fieldPrimary)): 
        	?>$query  = "delete from ".Config::_getTable('<?php echo $tmpTable ?>')." where `<?php echo $fieldPrimary ?>` = :primaryField";
            Core::_runQuery($query,$arrayBind);
	        <?php 
	        	endif; 		
        	endforeach; 
        	echo "\n"?>
        }

		