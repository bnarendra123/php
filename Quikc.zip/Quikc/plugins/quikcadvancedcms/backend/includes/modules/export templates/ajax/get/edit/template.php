<?php echo "<?php \n" ?>

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission('<?php echo $formDetails['filename']; ?>','view') ){
    $Base->_accessRestricted();
}

if(!$_POST){
    die();
}

extract($_POST);

if($formPrimaryField != -1){
    $query = "<?php echo $detailsForm['query']?>";
    $arrayBind= <?php echo $this->_prepareValue($detailsForm['arrayBind'])?>;
    
    $details = Core::_getRow($query,$arrayBind);
    
    $forms['name'] = "Editing ".$details-><?php echo $formDetails['displayTitleFieldForm']?>;

}else{
    $details = '';
}

echo $Forms->_generateForm($forms,$details);
		
