<?php echo "<?php \n" ?>

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission('<?php echo $listDetails['filename']; ?>','view') ){
    $Base->_accessRestricted();
}

echo $Lists->_generateList($listData);
		
