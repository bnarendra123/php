<?php echo "<?php \n" ?>

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

<?php
	$formFields = '';
	foreach($formDetails['fields'] as $detailsField){
		$formFields .= $this->_generateField($detailsField);
	}
?>
<?php echo $formFields." \n " ?>

$forms = array( 
	"identifier" 	=> "<?php echo $formDetails['identifier'] ?>", 
	"name" 			=> "<?php echo $formDetails['name'] ?>", 
    "primaryFiled"  => "<?php echo $formDetails['primaryFiled'] ?>", 
	"url" 			=> "<?php echo $formDetails['url'] ?>",
	"success"       => "<?php echo $formDetails['success'] ?>",
	"filename" 		=> "<?php echo $formDetails['filename'] ?>",
    "fields"        => $formFields,
);
		
