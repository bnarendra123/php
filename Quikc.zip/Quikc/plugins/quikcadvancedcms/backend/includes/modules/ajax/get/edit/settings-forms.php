<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(
									"quikcadvancedformsadvancedcodeoptionsstatus"	=>	Config::_get('quikc.advanced.forms.advanced.code.options.status'),
									
									"quikcadvancedformsnotvalidimport"   			=>	Config::_get('quikc.advanced.forms.import.not.valid.fields'),

									"quikcadvancedformsimportemailtypes"   			=>	Config::_get('quikc.advanced.forms.import.email.types'),
									"quikcadvancedformsimportemaillables"   		=>	Config::_get('quikc.advanced.forms.import.email.lables'),

									"quikcadvancedformsimporttextareatypes"   		=>	Config::_get('quikc.advanced.forms.import.textarea.types'),
									"quikcadvancedformsimporttextarealables"   		=>	Config::_get('quikc.advanced.forms.import.textarea.lables'),

									"quikcadvancedformsimportdatetypes"   			=>	Config::_get('quikc.advanced.forms.import.date.types'),
									"quikcadvancedformsimportdatelables"   			=>	Config::_get('quikc.advanced.forms.import.date.lables'),
									
									"quikcadvancedformsimportimagetypes"   			=>	Config::_get('quikc.advanced.forms.import.image.types'),
									"quikcadvancedformsimportimagelables"  			=>	Config::_get('quikc.advanced.forms.import.image.lables'),
									
									"quikcadvancedformsimportvideotypes"   			=>	Config::_get('quikc.advanced.forms.import.video.types'),
									"quikcadvancedformsimportvideolables"  			=>	Config::_get('quikc.advanced.forms.import.video.lables'),

									"quikcadvancedformsimportstatustypes"  			=>	Config::_get('quikc.advanced.forms.import.status.types'),
									"quikcadvancedformsimportstatuslables" 			=>	Config::_get('quikc.advanced.forms.import.status.lables'),
									
									"quikcadvancedformsimportselecttypes"  			=>	Config::_get('quikc.advanced.forms.import.select.types'),
									"quikcadvancedformsimportselectlables" 			=>	Config::_get('quikc.advanced.forms.import.select.lables'),
									"quikcadvancedformsimportselectdefault"			=>	Config::_get('quikc.advanced.forms.import.select.default'),
									);

echo $Forms->_generateForm($forms,$detailssystemconfig);


