<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

//echo '<pre>';
//print_r($_POST);
//die();
if($_POST){

    extract($_POST);
	
    if($do == 'edit'){
    
        $errors = array();
        $identifierTables = array();
        $Columns = array();
        
        if( $nameForm == ''){
            $errors[] = Config::_getMessage('forms.cms.forms.error.empty.form.name');
        }
        if( $linkForm == ''){
            $errors[] = Config::_getMessage('forms.cms.forms.error.empty.form.link');
        }else{
            $linkForm = $Base->_prepareLink($linkForm);
			
			$dynamicForms = new DynamicForms;
            if( $dynamicForms->_checkFormsLink($linkForm) && $dynamicForms->_getFormDetailsByLink($linkForm)->idForm != $idForm){
               // $errors[] = 'Form Link '.$linkForm.' already exists';
				$errors[] = Config::_prepareMessage('forms.cms.forms.validate.form.link.exists',array(":FORM_LINK" => $linkForm));            
            }
        }

        $tables = explode("_TABLES_",$tables);
        $fields = explode("_FIELDS_",$fields);

        $checkTablesForm = array();                
        foreach($tables as $tmpTable){
            // exploding to individual elements 
            $tmp = explode("_IDENTIFIER_",$tmpTable);
            // checking the tables in database
            if( !Core::_checkTable($tmp[0]) ){
                //$errors[] = "Table ".$tmp[0]." doesnot exist in the database.";
                 $errors[] = Config::_prepareMessage('forms.validation.lists.databasetable.exists',array(":TABLE_NAME" => $tmp[0]));                    
            }
            // checking for multiple Entries for Tables 
            if( in_array($tmp[0],$checkTablesForm) ){
                //$errors[] = "Table ".$tmp[0]." entered multiple times";
                 $errors[] = Config::_prepareMessage('forms.validation.lists.multiple.table.entry',array(":MULTIPLE_TABLE" => $tmp[0]));                    
            }
            // checking for multiple Entries for Table Identifier
            if( isset($identifierTables[$tmp[1]]) ){
                //$errors[] = "Table identifier ".$tmp[1]." entered multiple times";
                $errors[] = Config::_prepareMessage('forms.validation.lists.multiple.identifier.entry',array(":MULTIPLE_IDENTIFIER" => $tmp[1]));                    
            }

            // checking for multiple language field id for the table
            if( $tmp[4] != '' ){
                $Columns[] = $tmp[4];                    
            }

            $identifierTables[$tmp[1]] = $tmp;
            $checkTablesForm[] = $tmp[0];
        }
        unset($checkTablesForm);
           
	   // Chekcing weather the fields are valid or not
	   // If they are valid, then inserting them into $Columns to check with their tables
        foreach($fields as $tmpField){
            $tmp = explode("_SPLITTER_",$tmpField);
			// If $tmp[0] is empty, which means the field don't have any key(c.IdCountry etc). So we don't need to check that field
			// If the field is of type button, then also we will exclude that field
            if($tmp[0] != '' || strtolower($tmp[3]) == 'button'){
                $columnData[] = $tmp;
				// here $tmp[8] the field is a database field checkbox value
				// here we are checking weather the field is a database field or not 
				// If it is a database value, then we will include it for Columns check
                if($tmp[8] == '1')
                $Columns[]  = $tmp[0];
            }
        }

		
        foreach(array($primaryFieldForm,$displayTitleFieldForm) as $tmp){
            if($tmp != '' ){
                $Columns[]  = $tmp;
            }
        }
        foreach($Columns as $tmpColumn){
            if( !isset($identifierTables[Core::_getFieldPrefix($tmpColumn)][0]) ){
                //$errors[] = "Please add valid table identifier for the Column ".$tmpColumn;
                $errors[] =Config::_prepareMessage('forms.validation.lists.valid.identifier',array(":IDENTIFIER_TITLE" => $tmpColumn));
            }else if( !Core::_checkColumn($identifierTables[Core::_getFieldPrefix($tmpColumn)][0],Core::_getField($tmpColumn)) ){
                //$errors[] = "Column ".Core::_getField($tmpColumn)." doesnot exist in the Table ".$identifierTables[Core::_getFieldPrefix($tmpColumn)][0];
                $errors[] =Config::_prepareMessage('forms.validation.lists.column.exist.table',array(":COLUMN_NAME" => Core::_getField($tmpColumn),":COLUMN_TABLE"=>$identifierTables[Core::_getFieldPrefix($tmpColumn)][0]));
            }
        }
        
        if( count($errors) != 0 ){      
            $Base->_convertError($errors,false);
        }
        
        $fieldsListTable = array('nameForm','linkForm','whereForm','primaryFieldForm','displayTitleFieldForm','onSuccessForm');

        if( !isset($idForm) || $idForm == -1){
    
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fieldsListTable as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('forms')." (".implode(",",$insertKeys).",dateAdditionForm) values (".implode(",",$insertValues).",NOW())";
            Core::_runQuery($query, $arrayBind);
            $idForm = Core::_getLastInsertId();
			$User->_addUserLogActivity($User -> idUser() ,22);
            
        }else{
    
            if(!$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fieldsListTable as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('forms')." set ".implode(",",$setpPart)." where idForm = :idForm";
            $arrayBind[]= array("key" => ":idForm", "value" =>  $idForm);    
            Core::_runQuery($query,$arrayBind);
            
            unset($arrayBind);
            $arrayBind[]= array("key" => ":idForm", "value" =>  $idForm);    

            $query  = "delete from ".Config::_getTable('forms_tables')." where idForm = :idForm";
            Core::_runQuery($query,$arrayBind);
                        
            $query  = "delete from ".Config::_getTable('forms_fields')." where idForm = :idForm";
            Core::_runQuery($query,$arrayBind);
			$User->_addUserLogActivity($User -> idUser(),23);
        }
        
        foreach($identifierTables as $identifier => $tmpTable){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":idForm",             "value" => $idForm);
            $arrayBind[]= array("key" => ":tableForm",          "value" => $tmpTable[0]);
            $arrayBind[]= array("key" => ":identifierTableForm","value" => $identifier);
            $arrayBind[]= array("key" => ":joinTypeTable",      "value" => $tmpTable[2]);
            $arrayBind[]= array("key" => ":joinOnTable",        "value" => $tmpTable[3]);
            $arrayBind[]= array("key" => ":multiLanguageField", "value" => $tmpTable[4]);
                        
            $query = "insert into ".Config::_getTable('forms_tables')." (`idForm`,`tableForm`,`identifierTableForm`,`joinTypeTable`,`joinOnTable`,`multiLanguageField`) 
            values (:idForm,:tableForm,:identifierTableForm,:joinTypeTable,:joinOnTable,:multiLanguageField)";
            Core::_runQuery($query, $arrayBind);
        }
        
        foreach($columnData as $tmpColumn){

            if($tmpColumn[1] == '') $tmpColumn[1] = ucfirst(Core::_getField($tmpColumn[0]));
            unset($arrayBind);
            $arrayBind[]= array("key" => ":idForm",                 "value" => $idForm);
            $arrayBind[]= array("key" => ":fieldForm",              "value" => $tmpColumn[0]);
            $arrayBind[]= array("key" => ":titleFieldForm",         "value" => $tmpColumn[1]);
            $arrayBind[]= array("key" => ":orderFieldForm",         "value" => $tmpColumn[2]);
            $arrayBind[]= array("key" => ":typesFieldForm",         "value" => $tmpColumn[3]);
            $arrayBind[]= array("key" => ":setsFieldForm",          "value" => $tmpColumn[4]);
            $arrayBind[]= array("key" => ":defaultvalueFieldForm",  "value" => $tmpColumn[5]);
            $arrayBind[]= array("key" => ":additionalcssFieldForm", "value" => $tmpColumn[6]);
            $arrayBind[]= array("key" => ":requiredFieldForm",      "value" => $tmpColumn[7]);
            $arrayBind[]= array("key" => ":databasefieldFieldForm", "value" => $tmpColumn[8]);
            $arrayBind[]= array("key" => ":uniqueFieldForm",        "value" => $tmpColumn[9]);
                        
            $query = "insert into ".Config::_getTable('forms_fields')." (`idForm`,`fieldForm`,`titleFieldForm`,`orderFieldForm`,`typesFieldForm`,`setsFieldForm`,`defaultvalueFieldForm`,`additionalcssFieldForm`,`requiredFieldForm`,`databasefieldFieldForm`,`uniqueFieldForm`) 
            values (:idForm,:fieldForm,:titleFieldForm,:orderFieldForm,:typesFieldForm,:setsFieldForm,:defaultvalueFieldForm,:additionalcssFieldForm,:requiredFieldForm,:databasefieldFieldForm,:uniqueFieldForm)";
            Core::_runQuery($query, $arrayBind);
            }

		$generatedPath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/forms/$idForm/";
		
		$formFiles = array('form_before_start','form_before_call','form_after_call','form_before_display_errors','form_after_complete');
		foreach( $formFiles as $tmp){
			$Base->_createFile($generatedPath.$tmp.'.php',$$tmp);
		}

		DynamicForms::_getInstance()->_getFormDetails($idForm);
            
    }else if($do == 'status'){
            
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }
        $id = $_POST['id'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusForm";
        }

        // Status change query
        $query  = "update ".Config::_getTable('forms')." set statusForm = ".$changeToField." where idForm = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
			
			DynamicForms::_getInstance()->_getFormDetails($tmpId);
        }

    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        
        // Exploding to get the ids
        $idArray = explode(",",$id);
        
        $query1  = "delete from ".Config::_getTable('forms')." where idForm = :primaryField";
        $query2  = "delete from ".Config::_getTable('forms_fields')." where idForm = :primaryField";
        $query3  = "delete from ".Config::_getTable('forms_tables')." where idForm = :primaryField";
        foreach($idArray as $tmpId){
        		
        	if( !DynamicForms::_getInstance()->_checkFormExists($tmpId) ) continue;
			
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);

            Core::_runQuery($query1,$arrayBind);
            Core::_runQuery($query2,$arrayBind);
            Core::_runQuery($query3,$arrayBind);
			
			$generatedPath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/forms/$tmpId/";
			$Base->_removeDir($generatedPath);

			DynamicForms::_getInstance()->_getFormDetails($tmpId);
        }  
    }
    die('ok');
}

