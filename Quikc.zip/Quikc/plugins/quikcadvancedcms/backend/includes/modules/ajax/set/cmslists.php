<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

    extract($_POST);
	
    if($do == 'edit'){
    
        $errors = array();
        $identifierTables = array();
        $Columns = array();
        
        if( $nameList == ''){
            $errors[] = Config::_getMessage('forms.cms.lists.error.empty.list.name');
        }
        if( $linkList == ''){
            $errors[] = Config::_getMessage('forms.cms.lists.error.empty.list.link');
        }else{
            $linkList = $Base->_prepareLink($linkList);

			$dynamicLists = new dynamicLists;
            if( $dynamicLists->_checkListsLink($linkList) && $dynamicLists->_getListDetailsByLink($linkList)->idList != $idList){
               // $errors[] = 'List Link '.$linkList.' already exists';
               $errors[] = Config::_prepareMessage('forms.validation.lists.link.exists',array(":LINK_LIST" => $linkList));            
            }
        }
        
        $tables = explode("_TABLES_",$tables);
        $fields = explode("_FIELDS_",$fields);

        $checkTablesList = array();                
        foreach($tables as $tmpTable){
            // exploding to individual elements 
            $tmp = explode("_IDENTIFIER_",$tmpTable);
            // checking the tables in database
            if( !Core::_checkTable($tmp[0]) ){
                //$errors[] = "Table ".$tmp[0]." doesnot exist in the database.";
                $errors[] = Config::_prepareMessage('forms.validation.lists.databasetable.exists',array(":TABLE_NAME " => $tmp[0]));                    
            }
            // checking for multiple Entries for Tables 
            if( in_array($tmp[0],$checkTablesList) ){
                //$errors[] = "Table ".$tmp[0]." entered multiple times";      
                 $errors[] = Config::_prepareMessage('forms.validation.lists.multiple.table.entry',array(":MULTIPLE_TABLE  " => $tmp[0]));              
            }
            // checking for multiple Entries for Table Identifier
            if( isset($identifierTables[$tmp[1]]) ){
                //$errors[] = "Table identifier ".$tmp[1]." entered multiple times";
                $errors[] = Config::_prepareMessage('forms.validation.lists.multiple.identifier.entry',array(":MULTIPLE_IDENTIFIER   " => $tmp[1]));                     
            }

            $identifierTables[$tmp[1]] = $tmp;
            $checkTablesList[] = $tmp[0];
        }
        unset($checkTablesList);
           
        foreach($fields as $tmpField){
            $tmp = explode("_SPLITTER_",$tmpField);
            $columnData[] = $tmp;
            $Columns[]  = $tmp[0];
        }
        foreach(array($sortByFieldList,$primaryFieldList,$statusFieldList,$multiLanguageFieldList) as $tmp){
            if($tmp != '' ){
                $Columns[]  = $tmp;
            }
        }
        foreach($Columns as $tmpColumn){
            if( !isset($identifierTables[Core::_getFieldPrefix($tmpColumn)][0]) ){
            	$errors[] =Config::_prepareMessage('forms.validation.lists.valid.identifier',array(":IDENTIFIER_TITLE" => $tmpColumn));
                //$errors[] = "Please add valid table identifier for the Column ".$tmpColumn;
            }else if( !Core::_checkColumn($identifierTables[Core::_getFieldPrefix($tmpColumn)][0],Core::_getField($tmpColumn)) ){
                //$errors[] = "Column ".Core::_getField($tmpColumn)." doesnot exist in the Table ".$identifierTables[Core::_getFieldPrefix($tmpColumn)][0];
                $errors[] =Config::_prepareMessage('forms.validation.lists.column.exist.table',array(":COLUMN_NAME " => Core::_getField($tmpColumn),":COLUMN_TABLE"=>$identifierTables[Core::_getFieldPrefix($tmpColumn)][0]));
            }            
        }
        
        if( count($errors) != 0 ){      
            $Base->_convertError($errors,false);
        }
		
        $fieldsListTable = array('nameList','linkList','whereList','sortByFieldList','sortOrderFieldList','primaryFieldList','statusFieldList','multiLanguageFieldList','pagePaginationList','rowsPaginationList','pagesPaginationList','actionsList','editActionLink');

        if( !isset($idList) || $idList == -1){
    
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fieldsListTable as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('lists')." (".implode(",",$insertKeys).",dateAdditionList) values (".implode(",",$insertValues).",NOW())";
            Core::_runQuery($query, $arrayBind);
            $idList = Core::_getLastInsertId();
            $User->_addUserLogActivity($User -> idUser(),18);
            
        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fieldsListTable as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('lists')." set ".implode(",",$setpPart)." where idList = :idList";
            $arrayBind[]= array("key" => ":idList", "value" =>  $idList);    
            Core::_runQuery($query,$arrayBind);
            
            unset($arrayBind);
            $arrayBind[]= array("key" => ":idList", "value" =>  $idList);    

            $query  = "delete from ".Config::_getTable('lists_tables')." where idList = :idList";
            Core::_runQuery($query,$arrayBind);
                        
            $query  = "delete from ".Config::_getTable('lists_fields')." where idList = :idList";
            Core::_runQuery($query,$arrayBind);
			$User->_addUserLogActivity($User -> idUser(),19);
        }
        
		$generatedPath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/$idList/";
		
		$listFiles = array('list_before_start','list_before_call','list_after_call','status_before_start','status_after_update','delete_before_start','delete_after_update');
		foreach( $listFiles as $tmp){
			$Base->_createFile($generatedPath.$tmp.'.php',$$tmp);
		}
		
        foreach($identifierTables as $identifier => $tmpTable){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":idList",             "value" => $idList);
            $arrayBind[]= array("key" => ":tableList",          "value" => $tmpTable[0]);
            $arrayBind[]= array("key" => ":identifierTableList","value" => $identifier);
            $arrayBind[]= array("key" => ":joinTypeTable",      "value" => $tmpTable[2]);
            $arrayBind[]= array("key" => ":joinOnTable",        "value" => $tmpTable[3]);
                        
            $query = "insert into ".Config::_getTable('lists_tables')." (`idList`,`tableList`,`identifierTableList`,`joinTypeTable`,`joinOnTable`) 
            values (:idList,:tableList,:identifierTableList,:joinTypeTable,:joinOnTable)";
            Core::_runQuery($query, $arrayBind);
        }
        foreach($columnData as $tmpColumn){

            if($tmpColumn[1] == '') $tmpColumn[1] = ucfirst(Core::_getField($tmpColumn[0]));
            unset($arrayBind);
            $arrayBind[]= array("key" => ":idList",         "value" => $idList);
            $arrayBind[]= array("key" => ":fieldList",      "value" => $tmpColumn[0]);
            $arrayBind[]= array("key" => ":titleFieldList", "value" => $tmpColumn[1]);
            $arrayBind[]= array("key" => ":displayFieldList","value"=> $tmpColumn[2]);
            $arrayBind[]= array("key" => ":orderFieldList", "value" => $tmpColumn[3]);
            $arrayBind[]= array("key" => ":showFieldList",  "value" => $tmpColumn[4]);
            $arrayBind[]= array("key" => ":typesFieldList", "value" => $tmpColumn[5]);
            $arrayBind[]= array("key" => ":setsFieldList",  "value" => $tmpColumn[6]);
            
            $query = "insert into ".Config::_getTable('lists_fields')." (`idList`,`fieldList`,`titleFieldList`,`displayFieldList`,`orderFieldList`,`showFieldList`,`typesFieldList`,`setsFieldList`) 
            values (:idList,:fieldList,:titleFieldList,:displayFieldList,:orderFieldList,:showFieldList,:typesFieldList,:setsFieldList)";
            Core::_runQuery($query, $arrayBind);
        }

    }else if($do == 'status'){
            
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusList";
        }

        // Status change query
        $query  = "update ".Config::_getTable('lists')." set statusList = ".$changeToField." where idList = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);                
        }
		
		$User->_addUserLogActivity($User -> idUser() ,20);
    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
        
        // Exploding to get the ids
        $idArray = explode(",",$id);
        
        $query1  = "delete from ".Config::_getTable('lists')." where idList = :primaryField";
        $query2  = "delete from ".Config::_getTable('lists_fields')." where idList = :primaryField";
        $query3  = "delete from ".Config::_getTable('lists_tables')." where idList = :primaryField";
        foreach($idArray as $tmpId){
        	
        	if( !DynamicLists::_getInstance()->_checkListExists($tmpId) ) continue;
			
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);

            Core::_runQuery($query1,$arrayBind);
            Core::_runQuery($query2,$arrayBind);
            Core::_runQuery($query3,$arrayBind);
			
			$generatedPath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/$tmpId/";
			$Base->_removeDir($generatedPath);
	    }  
		
		$User->_addUserLogActivity($User -> idUser() ,21);              
    }
    die('ok');
}

