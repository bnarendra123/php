<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array(
									"quikcadvancedlistsadvancedcodeoptionsstatus"	=>	Config::_get('quikc.advanced.lists.advanced.code.options.status'),
									
									"quikcadvancedlistsnotvalidimport"   			=>	Config::_get('quikc.advanced.lists.import.not.valid.fields'),

									"quikcadvancedlistsimportdatetypes"   			=>	Config::_get('quikc.advanced.lists.import.date.types'),
									"quikcadvancedlistsimportdatelables"   			=>	Config::_get('quikc.advanced.lists.import.date.lables'),
									
									"quikcadvancedlistsimportimagetypes"   			=>	Config::_get('quikc.advanced.lists.import.image.types'),
									"quikcadvancedlistsimportimagelables"  			=>	Config::_get('quikc.advanced.lists.import.image.lables'),
									
									"quikcadvancedlistsimportstatustypes"  			=>	Config::_get('quikc.advanced.lists.import.status.types'),
									"quikcadvancedlistsimportstatuslables" 			=>	Config::_get('quikc.advanced.lists.import.status.lables'),
									
									"quikcadvancedlistsimportselecttypes"  			=>	Config::_get('quikc.advanced.lists.import.select.types'),
									"quikcadvancedlistsimportselectlables" 			=>	Config::_get('quikc.advanced.lists.import.select.lables'),
									"quikcadvancedlistsimportselectdefault"			=>	Config::_get('quikc.advanced.lists.import.select.default'),
									);

echo $Forms->_generateForm($forms,$detailssystemconfig);


