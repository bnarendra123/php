<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){
    
    extract($_POST);
    
    if($do == 'edit'){

        global $Widgets;
        $dbFields = array('titleWidget','typeWidget','statusWidget','systemItem','typeDisplayWidget','htmlCodeWidget','pathDisplayFileWidget');

        $errors = array();
        
        if( $titleWidget == ''){
            $errors[] = 'Please Enter Widget Title';
        }
        if( $typeWidget == ''){
            $errors[] = 'Please Select Widget Type';
        }

        
        if( $typeWidget == 'file'){
            
            $dbFields[] = 'pathWidget';
            
            if( $pathWidget =='' ){

                $errors[] = 'Please Enter Widget Path';

            }else{

                $detailsWidget = $Widgets->_getWidgetDetailsByPath($pathWidget);

                if( $detailsWidget && $detailsWidget->idWidget != $idWidget ){
                
                    $errors[] = 'Widget Already Exists with the path '.$pathWidget;
                    
                }elseif( !file_exists(Config::_getDir().'/'.$pathWidget) || !is_dir(Config::_getDir().'/'.$pathWidget) ){
                        
                    $errors[] = 'Invalid Widget Directory '.Config::_getDir().'/'.$pathWidget;
                }
            }
                
        }else if( $typeWidget == 'dynamic' ){


            if( $fields =='' ){

                $errors[] = 'Please Add Atleast One Valid Field';
                
            }else{

                $fields = explode("_FIELDS_",$fields);
                
               // Chekcing weather the fields are valid or not
               // If they are valid, then inserting them into $Columns to check with their tables
                foreach($fields as $tmpField){
                    $tmp = explode("_SPLITTER_",$tmpField);
                    // If $tmp[0] is empty, which means the field don't have any key(c.IdCountry etc). So we don't need to check that field
                    // If the field is of type button, then also we will exclude that field
 
                   $keyField = $Base->_prepareLink($tmp[0]);
        
                    if($keyField != ''){
                        
                        if( isset($processedFields[$keyField]) ){
                            
                            $errors[] = 'Duplicate Key '.$keyField.' for field : '.$tmp[1];

                        }else{

                            $processedFields[$keyField] = array( 
                                                        'keyFieldWidget'    =>  $keyField, 
                                                        'titleFieldWidget'  =>  $tmp[1], 
                                                        'typesFieldWidget'  =>  $tmp[2], 
                                                        'setsFieldWidget'   =>  $tmp[3], 
                                                        'orderFieldWidget'  =>  $tmp[4], 
                                                        'defaultvalueFieldWidget'   =>  $tmp[5], 
                                                        'additionalcssFieldWidget'  =>  $tmp[6],
                                                        'requiredFieldWidget'       =>  $tmp[7],
                                                );
                            
                        }

                    }
                }
                
            }


            if( $typeDisplayWidget == 'html' && $htmlCodeWidget == '' ){
                $errors[] = 'Please Enter Display Html Code';
            }
            if( $typeDisplayWidget == 'php' && $phpCodeWidget == '' ){
                $errors[] = 'Please Enter Display Php Code';
            }
            if( $typeDisplayWidget == 'file' ){

                if( $pathDisplayFileWidget == '' ){

                    $errors[] = 'Please Enter Display File Path';

                }else{

                    $pathFile = Config::_getDir()."/".$pathDisplayFileWidget;
                    
                    if( !file_exists($pathFile) || is_dir($pathFile) ){
                        $errors[] = "File doesn't Exists in the given path.";
                    }

                }

            }

        }
        
        if( count($errors) > 0 ){

            $Base->_convertError($errors,false);
            
        }
        
        if($idWidget == -1){
        	
            if( !$Permissions->_checkPagePermission($Base->_getFileName(__FILE__),'create') ){
                $Base->_accessRestricted();
            }

			//Preparing the created by fields
			$dbFields[] = 'createdById';
			$dbFields[] = 'createdByType';
			
			$createdById = $User -> idUser();
			$createdByType = 'user';

			//Preparing the created by fields
			$insertKeys  = array();
			$insertValues= array();
			$arrayBind	 = array();
	
			foreach($dbFields as $field){
				$insertKeys[]  = "`$field`";
				$insertValues[]= ":$field";
				$arrayBind[]= array("key" => ":$field",	"value" => $$field);
			}

			$query = "insert into ".Config::_getTable('widgets')." (".implode(",",$insertKeys).",dateAdditionWidget) values (".implode(",",$insertValues).",NOW())";
            
			if( Core::_runQuery($query, $arrayBind) ){

                $idWidget = Core::_getLastInsertId();

			}else{
			    
                $messageDie = 'Creation Failed';

			}
            
        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($dbFields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('widgets')." set ".implode(",",$setpPart)." where idWidget = :idWidget";
            $arrayBind[]= array("key" => ":idWidget", "value" =>  $idWidget);
    
            if(Core::_runQuery($query, $arrayBind)){
                
				Cache::_getInstance() -> _removeCache('widgets_' . $idWidget);
				Plugins::_runAction('widgets_edit',$idWidget);
				
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }

        if( $typeWidget == 'dynamic' ){

            $arrayBind = array();

            $query = "delete from ".Config::_getTable('widgets_fields')." where idWidget = :idWidget ";
            $arrayBind[]= array("key" => ":idWidget"  , "value" => $idWidget);
            Core::_runQuery($query, $arrayBind);


            $query = "insert into ".Config::_getTable('widgets_fields')." (`idWidget`,`keyFieldWidget`,`titleFieldWidget`,`typesFieldWidget`,`setsFieldWidget`,`orderFieldWidget`,`defaultvalueFieldWidget`,`additionalcssFieldWidget`,`requiredFieldWidget`) 
            values (:idWidget,:keyFieldWidget,:titleFieldWidget,:typesFieldWidget,:setsFieldWidget,:orderFieldWidget,:defaultvalueFieldWidget,:additionalcssFieldWidget,:requiredFieldWidget)";
            
            foreach($processedFields  as $field){
                    
                $arrayBind = array();

                $arrayBind[]= array("key" => ":idWidget"                , "value" => $idWidget);
                $arrayBind[]= array("key" => ":keyFieldWidget"          , "value" => $field['keyFieldWidget']);
                $arrayBind[]= array("key" => ":titleFieldWidget"        , "value" => $field['titleFieldWidget']);
                $arrayBind[]= array("key" => ":typesFieldWidget"        , "value" => $field['typesFieldWidget']);
                $arrayBind[]= array("key" => ":setsFieldWidget"         , "value" => $field['setsFieldWidget']);
                $arrayBind[]= array("key" => ":orderFieldWidget"        , "value" => $field['orderFieldWidget']);
                $arrayBind[]= array("key" => ":defaultvalueFieldWidget" , "value" => $field['defaultvalueFieldWidget']);
                $arrayBind[]= array("key" => ":additionalcssFieldWidget", "value" => $field['additionalcssFieldWidget']);
                $arrayBind[]= array("key" => ":requiredFieldWidget"     , "value" => $field['requiredFieldWidget']);
                
                Core::_runQuery($query, $arrayBind);
                
            }

            if( $typeDisplayWidget == 'php' ){
    
                $generatedPath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/widgets/$idWidget/";
                
                $Base->_createFile($generatedPath.'view.php',$phpCodeWidget);
    
            }
            
        }

    }else if($do == 'status'){

        global $Widgets;

        // Including default widgets set page for status action        
        include_once Config::_getDir('admin').'/includes/core/modules/ajax/set/widgets.php';
            
    }else if($do == 'delete'){
        
        global $Widgets;

        // Including default widgets set page for delete action        
        include_once Config::_getDir('admin').'/includes/core/modules/ajax/set/widgets.php';
        
    }
    die($messageDie);
}

