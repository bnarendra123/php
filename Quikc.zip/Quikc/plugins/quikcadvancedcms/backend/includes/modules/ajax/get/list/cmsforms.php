<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

echo $Lists->_generateList($listData);

?>
<script>
	function exportForm(idForm){
		
		if ( !confirm("Are you sure you want to export this item?. It will overwrite existing file(If any). ")) return false;

		var pass_url = "/ajax.php?action=<?php echo Config::_get('current.plugin'); ?>/backend/includes/modules/ajax/set/export";
	
		var pass_data = "type=form&idForm="+idForm;
		
		$.ajax({
			type        : "POST",
			beforeSend	: loadingStarts,
			url         : adminUrl+pass_url,
			data        : pass_data,
			success     : function(responseText){
							loadingEnds();
							alert(responseText);
							LoadList_<?php echo $Lists->_getListId(); ?>();
						}
		});
	}
</script>