<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission('cmsforms','view') ){
    $Base->_accessRestricted();
}

require_once Config::_getDir('current.plugin').'/backend/includes/classes/iforms.php';

extract($_POST);

$generatedColumns = iForms::_getInstance()->_generateImportFields($table);

echo json_encode($generatedColumns);

die();
