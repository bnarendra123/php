<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if(!$_POST){
    die();
}

if( !$Permissions->_checkPagePermission('cmslists','view') || !$Permissions->_checkPagePermission('cmsforms','view')){
    $Base->_accessRestricted();
}

$generatedForm['headding'] = 'Quick Generation Lists & Forms : ';

$quikcTables = array( 
						'cms_messages_log',
						'cms_pages',
						'cms_sets',
						'cms_sets_options',
						'cms_sets_tables',
						'cms_themes',
						'cms_themes_files',
						'configuration',
						'languages',
						'mails',

						'cms_forms',
						'cms_forms_fields',
						'cms_forms_tables',
						'cms_lists',
						'cms_lists_fields',
						'cms_lists_tables',

						'countries',
						'time_zones',
					);

$generatedForm['all_tables'] = Core::_getTables();
//$generatedForm['quikc_tables'] = $quikcTables;
//$generatedForm['other_tables'] = array_values(array_diff($generatedForm['all_tables'], $generatedForm['quikc_tables']));
$generatedForm['other_tables'] = array_diff($generatedForm['all_tables'], $quikcTables);
$generatedForm['quikc_tables'] = array_diff($generatedForm['all_tables'], $generatedForm['other_tables']);

echo '<pre>';
//print_r($generatedForm);
echo '</pre>';


$generatedForm['form_id'] = 'qgenerate';

include_once Config::_getDir('current.plugin').'/templates/backend/elements/qgenerate.phtml';
include_once Config::_getDir('admin.temp').'/elements/forms.phtml';

