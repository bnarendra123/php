<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$processedForm = $Forms->_processForm($forms,$_POST);

	extract($processedForm['formElements']);
	
	if( count($processedForm['error']) != 0 ){		
		$Base->_convertError($processedForm['error'],false);
	}
	
	$fields = array(
					"quikcadvancedlistsadvancedcodeoptionsstatus"	=>	'quikc.advanced.lists.advanced.code.options.status',
					
					"quikcadvancedlistsnotvalidimport"   			=>	'quikc.advanced.lists.import.not.valid.fields',

					"quikcadvancedlistsimportdatetypes"   			=>	'quikc.advanced.lists.import.date.types',
					"quikcadvancedlistsimportdatelables"   			=>	'quikc.advanced.lists.import.date.lables',
					
					"quikcadvancedlistsimportimagetypes"   			=>	'quikc.advanced.lists.import.image.types',
					"quikcadvancedlistsimportimagelables"  			=>	'quikc.advanced.lists.import.image.lables',
					
					"quikcadvancedlistsimportstatustypes"  			=>	'quikc.advanced.lists.import.status.types',
					"quikcadvancedlistsimportstatuslables" 			=>	'quikc.advanced.lists.import.status.lables',
					
					"quikcadvancedlistsimportselecttypes"  			=>	'quikc.advanced.lists.import.select.types',
					"quikcadvancedlistsimportselectlables" 			=>	'quikc.advanced.lists.import.select.lables',
					"quikcadvancedlistsimportselectdefault"			=>	'quikc.advanced.lists.import.select.default',
					);
	
	if( !$Permissions->_checkPagePermission($Base->_getFileName(__FILE__),'edit') ){
		$Base->_accessRestricted();
	}

	$setpPart = array();
	
	foreach($fields as $keyField => $keyValue){
		if(in_array($keyField, $processedForm['fields'])){
		    Config::_updateDbConfigEntry($keyValue,$$keyField);
		}
	}

	die('ok');
}

