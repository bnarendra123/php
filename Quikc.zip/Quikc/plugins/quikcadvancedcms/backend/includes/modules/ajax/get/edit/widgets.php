<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if(!$_POST){
    die();
}

if( !$Permissions->_checkPagePermission( $Base->_getFileName(__FILE__) ,'view') ){
    $Base->_accessRestricted();
}

extract($_POST);

if( isset($formPrimaryField) && $formPrimaryField != -1 ){
	
    global $Widgets;
    
    $detailsWidget = $Widgets->_getWidgetDetails($formPrimaryField);    

	$generatedForm['headding'] = 'Editing Widget : '.$detailsWidget->titleWidget;

}else{

    $formPrimaryField = -1;
    $detailsWidget = new stdClass();
    $detailsWidget->idWidget = $formPrimaryField;
    $detailsWidget->typeWidget = 'file';
    $detailsWidget->fields = array();

    $fieldsDefault = array('titleWidget','pathWidget','statusWidget','systemItem','typeDispalyWidget','htmlCodeWidget','phpCodeWidget','pathDisplayFileWidget');

    foreach($fieldsDefault as $field){

        $detailsWidget->$field = '';

    }

    $detailsWidget->statusWidget =  1;
    $detailsWidget->actionsList = array();

	$generatedForm['headding'] = 'Creating New Widget : ';
}

$generatedForm['form_id'] = 'widgets';

include_once Config::_getDir('current.plugin').'/templates/backend/elements/widgets.phtml';
include_once Config::_getDir('admin.temp').'/elements/forms.phtml';

