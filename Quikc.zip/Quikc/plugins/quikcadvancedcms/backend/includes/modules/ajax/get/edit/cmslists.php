<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if(!$_POST){
    die();
}

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

extract($_POST);

$dynamicLists = new dynamicLists;

$listFiles = array('list_before_start','list_before_call','list_after_call','status_before_start','status_after_update','delete_before_start','delete_after_update');

if( isset($formPrimaryField) && $formPrimaryField != -1 ){
    $detailsList = $dynamicLists->_getListDetails($formPrimaryField);

	$generatedPath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/$formPrimaryField/";
	
	foreach( $listFiles as $tmp){
		if(file_exists($generatedPath.$tmp.'.php')){
			$detailsList->$tmp = file_get_contents($generatedPath.$tmp.'.php');
		}else{
			$detailsList->$tmp = '';
		}
	}

	$generatedForm['headding'] = 'Editing List : '.$detailsList->nameList;
}else{
    $formPrimaryField = -1;
    $detailsList = new stdClass();
    $detailsList->idList = $formPrimaryField;

    $fieldsDefault = array_merge(array('nameList','linkList','whereList','sortByFieldList','sortOrderFieldList','primaryFieldList','statusFieldList','multiLanguageFieldList','pagePaginationList','rowsPaginationList','pagesPaginationList','editActionLink'),$listFiles);
    foreach($fieldsDefault as $field){
        $detailsList->$field = '';
    }
    $detailsList->actionsList = array('status','edit','delete');

	$generatedForm['headding'] = 'Creating New List : ';
}
//print_r($detailsList);
$generatedForm['form_id'] = 'cmslists';

include_once Config::_getDir('current.plugin').'/templates/backend/elements/cmslists.phtml';
include_once Config::_getDir('admin.temp').'/elements/forms.phtml';

