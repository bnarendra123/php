<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission('cmsforms','view') ){
    $Base->_accessRestricted();
}

require_once Config::_getDir('current.plugin').'/backend/includes/classes/qgenerate.php';
require_once Config::_getDir('current.plugin').'/backend/includes/classes/ilists.php';
require_once Config::_getDir('current.plugin').'/backend/includes/classes/iforms.php';

qGenerate::_getInstance()->_generate($_POST);

die();

