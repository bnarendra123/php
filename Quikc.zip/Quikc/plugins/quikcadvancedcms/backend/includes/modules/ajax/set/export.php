<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

if( $type == 'list' ){

	if( !$Permissions->_checkPagePermission('cmslists','edit') ){
	    $Base->_accessRestricted();
	}
	
	require_once Config::_getDir('current.plugin').'/backend/includes/classes/elists.php';
	eLists::_getInstance()->_generate($idList);
	
}else if( $type == 'form' ){

	if( !$Permissions->_checkPagePermission('cmsforms','edit') ){
	    $Base->_accessRestricted();
	}

	require_once Config::_getDir('current.plugin').'/backend/includes/classes/eforms.php';
	eForms::_getInstance()->_generate($idForm);
}

die();
