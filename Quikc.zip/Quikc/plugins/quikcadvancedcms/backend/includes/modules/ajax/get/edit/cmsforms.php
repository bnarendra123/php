<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if(!$_POST){
    die();
}

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

$dynamicForms = new DynamicForms;

extract($_POST);

$formFiles = array('form_before_start','form_before_call','form_after_call','form_before_display_errors','form_after_complete');

if( isset($formPrimaryField) && $formPrimaryField != -1 ){
	
    $detailsForm = $dynamicForms->_getFormDetails($formPrimaryField);    

	$generatedPath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/forms/$formPrimaryField/";
	
	foreach( $formFiles as $tmp){
		if(file_exists($generatedPath.$tmp.'.php')){
			$detailsForm->$tmp = file_get_contents($generatedPath.$tmp.'.php');
		}else{
			$detailsForm->$tmp = '';
		}
	}
	
	$generatedForm['headding'] = 'Editing Form : '.$detailsForm->nameForm;
}else{
    $formPrimaryField = -1;
    $detailsForm = new stdClass();
    $detailsForm->idForm = $formPrimaryField;

    $fieldsDefault = array_merge(array('nameForm','linkForm','whereForm','onSuccess','primaryFieldForm','displayTitleFieldForm','statusForm'),$formFiles);
    foreach($fieldsDefault as $field){
        $detailsForm->$field = '';
    }
    $detailsForm->onSuccessForm = "";
    $detailsForm->actionsList = array();

	$generatedForm['headding'] = 'Creating New Form : ';
}

$generatedForm['form_id'] = 'cmsforms';

include_once Config::_getDir('current.plugin').'/templates/backend/elements/cmsforms.phtml';
include_once Config::_getDir('admin.temp').'/elements/forms.phtml';

