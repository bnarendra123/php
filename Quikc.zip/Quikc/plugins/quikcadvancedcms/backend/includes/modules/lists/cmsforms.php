<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');


$actions = array("status","edit");

$actions[] = array('display' => '<a href="javascript:exportForm(\'primaryField\')">
					<img src="'.Config::_getUrl('img').'/export-icon.png" width="16" height="16" alt="Export Form" title="Export Form" />
				</a>', 'permissions' => 'create' );

$actions[]= "delete";

$displayFields  = array( 
 array( "id" => "idForm",			"title" => 'Form Id'      ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'f', "display" => ':data'),
 array( "id" => "nameForm",			"title" => 'Form Name'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'f', "display" => ':data'), 
 array( "id" => "linkForm",			"title" => 'Form Link'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'f', "display" => ':data'), 
 array( "id" => "statusForm",		"title" => 'Form Status'  ,"type" => 'select' ,"dbField" => true ,"tpx" => 'f', "display" => ':data',"set" => "status", "show" => false),
 array( "id" => "dateAdditionForm",	"title" => 'Created On'   ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'f', "display" => ':data', "show" =>	false),
 array( "id" => "dateUpdationForm",	"title" => 'Update On'    ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'f', "display" =>':data'), 
 array( "id" => "actions",			"title" => 'Actions'      ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    )
);

$listData = array( 
    "sql"           => "select * from ".Config::_getTable('forms')." f ", 
    "where"         => "",
    "arrayBind"     => "",
    "sortby"        => "nameForm", 
    "order"         => "asc", 
    "headding"      => Config::_getMessage('lists.cms.forms.title'), 
    "primaryField"  => "idForm", 
    "statusField"   => "statusForm", 
    //  Fields from here are same for all (in general)
    "multiActions"  => true, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

