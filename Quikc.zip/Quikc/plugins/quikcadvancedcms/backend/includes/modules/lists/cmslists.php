<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

$actions = array("status","edit");

$actions[] = array('display' => '<a href="javascript:exportList(\'primaryField\')">
					<img src="'.Config::_getUrl('img').'/export-icon.png" width="16" height="16" alt="Export List" title="Export List" />
				</a>', 'permissions' => 'create' );

$actions[]= "delete";


$displayFields  = array( 
 array( "id" => "idList",			"title" => 'List Id'      ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'l', "display" => ':data'),
 array( "id" => "nameList",			"title" => 'List Name'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'l', "display" => ':data'), 
 array( "id" => "linkList",			"title" => 'List Link'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'l', "display" => ':data'), 
 array( "id" => "statusList",		"title" => 'List Status'  ,"type" => 'select' ,"dbField" => true ,"tpx" => 'l', "display" => ':data',"set" => "status", "show" => false),
 array( "id" => "dateAdditionList",	"title" => 'Created On'   ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'l', "display" => ':data', "show" => false),
 array( "id" => "dateUpdationList",	"title" => 'Update On'    ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'l', "display" =>':data'), 
 array( "id" => "actions",			"title" => 'Actions'      ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    )
);

$listData = array( 
    "sql"           => "select * from ".Config::_getTable('lists')." l ", 
    "where"         => "",
    "arrayBind"     => "",
    "sortby"        => "nameList", 
    "order"         => "asc", 
    "headding"      => Config::_getMessage('lists.cms.lists.title'), 
    "primaryField"  => "idList", 
    "statusField"   => "statusList", 
    //  Fields from here are same for all (in general)
    "multiActions"  => true, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

