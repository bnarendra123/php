<?php                           

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

$actions = array("status","edit","delete");

$displayFields [] = array( "id" => "idWidgetQC",		"title" => 'Widget Id'      ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'l', "display" => ':data');
$displayFields [] = array( "id" => "nameWidgetQC",		"title" => 'Widget Name'    ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'l', "display" => ':data'); 
$displayFields [] = array( "id" => "pathWidgetQC",		"title" => 'List Link'      ,"type" => 'text'   ,"dbField" => true ,"tpx" => 'l', "display" => ':data');
$displayFields [] = array( "id" => "statusWidgetQC",	"title" => 'List Status'    ,"type" => 'select' ,"dbField" => true ,"tpx" => 'l', "display" => ':data',"set" => "status", "show" => false);
$displayFields [] = array( "id" => "systemWidgetQC",    "title" => 'List Status'    ,"type" => 'select' ,"dbField" => true ,"tpx" => 'l', "display" => ':data',"set" => "status", "show" => false);
$displayFields [] = array( "id" => "dateAdditionList",	"title" => 'Created On'     ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'l', "display" => ':data', "show" => false);
$displayFields [] = array( "id" => "dateUpdationList",	"title" => 'Update On'      ,"type" => 'date'   ,"dbField" => true ,"tpx" => 'l', "display" =>':data');
$displayFields [] = array( "id" => "actions",			"title" => 'Actions'        ,"type" => 'actions',"dbField" => false,"tpx" => '' , "display" => '',"set" => $actions    );


$listData = array( 
    "sql"           => "select * from ".Config::_getTable('cms_widgets')." w ", 
    "where"         => "",
    "arrayBind"     => "",
    "sortby"        => "nameList", 
    "order"         => "asc", 
    "headding"      => Config::_getMessage('lists.cms.lists.title'), 
    "primaryField"  => "idList", 
    "statusField"   => "statusList", 
    //  Fields from here are same for all (in general)
    "multiActions"  => true, 
    "multiLanguages"=> false, 
    "displayFields" => $displayFields,                                                                                                                                                                                      
    "page"          => 1, 
    "perpage"       => 10, 
    "displaypages"  => 10, 
    "filename"      => $Base->_getFileName(__FILE__)
);

