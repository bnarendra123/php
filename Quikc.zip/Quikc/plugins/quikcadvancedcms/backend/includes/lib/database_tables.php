<?php
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

Config::_setTable('lists'                   , 'cms_lists' );
Config::_setTable('lists_tables'            , 'cms_lists_tables' );
Config::_setTable('lists_fields'            , 'cms_lists_fields' );

Config::_setTable('forms'                   , 'cms_forms' );
Config::_setTable('forms_tables'            , 'cms_forms_tables' );
Config::_setTable('forms_fields'            , 'cms_forms_fields' );

