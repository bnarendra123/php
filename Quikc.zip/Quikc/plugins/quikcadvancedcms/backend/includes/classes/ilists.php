<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* Import Lists class 
* This class will generate the import fields for lists
*
* @version 1.0
* @http://www.quikc.org/
*/

class iLists{

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /**
    * Contains the object of the current variable
    *
    * @var array
    */
    private $listSets;

    /**
    * Contains the details of the column generated
    *
    * @var array
    */
    private $generatedColumns;

    /** Checks the object instance status and creates if there is not instance
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }

    /**
    * generates the list ( search, position, sort )
    *
    * @param  $listElements
    * @return string
    */
    public function _generateImportFields($nameTable){

		if(!Core::_checkTable($nameTable)){
			die('Invalid Table');
		}

		/* Generating sets, converting them as array in required format and storing them for further usage*/		
		global $Cms;
		
		$listSets = $Cms->_getListSets();
		
		foreach($listSets as $set){
			$arraySets[$set->linkSet] = $set->linkSet;
		}
		
		$this->listSets = $arraySets;
		/* Generating sets array completed */		

				
		$listColumns = Core::_getTableColumns($nameTable);
		
		$this->generatedColumns['fields'] = array();
		$i = 1;
		foreach($listColumns as $column){
		
			if ( $this->_validateField($column) ) {
				 
				$tmpColumn = array();
				
				$tmpColumn['key']	=  $column->Field;
				$tmpColumn['title'] =  $this->_generateTitle($column);
				$tmpColumn['order'] =  $i*5;
				$tmpColumn['display']  =  ':data';
				$tmpColumn['show']  =  1;
				$tmpColumn = array_merge($tmpColumn,$this->_generateType($column));
			
				$this->generatedColumns['fields'][] = $tmpColumn;
			
				if( strtolower($column->Key) == 'pri'){
					$this->generatedColumns['primary'] = $column->Field;
				}
			
				$i++;
			}
		}
		
		return $this->generatedColumns;
    }
    
    /**
    * Validate the field for importing into Lisis
    *
    * @param  $nameColumn(Object)
    * @return boolean
    */
    private function _validateField($nameColumn){
    	
		$typesNotAllowed = Config::_get('quikc.advanced.lists.import.not.valid.fields');
		
		if( strlen($typesNotAllowed) > 0 && in_array($nameColumn->Type,explode(",",$typesNotAllowed)) ){
			return false;
		}
	
		return true;
    }
	
	/**
    * generates title for the database column
    *
    * @param  $nameColumn(Object)
    * @return string
    */
    private function _generateTitle($nameColumn){

		$fieldKey = $nameColumn->Field;
	
		// Adding space before Capital letters
		$title = preg_replace('/(?<!\ )[A-Z]/', ' $0', $fieldKey);	
	
		// Converting - and _ to spaces
		$title = preg_replace('/(?<!\ )[-_]/', ' ', $title);	
		
		// Finally Converting the string into 'Field Title' format
		$title = ucwords(strtolower($title));
		
		return $title;
    }
    
    /**
    * generates type for the database column
    *
    * @param  $nameColumn(Object)
    * @return string
    */
    private function _generateType($nameColumn){

		$fieldType = $nameColumn->Type;
		
		$generatedType = array('type' => 'text', 'set' => '');
		
		if( $this->_checkType('date',$nameColumn) ){
			$generatedType['type'] = 'date';
			
		}else if( $this->_checkType('image',$nameColumn) ){
	
			$generatedType['type'] = 'image';
			
		}else if( isset($this->listSets[$nameColumn->Field]) ){
			
			$generatedType['type'] = 'select';
			$generatedType['set']  = $this->listSets[$nameColumn->Field];
			
		}else if( $this->_checkType('status',$nameColumn) ){
			
			$generatedType['type'] = 'select';
			$generatedType['set']  = 'status';
	
			$this->generatedColumns['status'] = $nameColumn->Field;		
			
		}else if( $this->_checkType('select',$nameColumn) ){
	
			$generatedType['type'] = 'select';
			$generatedType['set']  = Config::_get("quikc.advanced.lists.import.select.default");
			
		}
		
		return $generatedType;
    }
    
    /**
    * Check weather the given field belongs to the type or not
    *
    * @param  $type(string),$field(object)
    * @return boolean
    */
	function _checkType($type, $field) {

		if( in_array($field->Type,explode(",",Config::_get("quikc.advanced.lists.import.$type.types"))) ) return true;
		
		if( $this->_checkString(explode(",",Config::_get("quikc.advanced.lists.import.$type.lables")),$field->Field) ) return true;
		
		return false;
	}  	

    /**
    * Searches for the 
    *
    * @param  $array(array of strings),$string(string)
    * @return boolean
    */
	function _checkString($array, $string) {

		if(is_array($array)){
		    foreach ($array as $ele) {
		        if (stripos($string, $ele) !== false) return true;
		    }
		}else{
			if (stripos($string, $array) !== false) return true;;
		}
		
		return false;
	}  	
}

