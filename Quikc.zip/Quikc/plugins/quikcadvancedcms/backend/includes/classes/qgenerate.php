<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* Class used to Generate lists, forms, class from Quick Generate Page  
*
* @version 1.0
* @http://www.quikc.org/
*/

class qGenerate{

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /**
    * Contains the object of the current variable
    *
    * @var array
    */
    private $as;

    /**
    * Contains the details of the column generated
    *
    * @var array
    */
    private $generatedColumns;

    /** Checks the object instance status and creates if there is not instance
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }

    /**
    * generates the list ( search, position, sort )
    *
    * @param  $listElements
    * @return string
    */
    public function _generate($fields=false){

		if(!$fields){
			die();
		}
		
		$this->fields = $fields;
		
		$this->main_tables = $this->fields['main_tables'];
		$this->primaryField	= Core::_getTablePrimary($this->main_tables);
		$this->fieldsMainTable= Core::_getTableColumns($this->main_tables);
		
		/* preparing the general fields */

		global $Base;
				
		if($this->fields['name'] == ''){
			
			$this->fields['name'] = ucwords($this->fields['main_tables']);
			$this->fields['link'] = $Base->_prepareLink($this->fields['name']).''.$Base->_generateRandomString(5);
		}else{
			$this->fields['link'] = $Base->_prepareLink($this->fields['name']);
		}
		
		$errors = array();
		
		if( $this->fields['list'] == 1 ){
			
			$dynamicLists = new dynamicLists;
			
            if( $dynamicLists->_checkListsLink($this->fields['link']) ){
				$errors[] = Config::_prepareMessage('forms.validation.lists.link.exists',array(":LINK_LIST" => $this->fields['link']));           
            }			
		}

		if( $this->fields['form'] == 1 ){

			$dynamicForms = new DynamicForms;
			
            if( $dynamicForms->_checkFormsLink($this->fields['link']) ){
				$errors[] = Config::_prepareMessage('forms.cms.forms.validate.form.link.exists',array(":FORM_LINK" => $this->fields['link']));            
            }			
		}
		
		if( count($errors) != 0 ){      
            $Base->_convertError($errors,false);
        }

		/* generating the join statement */
		$this->_generateJoin();

		
		if( $this->fields['menu'] == 1  ){
			$idMenu = $this->_generateMenu();	
		    Cache::_getInstance()->_removeCache('admin_menus_list');
			echo 'Menu Created<br/>';
		}
		
		if( $this->fields['list'] == 1 ){
			$idList = $this->_generateList();		
			echo 'List Generated<br/>';
		}
		
		if( $this->fields['form'] == 1 ){
			$idList = $this->_generateForm();		
			echo 'Form Generated';
		}

		return ;
    }

    /**
    * Generates join statements
    *
    * @param  void
    * @return boolean
    */
    private function _generateJoin(){

		// generating the join statements for the tables
		// We use left join in default for all the tables
		// Below code will generate the left join on condition like a.id = b.id

		$this->sub_tables = explode(',',trim($this->fields['sub_tables']));
		
		if( trim($this->fields['sub_tables']) == '' || !is_array($this->sub_tables) || count($this->sub_tables) == 0 ){
			$this->sub_tables = array();
			$this->conditionsJoin = false;
			return false;
		}
				
		$conditionsJoin = array();
		
		foreach($this->sub_tables as $table){
		
			// Checking if the primary field of the main table exists in the sub table
			if(Core::_checkColumn($table,$this->primaryField)){
				
				$detailsColumn = Core::_getTableColumns($table,$this->primaryField);
				
				// Checking weather the key matched is auto increment or not
				if( strripos($detailsColumn->Extra, "auto_increment") === false ){
					$conditionsJoin[$table] = $this->_generateJoinQuery(array($this->main_tables,$this->primaryField),array($table,$this->primaryField));				
				}
			}
			
			// If Join query is not designed at the top
			if( !isset($conditionsJoin[$table]) || $conditionsJoin[$table] == '' ){
				
				// Checking if the primary field of the sub table exists in the main table
				$primaryFieldSubTable = Core::_getTablePrimary($table);
				
				if(Core::_checkColumn($this->main_tables,$primaryFieldSubTable)){
					
					$detailsColumn = Core::_getTableColumns($this->main_tables,$primaryFieldSubTable);
					
					// Checking weather the key matched is auto increment or not
					if( strripos($detailsColumn->Extra, "auto_increment") === false ){
						$conditionsJoin[$table] = $this->_generateJoinQuery(array($this->main_tables,$primaryFieldSubTable),array($table,$primaryFieldSubTable));
					}
				}				
			}
			
			// If Join query is not designed at the top
			if( !isset($conditionsJoin[$table]) || $conditionsJoin[$table] == '' ){
				
				foreach($this->fieldsMainTable as $field){
		
					if(Core::_checkColumn($table,$field->Field)){
						
						$detailsColumn = Core::_getTableColumns($table,$field->Field);
						
						// Checking weather the key matched is auto increment or not
						if( strripos($detailsColumn->Extra, "auto_increment") === false ){
							$conditionsJoin[$table] = $this->_generateJoinQuery(array($this->main_tables,$field->Field),array($table,$field->Field));
							break;
						}
					}		
				}	
			}
		}	

		$this->conditionsJoin = $conditionsJoin;
    }

    /**
    * Prepares the join statement with the given fields
    *
    * @param  $set1(array[table,field]),$set2(array[table,field])
    * @return string
    */
    public function _generateJoinQuery($set1,$set2){

		return "`$set1[0]`.`$set1[1]` = `$set2[0]`.`$set2[1]`";	
    }
	
	/**
	 * Generates new menu
	 *
	 * @param void
	 * @return int
	 */
	public function _generateMenu() {

		global $Plugins;

		$identifierPlugin = $Plugins -> _getWorkingPluginDetails() -> identifierPlugin;

		$errors = array();

		$validateFields = array('titleMenu', 'linkMenu');
		$nullValues = array('parentMenu', 'imageMenu', 'statusMenu', 'orderMenu', 'dashboardMenu', 'topMenu');

		$query = "insert into " . Config::_getTable('admin_menus') . " (titleMenu,linkMenu,createdById,createdByType,parentMenu,imageMenu,statusMenu,orderMenu,dashboardMenu,topMenu,dateAdditionAdminMenu)
         values (:titleMenu,:linkMenu,:createdById,:createdByType,:parentMenu,:imageMenu,:statusMenu,:orderMenu,:dashboardMenu,:topMenu,NOW())";
		$arrayBind[] = array("key" => ":titleMenu", "value" => $this->fields['name']);
		$arrayBind[] = array("key" => ":linkMenu", "value" => $this->fields['link']);
		$arrayBind[] = array("key" => ":createdById", "value" => $identifierPlugin);
		$arrayBind[] = array("key" => ":createdByType", "value" => 'plugin');
		$arrayBind[] = array("key" => ":parentMenu", "value" => 0);
		$arrayBind[] = array("key" => ":imageMenu", "value" => 'no-image.png');
		$arrayBind[] = array("key" => ":statusMenu", "value" => 1);
		$arrayBind[] = array("key" => ":orderMenu", "value" => 15);
		$arrayBind[] = array("key" => ":dashboardMenu", "value" => 1);
		$arrayBind[] = array("key" => ":topMenu", "value" => 1);

		Core::_runQuery($query, $arrayBind);
		
		return Core::_getLastInsertId();
	}
    
	/**
	 * Generates new list
	 *
	 * @param void
	 * @return int
	 */
	public function _generateList() {
		
        $fieldsListTable = array(
        						 'nameList' => $this->fields['name'],
        						 'linkList' => $this->fields['link'],
        						 'whereList'=> '',
        						 'sortByFieldList'=> '',
        						 'sortOrderFieldList'=>'',
        						 'primaryFieldList'=> ($this->primaryField != '')?($this->main_tables.".".$this->primaryField):'',
        						 'statusFieldList'=>'',
        						 'multiLanguageFieldList'=>'',
        						 'pagePaginationList'=>'',
        						 'rowsPaginationList'=>'',
        						 'pagesPaginationList'=>'',
        						 'actionsList'=>'status-edit-delete',
        						 'editActionLink'=>'',
							 );
							 
        $insertKeys  = array();
        $insertValues= array();
        
        foreach($fieldsListTable as $key => $field){
            $insertKeys[]  = "`$key`";
            $insertValues[]= ":$key";
            $arrayBind[]= array("key" => ":$key", "value" => $field);
        }
        $query = "insert into ".Config::_getTable('lists')." (".implode(",",$insertKeys).",dateAdditionList) values (".implode(",",$insertValues).",NOW())";
        Core::_runQuery($query, $arrayBind);
        $idList = Core::_getLastInsertId();

		global $User;
        $User->_addUserLogActivity($User -> idUser() ,18);

        $tables = array_merge(array($this->main_tables),$this->sub_tables);
		
		foreach($tables as $table){

            unset($arrayBind);

            $arrayBind[]= array("key" => ":idList",             "value" => $idList);
            $arrayBind[]= array("key" => ":tableList",          "value" => $table);
            $arrayBind[]= array("key" => ":identifierTableList","value" => $table);
			
			$joinQuery = (isset($this->conditionsJoin[$table]))?$this->conditionsJoin[$table]:'';
			$joinType  = 'left join';
				
			if($table == $this->main_tables){
				$joinType = $joinQuery = '';
			}
			
            $arrayBind[]= array("key" => ":joinTypeTable",      "value" => $joinType);
            $arrayBind[]= array("key" => ":joinOnTable",        "value" => $joinQuery);
                        
            $query = "insert into ".Config::_getTable('lists_tables')." (`idList`,`tableList`,`identifierTableList`,`joinTypeTable`,`joinOnTable`) 
            values (:idList,:tableList,:identifierTableList,:joinTypeTable,:joinOnTable)";
            Core::_runQuery($query, $arrayBind);

			$fieldsList = iLists::_getInstance()->_generateImportFields($table);
			
			// Generating status field if the table is the main table
			if($table == $this->main_tables && isset($fieldsList['status']) && $fieldsList['status'] != ''){
				$statusFieldList = $fieldsList['status'];
			}
			
	        foreach($fieldsList['fields'] as $field){

	            unset($arrayBind);
	            $arrayBind[]= array("key" => ":idList",         "value" => $idList);
	            $arrayBind[]= array("key" => ":fieldList",      "value" => $table.".".$field['key']);
	            $arrayBind[]= array("key" => ":titleFieldList", "value" => $field['title']);
	            $arrayBind[]= array("key" => ":orderFieldList", "value" => $field['order']);
	            $arrayBind[]= array("key" => ":typesFieldList", "value" => $field['type']);
	            $arrayBind[]= array("key" => ":setsFieldList",  "value" => $field['set']);
	            
	            $query = "insert into ".Config::_getTable('lists_fields')." (`idList`,`fieldList`,`titleFieldList`,`orderFieldList`,`typesFieldList`,`setsFieldList`) 
	            values (:idList,:fieldList,:titleFieldList,:orderFieldList,:typesFieldList,:setsFieldList)";
	            Core::_runQuery($query, $arrayBind);
	        }
			
        }

		if( isset($statusFieldList) && $statusFieldList != ''){
			unset($arrayBind);
			$query = "update ".Config::_getTable('lists')." set statusFieldList = :statusFieldList where idList = :idList ";
	        $arrayBind[]= array("key" => ":statusFieldList","value" => $this->main_tables.".".$statusFieldList);
	        $arrayBind[]= array("key" => ":idList",			"value" => $idList);
	        Core::_runQuery($query, $arrayBind);
		}
		
	}

	/**
	 * Generates new form
	 *
	 * @param void
	 * @return int
	 */
	public function _generateForm() {
		
        $fieldsListTable = array(
        						 'nameForm' => $this->fields['name'],
        						 'linkForm' => $this->fields['link'],
        						 'whereForm'=> '',
        						 'primaryFieldForm'=> $this->main_tables.".".$this->primaryField,
        						 'onCloseForm'=>"javascript:LoadList('get/list/:THIS_LINK',':DATA_FILTER')",
        						 'onSuccessForm'=>"javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
							 );

        $insertKeys  = array();
        $insertValues= array();
        
        foreach($fieldsListTable as $key => $field){
            $insertKeys[]  = "`$key`";
            $insertValues[]= ":$key";
            $arrayBind[]= array("key" => ":$key", "value" => $field);
        }
        $query = "insert into ".Config::_getTable('forms')." (".implode(",",$insertKeys).",dateAdditionForm) values (".implode(",",$insertValues).",NOW())";
        Core::_runQuery($query, $arrayBind);
        $idForm = Core::_getLastInsertId();

		global $User;
        $User->_addUserLogActivity($User -> idUser(),18);

        $tables = array_merge(array($this->main_tables),$this->sub_tables);
		
		foreach($tables as $table){

            unset($arrayBind);

            $arrayBind[]= array("key" => ":idForm",             "value" => $idForm);
            $arrayBind[]= array("key" => ":tableForm",          "value" => $table);
            $arrayBind[]= array("key" => ":identifierTableForm","value" => $table);
			
			$joinQuery = (isset($this->conditionsJoin[$table]))?$this->conditionsJoin[$table]:'';
			$joinType  = 'left join';
				
			if($table == $this->main_tables){
				$joinType = $joinQuery = '';
			}
			
            $arrayBind[]= array("key" => ":joinTypeTable",      "value" => $joinType);
            $arrayBind[]= array("key" => ":joinOnTable",        "value" => $joinQuery);
            $arrayBind[]= array("key" => ":multiLanguageField", "value" => '');
                                    
            $query = "insert into ".Config::_getTable('forms_tables')." (`idForm`,`tableForm`,`identifierTableForm`,`joinTypeTable`,`joinOnTable`,`multiLanguageField`) 
            values (:idForm,:tableForm,:identifierTableForm,:joinTypeTable,:joinOnTable,:multiLanguageField)";
            Core::_runQuery($query, $arrayBind);

			$fieldsList = iForms::_getInstance()->_generateImportFields($table);
			
	        foreach($fieldsList['fields'] as $field){
	        	
	            unset($arrayBind);
	            $arrayBind[]= array("key" => ":idForm",                 "value" => $idForm);
	            $arrayBind[]= array("key" => ":fieldForm",              "value" => $table.".".$field['key']);
	            $arrayBind[]= array("key" => ":titleFieldForm",         "value" => $field['title']);
	            $arrayBind[]= array("key" => ":orderFieldForm",         "value" => $field['order']);
	            $arrayBind[]= array("key" => ":typesFieldForm",         "value" => $field['type']);
	            $arrayBind[]= array("key" => ":setsFieldForm",          "value" => $field['set']);
	            $arrayBind[]= array("key" => ":defaultvalueFieldForm",  "value" => $field['default']);
	            $arrayBind[]= array("key" => ":additionalcssFieldForm", "value" => '');
	            $arrayBind[]= array("key" => ":requiredFieldForm",      "value" => $field['required']);
	            $arrayBind[]= array("key" => ":databasefieldFieldForm", "value" => 1);
	            $arrayBind[]= array("key" => ":uniqueFieldForm",        "value" => $field['unique']);
	                        
	            $query = "insert into ".Config::_getTable('forms_fields')." (`idForm`,`fieldForm`,`titleFieldForm`,`orderFieldForm`,`typesFieldForm`,`setsFieldForm`,`defaultvalueFieldForm`,`additionalcssFieldForm`,`requiredFieldForm`,`databasefieldFieldForm`,`uniqueFieldForm`) 
	            values (:idForm,:fieldForm,:titleFieldForm,:orderFieldForm,:typesFieldForm,:setsFieldForm,:defaultvalueFieldForm,:additionalcssFieldForm,:requiredFieldForm,:databasefieldFieldForm,:uniqueFieldForm)";
	            Core::_runQuery($query, $arrayBind);
		
	        }
        }

        // Generating button field
	    unset($arrayBind);
	    $arrayBind[]= array("key" => ":idForm",                 "value" => $idForm);
	    $arrayBind[]= array("key" => ":fieldForm",              "value" => '');
	    $arrayBind[]= array("key" => ":titleFieldForm",         "value" => '');
	    $arrayBind[]= array("key" => ":orderFieldForm",         "value" => 1000);
	    $arrayBind[]= array("key" => ":typesFieldForm",         "value" => 'button');
	    $arrayBind[]= array("key" => ":setsFieldForm",          "value" => '');
	    $arrayBind[]= array("key" => ":defaultvalueFieldForm",  "value" => 'Proceed');
	    $arrayBind[]= array("key" => ":additionalcssFieldForm", "value" => '');
	    $arrayBind[]= array("key" => ":requiredFieldForm",      "value" => 0);
	    $arrayBind[]= array("key" => ":databasefieldFieldForm", "value" => 0);
	    $arrayBind[]= array("key" => ":uniqueFieldForm",        "value" => 0);
	                
	    $query = "insert into ".Config::_getTable('forms_fields')." (`idForm`,`fieldForm`,`titleFieldForm`,`orderFieldForm`,`typesFieldForm`,`setsFieldForm`,`defaultvalueFieldForm`,`additionalcssFieldForm`,`requiredFieldForm`,`databasefieldFieldForm`,`uniqueFieldForm`) 
	    values (:idForm,:fieldForm,:titleFieldForm,:orderFieldForm,:typesFieldForm,:setsFieldForm,:defaultvalueFieldForm,:additionalcssFieldForm,:requiredFieldForm,:databasefieldFieldForm,:uniqueFieldForm)";
	    Core::_runQuery($query, $arrayBind);
        
	}

}

