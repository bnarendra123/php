<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* export Lists class 
* This class generate list files for the dynamic lists
*
* @version 1.0
* @http://www.quikc.org/
*/

class eLists extends DynamicLists{

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private $detailsList;

    /** Checks the object instance status and creates if there is not instance
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }

    /**
    * returns details of the currently active list 
    *
    * @param  void
    * @return object
    */
    public function _listDetails(){
		return $this->detailsList;
    }

    /**
    * generates list files 
    *
    * @param  idList (integer)
    * @return boolean
    */
    public function _generate($idList){

		if( !parent::_checkListExists($idList) ){
			echo "List doesn't Exist.";
			return false;			
		}
		//
		
		$databaseList = parent::_getListDetails($idList);
		$detailsList = parent::_generateListElements($databaseList);
		$detailsList['databaseList'] = $databaseList;
		$this->detailsList = $detailsList;

		$basciFileExporting = true;
		
		if( $this->_generateModuleListFile() ){
			echo "Module List File Exported Successfully.\n";
		}else{
			$basciFileExporting = false;
			echo "Module List File Exporting Failed.\n";
		}
		
		if( $this->_generateAjaxListFile() ){
			echo "Ajax get File Exported Successfully.\n";
		}else{
			$basciFileExporting = false;
			echo "Ajax get File Exporting Failed.\n";
		}

		$this->_generateAjaxSetFile();

		if( $basciFileExporting ){

	        $query  = " update ".Config::_getTable('lists')." set statusList = :statusList where idList = :idList";
	        $arrayBind[]= array("key" => ":statusList", "value" => 0);
	        $arrayBind[]= array("key" => ":idList", "value" => $idList);
	        Core::_runQuery($query,$arrayBind);
			
		}
		
		return true;
    }
    
    /**
    * Generates list module file (path:/administrator/includes/custom/modules/lists/)
    *
    * @param  void
    * @return boolean
    */
    private function _generateModuleListFile(){
    	
		$listDetails = $this->_listDetails();
		
		ob_start();
		require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/lists/template.php';
		$pageModulesList = ob_get_clean(); 
		
		$pathModuleList = Config::_getDir('admin').'/includes/custom/modules/lists/'.$listDetails['filename'].'.php';
		
		file_put_contents($pathModuleList, $pageModulesList);
	
		return true;
    }
	
    /**
    * Generates list ajax file (path:/administrator/includes/custom/modules/ajax/get/list/)
    *
    * @param  void
    * @return boolean
    */
    private function _generateAjaxListFile(){
    	
		$listDetails = $this->_listDetails();
		
		ob_start();
		require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/ajax/get/list/template.php';
		$pageAjaxList = ob_get_clean(); 
		
		$pathAjaxList = Config::_getDir('admin').'/includes/custom/modules/ajax/get/list/'.$listDetails['filename'].'.php';
		
		file_put_contents($pathAjaxList, $pageAjaxList);
	
		return true;
    }
	
	/**
    * Generates set file (path:/administrator/includes/custom/modules/ajax/set/)
    *
    * @param  void
    * @return boolean
    */
    private function _generateAjaxSetFile(){
    	
		$listDetails = $this->_listDetails();
		
		$pathAjaxList = Config::_getDir('admin').'/includes/custom/modules/ajax/set/'.$listDetails['filename'].'.php';
		
		// Checking weather the file already exists or not
		// If the file doesn't exist, then creating new file
		if( !file_exists($pathAjaxList) ){

			ob_start();
			require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/ajax/set/template.php';
			$pageAjaxList = ob_get_clean(); 

			file_put_contents($pathAjaxList, $pageAjaxList);
		}

		if( $this->_updateAjaxStatusCode() ){
			echo "Ajax Set File Status Code Exported Successfully.\n";
		}else{
			echo "Ajax Set File Status Code Exporting Failed.\n";
		}

		if( $this->_updateAjaxDeleteCode() ){
			echo "Ajax Set File Delete Code Exported Successfully.\n";
		}else{
			echo "Ajax Set File Delete Code Exporting Failed.\n";
		}

		return true;
    }

	/**
    * generates php code for status action
    *
    * @param  void
    * @return boolean
    */
    private function _updateAjaxStatusCode(){

		$listDetails = $this->_listDetails();
		$databaseList = $listDetails['databaseList'];
		
		// Checking weather status and primary fields exists or not
		if( $listDetails['statusField'] == '' || $listDetails['primaryField'] == '' ) return false;

		$pathAjaxList = Config::_getDir('admin').'/includes/custom/modules/ajax/set/'.$listDetails['filename'].'.php';

		$pageAjaxList = file_get_contents($pathAjaxList);
		
		$pointerStart = "// List status action starts here";
		$pointerEnd	= "// List status action ends here";
		// Now checking weather we can edit the file or not
		// If the file contains two strting "// Form status action starts here" and "// Form status action ends here" then we can edit it
		// Otherwise we can't edit the file

		// 1. Checking if the edit action start pointer exists or not
		// 2. Checking if the edit action end pointer exists or not
		if( strpos($pageAjaxList,$pointerStart) !== false && strpos($pageAjaxList,$pointerEnd) !== false ) {
			
			// Since both the pointers exists, now we have to generate the new code  
	        foreach($databaseList->tables as $tmpTable){
	            $tablesList[$tmpTable->identifierTableList] = $tmpTable->tableList;
	        }       

	        // Generating the primary field
	        $fieldPrimary = Core::_getField($databaseList->primaryFieldList);

            // Generating the status field table prefix
            $prefixStatus = Core::_getFieldPrefix($databaseList->statusFieldList);
            // Generating the status field
            $fieldStatus  = Core::_getField($databaseList->statusFieldList);
            // Generating Status Table
            $table = $tablesList[$prefixStatus];

			// Only One table hence including single table template
			ob_start();
			require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/ajax/set/template_status.php';
			$statusActionContent = ob_get_clean(); 
			
			$startingContent = explode($pointerStart,$pageAjaxList);
			$endingContent = explode($pointerEnd,$pageAjaxList);

			$newPageAjaxList = $startingContent[0] . $pointerStart . "\n" . $statusActionContent . $pointerEnd . $endingContent[1];

			file_put_contents($pathAjaxList, $newPageAjaxList);
			
		}else{
			return false;
		}

		return true;
    }
	
	/**
    * generates php code for delete action
    *
    * @param  void
    * @return boolean
    */
    private function _updateAjaxDeleteCode(){

		$listDetails = $this->_listDetails();
		$databaseList = $listDetails['databaseList'];
		
		// Checking weather primary field exists or not
		if( $listDetails['primaryField'] == '' ) return false;

		$pathAjaxList = Config::_getDir('admin').'/includes/custom/modules/ajax/set/'.$listDetails['filename'].'.php';

		$pageAjaxList = file_get_contents($pathAjaxList);
		
		$pointerStart = "// List delete action starts here";
		$pointerEnd	= "// List delete action ends here";
		// Now checking weather we can edit the file or not
		// If the file contains two strting "// Form status action starts here" and "// Form status action ends here" then we can edit it
		// Otherwise we can't edit the file

		// 1. Checking if the edit action start pointer exists or not
		// 2. Checking if the edit action end pointer exists or not
		if( strpos($pageAjaxList,$pointerStart) !== false && strpos($pageAjaxList,$pointerEnd) !== false ) {
			
			// Since both the pointers exists, now we have to generate the new code  
	        foreach($databaseList->tables as $tmpTable){
	            $tablesList[$tmpTable->identifierTableList] = $tmpTable->tableList;
	        }       

	        // Generating the primary field
	        $fieldPrimary = Core::_getField($databaseList->primaryFieldList);

			// Only One table hence including single table template
			ob_start();
			require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/ajax/set/template_delete.php';
			$deleteActionContent = ob_get_clean(); 
			
			$startingContent = explode($pointerStart,$pageAjaxList);
			$endingContent = explode($pointerEnd,$pageAjaxList);

			$newPageAjaxList = $startingContent[0] . $pointerStart . "\n" . $deleteActionContent . $pointerEnd . $endingContent[1];

			file_put_contents($pathAjaxList, $newPageAjaxList);
			
		}else{
			return false;
		}

		return true;
    }
	
	/**
    * generates php code for the given field
    *
    * @param  $detailsField(array)
    * @return string
    */
    private function _generateField($detailsField){

		$booleansArray = array('dbField' => false, 'show' => true);		

		$displayArray = array();
		
		foreach($detailsField as $key => $value){

			if( isset($booleansArray[$key]) ) $value = $this->_generateBoolean($value,$booleansArray[$key]);
			
			else $value = $this->_prepareValue($value); 

			$displayArray[] = '"'.$key.'" => '.$value.'';
		}
		$displayFields = '
$displayFields[] = array( '.implode("		,",$displayArray).');';
		
		return $displayFields;
    }
    
    /**
    * checks and converts given value
    *
    * @param  $value(string/array)
    * @return string/array($value)
    */
    private function _prepareValue($valueGiven){

		if( !is_array($valueGiven) ) return '"'.str_replace('"', '\"',$valueGiven).'"';
	
		$valueConverted = 'array(';
		
		foreach($valueGiven as $key => $value){
			$valueConverted .= '"'.$key.'" => '.$this->_prepareValue($value).',';
		}
		
		$valueConverted .= ")";

		return $valueConverted;
    }
    
    /**
    * checks and converts given value into true or false
    *
    * @param  $value, $defaultvalue
    * @return booealn(true/false)
    */
    private function _generateBoolean($valueGiven,$valueDefault = 'true'){

		$valueConverted = $valueDefault;

		if( $valueGiven == 1 ||  $valueGiven == "1" ) $valueConverted = 'true';

		if( $valueGiven == 0 ||  $valueGiven == "0" ) $valueConverted = 'false';

		return $valueConverted;
    }
    
}

