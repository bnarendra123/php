<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* export Lists class 
* This class generate list files for the dynamic lists
*
* @version 1.0
* @http://www.quikc.org/
*/

class eForms extends DynamicForms{

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private $detailsForms;

    /** Checks the object instance status and creates if there is not instance
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }

    /**
    * returns details of the currently active list 
    *
    * @param  void
    * @return object
    */
    public function _formDetails(){
		return $this->detailsForm;
    }

    /**
    * generates list files 
    *
    * @param  idList (integer)
    * @return boolean
    */
    public function _generate($idForm){

		if( !parent::_checkFormExists($idForm) ){
			echo "Form doesn't Exist.";
			return false;			
		} 
		
		$this->detailsForm = parent::_generateFormElements(parent::_getFormDetails($idForm)->linkForm);

		$basciFileExporting = true;
		
		if( $this->_generateModuleFormFile() ){
			echo "Module Form File Exported Successfully.\n";
		}else{
			$basciFileExporting = false;
			echo "Module Form File Exporting Failed.\n";
		}

		if( $this->_generateAjaxFormFile() ) {
			echo "Ajax get File Exported Successfully.\n";
		}else{
			$basciFileExporting = false;
			echo "Ajax get File Exporting Failed.\n";
		}

		if( $this->_generateAjaxSetFile() ){
			echo "Ajax Set Code Exported Successfully.\n";
		}else{
			echo "Ajax Set Code Exporting Failed.\n";
		}

		if( $basciFileExporting ){

	        $query  = " update ".Config::_getTable('forms')." set statusForm = :statusForm where idForm = :idForm";
	        $arrayBind[]= array("key" => ":statusForm", "value" => 0);
	        $arrayBind[]= array("key" => ":idForm", "value" => $idForm);
	        Core::_runQuery($query,$arrayBind);
			
		}
				
		return true;
    }
    
    /**
    * Generates form module file (path:/administrator/includes/custom/modules/forms/)
    *
    * @param  void
    * @return boolean
    */
    private function _generateModuleFormFile(){
    	
		$formDetails = $this->_formDetails();
		
		ob_start(); 
		require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/forms/template.php';
		$pageModulesList = ob_get_clean(); 
		
		$pathModuleList = Config::_getDir('admin').'/includes/custom/modules/forms/'.$formDetails['filename'].'.php';
		
		file_put_contents($pathModuleList, $pageModulesList);
	
		return true;
    }

    /**
    * Generates listform ajax file (path:/administrator/includes/custom/modules/ajax/get/edit/)
    *
    * @param  void
    * @return boolean
    */
    private function _generateAjaxFormFile(){
    	
		$formDetails = $this->_formDetails();
		
		$_POST['formPrimaryField'] = '$formPrimaryField' ;
		
		$detailsForm = parent::_generateFormDetails($formDetails['filename']);
		 
		ob_start();
		require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/ajax/get/edit/template.php';
		$pageAjaxList = ob_get_clean();
		
		$pathAjaxList = Config::_getDir('admin').'/includes/custom/modules/ajax/get/edit/'.$formDetails['filename'].'.php';
		
		file_put_contents($pathAjaxList, $pageAjaxList);
	
		return true;
    }
	
	/**
    * Generates set file (path:/administrator/includes/custom/modules/ajax/set/)
    *
    * @param  void
    * @return boolean
    */
    private function _generateAjaxSetFile(){
    	
		$formDetails = $this->_formDetails();
		
		$_POST['formPrimaryField'] = '$formPrimaryField' ;
		
        // Getting the form details from link
        $detailsForm = parent::_getFormDetailsByLink($formDetails['filename']);
		 
		//print_r($detailsForm);

		$pathAjaxList = Config::_getDir('admin').'/includes/custom/modules/ajax/set/'.$formDetails['filename'].'.php';
		
		// Checking weather the file already exists or not
		// If the file doesn't exist, then creating new file
		if( !file_exists($pathAjaxList) ){

			ob_start();
			require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/ajax/set/template.php';
			$pageAjaxList = ob_get_clean(); 

			file_put_contents($pathAjaxList, $pageAjaxList);
		}

		$pageAjaxList = file_get_contents($pathAjaxList);
		
		$pointerStart = "// Form edit action starts here";
		$pointerEnd	= "// Form edit action ends here";
		// Now checking weather we can edit the file or not
		// If the file contains two strting "// Form edit action starts here" and "// Form edit action ends here" then we can edit it
		// Otherwise we can't edit the file

		// 1. Checking if the edit action start pointer exists or not
		// 2. Checking if the edit action end pointer exists or not
		if( strpos($pageAjaxList,$pointerStart) !== false && strpos($pageAjaxList,$pointerEnd) !== false ) {
			
			// Since both the pointers exists, now we have to generate the new code  
			foreach($detailsForm->tables as $tmpTable){
			    $fieldsList[$tmpTable->identifierTableForm]['table'] = $tmpTable->tableForm;
			}

	        // Gaterting the list of fields in a table
	        foreach($detailsForm->fields as $field){
	            // Checking for the database fields
	            if($field->databasefieldFieldForm == 1 ){
	                $fieldsList[Core::_getFieldPrefix($field->fieldForm)]['fields'][] = array("id" => Core::_getField($field->fieldForm), "type" => $field->typesFieldForm , "unique" => $field->uniqueFieldForm );
	            }
	        }

			// Checking for the correct file based on the no of tables 			
			if( count($detailsForm->tables) == 1){
				
				// Only One table hence including single table template
				ob_start();
				require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/ajax/set/template_edit_single_table.php';
				$editActionContent = ob_get_clean(); 

			}elseif( count($detailsForm->tables) > 1){
				
				// Multiple tables hence including multiple tables template
				ob_start();
				require_once Config::_getDir('current.plugin').'/backend/includes/modules/export templates/ajax/set/template_edit_multi_tables.php';
				$editActionContent = ob_get_clean(); 
			}
			
			$startingContent = explode($pointerStart,$pageAjaxList);
			$endingContent = explode($pointerEnd,$pageAjaxList);

			$newPageAjaxList = $startingContent[0] . $pointerStart . "\n" . $editActionContent . $pointerEnd . $endingContent[1];

			file_put_contents($pathAjaxList, $newPageAjaxList);
			
		}else{
			return false;
		}
	
		return true;
    }
	
	/**
    * generates php code for the given field
    *
    * @param  $detailsField(array)
    * @return string
    */
    private function _generateField($detailsField){

		$booleansArray = array('req' => false);		

		$displayArray = array();
		
		foreach($detailsField as $key => $value){

			if( isset($booleansArray[$key]) ) $value = $this->_generateBoolean($value,$booleansArray[$key]);
			
			else $value = $this->_prepareValue($value); 

			$displayArray[] = '"'.$key.'" => '.$value.'';
		}
		$displayFields = '
$formFields[] = array( '.implode("		,",$displayArray).');';
		
		return $displayFields;
    }
    
    /**
    * checks and converts given value
    *
    * @param  $value(string/array)
    * @return string/array($value)
    */
    private function _prepareValue($valueGiven){

		if( !is_array($valueGiven) ) return '"'.str_replace('"','\"', $valueGiven).'"';
	
		$valueConverted = 'array(';
		
		foreach($valueGiven as $key => $value){
			$valueConverted .= '"'.$key.'" => '.$this->_prepareValue($value).',';
		}
		
		$valueConverted .= ")";

		return $valueConverted;
    }
    
    /**
    * checks and converts given value into true or false
    *
    * @param  $value, $defaultvalue
    * @return booealn(true/false)
    */
    private function _generateBoolean($valueGiven,$valueDefault = 'true'){

		$valueConverted = $valueDefault;

		if( $valueGiven == 1 ||  $valueGiven == "1" ) $valueConverted = 'true';

		if( $valueGiven == 0 ||  $valueGiven == "0" ) $valueConverted = 'false';

		return $valueConverted;
    }
    
}

