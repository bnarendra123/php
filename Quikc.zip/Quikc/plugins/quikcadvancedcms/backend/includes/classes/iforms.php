<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* Import Forms class 
* This class will generate the import fields for forms
*
* @version 1.0
* @http://www.quikc.org/
*/

class iForms{

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /**
    * Contains the object of the current variable
    *
    * @var array
    */
    private $listSets;

    /**
    * Contains the details of the column generated
    *
    * @var array
    */
    private $generatedColumns;

    /** Checks the object instance status and creates if there is not instance
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }

    /**
    * generates the list ( search, position, sort )
    *
    * @param  $listElements
    * @return string
    */
    public function _generateImportFields($nameTable){

		if(!Core::_checkTable($nameTable)){
			die('Invalid Table');
		}

		/* Generating sets, converting them as array in required format and storing them for further usage*/		
		global $Cms;
		
		$listSets = $Cms->_getListSets();
		
		foreach($listSets as $set){
			$arraySets[$set->linkSet] = $set->linkSet;
		}
		
		$this->listSets = $arraySets;
		/* Generating sets array completed */		

				
		$listColumns = Core::_getTableColumns($nameTable);
		$generatedColumns = '';
		
		$this->generatedColumns['fields'] = array();
		$i = 1;
		foreach($listColumns as $column){
		
			if ( $this->_validateField($column) ) { 
		
				$tmpColumn = array();
				
				$tmpColumn['key']		=  $column->Field;
				$tmpColumn['title'] 	=  $this->_generateTitle($column);
				$tmpColumn['order'] 	=  $i*5;
				$tmpColumn['default']	=  (null !== $column->Default)?$column->Default:'';
				$tmpColumn['unique']	=  (strtolower($column->Key) == 'uni')?1:0;
				$tmpColumn['required']	=  ('no' == strtolower($column->Null))?1:0;
				$tmpColumn = array_merge($tmpColumn,$this->_generateType($column));
		
				$this->generatedColumns['fields'][] = $tmpColumn;
			} 
			
			if( $this->_checkString("pri",$column->Key) ){
				$this->generatedColumns['primary'] = $column->Field;
			}
		
			$i++;
		}
		
		return $this->generatedColumns;
    }

    /**
    * Validate the field for importing into Forms
    *
    * @param  $nameColumn(Object)
    * @return boolean
    */
    private function _validateField($nameColumn){

		if( $this->_checkString("auto_increment",$nameColumn->Extra) ) return false;
	
		if( $this->_checkString("on update CURRENT_TIMESTAMP",$nameColumn->Extra) ) return false;
	
		if( $this->_checkString("pri",$nameColumn->Key) ) return false;

		$typesNotAllowed = Config::_get('quikc.advanced.forms.import.not.valid.fields');
		
		if( strlen($typesNotAllowed) > 0 && in_array($nameColumn->Type,explode(",",$typesNotAllowed)) ){
			return false;
		}
		
		return true;
    }
    
    /**
    * generates title for the database column
    *
    * @param  $nameColumn(Object)
    * @return string
    */
    private function _generateTitle($nameColumn){

		$fieldKey = $nameColumn->Field;
	
		// Adding space before Capital letters
		$title = preg_replace('/(?<!\ )[A-Z]/', ' $0', $fieldKey);	
	
		// Converting - and _ to spaces
		$title = preg_replace('/(?<!\ )[-_]/', ' ', $title);	
		
		// Finally Converting the string into 'Field Title' format
		$title = ucwords(strtolower($title));
		
		return $title;
    }
    
    /**
    * generates type for the database column
    *
    * @param  $nameColumn(Object)
    * @return string
    */
    private function _generateType($nameColumn){

		$fieldType = $nameColumn->Type;
		
		$generatedType = array('type' => 'text', 'set' => '');
		
		if( $this->_checkType('textarea',$nameColumn) ){
			
			$generatedType['type'] = 'textarea';
			
		}else if( $this->_checkType('date',$nameColumn) ){
			
			$generatedType['type'] = 'date';
			
		}else if( $this->_checkType('email',$nameColumn) ){
	
			$generatedType['type'] = 'email';
			
		}else if( $this->_checkType('image',$nameColumn) ){
	
			$generatedType['type'] = 'media';
			$generatedType['set']  = 'img';
			
		}else if( $this->_checkType('video',$nameColumn) ){
	
			$generatedType['type'] = 'media';
			$generatedType['set']  = 'vid';
			
		}else if( isset($arraySets[$nameColumn->Field]) || isset($arraySets[$nameColumn->Field.'s']) || isset($arraySets[$nameColumn->Field.'es']) || isset($arraySets[substr($nameColumn->Field, 0, -1).'ies']) ){
		
			$generatedType['type'] = 'select';
			
			if(isset($arraySets[$nameColumn->Field])){
				$generatedType['set']  = $arraySets[$nameColumn->Field];
			}else if(isset($arraySets[$nameColumn->Field.'s'])){
				$generatedType['set']  = $arraySets[$nameColumn->Field.'s'];
			}else if(isset($arraySets[$nameColumn->Field.'es'])){
				$generatedType['set']  = $arraySets[$nameColumn->Field.'es'];
			}else if(isset($arraySets[substr($nameColumn->Field, 0, -1).'ies'])){
				$generatedType['set']  = $arraySets[substr($nameColumn->Field, 0, -1).'ies'];
			}
			
		}else if( $this->_checkType('status',$nameColumn) ){
			
			$generatedType['type'] = 'select';
			$generatedType['set']  = 'status';
			
		}else if( $this->_checkType('select',$nameColumn) ){
	
			$generatedType['type'] = 'select';
			$generatedType['set']  = Config::_get("quikc.advanced.forms.import.select.default");
			
		}
		
		return $generatedType;    
	}

    /**
    * Check weather the given field belongs to the type or not
    *
    * @param  $type(string),$field(object)
    * @return boolean
    */
	function _checkType($type, $field) {

		if( in_array($field->Type,explode(",",Config::_get("quikc.advanced.forms.import.$type.types"))) ) return true;
		
		if( $this->_checkString(explode(",",Config::_get("quikc.advanced.forms.import.$type.lables")),$field->Field) ) return true;
		
		return false;
	}  	
    
    /**
    * Searches for the string in label
    *
    * @param  $array(array of strings),$string(string)
    * @return boolean
    */
	function _checkString($array, $string) {

		if(is_array($array)){
		    foreach ($array as $ele) {
		        if (stripos($string, $ele) !== false) return true;
		    }
		}else{
			if (stripos($string, $array) !== false) return true;;
		}
	    
		return false;
	}  	
    
}

