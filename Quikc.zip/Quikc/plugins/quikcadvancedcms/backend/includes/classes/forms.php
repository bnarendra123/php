<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* Extended Forms class, used for generating dynamic forms 
* This class will dynamicall generates the forms
*
* @version 1.0
* @http://www.quikc.org/
*/

class DynamicForms{

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /**
    * Contains the details of the forms based on its link
    *
    * @var Object
    */
    private $retrievedFormData;

    /** Checks the object instance status and creates if there is not instance
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }

    /* General Form related functions ends here    
    <!-----------------------------------------------------------------------------------------------------------------------------------------
    */
            
    /**
    * Check weather the forms page with the given page exists or not
    *
    * @param  string(page)
    * @return boolean
    */
    public function _checkFormsPage($currentStatus,$Page){
    	
		// If the forms doesn't exists in the parent class, then checking weather the lists page exists in the database or not
		if($this->_checkFormsLink($Page)) return true;
		
		return $currentStatus;		
	}

    /**
    * Checks weather the given Forms link exists or not
    *
    * @param string(Form Link)
    * @return boolean
    */
    public function _checkFormsLink($linkForm){
    
        $query  = " select * from ".Config::_getTable('forms')." where linkForm = :linkForm";
        $arrayBind[]= array("key" => ":linkForm", "value" => $linkForm);
        $countForms = Core::_getRowCount($query,$arrayBind);

        if($countForms == 0){
            return false;            
        }else{
            return true;
        }
    }
    
    /**
    * Checks weather the given Forms id exists or not
    *
    * @param int(Form id)
    * @return boolean
    */
    public function _checkFormExists($idForm){
    
        $query  = " select * from ".Config::_getTable('forms')." where idForm = :idForm";
        $arrayBind[]= array("key" => ":idForm", "value" => $idForm);
        $countForms = Core::_getRowCount($query,$arrayBind);

        if($countForms == 0){
            return false;            
        }else{
            return true;
        }
    }

    /**
    * Returns the Form elements from database by id
    *
    * @param int(Id Form)
    * @return form details(object)
    */
    public function _getFormDetails($idForm){
    
        $query  = " select * from ".Config::_getTable('forms')." where idForm = :idForm";
        $arrayBind[]= array("key" => ":idForm", "value" => $idForm);
        $detailsForm = Core::_getRow($query,$arrayBind);
		
		if( !$detailsForm ) return false;

        $detailsForm->tables = $this->_getFormTables($detailsForm->idForm);
        $detailsForm->fields = $this->_getFormFields($detailsForm->idForm);

		Cache::_getInstance() -> _setCache('cms_advanced_forms_' . $detailsForm->linkForm, $detailsForm);

        return $detailsForm;
    }

    /**
    * Returns the Form elements from database by link
    *
    * @param string(Form Link)
    * @return form details(object)
    */
    public function _getFormDetailsByLink($linkForm){

		if (isset($this -> retrievedFormData[$linkForm])) {
			$detailsForm = $this -> retrievedFormData[$linkForm];
		} else if (Cache::_getInstance() -> _isCached('cms_advanced_forms_' . $linkForm)) {
			$detailsForm = Cache::_getInstance() -> _getCache('cms_advanced_forms_' . $linkForm);
			$this -> retrievedFormData[$linkForm] = $detailsForm;
		} else {

	        $query  = " select * from ".Config::_getTable('forms')." where linkForm = :linkForm";
	        $arrayBind[]= array("key" => ":linkForm", "value" => $linkForm);
	        $detailsForm = Core::_getRow($query,$arrayBind);
	
	        $detailsForm->tables = $this->_getFormTables($detailsForm->idForm);
	        $detailsForm->fields = $this->_getFormFields($detailsForm->idForm);

			Cache::_getInstance() -> _setCache('cms_advanced_forms_' . $linkForm, $detailsForm);
			$this -> retrievedFormData[$linkForm] = $detailsForm;

		}
		
        return $detailsForm;
    }
	
    /**
    * Returns form Tables from database by id
    *
    * @param Integer(Id Form)
    * @return Tables(array of object)
    */
    public function _getFormTables($idForm){
    
        $arrayBind[]= array("key" => ":idForm", "value" => $idForm);
        $query  = " select * from ".Config::_getTable('forms_tables')." where idForm = :idForm";
        $tables = Core::_getAllRows($query,$arrayBind);

        return $tables;
    }
        
    /**
    * Returns form fields from database by id
    *
    * @param int(Form Id)
    * @return Fields(array of object)
    */
    public function _getFormFields($idForm){
    
        $arrayBind[]= array("key" => ":idForm", "value" => $idForm);
        $query  = " select * from ".Config::_getTable('forms_fields')." where idForm = :idForm order by orderFieldForm asc";
        $fields = Core::_getAllRows($query,$arrayBind);

        return $fields;
    }
    
    /**
    * Prepares the Form actions
    *
    * @param string/array(Form Actions)
    * @return array
    */
    public function _prepareFormActions($actions){
    
        if( !is_array($actions) ) $actions = explode("-",$actions);

        return $actions;
    }

    /* Forms related functions ends here
    -----------------------------------------------------------------------------------------------------------------------------------------!>
    */
    
    /**
    * generates the list ( search, position, sort )
    *
    * @param  $listElements
    * @return string
    */
    public function _generateForm($args){

		$formElements = $args[0];
		$detailsForm  = $args[1];

        if( !is_array($formElements) && $this->_checkFormsLink($formElements) ){
        	
	        // Form details by link name
	        $detailsForm = $this->_getFormDetailsByLink($formElements);
	        // Checking form status
	        if( !$detailsForm->statusForm ){
	        	global $Base;
	            $Message = Config::_prepareMessage('forms.disabled.form',array(":FORM_NAME" => $detailsForm->nameForm) );
	            $Base->_convertError($Message,false);
	        }        
        	
            $detailsForm  = $this->_generateFormDetails($formElements);
            $formElements = $this->_generateFormElements($formElements);
			
			if(isset($detailsForm['details'])){
	            $detailsForm  = $detailsForm['details'];
				$formElements['name'] .= " : ".$detailsForm->$formElements['displayTitleFieldForm'];
			}else{
				$detailsForm   = '';
			}
        }
        return array($formElements,$detailsForm);
    }
    
    /**
    * Checks weather advanced code is enabled or not
    *
    * @param void
    * @return boolean
    */
    public function _allowAdvancedCode(){

        if( Config::_get('quikc.advanced.forms.advanced.code.options.status') ) return true;

        return false;
    }
	    
    /* Dynamich functions
    
    <!-----------------------------------------------------------------------------------------------------------------------------------------
    */

    /**
    * generates Forms elements from database
    *
    * @param string(Form Link)
    * @return $formElements
    */
    protected function _generateFormElements($linkForm){

        // Initiating classes
        $Permissions = new Permissions;
        $Validate    = new Validate;  
        $Languages   = new Languages;  

        // List of languages. used for multilanguage fields
        $listLanguages = $Languages->_getLanguages(1);

        // Checking the permissions        
        if( !$Permissions->_checkPagePermission($linkForm,'view') ){
        	global $Base;
            $Base->_accessRestricted();
        }
        
        if(!$_POST){
            die();
        }
        extract($_POST);
        // Form details by link name
        $detailsForm = $this->_getFormDetailsByLink($linkForm);

        // Contains the tables which supports multiple languages
        $multiLingualTables = array();

        // Retrieving the tables supporting multiple language option
        if( is_array($detailsForm->tables) && count($detailsForm->tables) > 0){
            foreach($detailsForm->tables as $table){
                if( $table->multiLanguageField != '' && Core::_checkColumn($table->tableForm,Core::_getField($table->multiLanguageField)) )
                $multiLingualTables[$table->identifierTableForm] = Config::_getTable($table->tableForm);
            }
        }
                
        $formFields = array();

        if( is_array($detailsForm->fields) && count($detailsForm->fields) > 0)        
        foreach($detailsForm->fields as $fields){
            
             if( strtolower($fields->typesFieldForm) == 'password' && ( !isset($formPrimaryField) || $formPrimaryField == -1) ){
                 $fields->requiredFieldForm = 1;
             }
             // If true, the the field belong to multiple language
             if( isset($multiLingualTables[Core::_getFieldPrefix($fields->fieldForm)]) ){
                // Building the category name fields basing on the language
                foreach($listLanguages as $language){
                     $formFields[] = array("id"          => Core::_getField($fields->fieldForm)."_".$language->idLanguage,
                                           "label"       => $fields->titleFieldForm." ".$language->nameLanguage,
                                           "type"        => $fields->typesFieldForm,
                                           "value"       => $fields->defaultvalueFieldForm,
                                           "additional"  => $Validate->_unsanitizeVariable($fields->additionalcssFieldForm), 
                                           "set"         => $fields->setsFieldForm,
                                           "dbfield"     => ($fields->databasefieldFieldForm==1)?true:false,
                                           "req"         => ($fields->requiredFieldForm==1)?true:false,
                                           "unique"      => ($fields->uniqueFieldForm==1)?true:false
                                        );
                }                 
             }else{
                 $formFields[] = array("id"          => Core::_getField($fields->fieldForm),
                                       "label"       => $fields->titleFieldForm,
                                       "type"        => $fields->typesFieldForm,
                                       "value"       => $fields->defaultvalueFieldForm,
                                       "additional"  => $Validate->_unsanitizeVariable($fields->additionalcssFieldForm), 
                                       "set"         => $fields->setsFieldForm,
                                       "dbfield"     => ($fields->databasefieldFieldForm==1)?true:false,
                                       "req"         => ($fields->requiredFieldForm==1)?true:false,
                                       "unique"      => ($fields->uniqueFieldForm==1)?true:false
                                    );
                 
             }
        }
        
        if( !isset($formPrimaryField) || $formPrimaryField == -1){
            $headingForm = Config::_prepareMessage('forms.label.creating.new',array(":FORM_NAME" => $detailsForm->nameForm) );
        }else{
            $headingForm = Config::_prepareMessage('forms.label.editing',array(":FORM_NAME" => $detailsForm->nameForm) );
        }
		
		if( $detailsForm->displayTitleFieldForm && $detailsForm->displayTitleFieldForm != '' ){
			$displayTitleFieldForm = Core::_getField($detailsForm->displayTitleFieldForm);
		}else{
			// If no title field is given, then taking first field as title field
			$displayTitleFieldForm = $formFields[0]['id'];
		}
        
        // Replacing with form link
        $detailsForm->onSuccessForm = str_replace(':THIS_LINK',$linkForm,$detailsForm->onSuccessForm);
		
		if( $detailsForm->onSuccessForm == '' ){
			$detailsForm->onSuccessForm = "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)";
		}

        if(!isset($dataFilter)) $dataFilter = '';
        
        // Replacing with data filter
        $detailsForm->onSuccessForm = str_replace(':DATA_FILTER',$dataFilter,$detailsForm->onSuccessForm);

        $formElements = array(  "identifier"    => "dynamicForm", 
                                "name"          => $headingForm, 
                                "primaryFiled"  => Core::_getField($detailsForm->primaryFieldForm), 
                                "url"           => "set/".$linkForm, 
                                "success"       => $detailsForm->onSuccessForm, 
                                "filename"      => $linkForm,
                                "fields"        => $formFields, 
								// Following fields are additional Fields
								// These fields will not be useful to send to the main form class
								// but wil be used to furhter proceedings in ths class
                                "displayTitleFieldForm"	=> $displayTitleFieldForm, 
					        );         

		$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/forms/".$detailsForm->idForm."/form_before_call.php";
		if( $this->_allowAdvancedCode() && file_exists($filePath)){
			include $filePath;
		}
       
        //echo '<pre>';
        //print_r($databaseFrom);
        //print_r($_POST);
        //print_r($formElements);
        //die();
        return $formElements;        
    }

    /**
    * generates details for the form entry from database
    *
    * @param string(Form Link)
    * @return $formElements
    */
    protected function _generateFormDetails($linkForm){

        if(!$_POST){
            die();
        }
        extract($_POST);
        
        if( $formPrimaryField == -1){
            return array();
        }

        $detailsForm = $this->_getFormDetailsByLink($linkForm);

        // Contains the tables which supports multiple languages
        $multiLingualTables = array();
        
        $sqlArray[] = "select * from ";
        if( is_array($detailsForm->tables) && count($detailsForm->tables) > 0){
            foreach($detailsForm->tables as $table){
                // Tables which supports multiple language
                if( $table->multiLanguageField != '' && Core::_checkColumn($table->tableForm,Core::_getField($table->multiLanguageField)) )
                $multiLingualTables[$table->identifierTableForm] = array("table" => Config::_getTable($table->tableForm), "Multilanguage" => Core::_getField($table->multiLanguageField));
                
                $sqlTmp = " ".Config::_getTable($table->tableForm)." ".$table->identifierTableForm;
                if( $table->joinTypeTable != '' && in_array($table->joinTypeTable,array('join','left join','right join')) && $table->joinOnTable != '' ){
                    $sqlTmp = $table->joinTypeTable." ".$sqlTmp." on ".$table->joinOnTable;
                }
                $sqlArray[] = $sqlTmp;
            }
        }
        $query  = implode(' ',$sqlArray);
        $query .= ' where '.$detailsForm->primaryFieldForm.' = :primaryField';
        $arrayBind[]= array("key" => ":primaryField", "value" =>  $formPrimaryField);
        $detailsFormElement = Core::_getRow($query,$arrayBind);

        // Contains the fields which supports multiple languages
        $multiLingualFields = array();
        
        // Retrieving the data for multiple language tables
        if( is_array($detailsForm->fields) && count($detailsForm->fields) > 0)        
        foreach($detailsForm->fields as $fields){
             if( isset($multiLingualTables[Core::_getFieldPrefix($fields->fieldForm)]) ){
                 $multiLingualFields[Core::_getFieldPrefix($fields->fieldForm)][] = Core::_getField($fields->fieldForm);
             }          
        }
        
        unset($arrayBind);
        $arrayBind[] = array("key" => ":primaryField", "value" => $formPrimaryField );
        foreach($multiLingualTables as $key => $tables){
            $languageField = '';
            $query = "select * from ".Config::_getTable($tables['table'])." where ".Core::_getField($detailsForm->primaryFieldForm)." = :primaryField";
            $multiLanguagedescription = Core::_getAllRows($query,$arrayBind);

            // Converting them as field variables
            foreach( $multiLingualFields[$key] as $field){   
                foreach( $multiLanguagedescription as $tmpDescription){
                    $detailsFormElement->{$field."_".$tmpDescription->$tables['Multilanguage']} = $tmpDescription->$field;
                }
            }
        }
                
        return array("details"=>$detailsFormElement,"query" =>$query,"arrayBind"=>$arrayBind);        
    }

    /**
    * Process the default form actions like edit and create
    *
    * @param  string(form link)
    * @return string
    */
    public function _processFormActions($linkForm){

        // permissions object
        global $Permissions, $Languages, $Base;  
        
        // List of languages. used for multilanguage fields
        $listLanguages = $Languages->_getLanguages(1);        

        // Stopping execution if there is no post
        if(!$_POST){
            die();
        }

        // Checking the form link        
        if( !$this->_checkFormsLink($linkForm) ){
            $Message = Config::_prepareMessage('forms.invalid.form',array(":FORM_LINK" => $linkForm) );
            $Base->_convertError($Message,false);
        }        

        // Form details by link name
        $detailsForm = $this->_getFormDetailsByLink($linkForm);
        // Checking form status
        if( !$detailsForm->statusForm ){
        	global $Base;
            $Message = Config::_prepareMessage('forms.disabled.form',array(":FORM_NAME" => $detailsForm->nameForm) );
            $Base->_convertError($Message,false);
        }        

        // Getting the form elements from link
        $elementsForm = $this->_generateFormElements($linkForm);
        // Getting the form details from link
        $detailsForm  = $this->_getFormDetailsByLink($linkForm);

		global $Forms;
        // Processing the form. This will generate the default error messages, and form field conversions etc                
        $processedForm = $Forms->_processForm($elementsForm,$_POST);        

        // Extracting the form elements        
        extract($processedForm['formElements']);

        // Gaterting the list of tables        
        $fieldsList = array();
        foreach($detailsForm->tables as $tmpTable){
            $fieldsList[$tmpTable->identifierTableForm]['table'] = $tmpTable->tableForm;
            $fieldsList[$tmpTable->identifierTableForm]['multiLanguageField'] = $tmpTable->multiLanguageField;
        }

    	/*
		 * If the form is in quick field, then updating the quick fields to $fieldsQuickeditArray by exploding with ,
		 * If not then $fieldsQuickeditArray will an empty array
		 */
        $fieldsQuickeditArray = array();
        if(isset($fieldsQuickedit) && $fieldsQuickedit != '') $fieldsQuickeditArray = explode(',', $fieldsQuickedit);
		
        // Gaterting the list of fields in a table
        foreach($detailsForm->fields as $field){
            // Checking for the database fields
            // and checking if the form is in quick edit mode
            if($field->databasefieldFieldForm == 1 && ( $formPrimaryField == -1 || count($fieldsQuickeditArray) == 0 || in_array(Core::_getField($field->fieldForm), $fieldsQuickeditArray) ) ){
                // Validating if unique field option is selected
                if($field->uniqueFieldForm == 1){

                    //checking for the rows with same field value
                    unset($arrayBind);
                    $fieldUnique = Core::_getField($field->fieldForm);
                    $query  = " select * from ".Config::_getTable($fieldsList[Core::_getFieldPrefix($field->fieldForm)]['table'])." where `".$fieldUnique."` = :field and `".Core::_getField($detailsForm->primaryFieldForm)."` != :formPrimaryField ";
                    $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
                    $arrayBind[]= array("key" => ":field", "value" => $$fieldUnique);
                    $countRows = Core::_getRowCount($query,$arrayBind);
                    if($countRows != 0){
                        $processedForm['error'][] = $field->titleFieldForm.' already exists';
                    }
                }
                $fieldsList[Core::_getFieldPrefix($field->fieldForm)]['fields'][] = array("id" => Core::_getField($field->fieldForm), "type" => $field->typesFieldForm , "unique" => $field->uniqueFieldForm );
            }
        }

		$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/forms/".$detailsForm->idForm."/form_before_display_errors.php";
		if( $this->_allowAdvancedCode() && file_exists($filePath) ){
			include $filePath;
		}

        // Checking for the errors
        if( count($processedForm['error']) != 0 ){      
            $Base->_convertError($processedForm['error'],false);
        }
       
       // Permissions type create/edit based on primayr field
        if( $formPrimaryField == -1){
            $typePermission = "create";
        }else{
            $typePermission = "edit";
        }
        // Validating the user permissions
        if( !$Permissions->_checkPagePermission($linkForm,$typePermission) ){
             $Base->_convertError(Config::_getMessage('general.no.permissions'),false);
        }
        // Used to insert the primary key for the next tables.
        $lastPrimaryField = '';
        // Executing the querys for each table                
        foreach($fieldsList as $tables){
        	
            // if the field is not a database field, then skipping further process and continuing to the next entry
			if(!isset($tables['table'])) continue;
			
            // Declaring default arrays                
            $queryKeys  = $queryValues  =  $setpPart = $arrayBind    = array();

            // Table name for this query
            $currentTable = $tables['table'];
            
            // Retrieving the list of fields
            foreach($tables['fields'] as $fields){
                // Field id
                $field = $fields['id']; 
                // md5 encrypting for the password fields, if they are not null
                if( strtolower($fields['type']) == 'password' && $$field != '' ){
                    $$field = md5($$field);
                }
                // will be useful to identify weather the field accepted into the database or not
                $keyNoted = false;
                // All fields will be accepted, if it is a create option
                if( $formPrimaryField == -1){
                    $queryKeys[]  = "`$field`";
                    $queryValues[]= ":$field";
                    $keyNoted = true;
                }else{
                    // For edit, the password fields will only be updated if they are not null
                    // Checking the password field value
                    if( strtolower($fields['type']) == 'password'){
                        // accept the fielld, if type is password and value is not null
                        if( $$field != '' ){
                            $keyNoted = true;                    
                            $setpPart[] = "`$field`=:$field";
                        }
                    }else{
                        // accept the fielld, if type is not password
                        $setpPart[] = "`$field`=:$field";
                       $keyNoted = true;                    
                    }
                }
                // Bind the values if the field is accepted
                if($keyNoted)
                $arrayBind[]= array("key" => ":$field", "value" => $$field);                
            }
            if($formPrimaryField == -1){
                $multiLanguageFileds = $queryValues;
                if($lastPrimaryField != '' && Core::_checkColumn($currentTable,Core::_getField($detailsForm->primaryFieldForm))){
                    $queryKeys[]  = "`".Core::_getField($detailsForm->primaryFieldForm)."`";
                    $queryValues[]= ":".Core::_getField($detailsForm->primaryFieldForm);
                    $arrayBind[]= array("key" => ":".Core::_getField($detailsForm->primaryFieldForm), "value" => $lastPrimaryField);                                    
                }
                // Multi language save if the field is set
                if( $tables['multiLanguageField'] != ''){

                    // Repeating the update query for all the active languages
                    foreach($listLanguages as $language){

                        unset($arrayBind);
                        $query  = "insert into ".Config::_getTable($currentTable)." (`".Core::_getField($tables['multiLanguageField'])."`,".implode(",",$queryKeys).") values (:idLanguage,".implode(",",$queryValues).")";
                        $arrayBind[]= array("key" => ":idLanguage",     "value" =>  $language->idLanguage);
                        foreach($queryValues as $tmpQueryValues){
                            if( ':'.Core::_getField($detailsForm->primaryFieldForm) == $tmpQueryValues ){
                                $arrayBind[]= array("key" => ":".Core::_getField($detailsForm->primaryFieldForm),  "value" =>  $lastPrimaryField);
                            }else{
                                $tmp = explode(":",$tmpQueryValues);
                                $arrayBind[]= array("key" => ":".$tmp[1],  "value" =>  ${$tmp[1]."_".$language->idLanguage});
                            }
                        }
                        Core::_runQuery($query,$arrayBind);
                    }
                }else{
                    // Non multi language save                 
                    // Insert query
                    $query = "insert into ".Config::_getTable($currentTable)." (".implode(",",$queryKeys).") values (".implode(",",$queryValues).")";
                    Core::_runQuery($query, $arrayBind);
                    if($lastPrimaryField == '')
                    $lastPrimaryField = Core::_getLastInsertId();
                }
            }else{
                // Update query
                // Multi language save if the field is set
                if( $tables['multiLanguageField'] != ''){

                    // Repeating the update query for all the active languages
                    foreach($listLanguages as $language){

                        // Query to check the entry for the current language
                        unset($arrayBind);
                        $query  = "select * from ".Config::_getTable($currentTable)." where `".Core::_getField($detailsForm->primaryFieldForm)."` = :formPrimaryField and `".Core::_getField($tables['multiLanguageField'])."` = :idLanguage";
                        $arrayBind[]= array("key" => ":idLanguage",     "value" =>  $language->idLanguage);
                        $arrayBind[]= array("key" => ":formPrimaryField","value" => $formPrimaryField);     
                        
                        // creating new entry if the entry doesnot exists        
                        if( Core::_getRowCount($query,$arrayBind) == 0 ){
                            unset($arrayBind);
                            $query  = "insert into ".Config::_getTable($currentTable)." (`".Core::_getField($detailsForm->primaryFieldForm)."`,`".Core::_getField($tables['multiLanguageField'])."`) values (:formPrimaryField,:idLanguage)";
                            $arrayBind[]= array("key" => ":idLanguage",     "value" =>  $language->idLanguage);
                            $arrayBind[]= array("key" => ":formPrimaryField","value" => $formPrimaryField);     
                            Core::_runQuery($query,$arrayBind);
                        }
                        // Upading the field to the database
                        unset($arrayBind);
                        $query  = "update ".Config::_getTable($currentTable)." set ".implode(",",$setpPart)." where `".Core::_getField($detailsForm->primaryFieldForm)."` = :formPrimaryField  and `".Core::_getField($tables['multiLanguageField'])."` = :idLanguage";
                        $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
                        $arrayBind[]= array("key" => ":idLanguage"      , "value" =>  $language->idLanguage);
                        foreach($setpPart as $tmpSetpPart){
                            $tmp = explode(":",$tmpSetpPart);
                            $arrayBind[]= array("key" => ":".$tmp[1],  "value" =>  ${$tmp[1]."_".$language->idLanguage});
                        }
                        Core::_runQuery($query,$arrayBind);
                    }
                }else{
	                // Non multi language save 
                    $query  = "update `".Config::_getTable($currentTable)."` set ".implode(", ",$setpPart)." where `".Core::_getField($detailsForm->primaryFieldForm)."` = :formPrimaryField";                    
                    $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
                    Core::_runQuery($query,$arrayBind);
					
                	//echo $query.$formPrimaryField;
					/*
                	echo '<pre>';
					print_r($arrayBind);
					echo '</pre>';
					*/
                }
            }
        }

		$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/forms/".$detailsForm->idForm."/form_after_complete.php";
		if( $this->_allowAdvancedCode() && file_exists($filePath) ){
			include $filePath;
		}
        
        //echo '<pre>';
        //echo $query;
        //print_r(Core::_getError());
        //print_r($detailsForm);
        //print_r($arrayBind);
        //print_r($processedForm['formElements']);
        //print_r($elementsForm);        
        die('ok');
        
    }
}
