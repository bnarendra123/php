<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* Extended List class, used for generating dynamic lists 
* This class will dynamicall generates the lists
*
* @version 1.0
* @http://www.quikc.org/
*/

class DynamicLists{

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /** Checks the object instance status and creates if there is not instance
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }

    /* General List related functoins starts here
    
    <!-----------------------------------------------------------------------------------------------------------------------------------------
    */
    
    /**
    * Check weather the Forms page with the given page exists or not
    *
    * @param  string(page)
    * @return boolean
    */
    public function _checkListsPage($currentStatus,$Page){

		// If the lists doesn't exists in the parent class, then checking weather the lists page exists in the database or not
		if($this->_checkListsLink($Page)) return true;

		return $currentStatus;
	}
    
    /**
    * Checks weather the given lists link exists or not
    *
    * @param string(List Link)
    * @return boolean
    */
    public function _checkListsLink($linkList){
    
        $query  = " select * from ".Config::_getTable('lists')." where linkList = :linkList";
        $arrayBind[]= array("key" => ":linkList", "value" => $linkList);
        $countLists = Core::_getRowCount($query,$arrayBind);

        if($countLists == 0){
            return false;            
        }else{
            return true;
        }
    }
    
    /**
    * Checks weather the given lists id exists or not
    *
    * @param int(List id)
    * @return boolean
    */
    public function _checkListExists($idList){
    
        $query  = " select * from ".Config::_getTable('lists')." where idList = :idList";
        $arrayBind[]= array("key" => ":idList", "value" => $idList);
        $countLists = Core::_getRowCount($query,$arrayBind);

        if($countLists == 0){
            return false;            
        }else{
            return true;
        }
    }

    /**
    * Returns the list elements from database by id
    *
    * @param int(List Id)
    * @return List Details(object)
    */
    public function _getListDetails($idList){
    
        $query  = " select * from ".Config::_getTable('lists')." where idList = :idList";
        $arrayBind[]= array("key" => ":idList", "value" => $idList);
        $detailsList = Core::_getRow($query,$arrayBind);

        $detailsList->actionsList = $this->_prepareListActions($detailsList->actionsList);
        
        $detailsList->tables = $this->_getListTables($detailsList->idList);
        $detailsList->fields = $this->_getListFields($detailsList->idList);

        return $detailsList;
    }

    /**
    * Returns the list elements from database by link
    *
    * @param string(List Link)
    * @return List Details(object)
    */
    public function _getListDetailsByLink($linkList){
    
        $query  = " select * from ".Config::_getTable('lists')." where linkList = :linkList";
        $arrayBind[]= array("key" => ":linkList", "value" => $linkList);
        $detailsList = Core::_getRow($query,$arrayBind);

        $detailsList->actionsList = $this->_prepareListActions($detailsList->actionsList);

        $detailsList->tables = $this->_getListTables($detailsList->idList);
        $detailsList->fields = $this->_getListFields($detailsList->idList);

        return $detailsList;
    }

    /**
    * Returns the list elements from database by id
    *
    * @param string(Id List)
    * @return Tables(array of object)
    */
    public function _getListTables($idList){
    
        $arrayBind[]= array("key" => ":idList", "value" => $idList);
        $query  = " select * from ".Config::_getTable('lists_tables')." where idList = :idList";
        $tables = Core::_getAllRows($query,$arrayBind);

        return $tables;
    }
        
    /**
    * Returns the list elements from database by id
    *
    * @param int(Id List)
    * @return Fields(array of object)
    */
    public function _getListFields($idList){
    
        $arrayBind[]= array("key" => ":idList", "value" => $idList);
        $query  = " select * from ".Config::_getTable('lists_fields')." where idList = :idList order by orderFieldList asc";
        $fields = Core::_getAllRows($query,$arrayBind);

        return $fields;
    }
    
    /**
    * Prepares the list actions
    *
    * @param string/array(List Actions)
    * @return array
    */
    public function _prepareListActions($actions){
    
        if( !is_array($actions) ) $actions = explode("-",$actions);

        return $actions;
    }

    /**
    * Checks weather advanced code is enabled or not
    *
    * @param void
    * @return boolean
    */
    public function _allowAdvancedCode(){
    
        if( Config::_get('quikc.advanced.lists.advanced.code.options.status') ) return true;

        return false;
    }
	    
    /* List related functions ends here
    -----------------------------------------------------------------------------------------------------------------------------------------!>
    */
    /**
    * generates the list ( search, position, sort )
    *
    * @param  $listElements
    * @return string
    */
    public function _generateList($listElements){

        if( !is_array($listElements) && $this->_checkListsLink($listElements) ){

	        // Getting the list values from the database
	        $databaseList = $this->_getListDetailsByLink($listElements);
			
	        // Checking the status of the list
	        if( !$databaseList->statusList ){
	            $Message = Config::_prepareMessage('lists.disabled.list',array(":LIST_NAME" => $databaseList->nameList) );
				global $Base;
	            $Base->_convertError($Message,false);
	        }

            $listElements = $this->_generateListElements($databaseList);
        }
        return $listElements;
    }

    /**
    * generates the lists elements from database
    *
    * @param details of the list 
    * @return $listElements
    */
    protected function _generateListElements($databaseList){

        // Contains the generated list fields
        $displayFields = array();
        
        // Generating the list fields to display
        foreach($databaseList->fields as $fields){                
            
			if( $fields->displayFieldList == '' ) $fields->displayFieldList = ':data';
			
            $data  = $fields->displayFieldList;
            // Generating the data for the image type fields 
            if($fields->typesFieldList == 'image')
            $data  = '<img src=":data" width="50" />';
             
            $displayFields[] = array(
									"id"     	=> Core::_getField($fields->fieldList),
									"title"     => $fields->titleFieldList,
                                    "type"      => $fields->typesFieldList,
                                    "dbField"   => true ,
                                    "tpx"       => Core::_getFieldPrefix($fields->fieldList), 
                                    "display"   => $data,
                                    "set"       => $fields->setsFieldList,
                                    "show"   	=> $fields->showFieldList,
                                );
        }
        // Generating the list actions
        $displayFields[] = array(  
								"id"     	=> "actions",
								"title"     => "Actions",
                                "type"      => "actions",
                                "dbField"   => false ,
                                "tpx"       => '', 
                                "display"   => '',
                                "set"       => $databaseList->actionsList
                             );
        // Generating the list query
        $appendPrimaryField = '';
        // Usefull to avoid over writting the primary field
        if($databaseList->primaryFieldList != ''){
            $appendPrimaryField = ','.$databaseList->primaryFieldList;
        }
        $sqlArray[] = "select *".$appendPrimaryField." from ";

        // $databaseList->tables contains list of tables and their info
        foreach($databaseList->tables as $table){

            // Appending the table with its prefix
            $sqlTmp = " ".Config::_getTable($table->tableList)." ".$table->identifierTableList;

            // Checking for the join type of the table and validating
            if( $table->joinTypeTable != '' && in_array($table->joinTypeTable,array('join','left join','right join')) && $table->joinOnTable != '' ){
                $sqlTmp = $table->joinTypeTable." ".$sqlTmp." on ".$table->joinOnTable;
            }
            $sqlArray[] = $sqlTmp;
        }
        $sql = implode(' ',$sqlArray);

        if($databaseList->editActionLink != ''){
            $formList = $databaseList->editActionLink;
        }else{
        	$formList = $databaseList->linkList;
        }
        $databaseList->editActionLink = "get/edit/".$formList;

        // Generating the default list options        
        $listElements = array(  "sql"          => $sql,
                                "where"         => $databaseList->whereList,
                                "arrayBind"     => "",
                                "sortby"         => Core::_getField($databaseList->sortByFieldList), 
                                "order"          => $databaseList->sortOrderFieldList, 
                                "headding"       => $databaseList->nameList, 
                                "primaryField"   => Core::_getField($databaseList->primaryFieldList), 
                                "statusField"    => Core::_getField($databaseList->statusFieldList),
                                "editorUrl"		 => $databaseList->editActionLink,
                                "submitLink"	 => "set/".$formList,
                                "multiActions"   => true,
                                "multiLanguages" => Core::_getField($databaseList->multiLanguageFieldList),
                                "defaultLanguage"=> Languages::_getdefaultLanguage(),
                                "displayFields"  => $displayFields, 
                                "page"           => $databaseList->pagePaginationList, 
                                "perpage"        => $databaseList->rowsPaginationList, 
                                "displaypages"   => $databaseList->pagesPaginationList, 
                                // will be used in export list page also to create or edit the file while exporting the data
                                // need to change there if any changes here
                                "filename"       => $databaseList->linkList 
                        );
						
						
		$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/".$databaseList->idList."/list_before_call.php";
		if( $this->_allowAdvancedCode() && file_exists($filePath)){
			include $filePath;
		}
								
        //echo $sql;
        //echo '<pre>';
        //print_r($listElements);
        //print_r($databaseList);
        return $listElements;        
    }

    /**
    * process default list actions like status change and delete
    *
    * @param  string(list link)
    * @return string
    */
    public function _processListActions($linkList){

		global $Base;
		
        // Checking list existance
        if( !$this->_checkListsLink($linkList) ){
            
            $Message = Config::_prepareMessage('lists.invalid.list',array(":LIST_LINK" => $linkList) );
            $Base->_convertError($Message,false);
        }
        // Generating the list details by list
        $detailsList = $this->_getListDetailsByLink($linkList);
        
        foreach($detailsList->tables as $tmpTable){
            $tablesList[$tmpTable->identifierTableList] = $tmpTable->tableList;
        }       
        
        $Permissions  = new Permissions;
        extract($_POST);        

        if(isset($id)){
            // Exploding to get the ids
            $idArray = explode(",",$id);            
        }else{
            $idArray = array();
        }
        
        // Generating the primary field
        $fieldPrimary = Core::_getField($detailsList->primaryFieldList);

                
        switch($do){
            case 'status': 
				
							$checkPermissions = true;

							$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/".$detailsList->idList."/status_before_start.php";
							if( $this->_allowAdvancedCode() && file_exists($filePath) ){
								include $filePath;
							}
				
                            if( $checkPermissions && !$Permissions->_checkPagePermission($linkList,'edit') ){
                                $Base->_convertError(Config::_getMessage('general.no.permissions'),false);
                            }
                            // Generating the status field table prefix
                            $prefixStatus = Core::_getFieldPrefix($detailsList->statusFieldList);
                            // Generating the status field
                            $fieldStatus  = Core::_getField($detailsList->statusFieldList);
                            // Generating Status Table
                            $table = $tablesList[$prefixStatus];

                            // Checking the admin tables
                            global $Admin;
                            if( $Admin->_isAdminTables($table) ){
                                $Message = Config::_prepareMessage('lists.admin.table.action.status',array(":TABLE_NAME" => $table) );
                                $Base->_convertError($Message,false);
                            }
                            
                            // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
                            // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
                            if($changeTo == '1'){
                                $changeToField = 1;
                            }else if($changeTo == '0'){
                                $changeToField = 0;
                            }else{
                                $changeToField = "!".$fieldStatus;
                            }
                            // Status changer query
                            $query  = "update ".Config::_getTable($table)." set ".$fieldStatus." = ".$changeToField." where ".$fieldPrimary." = :primaryField";
                            foreach($idArray as $tmpId){
                                unset($arrayBind);
                                $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
                                Core::_runQuery($query,$arrayBind);
								
								$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/".$detailsList->idList."/status_after_update.php";
								if( $this->_allowAdvancedCode() && file_exists($filePath) ){
									include $filePath;
								}
                            }
                            die('ok');
            case 'delete': 

							$checkPermissions = true;

							$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/".$detailsList->idList."/delete_before_start.php";
							if( $this->_allowAdvancedCode() && file_exists($filePath) ){
								include $filePath;
							}
				
                            if( $checkPermissions && !$Permissions->_checkPagePermission($linkList,'delete') ){
                                $Base->_convertError(Config::_getMessage('general.no.permissions'),false);
                            }
                            // Checking for the admin tables
                            $adminTables = array();
                            foreach($tablesList as $tmpTable){
								global $Admin;
                                if( $Admin->_isAdminTables($tmpTable) && Core::_checkColumn($tmpTable,$fieldPrimary)){
                                    $adminTables[] = $tmpTable;
                                }
                            }
                            if( count($adminTables) > 0 ){
                                $Message = Config::_prepareMessage('lists.admin.table.action.delete',array(":TABLE_NAME" => implode(",",$adminTables)) );
                                $Base->_convertError($Message,false);
                            }

                            foreach($idArray as $tmpId){                                
                                unset($arrayBind);
                                $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
                                foreach($tablesList as $tmpTable){
                                    if( Core::_checkColumn($tmpTable,$fieldPrimary)){
                                        $query  = "delete from ".Config::_getTable($tmpTable)." where ".$fieldPrimary." = :primaryField";
                                        Core::_runQuery($query,$arrayBind);
                                    }
                                }

								$filePath = Config::_getDir('current.plugin')."/backend/includes/modules/generated/lists/".$detailsList->idList."/delete_after_update.php";
								if( $this->_allowAdvancedCode() && file_exists($filePath) ){
									include $filePath;
								}
                            }
                            die('ok');
        }
    }
}

