<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

// Admin Menu Generation 
$idMainMenu = $this->_addPluginMenu(array("titleMenu" => "Media","linkMenu" => "media","imageMenu" => "library-icon.png","parentMenu" => 0,"statusMenu" => '1',"orderMenu"=> 10,"dashboardMenu"=>0,"topMenu"=>1));
$idMenu     = $this->_addPluginMenu(array("titleMenu" => "Media Library","linkMenu" => "media","imageMenu" => "library-icon.png","parentMenu" => $idMainMenu,"statusMenu" => 1,"orderMenu"=> 10,"dashboardMenu"=>0,"topMenu"=>0));
$idMenu     = $this->_addPluginMenu(array("titleMenu" => "Media Categories","linkMenu" => "mediacategories","imageMenu" => "menu-icon.png","parentMenu" => $idMainMenu,"statusMenu" => 1,"orderMenu"=> 10,"dashboardMenu"=>0,"topMenu"=>0));
$idMenu     = $this->_addPluginMenu(array("titleMenu" => "Media Settings","linkMenu" => "mediasettings","imageMenu" => "configuration-settings-icon.png","parentMenu" => $idMainMenu,"statusMenu" => 1,"orderMenu"=> 15,"dashboardMenu"=>0,"topMenu"=>0));

$this->_addMessage(array("keyMessage"=>"lists.media.categories.cms.title","contentMessage"=>"Media Categories","statusMessage"=>"1"));
$this->_addMessage(array("keyMessage"=>"lists.media.categories.title","contentMessage"=>"Media Categories","statusMessage"=>"1"));
$this->_addMessage(array("keyMessage"=>"lists.media.title","contentMessage"=>"Media","statusMessage"=>"1"));

$this->_addConfig(array("keyConfig"=>"media.allow.upload"	,"valueConfig"=>"1"						,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>"media.max.file.size"	,"valueConfig"=>"20"					,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>"media.allowed.types"	,"valueConfig"=>"jpeg,jpg,png,gif,flv,mp4"	,"statusConfig"=>"1","systemItem"=>"1"));

$this->_addConfig(array("keyConfig"=>"media.sets.img"		,"valueConfig"=>"jpeg,jpg,png,gif"		,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>"media.sets.vid"		,"valueConfig"=>"flv,mp4"				,"statusConfig"=>"1","systemItem"=>"1"));
$this->_addConfig(array("keyConfig"=>"media.sets.doc"		,"valueConfig"=>"xls,doc"				,"statusConfig"=>"1","systemItem"=>"1"));

$query[] = "CREATE TABLE IF NOT EXISTS `".Config::_getTable('media')."` (
 `idMedia` int(11) NOT NULL AUTO_INCREMENT,
 `pathMedia` varchar(500) NOT NULL,
 `nameMedia` varchar(100) DEFAULT NULL,
 `idCategory` int(11) DEFAULT NULL,
 `typeMedia` varchar(50) DEFAULT NULL,
 `widthMedia` int(5) DEFAULT NULL,
 `heightMedia` int(5) DEFAULT NULL,
 `sizeMedia` int(11) DEFAULT NULL,
 `uses` int(11) DEFAULT NULL,
 `starred` tinyint(1) DEFAULT NULL,
 `time` datetime DEFAULT NULL,
 `Updatedtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 PRIMARY KEY (`idMedia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

$query[] = "CREATE TABLE IF NOT EXISTS `".Config::_getTable('media_categories')."` (
  `idCategory` int(11) NOT NULL auto_increment,
  `nameCategory` varchar(300) NOT NULL,
  `statusCategory` tinyint(1) NOT NULL default '1',
  `dateAdditionMediaCategory` datetime NOT NULL,
  `dateUpdationMediaCategory` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`idCategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;";

$query[] = "INSERT INTO `".Config::_getTable('media_categories')."` VALUES('1', 'Images', 1, NOW(), NOW());";
$query[] = "INSERT INTO `".Config::_getTable('media_categories')."` VALUES('2', 'Videos', 1, NOW(), NOW());";
$query[] = "INSERT INTO `".Config::_getTable('media_categories')."` VALUES('3', 'Documents', 1, NOW(), NOW());";


$this->_executePluginDatabase($query);

