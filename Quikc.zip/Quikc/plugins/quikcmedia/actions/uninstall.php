<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$query[]  = "drop table if exists ".Config::_getTable('media');
$query[]  = "drop table if exists ".Config::_getTable('media_categories');

$this->_executePluginDatabase($query);
