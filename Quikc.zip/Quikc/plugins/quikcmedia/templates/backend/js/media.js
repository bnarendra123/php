var selectedMedia = '';

function deleteMedia(id){

    if( !confirm("Are you sure you want to delete this Media Item?") )
    return false;

    var pass_url = '/ajax.php?action='+plugin_media_path+'/backend/includes/modules/ajax/set/media';
    var pass_data = 'do=delete&id='+id;
    
    $.ajax({
        type        : "POST",
        beforeSend  : loadingStarts,
        url         : adminUrl+pass_url,
        data        : pass_data,
        success     : function(responseText){
                        loadingEnds();
                        if(responseText == 'ok' ){
                            $("#media_td_"+id).html('');
                        }else{
                            alert(responseText);
                        }
                    }
    });        
    
}
function editMedia(id){

    var idCategory   = getValueFromId('editSelectGalleryImage_'+id,'');

    var pass_url = '/ajax.php?action='+plugin_media_path+'/backend/includes/modules/ajax/set/media';
    var pass_data = 'do=edit&id='+id+'&idCategory='+idCategory;
    
    $.ajax({
        type        : "POST",
        beforeSend  : loadingStarts,
        url         : adminUrl+pass_url,
        data        : pass_data,
        success     : function(responseText){
                        loadingEnds();
                        if(responseText == 'ok' ){
                            if( $("#searchCategoryMedia").val() != '' && $("#searchCategoryMedia").val() != idCategory )
                                $("#media_td_"+id).remove();
                        }else{
                            alert(responseText);
                        }
                    }
    });        
    
}
function selectMedia(idMedia,idCategory,fullPathMedia,relPathMedia,baseMedia,fromEditor){

	fromEditor = typeof fromEditor !== 'undefined' ? fromEditor : 0;

    if(fromEditor == '0'){
        if( targettedField != '' && $("#"+targettedField))
        $("#"+targettedField).val(relPathMedia);
    
        if( targettedField != '' && $("#"+targettedField+'_media'))
        $("#"+targettedField+'_media').attr("src",fullPathMedia);
        
    }else{
        $("#"+targettedField).val(fullPathMedia);
    }

    if(selectedMedia != ''){
        $("#edittdMedia_"+selectedMedia).css('display','none');
    }
    
    if(selectedMedia != idMedia)
    $("#editSelectMedia_"+idMedia).val(idCategory);
    
    $("#edittdMedia_"+idMedia).css('display','block');
    
    selectedMedia = idMedia;
    unloadPopupBox('media');
    
}
function changedCategory(){

    var currentCategory = document.getElementById('category_id').value;
    
    if( currentCategory == 7 )
    $('#currentaffairs').css('display','block');
    else
    $('#currentaffairs').css('display','none');
    
    return true;
}
var targettedField = '';

function media(mediaFor,fromEditor){
    targettedField = mediaFor;
    
    if( $("#media").length == 0 ){
	    loadPopupBox("media",mediaClosed);
	    $("#media").append('<div class="grid_12" id="mediaHolder"></div>');
    }

    loadMedia('',fromEditor);
}
function loadMedia(ele,fromEditor){

    selectedMedia = '';
    var searchInMedia         = getValueFromId('searchInMedia','');
    var typeMedia         	  = getValueFromId(targettedField+'_allowed_types','');
    var searchQueryMedia      = getValueFromId('searchQueryMedia','');
    var searchCategoryMedia   = getValueFromId('searchCategoryMedia','');
    var searchOrderbyMedia    = getValueFromId('searchOrderbyMedia','');
    var searchOrdertypeMedia  = getValueFromId('searchOrdertypeMedia','');
    var searchnoPageMedia     = parseInt(getValueFromId('searchnoPageMedia',''));
    var searchperPageMedia    = parseInt(getValueFromId('searchperPageMedia',''));

    if( ele == 'First' ) searchnoPageMedia = 1;
    else if( ele == 'Previous' ) searchnoPageMedia = searchnoPageMedia - 1;
    else if( ele == 'Next' ) searchnoPageMedia = searchnoPageMedia + 1;
    else if( ele == 'Last' ) searchnoPageMedia = searchnoPageMedia + 10000;
    else if( ele != '' ) searchnoPageMedia = ele ;

    var pass_url  = '/ajax.php?action='+plugin_media_path+'/backend/includes/modules/ajax/get/list/media';
    var pass_data = 'fromEditor='+fromEditor+'&typeMedia='+typeMedia+'&searchInMedia='+searchInMedia+'&searchQueryMedia='+searchQueryMedia+'&searchCategoryMedia='+searchCategoryMedia+'&searchOrderbyMedia='+searchOrderbyMedia+'&searchOrdertypeMedia='+searchOrdertypeMedia;
    pass_data = pass_data + '&searchnoPageMedia='+searchnoPageMedia+'&searchperPageMedia='+searchperPageMedia;

    $.ajax({
        type        : "POST",
        beforeSend  : loadingStarts,
        url         : adminUrl+pass_url,
        data        : pass_data,
        success     : function(responseText){
                        loadingEnds();
                        $("#mediaHolder").html(responseText);
                        centerElement('media');
                    }
    });        
}
function mediaClosed(){
	unloadPopupBox('mediauploadpopup');
}
function iconMediaDelete(idMedia,ele){   
    if(!document.getElementById('media_close_'+idMedia)) return false;
    if( ele == 0){
        document.getElementById('media_close_'+idMedia).style.display = 'none';   
    }else{
        document.getElementById('media_close_'+idMedia).style.display = 'block';  
    }
    return true;
}
function updateMedia(){

    if( !confirm("Are you sure you want to update all the Media items?") )
    return false;

    var pass_url = '/ajax.php?action='+plugin_media_path+'/backend/includes/modules/ajax/set/updatemedia';
    var pass_data = 'do=update';
    
    $.ajax({
        type        : "POST",
        beforeSend  : loadingStarts,
        url         : adminUrl+pass_url,
        data        : pass_data,
        success     : function(responseText){
                        loadingEnds();
                        if(responseText == 'ok' ){
	                        loadMedia();
                        }else{
                            alert(responseText);
                        }
                    }
    });        
    
}
var uploadMediaFormContent = '';
function uploadMedia(){	

	if($('#mediaupload').length != 0){
		uploadMediaFormContent = $('#mediaupload').html();
		$('#mediaupload').remove();
	}
	
	if($('#mediauploadpopup').length == 0) {
		loadPopupBox('mediauploadpopup',function(){loadMedia('',0)});
		centerElement('mediauploadpopup','500');
		$('#mediauploadpopup').append(uploadMediaFormContent);
		updateZindex('mediauploadpopup',zindex +5);

	    var Mediabar = $('.Mediabar');
	    var Mediapercent = $('.Mediapercent');
	    var Mediastatus = $('#Mediastatus');      
		
	    $('#MediaForm').ajaxForm({    
	        beforeSend: function() {
	            Mediastatus.empty();
	            var percentVal = '0%';
	            Mediabar.width(percentVal)
	            Mediapercent.html(percentVal);
	        },
	        uploadProgress: function(event, position, total, percentComplete) {
	            var percentVal = percentComplete + '%';
	            Mediabar.width(percentVal)
	            Mediapercent.html(percentVal);
	        },
	        success: function() {
	            var percentVal = '100%';
	            Mediabar.width(percentVal)
	            Mediapercent.html(percentVal);
	        },
	        complete: function(xhr) {
	            Mediastatus.html(xhr.responseText);      
	        }
	    });   
	}
}