<?php
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

Config::_setTable('media'      			, 'media' );
Config::_setTable('media_categories'    , 'media_categories' );

