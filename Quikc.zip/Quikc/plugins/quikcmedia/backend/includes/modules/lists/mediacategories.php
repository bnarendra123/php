<?php
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$actions = array("status","edit","delete");
$displayFields  = array(   array( "id" => "idCategory", 				"title" => 'Category Id'      ,"type" => 'text'    ,"dbField" => true ,"tpx" =>'mc',"display" => ':data'), 
						   array( "id" => "nameCategory",    			"title" => 'Category Name'    ,"type" => 'text'    ,"dbField" => true ,"tpx" =>'mc',"display" => ':data'),  
						   array( "id" => "statusCategory",  			"title" => 'Category Status'  ,"type" => 'select'  ,"dbField" => true ,"tpx" =>'mc',"display" => ':data',"set" => 'status'), 
						   array( "id" => "dateAdditionMediaCategory",  "title" => 'Created on'		  ,"type" => 'date'    ,"dbField" => true ,"tpx" =>'mc',"display" => ':data'), 
						   array( "id" => "dateUpdationMediaCategory",  "title" => 'Updated on'    	  ,"type" => 'date'    ,"dbField" => true ,"tpx" =>'mc',"display" => ':data'),  
						   array( "id" => "actions",         			"title" => 'Actions'          ,"type" => 'actions' ,"dbField" => false,"tpx" =>'mc',"display" => '',"set" => $actions)
					  );
						   
$usersData = array(     
		"sql"           => " select * from ".Config::_getTable('media_categories')." mc ",    
		"where"         => "",
		"arrayBind"     => "",    
		"sortby"        => "nameCategory",     
		"order"         => "asc",    
		"headding"      => Config::_getMessage('lists.media.categories.title'),     
		"primaryField"  => "idCategory",     
		"statusField"   => "statusCategory",
		//  Fields from here are same for all (in general)    
	    "multiActions"  => true, 
		"multiLanguages"=> false,     
		"displayFields" => $displayFields,    
		"page"          => 1, 
	    "perpage"       => 10, 
	    "displaypages"  => 10, 
	    "filename"      => $Base->_getFileName(__FILE__)
);
