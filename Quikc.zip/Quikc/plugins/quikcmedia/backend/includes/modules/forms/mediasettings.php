<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields[] = array("id" => "mediaallowupload",  "type" => "checkbox",	"label" => "Allow File Upload","req" => false ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="Files are allowed to upload if the checkbox is checked." />');

$formFields[] = array("id" => "mediamaxfilesize",  "type" => "text",	"label" => "Maximum File Upload Size","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'MB<span class="fieldhelp" title="Maximum upload file size allowed." />');

$formFields[] = array("id" => "mediaallowedtypes",  "type" => "text",	"label" => "Allowed Media Extensions","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="The given extensions are only allowed for uploading. Use , to seperate multiple extensions." />');

$formFields[] = array("id" => "mediasetsimg", "type" => "text",	"label" => "Image Extensions","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="Allowed Image extensions. Use , to seperate multiple extensions." />');

$formFields[] = array("id" => "mediasetsvid",  "type" => "text",	"label" => "Video Extensions","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="Allowed Image extensions. Use , to seperate multiple extensions." />');

$formFields[] = array("id" => "mediasetsdoc",  "type" => "text",	"label" => "Document Extensions","req" => true ,"value" => "", "additional" => '',
"postFieldLable"=>'<span class="fieldhelp" title="Allowed Image extensions. Use , to seperate multiple extensions." />');

$formFields[] = array("id" => "",		 "type" => "Button","label" => "",			"req" => false,"value" => "Proceed","additional" => 'class="submit-btn"' );

$forms = array(
	"identifier" 	=> "mediaSettingsForm", 
	"name" 			=> "Media Settings", 
	"primaryFiled" 	=> "idSystemconfig", 
    "url"           => Config::_get('current.plugin')."/backend/includes/modules/ajax/set/".$Base->_getFileName(__FILE__),
	"success" 		=> "message_reporting('message_:FORM_ID','Your details saved successfully.',1);", 
	"closeLink" 	=> "",
	"filename" 		=> $Base->_getFileName(__FILE__),
	"fields" 		=> $formFields
); 
