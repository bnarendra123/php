<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

extract($_POST);
if(!isset($dataFilter)) $dataFilter = '';
$formFields[] = array("id" => "nameCategory"    ,"type" => "Text"   ,"label" => "Category Name"   ,"req" => true ,"value" => "",  "additional" => '');
$formFields[] = array("id" => "statusCategory"  ,"type" => "Select" ,"label" => "Category Status" ,"req" => true ,"value" => "1", "additional" => '',"set" => "status");
$formFields[] = array("id" => ""                ,"type" => "Button" ,"label" => ""                , "req" =>false,"value" => "Proceed" ,"additional" => 'class="submit-btn"' );
$forms = array(
    "identifier"    => "idCategory",     
    "name"          => "New Media Category",     
    "primaryFiled"  => "idCategory",     
    "url"           => Config::_get('current.plugin')."/backend/includes/modules/ajax/set/".$Base->_getFileName(__FILE__),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
    "filename"      => $Base->_getFileName(__FILE__),
    "fields"        => $formFields
);
