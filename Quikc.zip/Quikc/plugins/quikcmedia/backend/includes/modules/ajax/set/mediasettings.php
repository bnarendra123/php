<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){

	$processedForm = $Forms->_processForm($forms,$_POST);

	extract($processedForm['formElements']);

	if( floatval($mediamaxfilesize) <= 0 ){
		$processedForm['error'][] = 'Please Enter a valid maximum upload file size.';
	}
	
	if( count($processedForm['error']) != 0 ){		
		$Base->_convertError($processedForm['error'],false);
	}

	$fields =  array("mediaallowupload" 				=>  'media.allow.upload',
					 "mediamaxfilesize" 				=>  'media.max.file.size',
					 "mediaallowedtypes" 				=>  'media.allowed.types',
					 "mediasetsimg" 					=>  'media.sets.img',
					 "mediasetsvid" 					=>  'media.sets.vid',
					 "mediasetsdoc" 					=>  'media.sets.doc',
               );

	if( !$Permissions->_checkPagePermission($Base->_getFileName(__FILE__),'edit') ){
		$Base->_accessRestricted();
	}

	$setpPart = array();
	
	foreach($fields as $keyField => $keyValue){
	    Config::_updateDbConfigEntry($keyValue,$$keyField);
	}
	die('ok');
}
