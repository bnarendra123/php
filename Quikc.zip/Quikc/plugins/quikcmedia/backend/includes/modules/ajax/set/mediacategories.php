<?php
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if($_POST){

    extract($_POST);

    if($do == 'edit'){
    	
	    $processedForm = $Forms->_processForm($forms,$_POST);        
		extract($processedForm['formElements']);
		
        if( count($processedForm['error']) != 0 ){
            $Base->_convertError($processedForm['error'],false);
        }

		$fields = $processedForm['fields'];
				       
        if($formPrimaryField == -1){
 
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }
			
            $insertKeys  = array();
			$insertValues= array();   
			         
			foreach($fields as $field){
				
                $insertKeys[]  = "`$field`";                
                $insertValues[]= ":$field";                
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }        
			    
            $query = "insert into ".Config::_getTable('media_categories')." (".implode(",",$insertKeys).",dateAdditionMediaCategory) values (".implode(",",$insertValues).",NOW())";            
            Core::_runQuery($query, $arrayBind);        

		}else{
					
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }
			
            $setpPart = array();
			
            foreach($fields as $field){
            	
                $setpPart[] = "`$field`=:$field";                
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
			
            $query  = "update ".Config::_getTable('media_categories')." set ".implode(",",$setpPart)." where idCategory = :idCategory";            
            $arrayBind[]= array("key" => ":idCategory", "value" =>  $formPrimaryField);
            $statusQuery= Core::_runQuery($query,$arrayBind);
        }
        
    }else if($do == 'status'){
    	
        if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
            $Base->_accessRestricted();
        }
        $id = $_POST['id'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusCategory";
        }

        // Status change query
        $query  = "update ".Config::_getTable('media_categories')." set statusCategory = ".$changeToField." where idCategory = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
        }
    }else if($do == 'delete'){
    	
        if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
            $Base->_accessRestricted();
        }

        $id = $_POST['id'];
		
        // Exploding to get the ids
        $idArray = explode(",",$id);

        $query  = "delete from ".Config::_getTable('media_categories')." where idCategory = :idCategory";       
        foreach($idArray as $tmpId){

            unset($arrayBind);
            $arrayBind[]= array("key" => ":idCategory", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
        }
    }
    die($messageDie);
}