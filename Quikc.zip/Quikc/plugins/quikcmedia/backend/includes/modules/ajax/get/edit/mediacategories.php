<?php
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}
if(!$_POST){
    die();
}
extract($_POST);

if($formPrimaryField != -1){
    unset($arrayBind);
    // Retrieving the details of the categories
    $query = "select * from ".Config::_getTable('media_categories')." where idCategory = :idCategory";    
    $arrayBind[] = array("key" => ":idCategory", "value" => $formPrimaryField );    
    $detailsCategory = Core::_getRow($query,$arrayBind);
    $forms['name']      = "Editing Media Category : ".$detailsCategory->nameCategory;
}else{
    $detailsCategory = '';
}
echo $Forms->_generateForm($forms,$detailsCategory);
