<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if($_POST){
	
	 extract($_POST);
	
    if($do == 'edit'){   	
        if( !$Permissions->_checkPagePermission('media','create') ){
            $Base->_accessRestricted();
        }
		
        $fields = array('idCategory');        
        $setpPart = array();
		
        foreach($fields as $field){        	
            $setpPart[] = "`$field`=:$field";            
            $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
        }
		
        $query  = "update ".Config::_getTable('media')." set ".implode(",",$setpPart)." where idMedia = :idMedia";
        $arrayBind[]= array("key" => ":idMedia", "value" =>  $id);
        Core::_runQuery($query,$arrayBind);
		
		$User->_addUserLogActivity( $User -> idUser(),12);
        
    }else if($do == 'delete'){

        if( !$Permissions->_checkPagePermission('media','delete') ){
            $Base->_accessRestricted();
        }
		
        unlink(Config::_getDir('img').'/'.Media::_getInstance()->_getMediaPath($id));
        $arrayBind[]= array("key" => ":idMedia", "value" =>  $id);
        $query  = "delete from ".Config::_getTable('media')." where idMedia = :idMedia";
        Core::_runQuery($query,$arrayBind);
		
		$User->_addUserLogActivity($User -> idUser(),13);

    }
    die('ok');
}

