<?php							

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
	$Base->_accessRestricted();
}

if(!$_POST){
	die();
}

extract($_POST);

$detailssystemconfig = (object)array("mediaallowupload" 				=>  Config::_get('media.allow.upload'),
									 "mediamaxfilesize" 				=>  Config::_get('media.max.file.size'),
									 "mediaallowedtypes" 				=>  Config::_get('media.allowed.types'),
									 "mediasetsimg" 					=>  Config::_get('media.sets.img'),
									 "mediasetsvid" 					=>  Config::_get('media.sets.vid'),
									 "mediasetsdoc" 					=>  Config::_get('media.sets.doc'),
                       );

echo $Forms->_generateForm($forms,$detailssystemconfig);