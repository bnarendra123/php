<?php
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if(!Config::_get('media.allow.upload')){
	
	$linkSettings = '<a href="javascript:generateEditor(\''.Config::_get('current.plugin').'/backend/includes/modules/ajax/get/edit/mediasettings\',\'edit\')">Click here to edit</a>';
    $Base->_convertError(array("File upload option disabled. Please Enable it in Media Settings.$linkSettings"),false);
}

if(!isset($_FILES) || !isset($_FILES['myfile']) || !isset($_FILES['myfile']['name']) || !isset($_FILES['myfile']['tmp_name']) || !isset($_FILES['myfile']['size'])){
    $Base->_convertError(array("Please Select files to upload"),false);
}

$name    = $_FILES['myfile']['name'];
$tmppath = $_FILES['myfile']['tmp_name'];
$size    = $_FILES['myfile']['size'];

$totalfiles  = count($name);

$allowedExtensions  = array_map('strtolower', explode(",",Config::_get('media.allowed.types')));
$maxFileSize  		= Config::_get('media.max.file.size');
$imgExtensions   	= array_map('strtolower', explode(",",Config::_get('media.sets.img')));
$vidExtensions  	= array_map('strtolower', explode(",",Config::_get('media.sets.vid')));
$docExtensions  	= array_map('strtolower', explode(",",Config::_get('media.sets.doc')));

$categoryid  = $_POST['selectcategory'];
$process['failure'] = $process['success'] = array();

for($i=0; $i < $totalfiles; $i++) {
	
    $fileParts = pathinfo($name[$i]);    
    $fileParts['extension'] = strtolower($fileParts['extension']);
    
    if(in_array($fileParts['extension'],$allowedExtensions)){
	    if( $size[$i] <= ($maxFileSize * 1024 * 1024) ){
	    	
	        $nameMedia = $name[$i];
	
	        $name[$i] = $Base->_generateRandomString(10)."_".$name[$i];		
	
			$widthMedia = $heightMedia = 0;
	
		    if(in_array($fileParts['extension'],$imgExtensions)){
	
				list($widthMedia, $heightMedia, $typeMedia, $attr) = getimagesize($tmppath[$i]);
				$uploadDir = Config::_getDir('img');
				$new_categoryid = 1;
	
			}else if(in_array($fileParts['extension'],$vidExtensions)){
	
				$uploadDir = Config::_getDir('vid');
	        	$new_categoryid = 2;
	
			}else if(in_array($fileParts['extension'],$docExtensions)){
				
				$uploadDir = Config::_getDir('doc');
				$new_categoryid = 3;
			}else{
				$uploadDir = dirname(Config::_getDir('doc'));
				$new_categoryid = 0;
			}
	
	        move_uploaded_file($tmppath[$i],$uploadDir.'/'.$name[$i]);
	
	        if($categoryid == 0){
	        	$categoryid = $new_categoryid;
	        }
			
	        $query  = "insert into ".Config::_getTable('media')." (`pathMedia`,`nameMedia`,`typeMedia`,`widthMedia`,`heightMedia`,`sizeMedia`,`idCategory`,`time`) values (:pathMedia,:nameMedia,:typeMedia,:widthMedia,:heightMedia,:sizeMedia,:idCategory,NOW())";
	        unset($arrayBind);
	        $arrayBind[] = array("key" => ":pathMedia",     "value" =>  $name[$i]);
	        $arrayBind[] = array("key" => ":nameMedia",     "value" =>  $nameMedia);
	        $arrayBind[] = array("key" => ":typeMedia",     "value" =>  $fileParts['extension']);
	        $arrayBind[] = array("key" => ":widthMedia",    "value" =>  $widthMedia);
	        $arrayBind[] = array("key" => ":heightMedia",   "value" =>  $heightMedia);
	        $arrayBind[] = array("key" => ":sizeMedia",   	"value" =>  $size[$i]);
	        $arrayBind[] = array("key" => ":idCategory",    "value" =>  $categoryid);
	        $statusQuery = Core::_runQuery($query,$arrayBind);
	
	        $process['success'][] = $name[$i].' file of size '.$Base->_convertByes($size[$i]).' uploaded Successfully ';
	        $User->_addUserLogActivity($User -> idUser(),11);
	    }else{
	        $process['failure'][] = "Maximum File size of ".$maxFileSize.' MB exceed for '.$name[$i];
	    }   
    }else{
        $process['failure'][] = "Invalid File Format ".$fileParts['extension'] .' for '.$name[$i];
    }   
}

$output  = $Base->_convertError($process['failure'],true);
$output .= $Base->_convertError($process['success'],true);

echo $output;
