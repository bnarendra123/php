<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

if( !$Permissions->_checkPagePermission(__FILE__,'view') ){
    $Base->_accessRestricted();
}

$columns = array("idMedia"     =>"Media Id",
                 "nameMedia"   =>"Media Name",
                 "typeMedia"   =>"Media Type",
                 "widthMedia"  =>"Media Width",
                 "heightMedia" =>"Media Height",
                 "sizeMedia"   =>"Media Size",
                 "uses"        =>"Uses",
                 "starred"     =>"Starred",
                 "time"        =>"Upload Date"
           );  

$Ordertype = array("asc"   =>"Ascending",
                   "desc"  =>"Descending"
             );           

$searchdisplaypagesMedia = 5; 
$perRow = 10;

if(!isset($_POST) || !isset($_POST['typeMedia'])){

    echo'<div class="grid_12" id="mediaHolder">';

    $typeMedia = '';
    $searchInMedia = '';
    $searchQueryMedia = '';
    $searchCategoryMedia = '';
    $searchOrderbyMedia = '';
    $searchOrdertypeMedia = ''; 
    $searchnoPageMedia = 1; 
    $searchperPageMedia = ''; 
    $fromEditor = 0;    

}else{
    extract($_POST);
}

if( !array_key_exists($searchOrderbyMedia,$columns) ){
    $searchOrderbyMedia = 'time'; 
    $searchOrdertypeMedia = 'desc'; 
}

if( (int)$searchperPageMedia == 0 ){
    $searchperPageMedia = 20; 
}

$query = "select * from ".Config::_getTable('media')." ";
$whereArray = $arrayBind = array();

if( $typeMedia == 'img' ){
	$allowedExtensions   = array_map('strtolower', explode(",",Config::_get('media.sets.img')));
}else if( $typeMedia == 'vid' ){
	$allowedExtensions   = array_map('strtolower', explode(",",Config::_get('media.sets.vid')));
}else if( $typeMedia == 'doc' ){
	$allowedExtensions   = array_map('strtolower', explode(",",Config::_get('media.sets.doc')));
}else{
	$allowedExtensions = explode(',',$typeMedia);
}

if($typeMedia != '' && $typeMedia != 'undefined'){
	$whereArray[] = " typeMedia in ('".implode("','",$allowedExtensions)."') ";
}

if( $searchInMedia != '' && array_key_exists($searchInMedia,$columns) && $searchQueryMedia != ''){
    $whereArray[] = " $searchInMedia like :searchQueryMedia ";
    $arrayBind[]= array("key" => ":searchQueryMedia","value" => "%".$searchQueryMedia."%");
}

if( $searchCategoryMedia != ''){
    $whereArray[] = " idCategory = :idCategory";
    $arrayBind[]= array("key" => ":idCategory", "value" =>  $searchCategoryMedia);
}

if( count($whereArray) > 0 ){
    $query .= " where ".implode(" and ",$whereArray);
}

if( $searchOrderbyMedia != '' && array_key_exists($searchOrderbyMedia,$columns) ){
    $query .= " order by $searchOrderbyMedia ";

    if( $searchOrdertypeMedia != '' && array_key_exists($searchOrdertypeMedia,$Ordertype) ){
        $query .= " $searchOrdertypeMedia ";
    }
}

$gQuery["sql"] = $query;
$gQuery["arrayBind"] = $arrayBind;
$pagination = $Base->_generatePagination($gQuery,$searchnoPageMedia,$searchperPageMedia,$searchdisplaypagesMedia);

$query  .= " limit :LL,:LT ";
$arrayBind[] = array("key" => ":LL", "value" =>  (int)$pagination['LL'] , "type" => PDO::PARAM_INT);
$arrayBind[] = array("key" => ":LT", "value" =>  (int)$pagination['LT'] , "type" => PDO::PARAM_INT);

$listMedia = Core::_getAllRows($query,$arrayBind);

?>
    <div class="module">
        <h2><span>Media : <?php echo $pagination['DF'].' - '.$pagination['DT'].' of '.$pagination['TR']; ?></span></h2>
        <div class="searchdiv">
        	<a href="javascript:updateMedia()">Update Media</a>
        	<input type="button" value="Upload Images" onclick="javascript:uploadMedia()"/>
            <select id="searchInMedia" >
                <option value="">Search In</option>
                <?php 
                foreach ($columns as $key => $value){
                    if($searchInMedia == $key) $selected = 'selected="selected"'; else $selected = '';
                    echo '<option value='.$key.' '.$selected.'>'.$value.'</option>';
                }
                ?>
            </select>
            <input type="text" id="searchQueryMedia" value="<?php echo $searchQueryMedia; ?>" placeholder="Search Query" onkeypress="return Ajax_Submit(event,'loadMedia');">
            <select id="searchCategoryMedia" >
                <option value="">Select Category</option>
                <?php
                $query = "select * from ".Config::_getTable('media_categories')." where statusCategory = 1 order by nameCategory asc";
                $listCategory = Core::_getAllRows($query,'');
				
                foreach ($listCategory as $key => $value){
                    if($searchCategoryMedia == $value->idCategory) $selected = 'selected="selected"'; else $selected = '';
                    echo '<option value='.$value->idCategory.' '.$selected.'>'.$value->nameCategory.'</option>';
                }
                ?>
            </select>
            <select id="searchOrderbyMedia" >
                <option value="">Order By</option>
                <?php
                foreach ($columns as $key => $value){
                    if($searchOrderbyMedia == $key) $selected = 'selected="selected"'; else $selected = '';
                    echo '<option value='.$key.' '.$selected.'>'.$value.'</option>';
                }
                ?>
            </select>
            <select id="searchOrdertypeMedia" >
                <?php
                foreach ($Ordertype as $key => $value){
                    if($searchOrdertypeMedia == $key) $selected = 'selected="selected"'; else $selected = '';
                    echo '<option value='.$key.' '.$selected.'>'.$value.'</option>';
                }
                ?>
            </select>
            <input type="submit" value="Go" onclick="loadMedia('',<?php echo $fromEditor;?>);" class="submit-green" >
        </div>
        <table border=0 cellpadding="5" cellspacing="5" class="module-table-body">
        <?php
        $i = 1;
        $j = false;
        if( $pagination['TR'] > 0 ){
            $editCategories = '<option>Select Category</option>';

            foreach ($listCategory as $key => $value){
                $editCategories .= '<option value='.$value->idCategory.'>'.$value->nameCategory.'</option>';
            }
   
            foreach($listMedia as $key => $tmpMedia){

                if($i == 1){
                    //$class = $j?'class="even"':'class="odd"';
                    echo '<tr class="odd">';                
                    //$j = !$j;
                }   

                $dimenssionsMedia = $tmpMedia->widthMedia.'x'.$tmpMedia->heightMedia;

                echo '<td class="tdMediaRow" id="media_td_'.$tmpMedia->idMedia.'" onmouseover="return iconMediaDelete('.$tmpMedia->idMedia.',1);" onmouseout="return iconMediaDelete('.$tmpMedia->idMedia.',0);">
                          <table style="border:0px;">
                          <tr class="odd"><td>
                          	<img onclick="return selectMedia('.$tmpMedia->idMedia.','.$tmpMedia->idCategory.',\''.$Base->_displayPhpthumb($tmpMedia->pathMedia,75,75).'\',\''.$tmpMedia->pathMedia.'\',\'\','.$fromEditor.');" src="'.$Base->_displayPhpthumb($tmpMedia->pathMedia,100,100).'" class="Media" />
                          </td></tr>
                          <tr class="odd"><td>
                          	'.$dimenssionsMedia.'('.$tmpMedia->typeMedia.')
                          	<br/>'.$Base->_convertByes($tmpMedia->sizeMedia).'
                          	<br/>'.wordwrap($tmpMedia->nameMedia, 12, "<br />\n", true).'';
							
							  if($Permissions->_checkPagePermission(__FILE__,'delete')){
		                         echo '<img src="'.Config::_getUrl().Config::_get('admin.temp').'/images/cross-on-white.gif" id="media_close_'.$tmpMedia->idMedia.'" class="MediaDelete" onclick="deleteMedia('.$tmpMedia->idMedia.')"/>';
							  }

                          echo '</td></tr>
                          <tr class="odd"><td>';

						  if($Permissions->_checkPagePermission(__FILE__,'edit')){
                             echo '<div id="edittdMedia_'.$tmpMedia->idMedia.'" style="display: none">
                                    <select id="editSelectMedia_'.$tmpMedia->idMedia.'" style="width:100px">
                                    '.$editCategories.'
                                    </select><br/>
                                    <input type="button" value="Update" onclick="editMedia('.$tmpMedia->idMedia.')"/>              
                                </div>'; 
						  }                                     
                          echo '</td></tr>
                          </table>
                      </td>';
                if($i == $perRow){
                    $i = 0;
                    echo '</tr>';
                }
                $i++;
            }
        }else{
	        echo '<tr class="even"><td colspan="'.$perRow.'" align="center">No Media Items Found</td></tr>';
        }

        if( $i != 0){
            for(;$i<=$perRow;$i++){
                echo '<td/>';
            }    
            echo '</tr>';
        }   
        ?>

        <tr <?php echo $j?'class="even"':'class="odd"'; ?>><td colspan="<?php echo $perRow; ?>">
            <div class="pager" id="pager">
                <?php echo '
                <div>
                <a href="javascript:loadMedia(\'First\','.$fromEditor.');">
                    <img class="first" src="'.Config::_getUrl('admin.temp').'/images/arrow-stop-180.gif" alt="first">
                </a>
                <a href="javascript:loadMedia(\'Previous\','.$fromEditor.');">
                    <img class="prev" src="'.Config::_getUrl('admin.temp').'/images/arrow-180.gif" alt="prev"> 
                </a>
                <input type="text" class="pagedisplay input-short align-center" value="'.$pagination['current_page'].'" id="searchnoPageMedia" onkeypress="return Ajax_Submit(event,\'loadMedia\');">
                <a href="javascript:loadMedia(\'Next\','.$fromEditor.');">
                    <img class="next" src="'.Config::_getUrl('admin.temp').'/images/arrow.gif" alt="next">
                </a>
                <a href="javascript:loadMedia(\'Last\','.$fromEditor.');">
                    <img class="last" src="'.Config::_getUrl('admin.temp').'/images/arrow-stop.gif" alt="last"> 
                </a>
                Per Page<input type="text" class="pagedisplay input-short align-center" value="'.$pagination['PP'].'" id="searchperPageMedia" onkeypress="return Ajax_Submit(event,\'loadMedia\');">
                <input class="submit-green" type="button" value="Go" onclick="return loadMedia(\'\','.$fromEditor.')">
                </div>';
                ?>
            </div>
            <div class="table-apply" style="width:55%">
                <div class="pagination">           
                    <div class="numbers">
                        <span>Page:</span> 
                        <?php
                        // $i value to find the last row
                        $i = 0;
                        foreach( $pagination['pages'] as $key => $page ){
	                        // Generating the page text
                            echo ($page['key'] == $pagination['current_page'] ? $page['value'] : '<a href="javascript:loadMedia('.$page['key'].','.$fromEditor.')">
    	                    '.$page['value'].'</a>');
                            if(++$i != count($pagination['pages']) ) {
                            echo '<span>|</span> ';
                            }
                        }
                        $j = !$j;
                        ?>
                    </div> 
                <div style="clear: both;"></div> 
             </div>
        </div>          
        </td></tr>
        <tr <?php echo $j?'class="even"':'class="odd"'; ?>><td colspan="<?php echo $perRow; ?>">
        <!--Media upload html starts-->
        <div id="mediaupload" style="display:none;overflow:auto">
            <form id="MediaForm" action="ajax.php?action=<?php echo Config::_get('current.plugin'); ?>/backend/includes/modules/ajax/set/mediaupload" method="post" enctype="multipart/form-data">
            <table class="uploadTable">
            	<tr><td>Upload Media File :</td><td><input type="file" name="myfile[]" multiple></td></tr>
            	<tr><td>Select Category :</td>
	            	<td>
		                <select id="selectcategory" name="selectcategory">
		                    <option>Select Category</option>
		                    <?php
		                    foreach ($listCategory as $key => $value){
		                        if($searchCategoryMedia == $value->idCategory) $selected = 'selected="selected"'; else $selected = '';
		                        echo '<option value='.$value->idCategory.' '.$selected.'>'.$value->nameCategory.'</option>';
		                    }
		                    ?>
		                </select>
	            	</td>
            	</tr>
            	<tr><td></td><td><input type="submit" value="Upload" class="submit-btn" ></td></tr>
            	<tr><td colspan="2">
		            <div class="Mediaprogress progress">
		                <div class="Mediabar bar"></div >
		                <div class="Mediapercent percent">0%</div >
		            </div>           
		            <div id="Mediastatus"></div>
            	</td></tr>
            </table>
            </form>            
        </div>
        <!--Media upload html ends-->
     </td></tr>
     </table>
<?php     

if(!isset($_POST)){
    echo'</div>';
}           
?>
<style>
.uploadTable td{
	padding: 5px;
}
.tdMediaRow{
    vertical-align: top;
}
.Media{
    cursor:pointer;
    float:left;
    max-width: 100px;
	max-height: 100px;
}
.MediaDelete{
    position: relative;
    right: -88px;
    bottom: 14px;
	margin-bottom: -16px;
    z-index:10000;
    display:none;
}
#mediaupload{ 
	display:none; /* Hide the DIV */
	position:fixed;  
	_position:absolute; /* hack for internet explorer 6 */  
	height:130px;  
	width:700px;  
	background:#FFFFFF;  
	z-index:1500; /* Layering ( on-top of others), if you have lots of layers: I just maximized, you can change it yourself */
	margin-left: 15px;  
	
	/* additional features, can be omitted */
	border:2px solid #006EB9;  	
	padding:15px;  
	font-size:15px;  
}
.closebutton {
background: #F4F4F4;
padding: 6px 14px;
font-size: 15px;
text-transform: uppercase;
color: #006EB9;
font-weight: bold;
}
#MediaForm{
	background: #fff;
}
</style>