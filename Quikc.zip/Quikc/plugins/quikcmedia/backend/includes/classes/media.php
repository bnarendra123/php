<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* Media class, contains functions related to Medias plugin
* This includes 
*
* @version 1.0
* @http://www.quikc.org/
*/

class Media {

    /**
    * Contains the object of the current variable
    *
    * @var Object
    */
    private static $instance;

    /* Basic Configuration functions starts from here
    
    <!-----------------------------------------------------------------------------------------------------------------------------------------
    */

    /** Checks the database connection status and connets if there is not connection
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){
        
        if (null === self::$instance) {
            // Getting the name of the class. Here it is Core
            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }
		
    /**
    * Return the media path from media id
    *
    * @param media id(int)
    * @return media path(string)
    */
	public function _getMediaPath($idMedia){
		// query for selecting image_path 
		$query	= " select pathMedia from ".Config::_getTable('media')." where idMedia = :idMedia ";
		// bind values
		$arrayBind[]= array("key" => ":idMedia", "value" => $idMedia);
		// executing query
		$detailsMedia = Core::_getRow($query,$arrayBind);
        if(isset($detailsMedia->pathMedia)) return $detailsMedia->pathMedia;
        return false;
	}

 	/** 
    * Updates medis entry
    *
    * @param image id(int)
    * @return image path(string)
    */
    public function _updateMediaEntries($locationMedia){
	    $fileParts = pathinfo($locationMedia);    

		$fileParts['extension']	= strtolower($fileParts['extension']);

		$allowedExtensions  = array_map('strtolower', explode(",",Config::_get('media.allowed.types')));

		if(!in_array($fileParts['extension'],$allowedExtensions)) return false;

        $query  = "select * from ".Config::_getTable('media')." where pathMedia = :pathMedia";
        $arrayBind[] = array("key" => ":pathMedia",     "value" =>  $fileParts['basename']);
        $countMedia = Core::_getRowCount($query,$arrayBind);

		$nameArray = explode("_",$fileParts['filename']);
		if(count($nameArray) > 1)array_shift($nameArray);
		$nameMedia = implode("_",$nameArray);

		$imgExtensions   	= array_map('strtolower', explode(",",Config::_get('media.sets.img')));
		$vidExtensions  	= array_map('strtolower', explode(",",Config::_get('media.sets.vid')));
		$docExtensions  	= array_map('strtolower', explode(",",Config::_get('media.sets.doc')));

		$widthMedia = $heightMedia = $categoryid = 0;

	    if(in_array($fileParts['extension'],$imgExtensions)){
			list($widthMedia, $heightMedia, $typeMedia, $attr) = getimagesize($locationMedia);
			$categoryid = 1;
		}else if(in_array($fileParts['extension'],$vidExtensions)){
        	$categoryid = 2;
		}else if(in_array($fileParts['extension'],$docExtensions)){
			$categoryid = 3;
		}
		
		if( $countMedia == 0){
	        $query  = "insert into ".Config::_getTable('media')." (`pathMedia`,`nameMedia`,`typeMedia`,`widthMedia`,`heightMedia`,`sizeMedia`,`idCategory`,`time`) values (:pathMedia,:nameMedia,:typeMedia,:widthMedia,:heightMedia,:sizeMedia,:idCategory,NOW())";
	        unset($arrayBind);
	        $arrayBind[] = array("key" => ":pathMedia",     "value" =>  $fileParts['basename']);
	        $arrayBind[] = array("key" => ":nameMedia",     "value" =>  $nameMedia);
	        $arrayBind[] = array("key" => ":typeMedia",     "value" =>  $fileParts['extension']);
	        $arrayBind[] = array("key" => ":widthMedia",    "value" =>  $widthMedia);
	        $arrayBind[] = array("key" => ":heightMedia",   "value" =>  $heightMedia);
	        $arrayBind[] = array("key" => ":sizeMedia",   	"value" =>  filesize($locationMedia));
	        $arrayBind[] = array("key" => ":idCategory",    "value" =>  $categoryid);
	        Core::_runQuery($query,$arrayBind);
		}else{
			$detailsMedia = Core::_getRow($query,$arrayBind);
			if( $detailsMedia->nameMedia == '' ) $detailsMedia->nameMedia = $nameMedia;
		    $query  = "update ".Config::_getTable('media')." set `nameMedia`=:nameMedia,`typeMedia`=:typeMedia,`widthMedia`=:widthMedia,`heightMedia`=:heightMedia,
		    `sizeMedia`=:sizeMedia where pathMedia = :pathMedia ";
		    unset($arrayBind);
	        $arrayBind[] = array("key" => ":pathMedia",     "value" =>  $fileParts['basename']);
		    $arrayBind[] = array("key" => ":nameMedia",     "value" =>  $detailsMedia->nameMedia);
		    $arrayBind[] = array("key" => ":typeMedia",     "value" =>  $fileParts['extension']);
		    $arrayBind[] = array("key" => ":widthMedia",    "value" =>  $widthMedia);
		    $arrayBind[] = array("key" => ":heightMedia",   "value" =>  $heightMedia);
		    $arrayBind[] = array("key" => ":sizeMedia",   	"value" =>  filesize($locationMedia));
		    Core::_runQuery($query,$arrayBind);
		}
    }
 }
