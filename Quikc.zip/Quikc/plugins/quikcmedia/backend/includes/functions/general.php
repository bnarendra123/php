<?php

function media_header(){
    echo'<script type="text/javascript">var plugin_media_path = "'.Config::_get('current.plugin').'";</script>
         <script type="text/javascript" src="'.Config::_getUrl('current.plugin').'/templates/backend/js/media.js"></script>';
}

function media($id,$lable){
    return '<a href="javascript:media(\''.$id.'\',0)">'.$lable.'</a>';  
};
