<?php                           
defined('QC_VALID') or die('Restricted Access!');

if(defined('QC_ADMIN') ){
    
    require_once Config::_getDir('current.plugin').'/backend/includes/lib/database_tables.php';
    require_once Config::_getDir('current.plugin').'/backend/includes/functions/general.php';
    require_once Config::_getDir('current.plugin').'/backend/includes/classes/media.php';

    Plugins::_hookAction('admin_header','media_header');
    Plugins::_hookAction('media','media');
    
    Config::_set('media.js.functon','media');
}else{
}

