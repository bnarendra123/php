<?php

defined('QC_VALID') or die('Restricted Access!');

require_once Config::_getDir('current.plugin').'/backend/includes/functions/general.php';

if(defined('QC_ADMIN') ){

    Plugins::_hookAction('admin_header','seo_backend_header');

}else{

    Plugins::_hookAction('header','seo_header');

}

