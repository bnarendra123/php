<?php

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
                  
$pluginConfig = array(
				'identifier' =>   'quikcseo',
				'version'    =>   '1.0.0',
				'install-type'=>  'full',
				'name'       =>   'Quikc Seo',
				'url'        =>   'http://www.quikc.org/',
				'description'=>   'This plugin help to improve seo of your website',
				'author'     =>   'Quikc',
				'author-url' =>   'http://www.quikc.org/',
				'auto-load'  =>   true,
				);
