jQuery(document).ready(function(){
	$(".customizesite").click(function(){
		var contentPopup = '';
		contentPopup = contentPopup+ '<li><Strong style="font-size:14px;color:#67C7E6;">Seo Options</strong></li>';
		contentPopup = contentPopup + '<li><a href="javascript:generateEditor(\'get/edit/settings-general\',\'qseo_general_settings\',\'edit\')">Site Settings</a></li>';
		contentPopup = contentPopup + '<li><a href="javascript:loadPageEdit()">Open this Page</a></li>';
		contentPopup = contentPopup + '<li><a href="javascript:loadPageSeo()">Seo of this page</a></li>';
			setTimeout(function(){
			jQuery('#customizemenu').append(contentPopup);
			});
	});
});

listElements =  new Array;
function addElement(key,val){
	listElements[key] = val;
}
function getElement(key){
	return listElements[key];
}
function test_cfz(index,type){
	
	var ele = getElement(index);
		
	var funct = $(ele).closest("span.customEditorLabel").attr('onmouseover');	
		
	if( typeof funct == 'undefined' ){
		var idFile=document.getElementById("customizeSiteIframeId").contentWindow.idFile;
		
		generateEditor('get/edit/cmsthemes-phtml','','edit',idFile)
	}
				
	var args = funct.replace("return mouseOverEditor(event,this,'", '').split("','");	
	args[args.length-1] = args[args.length-1].replace("')","");
		
	document.getElementById("customizeSiteIframeId").contentWindow.generateCustomEditor(event,args[0],args[1],args[2],'');
}

function contenttoggle(ele){
	jQuery("#daata_"+ele).toggle();
}

function getCurrentPage(){
	return document.getElementById("customizeSiteIframeId").contentWindow.idPage;
}

function loadPageEdit(){
	var idPage = getCurrentPage();
	generateEditor('get/edit/cmspages','qseo_'+idPage+'','edit',idPage);
}

function pageUrl(){
	var link = document.getElementById("addressBarIframe").value;

	return link;
	
}

function loadPageSeo(){
	
	var idPage = getCurrentPage();
	
	if( $('#Page_seo_'+idPage).length == 0 ){
		loadPopupBox('Page_seo_'+idPage);	
		$('#Page_seo_'+idPage).append('<div id="Page_seo_'+idPage+'_content" style="background:#fff""></div>');
	}
	
	var toReturn;
  	$.ajax({
   		url: pageUrl(),
   		async: false
  		}).done(function(data){
   		toReturn = data;
  	});
  
    var i,n=1,temp,count,generatedSeoData = '';
	var items = {'a':['rel','target','href'],'img':['alt','src','width','height'],'meta':['name','content'],'h1':[''],'h2':[''],'h3':['']};
	var tags  = {'a':['anchor',0],'img':['image',0],'meta':['meta',0],'h1':['h1',5],'h2':['h2',5],'h3':['h3',5]};
	generatedSeoData = generatedSeoData + '<div class="module" id="plugin_seo"><table><tr><td><thead><th>Error Type</th><th>Count</th><th>Total Errors</th></thead></td></tr>';
	for(i in items){
		count=0;
		var tem='';
		temp=items[i];
		if(n%2==0){
		 		var claass="even";
		 }else{
		 		var claass="odd";
		}
		 	
		 	if($(toReturn).find(i).length>tags[i][1]){
		 		
				generatedSeoData = generatedSeoData + '<tr class="'+claass+'"><td><a href="javascript:contenttoggle(\''+i+'\')">'+tags[i][0] +' tag </a></td><td>';
			 
				for(j in temp){
					if(i=='h1'||i=='h2'||i=='h3'){
						generatedSeoData = generatedSeoData + '<span class="contentcolor">Too many '+i+' tags </span>';
					}else{	
						generatedSeoData = generatedSeoData + '<span id="m'+temp[j]+'" class="contentcolor"> </span><span class="contentcolor" >'+(($('#m'+temp[j]).html()==0)?'':'-'+temp[j])+'</span>&nbsp;&nbsp;';
					}		
				}
				generatedSeoData = generatedSeoData + '</td><td><span id="m'+i+'" class="contentcolor"> </span> <span class="contentcolor">Errors Found</span></td></tr><tr ><td colspan="3"><div id="daata_'+i+'" style="display:none;"></div></td></tr>';
			}
				n++;
				
		}
		
	generatedSeoData = generatedSeoData + '</table></div>';
	
	$('#Page_seo_'+idPage+'_content').html(generatedSeoData);
	
	for(i in items){
			count=0;
			var tem='';
			temp=items[i];
			for(j in temp){
				
				tem = tem + findElement(toReturn,i,temp[j]);
				
			}
			$('#daata_'+i).html(tem);
			$('#m'+i).html(count);
			
		}
	
  	function findElement(string,tag,attribute){
 		 var returndata='<table class="tablecss"><tr><thead><th width="25px">Sno</th><th width="120px">Name</th><th width="150px">Error Attribute</th><th width="800px">Tag</th><th width="100px">Tag Closed</th><th width="75px">Edit</th></thead></tr>',inc=1;
		 $(string).find(tag).each(function( index ) {
		 	if(inc%2==0){
		 		var claass="even";
		 	}else{
		 		var claass="odd";
		 	}
		 	returndata +='<tr class="'+claass+'">';
		  		var key = 'seo_find_element_'+tag+'_'+attribute+'_'+index;
			  
			  if ($(this).attr(attribute) != undefined && $(this).attr(attribute)!='') {
			  	inc=--inc;
			  } else if($(this).attr(attribute) != undefined && $(this).attr(attribute)=='' ) {		
					returndata = returndata + '<td class=".elements">'+( inc + '</td><td>' + $( this ).text() )+'</td><td>exists but '+ attribute +' value is empty</td><td ><xmp style="margin:0px;">'+getHtmlTagLine($(this))+'</xmp><td>'+validateTag(tag,getHtmlTagLine($(this)))+'</td></td><td><a href="javascript:test_cfz(\''+key+'\',\'empty\')"><img src="http://127.0.0.1:8080/Quikc/templates/backend/default/images/pencil.gif" width="16" height="16" alt="edit" title="edit"></a>';
					count++;
			
			 } else {
			   		returndata = returndata +'<td>'+ ( inc + '</td><td> ' + $( this ).text() )+'</td><td> '+ attribute +' Doesnt  exists</td><td><xmp style="margin:0px;">'+getHtmlTagLine($(this))+'</xmp></td><td>'+validateTag(tag,getHtmlTagLine($(this)))+'</td><td><a href="javascript:test_cfz(\''+key+'\',\'doesnot\')"><img src="http://127.0.0.1:8080/Quikc/templates/backend/default/images/pencil.gif" width="16" height="16" alt="edit" title="edit"></a>';
			   		count++;
			   		
			  }
			  returndata +='</td></tr>';
			  inc++;
			 
			addElement(key,$(this));
		 });
		 
			  returndata +='</table>';
			  
			  (--inc==0)?$('#m'+attribute).html(''):$('#m'+attribute).html(inc);				  
			  
			  
		 return returndata;
		 
	}
	function validateTag(tag,element){
 
		 if(element.indexOf('</'+tag+'>') != -1){
		  return 'Yes';
		 }else{
		  return 'No';
		 }
 
	}
	function getHtmlTagLine(obj){
	
		return obj.clone().wrap('<p>').parent().html().replace(/\s+/g,' ') ;	
 
 	}	
	
}
	
