<?php

function seo_backend_header(){
    echo'
        <link rel="stylesheet" type="text/css" href="'.Config::_getUrl('current.plugin').'/templates/backend/css/qseo.css" />       

        <script type="text/javascript">var plugin_media_path = "'.Config::_get('current.plugin').'";</script>
        <script type="text/javascript" src="'.Config::_getUrl('current.plugin').'/templates/backend/js/seo.js"></script>
        ';
}

function seo_header(){
    
    GLOBAL $Editor;
    if(!$Editor->_isCustomizeMode()) return false;

    GLOBAL $Themes;

    $detailsPage = $Themes->_getCurrentPageDetails();    
    
    if( $detailsPage->themePage == 'global' ){
        $detailsPage->themePage = $Themes->_getActiveTheme()->pathTheme;
    }
    
    $idTheme = $Themes->_getThemeDetailsByPath($detailsPage->themePage)->idTheme;

    $query = " select * from `".Config::_getTable('cms_themes_files')."` where idTheme = :idTheme and pathFile = :pathFile ";
    $arrayBind[] = array('key' => ':idTheme',  'value' => $idTheme);
    $arrayBind[] = array('key' => ':pathFile', 'value' => 'templates/'.$detailsPage->templatePage.'.phtml');

    $detailsFile = Core::_getRow($query, $arrayBind);
    
    echo '
        <script>
        var idPage = "'.$detailsPage->idPage.'";    
        var idFile = "'.$detailsFile->idFile.'";    
        </script>
    ';
}
