<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$idMenu = $this->_addPluginMenu(array("titleMenu" => "QSlider","linkMenu" => "qsliders","imageMenu" => "library-icon.png","parentMenu" => 0,"statusMenu" => 1,"orderMenu"=> 15,"dashboardMenu"=>0,"topMenu"=>1));

$query[] = "CREATE TABLE  `".Config::_getTable('qsliders')."` (
`idSlider` INT( 11 ) NOT NULL AUTO_INCREMENT ,
`nameSlider` VARCHAR( 200 ) NOT NULL ,
`linkSlider` VARCHAR( 100 ) NOT NULL ,
`statusSlider` TINYINT( 1 ) NOT NULL DEFAULT  '1',
`dateAdditionSlider` DATETIME NOT NULL ,
`dateUpdationSlider` TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
PRIMARY KEY (`idSlider`)
) ENGINE = MYISAM ;";

$query[] = "CREATE TABLE `".Config::_getTable('qslider_entries')."` (
`idSliderEntry` int(11) NOT NULL AUTO_INCREMENT,
`idSlider` int(11) NOT NULL,
`titleSliderEntries` varchar(200) NOT NULL,
`widthSliderEntries` varchar(10) NOT NULL,
`heightSliderEntries` varchar(10) NOT NULL,
`statusSliderEntries` TINYINT( 1 ) NOT NULL DEFAULT  '1',
`optionsSliderEntries` text NOT NULL,
`dateAdditionSliderEntry` datetime NOT NULL,
`dateUpadationSliderEntry` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON
UPDATE CURRENT_TIMESTAMP,
PRIMARY KEY (`idSliderEntry`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1";

$query[] = "CREATE TABLE `".Config::_getTable('qslider_items')."` (
`idSliderItem` int(11) NOT NULL AUTO_INCREMENT,
`idSliderEntry` int(11) NOT NULL,
`titleSlideItem` varchar(200) NOT NULL,
`imageSlideItem` varchar(200) NOT NULL ,
`descriptionSlideItem` text NOT NULL,
`orderSliderItem` int(4) NOT NULL,
`statusSliderItem` TINYINT( 1 ) NOT NULL DEFAULT  '1',
`optionSlideItems` text NOT NULL,
`dateAddtionSliderItem` datetime NOT NULL,
`dateUpdationSliderItem` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON
UPDATE CURRENT_TIMESTAMP,
PRIMARY KEY (`idSliderItem`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1";

$query[] = "INSERT INTO `".Config::_getTable('qsliders')."` (`nameSlider`,`linkSlider`,`statusSlider`) values ('Basic Slider','basicslider','1') ";
$query[] = "INSERT INTO `".Config::_getTable('qsliders')."` (`nameSlider`,`linkSlider`,`statusSlider`) values ('lean Slider','leanslider','1') ";
$query[] = "INSERT INTO `".Config::_getTable('qsliders')."` (`nameSlider`,`linkSlider`,`statusSlider`) values ('Camera Slider','cameraslider','1') ";


$query[] = "INSERT INTO `".Config::_getTable('widgets')."`  (`titleWidget`,`defaultOptionsWidget`,`pathWidget`,`systemItem`,`statusWidget`,`createdById`,`createdByType`) values ('Qsliders','','plugins/qslider/widgets/qslider','0','1','1','Plugin')";

$this->_executePluginDatabase($query);

