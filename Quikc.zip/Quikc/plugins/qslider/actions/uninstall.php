<?php                           
defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$query[]  = "drop table if exists ".Config::_getTable('qsliders');
$query[]  = "drop table if exists ".Config::_getTable('qslider_entries');
$query[]  = "drop table if exists ".Config::_getTable('qslider_items');

$query[]  = "delete from ".Config::_getTable('widgets')." where linkWidget = 'plugins/qslider/widgets/qslider'";

$this->_executePluginDatabase($query);
