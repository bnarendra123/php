<script>
function sliderCategoryWidgetChanged_<?php echo $Forms->_getFormId(); ?>(){
    var listSliders = <?php echo json_encode(qSlider::_getInstance()->_getSliderEntries()); ?>;
	var idForm = '<?php echo $Forms->_getFormId(); ?>';
	
	var idSlider = document.getElementById("options_idSlider_"+idForm).value;
    var idSliderEntry = document.getElementById("options_idSliderEntry_"+idForm).value;
	
	var modifiedListSliders = new Array;
	for(var i in listSliders){
	    if( listSliders[i].idSlider == idSlider ){
            modifiedListSliders.push(listSliders[i]);
	    }
	}
	
	var generatedHtml = generateSelectBox(modifiedListSliders,'idSliderEntry','titleSliderEntries',"options_idSliderEntry_"+idForm,idSliderEntry,true,'onchange="return sliderWidgetChanged_<?php echo $Forms->_getFormId(); ?>()"');
	generatedHtml = generatedHtml + '<span></span>';
	
	$("#options_idSliderEntry_"+idForm).parent().html(generatedHtml);

    var generatedHtml = '&nbsp;<a href="javascript:manageSlider(\''+idSlider+'\');">Manage this category</a>';

    $("#options_idSlider_"+idForm).parent().find('span').html(generatedHtml);
	
	updateTableRows();
    sliderWidgetChanged_<?php echo $Forms->_getFormId(); ?>();
}
function sliderWidgetChanged_<?php echo $Forms->_getFormId(); ?>(){
    var idForm = '<?php echo $Forms->_getFormId(); ?>';
    var idSliderEntry = document.getElementById("options_idSliderEntry_"+idForm).value;
    
    if( typeof idSliderEntry == 'undefined' || idSliderEntry == ''  )
    	var generatedHtml = '';
    else
    	var generatedHtml = '&nbsp;<a href="javascript:manageSlides(\''+idSliderEntry+'\');">Manage this slider</a>';
    	
    $("#options_idSliderEntry_"+idForm).parent().find('span').html(generatedHtml);
}
sliderCategoryWidgetChanged_<?php echo $Forms->_getFormId(); ?>();
</script>