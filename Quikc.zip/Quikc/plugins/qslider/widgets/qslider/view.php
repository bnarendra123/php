<?php 

$Plugins -> _workingPlugin('qslider');

$idSliderEntry = $detailsWidget->options->idSliderEntry;

$detailsSliderEntry = qSlider::_getInstance()->_getSlideEntryDetails($idSliderEntry);

if( !$detailsSliderEntry ){
    echo 'Invalid Slider';
    return;
}

if( !$detailsSliderEntry->statusSliderEntries ){
    echo 'Slider Disabled';
    return;
}

$detailsSlider = qSlider::_getInstance()->_getSliderDetails($detailsSliderEntry->idSlider);

if( !$detailsSlider ){
    echo 'Invalid Slider Category';
    return;
}

if( !$detailsSlider->statusSlider ){
    echo 'Slider Category Disabled';
    return;
}

$pathSliderTemplate         = Config::_getDir('current.plugin').'/templates/frontend/sliders/'.$detailsSlider->linkSlider;
$loaderPathSliderTemplate   = $pathSliderTemplate.'/loader.phtml';
$viewPathSliderTemplate     = $pathSliderTemplate.'/view.phtml';

if( file_exists($loaderPathSliderTemplate) ){
    include_once $loaderPathSliderTemplate;
}

if( file_exists($viewPathSliderTemplate) ){
	
    include $viewPathSliderTemplate;
}

$Plugins -> _removeWorkingPlugin();