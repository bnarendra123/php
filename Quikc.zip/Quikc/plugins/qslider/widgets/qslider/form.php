<?php

$widgetFields[] = array("id" => "idSlider",  "type" => "select"	,"label"  => "Slider Category",	"req" => true ,"value" => "", "additional" => 'onchange="return sliderCategoryWidgetChanged_'.$Forms->_getFormId().'()"', "set" => "qslider-slider-categories", "postFieldLable"=>'<span></span>');

$widgetFields[] = array("id" => "idSliderEntry",  "type" => "select" ,"label"  => "Select Slider",   "req" => true ,"value" => "", "additional" => '', "set" => "qslider-sliders", 
"postFieldLable"=>'<span></span> ');

