function manageSlider(idSlider,dataFilter){

	if(!document.getElementById('manageSliderPopup_'+idSlider)){
		loadPopupBox('manageSliderPopup_'+idSlider);
		$('#manageSliderPopup_'+idSlider).append('<div id="manageSlider_'+idSlider+'"></div>');
	}

	LoadList(plugin_qslider_path+'/backend/includes/modules/ajax/get/list/qsliderentries','manageSlider_'+idSlider,{'idSlider':idSlider});
	
	if(!document.getElementById('manageSliderPopup_'+idSlider)){
	    setTimeout(function(){centerElement('manageSliderPopup_'+idSlider, 0, 0)},500);
	}
}
function manageSlides(idSliderEntry,dataFilter){

	if(!document.getElementById('manageSlidePopup_'+idSliderEntry)){
		loadPopupBox('manageSlidePopup_'+idSliderEntry);
		$('#manageSlidePopup_'+idSliderEntry).append('<div id="manageSlide_'+idSliderEntry+'"></div>');
	}

	LoadList(plugin_qslider_path+'/backend/includes/modules/ajax/get/list/qslideritems','manageSlide_'+idSliderEntry,{'idSliderEntry':idSliderEntry});
	
	if(!document.getElementById('manageSlidePopup_'+idSliderEntry)){
	    setTimeout(function(){centerElement('manageSlidePopup_'+idSliderEntry, 0, 0)},500);
	}
}
function LoadSlidesList(idSlider, dataFilter) {

    var pass_url = '/ajax.php?action='+getListPage();

	var pass_data = 'idSlider=' + idSlider;
	pass_data = pass_data + '&' + dataFilter;

	$.ajax({
		type : "POST",
		beforeSend : loadingStarts,
		url : adminUrl + pass_url,
		data : pass_data,
		complete : loadingEnds,
		success : function(responseText) {
			message_reporting(getListPlaceholder(), responseText, 0);
		}
	});
}
function generateSliderEditor(formType,formPrimaryField, idSlider) {

	var dataFilter = generateListUrl('');
	
	var edtPage = getListPage().replace(/list/, 'edit');
	
	var pass_url = '/ajax.php?action=' + edtPage;
	
	var pass_data = 'formType=' + formType + '&page=' + edtPage + '&formPrimaryField=' + formPrimaryField +'&idSlider=' + idSlider + '&dataFilter=' + encodeData(dataFilter);

	$.ajax({
		type : "POST",
		beforeSend : loadingStarts,
		url : adminUrl + pass_url,
		data : pass_data,
		success : function(responseText) {
			loadingEnds();
			responseText = '<div class="generatedEditor">' + responseText + '</div>';

			message_reporting(getEditPlaceholder(), responseText, 0);
		}
	});
}