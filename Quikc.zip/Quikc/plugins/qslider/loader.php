<?php                           
defined('QC_VALID') or die('Restricted Access!');

require_once Config::_getDir('current.plugin').'/includes/lib/database_tables.php';
require_once Config::_getDir('current.plugin').'/includes/classes/qslider.php';

if(defined('QC_ADMIN') ){

    require_once Config::_getDir('current.plugin').'/backend/includes/functions/general.php';
    Plugins::_hookAction('admin_header','_loadAdminHeader');

}else{
    
}
