<?php

function _loadAdminHeader(){ 

    echo'<script type="text/javascript">var plugin_qslider_path = "'.Config::_get('current.plugin').'";</script>
         <script type="text/javascript" src="'.Config::_getUrl('current.plugin').'/templates/backend/js/qslider.js"></script>';
}

