<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

if( !$Permissions->_checkPagePermission('qslider-qsliders','view') ){
    $Base->_accessRestricted();
}

if(!$_POST){
    die();
}

extract($_POST);

if($formPrimaryField != -1){

    $details = qSlider::_getInstance()->_getSliderDetails($formPrimaryField);
    $forms['name'] = "Editing ".$details->nameSlider;

}else{
    $details = '';
}

echo $Forms->_generateForm($forms,$details);
		
