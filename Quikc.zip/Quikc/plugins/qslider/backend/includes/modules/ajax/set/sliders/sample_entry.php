<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

extract($_POST);

if($_POST){

    $do = $_POST['do'];
	
	if($do == 'edit'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// Form edit action starts here

		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);
		
        if( count($processedForm['error']) != 0 ){      
            $Base->_convertError($processedForm['error'],false);
        }

        $fields = $processedForm['fields'];

        unset($arrayBind);
		
        if($formPrimaryField == -1){
    
            if( !$Permissions->_checkPagePermission(__FILE__,'create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
            
            foreach($fields as $field){
                $insertKeys[]  = "`$field`";
                $insertValues[]= ":$field";
                $arrayBind[]= array("key" => ":$field", "value" => $$field);
            }
            $query = "insert into ".Config::_getTable('qslider_entries')." (".implode(",",$insertKeys).",dateAdditionSliderEntry) values (".implode(",",$insertValues).",now())";

           if(Core::_runQuery($query, $arrayBind)){
				$formPrimaryField = Core::_getLastInsertId();
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }else{
    
            if( !$Permissions->_checkPagePermission(__FILE__,'edit') ){
                $Base->_accessRestricted();
            }

            $setpPart = array();
    
            foreach($fields as $field){
                $setpPart[] = "`$field`=:$field";
                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            }
            $query  = "update ".Config::_getTable('qslider_entries')." set ".implode(",",$setpPart)." where idsliderEntry= :formPrimaryField";
            $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
    
           if(!Core::_runQuery($query, $arrayBind)){
				$Base->_convertError(array("Save Filed"),false);  
            }
        }

		// Form edit action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }else if($do == 'status'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// List status action starts here

		// List status action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }else if($do == 'delete'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// List delete action starts here

		if( !$Permissions->_checkPagePermission(__FILE__,'delete') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
		
        // Exploding to get the ids
        $idArray = explode(",",$id);

        foreach($idArray as $tmpId){

            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);

            $query  = "delete from ".Config::_getTable('qslider_entries')." where `idsliderEntry` = :primaryField";
            Core::_runQuery($query,$arrayBind);
	        
        }

		// List delete action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }
    die($messageDie);
}
		