<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');
if( !Ajax::_isAjax() ) die('Restricted Access!');

$messageDie = 'ok';

if( !isset($formPrimaryField) || $formPrimaryField == -1 && isset($formId) && isset(${'idSliderEntry_'.$formId}) ){
    $idSliderEntry = ${'idSliderEntry_'.$formId};
}else{
    $detailsSliderEntry = qSlider::_getInstance()->_getSliderItemDetails($formPrimaryField);
    
    if( !$detailsSliderEntry ){
        die('Slider Entry Not Valid!');
    }
    
    $idSliderEntry = $detailsSliderEntry->idSliderEntry;
}

$detailsSlider = qSlider::_getInstance()->_getSliderDetails(qSlider::_getInstance()->_getSlideEntryDetails($idSliderEntry)->idSlider);

if( !$detailsSlider ){
    die('Slider Not Valid!');
}

$pathListFile = Config::_getDir('current.plugin').'/backend/includes/modules/ajax/set/sliders/'.$detailsSlider->linkSlider.'_slide.php';
        
if( file_exists($pathListFile) ){
    
    include $pathListFile;
    return;    
}

if($_POST){

    $do = $_POST['do'];
	
	if($do == 'edit'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// Form edit action starts here

		$processedForm = $Forms->_processForm($forms,$_POST);
		extract($processedForm['formElements']);
		
        if( count($processedForm['error']) != 0 ){      
            $Base->_convertError($processedForm['error'],false);
        }

        $fields = $processedForm['fields'];
		$defaultFields = array('idSliderEntry','titleSlideItem','descriptionSlideItem','imageSlideItem','statusSliderItem','orderSliderItem');
		

        unset($arrayBind);
		
        if($formPrimaryField == -1){
    
            if( !$Permissions->_checkPagePermission('qslideritems','create') ){
                $Base->_accessRestricted();
            }

            $insertKeys  = array();
            $insertValues= array();
			$options = array();
						
            foreach($fields as $field){
            	
            	if( in_array($field, $defaultFields) ){
            		
	                $insertKeys[]  = "`$field`";
	                $insertValues[]= ":$field";
					$arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            	}else{
            		$options[$field] = $$field;
            	}
            }
            $insertKeys[]	= 'optionSlideItems';
            $insertValues[]	= ':optionSlideItems';
            $arrayBind[]	= array("key" => ":optionSlideItems", "value" => json_encode($options));
			
            $query = "insert into ".Config::_getTable('qslider_items')." (".implode(",",$insertKeys).",dateAddtionSliderItem) values (".implode(",",$insertValues).",now())";

           if(Core::_runQuery($query, $arrayBind)){
				$formPrimaryField = Core::_getLastInsertId();
            }else{
				$Base->_convertError(array("Save Filed"),false);  
            }
        }else{
    
            if( !$Permissions->_checkPagePermission('qslideritems','edit') ){
                $Base->_accessRestricted();
            }

		    $setpPart = array();
			$options = array();
    
            foreach($fields as $field){

            	if( in_array($field, $defaultFields) ){
	                $setpPart[] = "`$field`=:$field";
	                $arrayBind[]= array("key" => ":$field", "value" =>  $$field );
            	}else{
            		$options[$field] = $$field;
            	}

            }

            $setpPart[]	= 'optionSlideItems=:optionSlideItems';
            $arrayBind[]	= array("key" => ":optionSlideItems", "value" => json_encode($options));
    
            $query  = "update ".Config::_getTable('qslider_items')." set ".implode(",",$setpPart)." where idSliderItem = :formPrimaryField";
            $arrayBind[]= array("key" => ":formPrimaryField", "value" =>  $formPrimaryField);
    
           if(!Core::_runQuery($query, $arrayBind)){
				$Base->_convertError(array("Save Filed"),false);  
            }
		   Cache::_getInstance()->_removeCache('qslider_slider_item_' .$formPrimaryField);
        }

		// Form edit action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }else if($do == 'status'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// List status action starts here

		if( !$Permissions->_checkPagePermission('qslider-qsliders','edit') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
        // Exploding to get the ids
        $idArray = explode(",",$id);

        // Checking the change values. 1(Enable),0(Disable) and Invert for the other values
        // '1','0' has to be used instead of 1,0 because '1','0' are considered as string where as 1,0 are considered as boolean values 
        if($changeTo == '1'){
            $changeToField = 1;
        }else if($changeTo == '0'){
            $changeToField = 0;
        }else{
            $changeToField = "!statusSliderItem";
        }

        // Status change query
        $query  = "update ".Config::_getTable('qslider_items')." set statusSliderItem = ".$changeToField." where `idSliderItem` = :primaryField";
        foreach($idArray as $tmpId){
            unset($arrayBind);
            $arrayBind[]= array("key" => ":primaryField", "value" =>  $tmpId);
            Core::_runQuery($query,$arrayBind);
			Cache::_getInstance()->_removeCache('qslider_slider_item_' .$tmpId);
        }
        
		// List status action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }else if($do == 'delete'){

		// Don't delete or modify below content in comments. If modified then code can't be exported for this file 
		// List delete action starts here

		if( !$Permissions->_checkPagePermission('qslider-qsliders','delete') ){
			$Base->_accessRestricted();
		}

        $id = $_POST['id'];
		
        // Exploding to get the ids
        $idArray = explode(",",$id);

        foreach($idArray as $tmpId){

 			qSlider::_getInstance()->_deleteSliderItems($tmpId);
        }

		// List delete action ends here
		// Don't delete or modify above content in comments. If modified then code can't be exported for this file 

    }
    die($messageDie);
}
		