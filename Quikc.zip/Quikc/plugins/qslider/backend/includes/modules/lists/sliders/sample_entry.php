<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$detailsSlider = qSlider::_getInstance()->_getSliderDetailsByLink('link_slider');

if( !isset($idSlider) || $idSlider == '' || !$detailsSlider ) {
    return;
}

$manageSlide= '<a href="javascript:manageSlides(\':data\');">Manage Slides</a>';

$displayFields	= array( 
	array( "id" => "idsliderEntry"	,"title" => "Idslider Category"	,"type" => "text"	,"dbField" => true	,"tpx" => "qe"	,"display" => ":data"),
	array( "id" => "idSlider"		,"title" => "Id Slider"			,"type" => "text"	,"dbField" => true	,"tpx" => "qe"	,"display" => ":data"),

	array( "id" => "titlesliderItems"	,"title" => "Titleslider Items"	,"type" => "text"	,"dbField" => true	,"tpx" => "qe"	,"display" => ":data"),
	array( "id" => "pathsliderItems"	,"title" => "Pathslider Items"	,"type" => "image"	,"dbField" => true	,"tpx" => "qe"	,"display" => "<img src=\":data\" width=\"50\" />"),

	array( "id" => "idsliderEntry"	,"title" => 'Manage Slider'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => '', "display" => $manageSlide),
	
	array( "id" => "actions" ,"title" => "Actions" ,"type" => "actions" ,"dbField" => false	,"tpx" => "" ,"display" => ""	,"set" => array("status","edit","delete")),
);

unset($arrayBind);
$arrayBind[] = array("key" => ":idSlider", "value" => $detailsSlider->idSlider );  

$listData = array( 
	"sql" 			=> "select *,qe.idsliderEntry from  qslider_entries qe",
    "where"         => "idSlider = :idSlider",
    "arrayBind"     => $arrayBind,
	"sortby" 		=> "", 
	"order" 		=> "", 
	"headding" 		=> "qsliderentries", 
	"primaryField" 	=> "idsliderEntry", 
	"statusField" 	=> "statusSliderEntries",
	"params"  		=> "{'idSlider':$idSlider}", 
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> "0", 
	"perpage" 		=> "0", 
	"displaypages" 	=> "0", 
	"filename" 		=>$Base->_getFileName(__FILE__), 
);

