<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$idSliderEntry = $params->idSliderEntry;
$detailsSliderEntry = qSlider::_getInstance()->_getSlideEntryDetails($idSliderEntry);

if( !isset($idSliderEntry) || $idSliderEntry == '' || !$detailsSliderEntry ) {
    return;
}

$displayFields  = array( 
    array( "id" => "idSliderItem"       ,"title" => "Id Slider Item"        ,"type" => "text"       ,"dbField" => true      ,"tpx" => "qslider_items"       ,"display" => ":data"       ,"set" => ""        ,"show" => true),
    array( "id" => "idSliderEntry"      ,"title" => "Id Slider Entry"       ,"type" => "text"       ,"dbField" => true      ,"tpx" => "qslider_items"       ,"display" => ":data"       ,"set" => ""        ,"show" => true),

    array( "id" => "titleSlideItem"     ,"title" => "Bigtitle Slider Item"      ,"type" => "text"       ,"dbField" => true      ,"tpx" => "qslider_items"       ,"display" => ":data"       ,"set" => ""        ,"show" => true),
    array( "id" => "imageSliderItem"        ,"title" => "Image Slider Item"     ,"type" => "image"      ,"dbField" => true      ,"tpx" => "qslider_items"       ,"display" => "<img src=\":data\" width=\"50\" />"      ,"set" => ""        ,"show" => true),

    array( "id" => "statusSliderItem"       ,"title" => "Status Slider Item"        ,"type" => "select"     ,"dbField" => true      ,"tpx" => "qslider_items"       ,"display" => ":data"       ,"set" => "status"      ,"show" => true),
    array( "id" => "actions"        ,"title" => "Actions"       ,"type" => "actions"        ,"dbField" => false     ,"tpx" => ""        ,"display" => ""        ,"set" => array("0" => "status","1" => "edit","2" => "delete",)),
);

unset($arrayBind);
$arrayBind[] = array("key" => ":idSliderEntry", "value" => $idSliderEntry);  

$listData = array( 
	"sql" 			=> "select *,qslider_items.idSliderItem from   qslider_items qslider_items",
    "where"         => "idSliderEntry = :idSliderEntry",
    "arrayBind"     => $arrayBind,
	"sortby" 		=> "", 
	"order" 		=> "", 
	"headding" 		=> "qslideritems", 
	"primaryField" 	=> "idSliderItem", 
	"statusField" 	=> "statusSliderItem",
	"params"  		=> "{'idSliderEntry':$idSliderEntry }", 
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> "0", 
	"perpage" 		=> "0", 
	"displaypages" 	=> "0", 
	"filename" 		=>$Base->_getFileName(__FILE__),
);
		
