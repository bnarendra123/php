<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$idSlider = $params->idSlider;

$detailsSlider = qSlider::_getInstance()->_getSliderDetails($idSlider);

if( !$detailsSlider ){
    return;
}

$pathListFile = Config::_getDir('current.plugin').'/backend/includes/modules/lists/sliders/'.$detailsSlider->linkSlider.'_entry.php';
        
if( file_exists($pathListFile) ){
    
    include $pathListFile;
    return;    
}

$manageSlide= '<a href="javascript:manageSlides(\':data\');">Manage Slides</a>';

$displayFields	= array( 
	array( "id" => "idSliderEntry"	,"title" => "Idslider Category"		,"type" => "text"		,"dbField" => true		,"tpx" => "qslider_categories"		,"display" => ":data"		,"set" => ""		,"show" => true),

	array( "id" => "titleSliderEntries"	,"title" => "Titleslider Items"		,"type" => "text"		,"dbField" => true		,"tpx" => "qslider_categories"		,"display" => ":data"		,"set" => ""		,"show" => true),
	array( "id" => "idSliderEntry"	    ,"title" => 'Manage Slider'	 ,"type" => 'text'   ,"dbField" => true ,"tpx" => '', "display" => $manageSlide),
	
	array( "id" => "actions"		,"title" => "Actions"		,"type" => "actions"		,"dbField" => false		,"tpx" => ""		,"display" => ""		,"set" => array("0" => "status","1" => "edit","2" => "delete",)),
);

unset($arrayBind);
$arrayBind[] = array("key" => ":idSlider", "value" => $detailsSlider->idSlider );  

$listData = array( 
	"sql" 			=> "select *,qslider_entries.idsliderEntry from   qslider_entries qslider_entries",
    "where"         => "idSlider = :idSlider",
    "arrayBind"     => $arrayBind,
	"sortby" 		=> "", 
	"order" 		=> "", 
	"headding" 		=> " Slider Entries of ".$detailsSlider->nameSlider.":", 
	"primaryField" 	=> "idSliderEntry", 
	"statusField" 	=> "statusSliderEntries",
	"params"  		=> "{'idSlider':$idSlider}", 
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> "0", 
	"perpage" 		=> "0", 
	"displaypages" 	=> "0", 
	"filename" 		=>$Base->_getFileName(__FILE__), 
);

