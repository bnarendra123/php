<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$manageSlider= '<a href="javascript:manageSlider(\':data\');">Manage Slider</a>';
$actions = array("status");

$displayFields	= array( 
	array( "id" => "idSlider"		,"title" => "Id Slider"		,"type" => "text"	,"dbField" => true	,"tpx" => "qsliders"	,"display" => ":data"		,"set" => ""		,"show" => true),
	array( "id" => "nameSlider"		,"title" => "Name Slider"	,"type" => "text"	,"dbField" => true	,"tpx" => "qsliders"	,"display" => ":data"		,"set" => ""		,"show" => true),
	array( "id" => "linkSlider"		,"title" => "Link Slider"	,"type" => "text"	,"dbField" => true	,"tpx" => "qsliders"	,"display" => ":data"		,"set" => ""		,"show" => true),
	array( "id" => "statusSlider"	,"title" => "Status Slider"	,"type" => "select"	,"dbField" => true	,"tpx" => "qsliders"	,"display" => ":data"		,"set" => "status"	,"show" => true),
	array( "id" => "idSlider"	    ,"title" => 'Manage Slider'	,"type" => 'text'   ,"dbField" => true  ,"tpx" => ''            , "display" => $manageSlider),

	array( "id" => "actions"		,"title" => "Actions"		,"type" => "actions"		,"dbField" => false		,"tpx" => ""		,"display" => ""		,"set" => $actions),
);

$listData = array( 
	"sql" 			=> "select * from qsliders",
	"where" 		=> "", 
	"arrayBind" 	=> "",
	"sortby" 		=> "", 
	"order" 		=> "", 
	"headding" 		=> "Sliders ", 
	"primaryField" 	=> "idSlider", 
	"statusField" 	=> "statusSlider",
	"noCreate" 		=> true,
//  Fields from here are same for all (in general)
    "multiActions"  => true, 
	"multiLanguages"=> false, 
	"displayFields" => $displayFields, 
	"page" 			=> "0", 
	"perpage" 		=> "0", 
	"displaypages" 	=> "0", 
	"filename" 		=> $Base->_getFileName(__FILE__), 
);
		
