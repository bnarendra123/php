<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

// value will be updated when getting the create/edit forms
if(isset($params->idSliderEntry)){
    $idSliderEntry = $params->idSliderEntry;
}

// value will be updated when saving the values for the create slider item
if(isset($formId) && $formId != '' && isset(${'idSliderEntry_'.$formId}) ){
    $idSliderEntry = ${'idSliderEntry_'.$formId};
}


// value will be updated when saving the values for existing slider item
if( isset($formPrimaryField) && $formPrimaryField != '' && $formPrimaryField != -1 ){
    
    $detailsSliderItem = qSlider::_getInstance()->_getSliderItemDetails($formPrimaryField);
    
    if( !$detailsSliderItem ){
        die("Not Allowed");
    }
    $idSliderEntry = $detailsSliderItem->idSliderEntry; 
}

if( !isset($idSliderEntry) || $idSliderEntry == '' ) {
    die('Id Slider Not Defined');
}


$detailsSlider = qSlider::_getInstance()->_getSliderDetails(qSlider::_getInstance()->_getSlideEntryDetails($idSliderEntry)->idSlider);

if( !$detailsSlider ) {
    die('Not A Valid Slider');
}

$pathListFile = Config::_getDir('current.plugin').'/backend/includes/modules/forms/sliders/'.$detailsSlider->linkSlider.'_slide.php';
        
if( file_exists($pathListFile) ){
    
    include $pathListFile;
    return;    
}


// Updating slider id when set form is called(when saving the data to the form)

if($formPrimaryField == -1 ){
	
	$formFields[] = array("id" => "idSliderEntry",     "type" => "Hidden",   "label" => "Slider Id",   "req" => true ,"value" => "$idSliderEntry", "additional" => '' );
}

$formFields[]	= array( "id" => "titleSlideItem"		,"label" => "Title"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => "");
$formFields[]	= array( "id" => "descriptionSlideItem","label" => "Description"		,"type" => "textarea"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => "");
$formFields[]   = array( "id" => "imageSlideItem"		,"label" => "Image Slider"		,"type" => "media"		,"value" => ""		,"additional" => ""		,"set" => "img"		,"dbfield" => "1"		,"req" => true		,"unique" => "");
$formFields[]   = array( "id" => "statusSliderItem"		,"label" => "Status Slider Item"		,"type" => "checkbox"		,"value" => "1"		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => "");
$formFields[]	= array( "id" => "orderSliderItem"		,"label" => "Order"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => "");

$formFields[]   = array( "id" => ""		,"label" => ""		,"type" => "button"		,"value" => "Proceed"		,"additional" => ""		,"set" => ""		,"dbfield" => ""		,"req" => false		,"unique" => "");

$forms = array( 
	"identifier" 	=> "dynamicForm", 
	"name" 			=> "Creating New QSlider Items", 
    "primaryFiled"  => "idSliderItem", 
	"url" 			=> Config::_get('current.plugin')."/backend/includes/modules/ajax/set/".$Base->_getFileName(__FILE__),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> $Base->_getFileName(__FILE__),
    "fields"        => $formFields,
);
		
