<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$detailsSlider = qSlider::_getInstance()->_getSliderDetailsByLink('link_slider');

if( !isset($idSlider) || $idSlider == '' || !$detailsSlider ) {
    return;
}

if($formPrimaryField == -1 ){
	
	$formFields[] = array("id" => "idSlider",     "type" => "Hidden",   "label" => "Slider Id",   "req" => true ,"value" => $detailsSlider->idSlider, "additional" => '' );
}

$formFields[]	= array( "id" => "titleSliderEntries"	,"label" => "Title Slider"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"	,"req" => true		,"unique" => "");
$formFields[]   = array( "id" => "statusSliderEntries"	,"label" => "Status Slider"		,"type" => "checkbox"	,"value" => "1"		,"additional" => ""		,"set" => ""		,"dbfield" => "1"	,"req" => false		,"unique" => "");
$formFields[]   = array( "id" => "statusSliderEntries1"  ,"label" => "Status Slider"     ,"type" => "checkbox"   ,"value" => "1"     ,"additional" => ""     ,"set" => ""        ,"dbfield" => "1"   ,"req" => false     ,"unique" => "");
$formFields[]   = array( "id" => ""		                ,"label" => ""	,"type" => "button"		,"value" => "Proceed"		,"additional" => ""		,"set" => ""		,"dbfield" => ""		,"req" => false		,"unique" => "");

$forms = array( 
	"identifier" 	=> "dynamicForm", 
	"name" 			=> "Creating New Slider Entry", 
    "primaryFiled"  => "idsliderEntry", 
	"url" 			=> Config::_get('current.plugin')."/backend/includes/modules/ajax/set/".$Base->_getFileName(__FILE__),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> $Base->_getFileName(__FILE__),
    "fields"        => $formFields,
);
		
