<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

$formFields	= array( 
	array( "id" => "nameSlider"		,"label" => "Name Slider"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => ""),
	array( "id" => "linkSlider"		,"label" => "Link Slider"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => ""),
	array( "id" => "statusSlider"	,"label" => "Status Slider"		,"type" => "checkbox"	,"value" => "1"		,"additional" => ""		,"set" => ""	    ,"dbfield" => "1"		,"req" => true		,"unique" => ""),
	array( "id" => ""		        ,"label" => ""	                ,"type" => "button"		,"value" => "Proceed","additional" => ""	,"set" => ""		,"dbfield" => ""		,"req" => false		,"unique" => ""),
);

$forms = array( 
	"identifier" 	=> "dynamicForm", 
	"name" 			=> "Creating New qsliders", 
    "primaryFiled"  => "idSlider", 
	"url" 			=> Config::_get('current.plugin')."/backend/includes/modules/ajax/set/".$Base->_getFileName(__FILE__),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> $Base->_getFileName(__FILE__),
    "fields"        => $formFields,
);
		
