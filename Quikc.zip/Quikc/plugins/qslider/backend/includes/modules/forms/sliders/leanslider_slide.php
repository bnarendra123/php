<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

$detailsSlider = qSlider::_getInstance()->_getSliderDetails(qSlider::_getInstance()->_getSlideEntryDetails($idSliderEntry)->idSlider);

if( !isset($idSliderEntry) || $idSliderEntry == '' || !$detailsSlider ) {
    die('Not A Valid Slider');
}

// Updating slider id when set form is called(when saving the data to the form)

if($formPrimaryField == -1 ){
	
	$formFields[] = array("id" => "idSliderEntry",     "type" => "Hidden",   "label" => "Slider Id",   "req" => true ,"value" => "$idSliderEntry", "additional" => '' );
}

$formFields[]	= array( "id" => "titleSlideItem"		,"label" => "Title"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => "");
$formFields[]	= array( "id" => "descriptionSlideItem","label" => "Description"		,"type" => "textarea"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => "");
$formFields[]   = array( "id" => "imageSlideItem"		,"label" => "Image Slider"		,"type" => "media"		,"value" => ""		,"additional" => ""		,"set" => "img"		,"dbfield" => "1"		,"req" => true		,"unique" => "");
$formFields[]   = array( "id" => "statusSliderItem"		,"label" => "Status Slider Item"		,"type" => "select"		,"value" => "1"		,"additional" => ""		,"set" => "status"		,"dbfield" => "1"		,"req" => true		,"unique" => "");
$formFields[]	= array( "id" => "orderSliderItem"		,"label" => "Order"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => true		,"unique" => "");

$formFields[]	= array( "id" => "smalltitleSlideItem"		,"label" => "Small Title"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => false		,"unique" => "");
$formFields[]	= array( "id" => "mediumtitleSlideItem"		,"label" => "Medium Title"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => false		,"unique" => "");
$formFields[]	= array( "id" => "Width"		,"label" => "width"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => false		,"unique" => "");
$formFields[]	= array( "id" => "height"		,"label" => "Height"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"		,"req" => false		,"unique" => "");

$formFields[]   = array( "id" => ""		,"label" => ""		,"type" => "button"		,"value" => "Proceed"		,"additional" => ""		,"set" => ""		,"dbfield" => ""		,"req" => false		,"unique" => "");

$forms = array( 
	"identifier" 	=> "dynamicForm", 
	"name" 			=> "Creating New qslideritems", 
    "primaryFiled"  => "idSliderItem", 
	"url" 			=> Config::_get('current.plugin')."/backend/includes/modules/ajax/set/qslideritems",
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> "qslideritems",
    "fields"        => $formFields,
);
		
