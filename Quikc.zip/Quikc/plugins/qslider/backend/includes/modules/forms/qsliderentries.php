<?php 

defined('QC_VALID') or die('Restricted Access!');
defined('QC_ADMIN') or die('Restricted Access!');

extract($_POST);

// value will be updated when getting the create/edit forms
if(isset($params->idSlider)){
	$idSlider = $params->idSlider;
}

// value will be updated when saving the values for the create new slider entry 
if( isset($formId) && $formId != '' && isset(${'idSlider_'.$formId}) ){
	$idSlider = ${'idSlider_'.$formId};	
}

// value will be updated when saving the values for existing slider entry
if( isset($formPrimaryField) && $formPrimaryField != '' && $formPrimaryField != -1 ){

    $detailsSliderEntry = qSlider::_getInstance()->_getSlideEntryDetails($formPrimaryField);
    
    if( !$detailsSliderEntry ){
        die("Not Allowed");
    }
    $idSlider = $detailsSliderEntry->idSlider; 
}

if( !isset($idSlider) || $idSlider == '' ) {
    die('Id Slider Not Defined');
}

$detailsSlider = qSlider::_getInstance()->_getSliderDetails($idSlider);

if( !$detailsSlider ) {
    die('Invalid Id Slider');
}

$pathListFile = Config::_getDir('current.plugin').'/backend/includes/modules/forms/sliders/'.$detailsSlider->linkSlider.'_entry.php';
        
if( file_exists($pathListFile) ){
    
    include $pathListFile;
    return;    
}

$formFields[]	= array( "id" => "titleSliderEntries"	,"label" => "Title Slider"		,"type" => "text"		,"value" => ""		,"additional" => ""		,"set" => ""		,"dbfield" => "1"	,"req" => true		,"unique" => "");
$formFields[]   = array( "id" => "statusSliderEntries"	,"label" => "Status Slider"		,"type" => "checkbox"	,"value" => "1"		,"additional" => ""		,"set" => ""		,"dbfield" => "1"	,"req" => false		,"unique" => "");

$formFields[]	= array( "id" => "widthSliderEntries"	,"label" => "Width"		,"type" => "text"		,"value" => "250"		,"additional" => ""		,"set" => ""		,"dbfield" => "1"	,"req" => true		,"unique" => "");
$formFields[]	= array( "id" => "heightSliderEntries"	,"label" => "Height"		,"type" => "text"		,"value" => "250"		,"additional" => ""		,"set" => ""		,"dbfield" => "1"	,"req" => true		,"unique" => "");

$formFields[]   = array( "id" => ""		                ,"label" => ""	,"type" => "button"		,"value" => "Proceed"		,"additional" => ""		,"set" => ""		,"dbfield" => ""		,"req" => false		,"unique" => "");

if($formPrimaryField == -1 ){
    $formFields[] = array("id" => "idSlider",     "type" => "Hidden",   "label" => "Slider Id",   "req" => true ,"value" => "$idSlider", "additional" => '' );
}


$forms = array( 
	"identifier" 	=> "dynamicForm", 
	"name" 			=> "Creating New Slider Entry", 
    "primaryFiled"  => "idSliderEntry", 
	"url" 			=> Config::_get('current.plugin')."/backend/includes/modules/ajax/set/".$Base->_getFileName(__FILE__),
	"success"       => "javascript:message_reporting('message_:FORM_ID','Your details saved successfully.',1)",
	"filename" 		=> $Base->_getFileName(__FILE__),
    "fields"        => $formFields,
);
		
