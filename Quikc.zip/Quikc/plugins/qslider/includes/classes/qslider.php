<?php
defined('QC_VALID') or die('Restricted Access!');

/**
* qSlider class, contains functions related to qSlider plugin
* 
*
* @version 1.0
* @http://www.quikc.org/
*/

class qSlider {
    /**
    * Array Contains the list of objects of the given slider 
    *
    * @var Object
    */
    private static $instance;

    /**
    * Contains the details of the retrieved sliders
    *
    * @var Object
    */
    private static $slidersDetails = array();

    /**
    * Contains the details of the retrieved slides
    *
    * @var Object
    */
    private static $slidesEntryDetails = array();
    
    /**
    * Contains the details of the retrieved slides
    *
    * @var Object
    */
    private static $sliderItemDetails = array();
    

    /* Basic Configuration functions starts from here
    <!-----------------------------------------------------------------------------------------------------------------------------------------
    */

    /** Checks weather there is any valid class instance exists or not. creates if there is not a valid instance exists
    * 
    *
    * @param void
    * @var Core class instance(object)
    */
    public static function _getInstance(){ 

        if (null === self::$instance) {

            $object = __CLASS__;
            // Starting new class object
            self::$instance = new $object;
        }
        return self::$instance;
    }

    /**
    * Return qSlider Details
    *
    * @param slider id(int)
    * @return slider details(object)
    */
    public function _getSliderDetails($idSlider){

        if(isset(self::$slidersDetails[$idSlider])){
            return self::$slidersDetails[$idSlider];
        } else if (Cache::_getInstance() -> _isCached('qslider_' . $idSlider)) {
            $detailsSlider = Cache::_getInstance() -> _getCache('qslider_' . $idSlider);
        } else {

            // query for 
            $query = "select * from ".Config::_getTable('qsliders')." where idSlider = :idSlider";    
            // bind values
            $arrayBind[] = array("key" => ":idSlider", "value" => $idSlider );    
            $detailsSlider = Core::_getRow($query,$arrayBind);

            Cache::_getInstance() -> _setCache('qslider_' . $idSlider, $detailsSlider);
        }

        if (!$detailsSlider) return false;

        self::$slidersDetails[$detailsSlider -> idSlider] = $detailsSlider;

        return $detailsSlider;
    }

    /**
    * Return qSlider Details by link
    *
    * @param slider id(string)
    * @return slider details(object)
    */

    public function _getSliderDetailsByLink($linkSlider){

        // query for 
        $query = "select * from ".Config::_getTable('qsliders')." where linkSlider = :linkSlider";    
        // bind values
        $arrayBind[] = array("key" => ":linkSlider", "value" => $linkSlider );    
        $detailsSlider = Core::_getRow($query,$arrayBind);

        if (!$detailsSlider) return false;

        Cache::_getInstance() -> _setCache('qslider_' . $detailsSlider -> idSlider, $detailsSlider);

        self::$slidersDetails[$detailsSlider -> idSlider] = $detailsSlider;

        return $detailsSlider;
    }

    /**
    * Return qSlider Slide entry Details
    *
    * @param slider id(int)
    * @return slider details(object)
    */
    public function _getSlideEntryDetails($idSliderEntry){
        
        if(isset(self::$slidesEntryDetails[$idSliderEntry])){
              
            return self::$slidesEntryDetails[$idSliderEntry];
        } else if (Cache::_getInstance() -> _isCached('qslider_entry_' . $idSliderEntry)) {
            $detailsSlideEntry = Cache::_getInstance() -> _getCache('qslider_entry_' . $idSliderEntry);
        } else {

            // query for 
            $query = "select * from ".Config::_getTable('qslider_entries')." where idSliderEntry = :idSliderEntry";    
            // bind values
            $arrayBind[] = array("key" => ":idSliderEntry", "value" => $idSliderEntry);    

            $detailsSlideEntry = Core::_getRow($query,$arrayBind);
            
            Cache::_getInstance() -> _setCache('qslider_entry_' . $idSliderEntry, $detailsSlideEntry);
        }
        
        if (!$detailsSlideEntry) return false;

        $optionsSliderEntries = json_decode( $detailsSlideEntry->optionsSliderEntries );

        if( count($optionsSliderEntries) > 0){
            foreach($optionsSliderEntries as $key => $value ){
                $detailsSlideEntry->$key = $value;
            }
        }

        self::$slidesEntryDetails[$detailsSlideEntry -> idSliderEntry] = $detailsSlideEntry;

        return $detailsSlideEntry;
    }
    
    
/**
    * Return qSlider Slide item Details
    *
    * @param slider id(int)
    * @return slider details(object)
    */
    public function _getSliderItemDetails($idSliderItem){
        
        if(isset(self::$sliderItemDetails[$idSliderItem])){
              
            return self::$sliderItemDetails[$idSliderItem];
        } else if (Cache::_getInstance() -> _isCached('qslider_slider_item_' . $idSliderItem)) {
            $detailsSliderItem = Cache::_getInstance() -> _getCache('qslider_slider_item_' . $idSliderItem);
        } else {

            // query for 
            $query = "select * from ".Config::_getTable('qslider_items')." where idSliderItem = :idSliderItem";    
            // bind values
            $arrayBind[] = array("key" => ":idSliderItem", "value" => $idSliderItem);    

            $detailsSliderItem = Core::_getRow($query,$arrayBind);
            
            Cache::_getInstance() -> _setCache('qslider_slider_item_' . $idSliderItem, $detailsSliderItem);
        }

        if (!$detailsSliderItem) return false;

        $optionSlideItems = json_decode( $detailsSliderItem->optionSlideItems);
        
        if(is_array($optionSlideItems) && count($optionSlideItems) > 0){
                    
            foreach($optionSlideItems as $key => $value ){
                $detailsSliderItem->$key = $value;
            }
        }

        self::$sliderItemDetails[$detailsSliderItem -> idSliderItem] = $detailsSliderItem;

        return $detailsSliderItem;
    }
    
    /**
    * Return list of Slider entries
    *
    * @param void
    * @return $listSliderEntries(array of objects)
    */
    public function _getSliderEntries(){

        // query for 
        $query = "select * from ".Config::_getTable('qslider_entries')." where statusSliderEntries = :statusSliderEntries order by titleSliderEntries";    
        // bind values
        $arrayBind[] = array("key" => ":statusSliderEntries", "value" => 1 );
        $listSliderEntries = Core::_getAllRows($query,$arrayBind);

        return $listSliderEntries;
    }

    /**
    * Return list of items for the given Slides
    *
    * @param slider id(int)
    * @return $listSlides(array of objects)
    */
    public function _getSliderItems($idSliderEntry){

        // query for 
        $query = "select * from ".Config::_getTable('qslider_items')." where idSliderEntry = :idSliderEntry order by orderSliderItem";    
        // bind values
        $arrayBind[] = array("key" => ":idSliderEntry", "value" => $idSliderEntry );
        $listSlides = Core::_getAllRows($query,$arrayBind);

        return $listSlides;
    }
    
    /**
     * Returns list of Slider Entries for a given Slider
     *
     * @param $idSliderEntry(SliderEntryid)
     * @return array of objects
     */
    public function _getSliderEntriesById($idSliderEntry) {
        
        if(!$idSliderEntry) return false;

        $query = " select * from " . Config::_getTable('qslider_entries') . " where idSliderEntry = :idSliderEntry ";
        $arrayBind[] = array("key" => ":idSliderEntry", "value" => $idSliderEntry);

        $listSliderEntries = Core::_getAllRows($query, $arrayBind);

        return $listSliderEntries;

    }
    /**
     * Returns list of Slider items for a given Slider Entry
     *
     * @param $idSliderItem(SliderItem id)
     * @return array of objects
     */
    public function _getSliderItemsById($idSliderItem) {
        
        if(!$idSliderItem) return false;

        $query = " select * from " . Config::_getTable('qslider_entries') . " where idSliderItem = :idSliderItem ";
        $arrayBind[] = array("key" => ":idSliderItem", "value" => $idSliderItem);

        $listSliderItems = Core::_getAllRows($query, $arrayBind);

        return $listSliderItems;

    }
    
    /**
     * Deletes given Slider Entry
     *
     * @param int(idSliderEntry id)
     * @return null
     */
    public function _deleteSliderEntry($idSliderEntry) {

        $arrayBind[]= array("key" => ":primaryField", "value" =>  $idSliderEntry);

        $query  = "delete from ".Config::_getTable('qslider_items')." where idSliderEntry = :primaryField";
        Core::_runQuery($query,$arrayBind);
        
        $query  = "delete from ".Config::_getTable('qslider_entries')." where idSliderEntry = :primaryField";
        Core::_runQuery($query,$arrayBind);
       
        // Removing the cache
        Cache::_getInstance() -> _removeCache('qslider_entry_ ' . $idSliderEntry);

    }
    
    /**
     * Deletes given Slider item
     *
     * @param int(idSliderItem id)
     * @return null
     */
    public function _deleteSliderItems($idSliderItem) {
    
        $query  = "delete from ".Config::_getTable('qslider_items')." where `idSliderItem` = :idSliderItem";
        $arrayBind[]= array("key" => ":idSliderItem", "value" =>  $idSliderItem);

        Core::_runQuery($query,$arrayBind);

        // Removing the cache
        Cache::_getInstance() -> _removeCache('qslider_slider_item_' . $idSliderItem);
        
    }

 }

