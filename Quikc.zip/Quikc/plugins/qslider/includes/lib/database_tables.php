<?php
defined('QC_VALID') or die('Restricted Access!');

Config::_setTable('iossliders'      	, 'iossliders' );
Config::_setTable('iossliders_slides'   , 'iossliders_slides' );


