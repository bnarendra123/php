<form method="post" action="" id="reg">
Name : <input type="text" name="name"><br>
Email : <input type="text" name="email"><br>
<input type="submit" name="submit" value="Submit">
</form>
<link href="style-main.css" rel="stylesheet">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script>

$(document).ready(function()

{

$("#reg").validate

        ({

    

                // Specify the validation rules

                rules: 

                {

                    name: "required",
					email: {

                        required: true,

                        email: true

                    },
                },

                

                // Specify the validation error messages

                messages: 

                {

                    name: "Please enter name",
					
					email: "Please enter a valid email address",

                    
                },

                

               

        });

        

});

</script>