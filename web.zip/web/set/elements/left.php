<?php
include "elements/config.php";
$sql="select * from categories where status ='0'";
$result=mysql_query($sql,$con);
?>
 <div class="sub-cate">
				<div class=" top-nav rsidebar span_1_of_left">
					<h3 class="cate">CATEGORIES</h3>
					<?php
					while($row=mysql_fetch_array($result)){ ?>
		 <ul class="menu">
		 	<?php
$sql1="select c.* from subcategories c join categories t where t.id=c.status";
$query=mysql_query($sql1,$con);
?>
		<li class="item1"><a href="#"><?php echo $row['category']; ?><img class="arrow-img" src="images/arrow1.png" alt=""/> </a>
			
<?php
					while($row1=mysql_fetch_array($query)){
						if($row1['status']==$row['id']){
							?>
						
			<ul class="cute">
				<li class="subitem1"><a href="product.html"><?php echo $row1['name']; ?> </a></li>
				
			</ul>
			<?php } }?>
		</li>
		<?php } ?>
		
		
			
	</ul>
					</div>
				<!--initiate accordion-->
		<script type="text/javascript">
			$(function() {
			    var menu_ul = $('.menu > li > ul'),
			           menu_a  = $('.menu > li > a');
			    menu_ul.hide();
			    menu_a.click(function(e) {
			        e.preventDefault();
			        if(!$(this).hasClass('active')) {
			            menu_a.removeClass('active');
			            menu_ul.filter(':visible').slideUp('normal');
			            $(this).addClass('active').next().stop(true,true).slideDown('normal');
			        } else {
			            $(this).removeClass('active');
			            $(this).next().stop(true,true).slideUp('normal');
			        }
			    });
			
			});
		</script>
					
	   		     	<!-- <a class="view-all all-product" href="product.html">VIEW ALL PRODUCTS<span> </span></a>--> 	
			</div>