<?php
session_start();
session_destroy();
include "../elements/config.php";
header("location: ../index.php");
?>

