<?php
session_start();
$sid=$_SESSION['id']; 
include "../elements/config.php";
$sql="delete from cart where user='$sid'";
$result=mysql_query($sql);
if($result)
{
	echo "<script>alert('cart items cleared')</script>";
	header("Refresh:0; url=../index.php");
}
	else
	{
		echo "<script>alert('fail to clear cart items')</script>";
		header("Refresh:0; url=../cart.php");
	}
?>
