<form method="post" action="">
<p align="center">Fill details</p>
Name : <input type="text" name="name" id="name"><br><br>
Email : <input type="text" name="email" id="email"><br><br>
Mobile number : <input type="text" name="phone" id="phone"><br><br>
Address : <textarea name="address" id="address" rows="5" cols="20"></textarea><br><br>
<input type="submit" name="submit" value="Submit">&emsp; &emsp; <input type="reset" name="reset" value="Reset">
<?php
session_start();
$sid=$_SESSION['id'];
?>
<?php
if(isset($_POST['submit'])){
	$name=$_POST['name'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$address=$_POST['address'];
	$con=mysql_connect("localhost","root","");
	$db=mysql_select_db("core",$con);
	$sql="insert into details values('','$name','$email','$phone','$address','$sid')";
	$result=mysql_query($sql,$con);
	if($result){
		$sql2="select * from cart where user='$sid'";
		$result1=mysql_query($sql2);
		while($row=mysql_fetch_array($result1)){
			$id=$row['id'];
			$producttitle=$row['producttitle'];
			$category=$row['category'];
			$image=$row['image'];
			$quantity=$row['quantity'];
			$price=$row['price'];
			$description=$row['description'];
		}
		$sql4="insert into orders values ('','$id','$category','$producttitle','$image','$quantity','$price','$description','$sid')";
		$result2=mysql_query($sql4,$con);
		if($result2){
		$sql1="delete from cart where user='$sid'";
		$result1=mysql_query($sql1,$con);
		if($result1){
			echo "<script>alert('order successful')</script>";
		}
	}else{
		echo "<script>alert('Order failed')</script>";
	}
}
}
?>
</form>