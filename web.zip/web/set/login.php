
<?php
session_start();
	$email=$_POST['email'];
	$password=$_POST['password'];
	$con=mysql_connect("localhost","root","") or die(mysql_error());
	$db=mysql_select_db("core",$con) or die(mysql_error());
	$result=mysql_query("select * from registration where email='$email' and password='$password'");
	/*$row = mysql_fetch_array($result);
	//$id= $row['id'];
	$id1=$_SESSION['id'];
if($row["email"]==$email && $row["password"]==$password)
    //echo "<script>alert('login success')</script><script>location.href='index.php'</script>";
  //header("location:index.php");
  die('ok');
else
    //echo "<script>alert('invalid login details')";
    die('fail');*/
	
	while($row=mysql_fetch_array($result))
		{
			$id = $row['id'];
		}	
	$_SESSION['id']=$id;
		
	$num_row=mysql_num_rows($result);
	if($num_row>0)
	{
		//echo "<script>alert('login success')</script><script>location.href='index.php'</script>";
		die('ok');
	//print"welcome to your page";	
	}
	else {
		die('fail');
	}
?>