<?php
    $name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	
	include "elements/config.php";
	$sql="insert into registration values('','$name','$email','$password')";
	$query=mysql_query($sql,$con);
	if($query){
		//echo "<script>alert('successfully registered')</script>";
		die('ok');
	}else{
		//echo "<script>alert('insert failed')</script>";
		die('fail');
	}
	mysql_close($con);
?>