<?php
    $name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	
	include "elements/config.php";
	$sql1="select email from registration where email='$email'";
	$result=mysql_query($sql1,$con);
	
	if(mysql_num_rows($result)>1){
		echo "<script>alert('User already exists')</script>";
	} 
	else{
	$sql="insert into registration values('','$name','$email','$password')";
	$query=mysql_query($sql,$con);
		echo "<script>alert('successfully registered')</script>";
	if(!$query){
		echo "<script>alert('fail to register')</script>";
	}
	mysql_close($con);
	}
?>