<?php
session_start();
$sid=$_SESSION['id'];
	$password=$_POST['password'];
	$newpassword=$_POST['newpassword'];
	$confirmpassword=$_POST['confirmpassword'];
	if($newpassword==$confirmpassword)
	{
		$con=mysql_connect("localhost","root","") or die(mysql_error());
		$db=mysql_select_db("core",$con) or die(mysql_error());
		$sql="select password from registration where id='$sid'";
		$result=mysql_query($sql,$con);
		while($row=mysql_fetch_array($result))
		
			
			if($password==$row['password'])
			{
				$sql1=mysql_query("UPDATE registration SET password='$newpassword' where id='$sid'");
				if($sql1)
				
					die('Password Changed Successfully');
			
						else
					{
						die('fail');
					}
			
			}
				else
			{
				echo "Old Password wrong";
			}
		}			
			else
			{
				echo "Passwords not match";
			}
?>
