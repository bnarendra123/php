<?php
include "elements/header.php";
include "elements/left.php";
include "elements/config.php";
?>
<?php
 $id=$_REQUEST['id'];
 $sid=$_SESSION['id'];
$count="select id,user from wishlist where pid='$id' and user='$sid'";
$results=mysql_query($count);
if(mysql_num_rows($results)==0)
{
	$sql="select * from items where id='$id'";
	$result=mysql_query($sql);
	while($row=mysql_fetch_array($result))
	{
		$id=$row['id'];
		$category=$row['category'];
		$producttitle=$row['producttitle'];
		$image=$row['image'];
		 $price=$row['price'];
		$quantity = 1;
		$availablity = $row['availablity'];
		 $description=$row['description'];
		$sql1="insert into wishlist values ('','$id','$category','$producttitle','$image','$price','$description','$sid')";
		$result1=mysql_query($sql1,$con);
		if($result1)
		{
			echo"<script>alert('item added to wishlist');</script>";
		}
	}
}
else
{
	echo "<script>alert('item already added to wishlist')</script>";	
}
?>
<table border="0" cellspacing="5" cellpadding="5" width="800px" style="margin-top: 50px;">
	<th>Image</th><th>Producttitle</th><th>Price</th><th>Description</th>
<?php
$sql2= "select * from wishlist where user='$sid'";
$query = mysql_query($sql2,$con);
while($row=mysql_fetch_array($query))
{
?>
		<tr>
			<td><img src="admin/images/<?php echo $row['image']; ?>" width="100px" height="100px"/></td>
			<td><?php echo $row['producttitle']; ?></td>
			<td><?php echo $row['price']; ?></td>
			<td><?php echo $row['description']; ?></td>
			<td><a href="set/wishdelete.php?id=<?php echo $row['id']; ?>">Delete</td>
			<td><a href="wishadd.php?id=<?php echo $row['id']; ?>">Add to cart</a></td>
		</tr>
<?php } ?>
</table>