<div class="footer">
		<div class="footer-top">
			<div class="container">
				<div class="latter">
					<h6>NEWS-LETTER</h6>
					<div class="sub-left-right">
						<form method="post" action="">
							<input type="text" name="email" value="Enter email here"onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter email here';}" required="required"/>
							<input type="submit" value="SUBSCRIBE" name="submit"/>
						</form>
					</div>
					<div class="clearfix"> </div>
				</div>
				<div class="latter-right">
					<p>FOLLOW US</p>
					<ul class="face-in-to">
						<li><a href="https://www.twitter.com/shopee" target="_blank"><span> </span></a></li>
						<li><a href="https://www.facebook.com/shopee" target="_blank"><span class="facebook-in"> </span></a></li>
						<div class="clearfix"> </div>
					</ul>
					<div class="clearfix"> </div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="footer-bottom">
			<div class="container">
				<div class="footer-bottom-cate">
					<h6>CATEGORIES</h6>
					<ul>
						<li><a href="#">Mobiles</a></li>
						<li><a href="#">Desktop</a></li>
						<li><a href="#">Laptop</a></li>
						<li ><a href="#">Sports</a></li>
						<li ><a href="#">Shoes</a></li>
						
					</ul>
				</div>
				<div class="footer-bottom-cate bottom-grid-cat">
					<h6>FEATURE PROJECTS</h6>
					<ul>
						<li><a href="#">Curabitur sapien</a></li>
						<li><a href="#">Dignissim purus</a></li>
						<li><a href="#">Tempus pretium</a></li>
						<li ><a href="#">Dignissim neque</a></li>
						<li ><a href="#">Ornared id aliquet</a></li>
						<li><a href="#">Ultrices id du</a></li>
						<li><a href="#">Commodo sit</a></li>
					</ul>
				</div>
				<div class="footer-bottom-cate">
					<h6>TOP BRANDS</h6>
					<ul>
						<li><a href="#">Samsung</a></li>
						<li><a href="#">Dell laptop</a></li>
						<li><a href="#">Reebock</a></li>
						<li ><a href="#">Acer Desktop</a></li>
						
						
					</ul>
				</div>
				<div class="footer-bottom-cate cate-bottom">
					<h6>OUR ADDERSS</h6>
					<ul>
						<li>Aliquam metus  dui. </li>
						<li>orci, ornareidquet</li>
						<li> ut,DUI.</li>
						<li >nisi, dignissim</li>
						<li >gravida at.</li>
						<li class="phone">PH : 9848032919</li>
						<!--<li class="temp"> <p class="footer-class">Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p></li>-->
					</ul>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	
<?php
if(isset($_POST['submit']))
{
	echo $newsletter=$_POST['email'];
	$con=mysql_connect("localhost","root","") or die(mysql_error());
	$db=mysql_select_db("core",$con) or die(mysql_error());
	$sql="insert into newsletter values('','$newsletter')";
	$result=mysql_query($sql,$con);
	if($result)
	{
		echo "<script>alert('Newsletter Subscription success')</script>";
	}else
		{
			echo "<script>alert('fail to subscribe')</script>";
		}
		
}
