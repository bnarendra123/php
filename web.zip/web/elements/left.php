<?php 
include "elements/config.php";
?>
<div class="sub-cate">
				<div class=" top-nav rsidebar span_1_of_left">
					<h3 class="cate">CATEGORIES</h3>
		 <ul class="menu">
		<?php
		$sql="select * from categories where status = '0'";
		$result=mysql_query($sql);
		while($row=mysql_fetch_array($result))
		{
			$cat_id=$row['id']; 
		?>
		<li class="item2"><a href="#"><?php echo $row['category']; ?><img class="arrow-img " src="images/arrow1.png" alt=""/></a>
			
			
			<ul class="cute">
				<?php 
			$sql1="select * from subcategories where status = '$cat_id' ";
			$result1=mysql_query($sql1);
			while($row1=mysql_fetch_array($result1))
			{
				$name=$row1['name'];	
			
			?>
				<li class="subitem1"><a href="product.php?category=<?php echo $row['id']; ?>&subcategory=<?php echo $row1['status']; ?>&sscategory=<?php echo $row1['id']; ?>"><?php echo $name; ?></a></li>
				
				<?php } ?>
			</ul>
			
		</li>
		<?php } ?>	
		
	</ul>
					</div>
				<!--initiate accordion-->
		<script type="text/javascript">
			$(function() {
			    var menu_ul = $('.menu > li > ul'),
			           menu_a  = $('.menu > li > a');
			    menu_ul.hide();
			    menu_a.click(function(e) {
			        e.preventDefault();
			        if(!$(this).hasClass('active')) {
			            menu_a.removeClass('active');
			            menu_ul.filter(':visible').slideUp('normal');
			            $(this).addClass('active').next().stop(true,true).slideDown('normal');
			        } else {
			            $(this).removeClass('active');
			            $(this).next().stop(true,true).slideUp('normal');
			        }
			    });
			
			});
		</script>
					
	   		     	 
			</div>
	   		    <div class="clearfix"> </div>        	         
		</div>