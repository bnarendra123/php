<?php
include "elements/header.php";
include "elements/left.php";
include "elements/config.php";
?>
<?php
 $id=$_REQUEST['id'];
 $sid=$_SESSION['id'];
$count="select id,user from cart where pid='$id' and user='$sid'";
$results=mysql_query($count);
if(mysql_num_rows($results)==0)
{
	$sql="select * from items where id='$id'";
	$result=mysql_query($sql);
	while($row=mysql_fetch_array($result))
	{
		$id=$row['id'];
		$category=$row['category'];
		$producttitle=$row['producttitle'];
		$image=$row['image'];
		 $price=$row['price'];
		$quantity = 1;
		$availablity = $row['availablity'];
		 $description=$row['description'];
		$sql1="insert into cart values ('','$id','$category','$producttitle','$image','$quantity','$price','$description','$sid')";
		$result1=mysql_query($sql1,$con);
		if($result1)
		{
			echo"<script>alert('item added to cart');</script>";
		}
	}
}
else
{
	echo "<script>alert('item already added to cart')</script>";	
}

?>
<table border="0" cellspacing="5" cellpadding="5" width="800px">
	<th>Image</th><th>Producttitle</th><th>Price</th><th>Quantity</th><th>Amount</th><th>Description</th>
<?php
$sql2= "select * from cart where user='$sid'";
$query = mysql_query($sql2,$con);
if($query){
while($row=mysql_fetch_array($query))
{
?>
		<tr>
			<td><img src="admin/images/<?php echo $row['image']; ?>" width="100px" height="100px"/></td>
			<td><?php echo $row['producttitle']; ?></td>
			<td><?php echo $row['price']; ?></td>
			<td><input type="number" name="quantity" value="<?php echo $row['quantity'] ?>" min="1" max="1000" id="<?php echo $row['id']; ?>" onchange="submit(this.value,<?php echo $row['id']; ?>)"></td>
			<td><?php echo $amount=$row['quantity'] *$row['price'] ?></td>
			<td><?php echo $row['description']; ?></td>
			<td><a href="set/cartdelete.php?id=<?php echo $row['id']; ?>">Delete</td>
		</tr>
		
		 <?php $totalamount=$totalamount + $amount; ?>
<?php } ?>
 <?php $_SESSION['tamount']=$totalamount;?>
 <tr>
 	<td>&emsp; &emsp; </td>
 </tr>
<tr>
	<td colspan="6" style="color: green; font-size: 18px;">Total amount:</td><td style="color: green; font-size: 18px;"><?php echo $_SESSION['tamount']; ?></td>
<tr>
	<tr>
		<td>&emsp; &emsp; </td>
	</tr>
	<tr>
		<td><a href="set/checkout.php">Checkout</a></td><td><a href="set/clearcart.php">Clear cart</a></td>
	</tr>
</table>
<?php } else{ ?>
			<p>There is no items in your cart</p>
			<?php } ?>
<script type="text/javascript">
	function submit(txt,id){
		window.location="update.php?quantity="+txt+"&id="+id;
	}
</script>