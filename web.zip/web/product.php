<?php
include "elements/header.php";
include "elements/config.php";
?>
	<!---->
	<!-- start content -->
	<?php
	$id=$_GET['category'];
	$pid=$_GET['subcategory'];
	$sid=$_GET['sscategory'];
	$sql="select * from items where category='$id' and subcategory='$pid' and sscategory='$sid'";
	//print_r($sql);
	$result=mysql_query($sql); 
	?>
	<div class="container">
		
	<div class="women-product">
		<div class=" w_content">
			<div class="women">
				<!--<a href="#"><h4>Enthecwear - <span>4449 itemms</span> </h4></a>-->
				<ul class="w_nav">
					<li>Sort : </li>
			     	<li><a class="active" href="#">popular</a></li> |
			     	<li><a href="#">new </a></li> |
			     	<li><a href="#">discount</a></li> |
			     	<li><a href="#">price: Low High </a></li> 
			     <div class="clearfix"> </div>	
			     </ul>
			     <div class="clearfix"> </div>	
			</div>
		</div>
		<?php 
		while($row=mysql_fetch_array($result)){ ?>
		<!-- grids_of_4 -->
		<div class="grid-product">
		  <div class="  product-grid">
			<div class="content_box"><a href="single.html">
			   	<div class="left-grid-view grid-view-left">
			   	   	 <a href="single.php?id=<?php echo $row['id']; ?>"><img src="admin/images/<?php echo $row['image']; ?>" class="img-responsive watch-right" alt=""/></a>
				   	   	<div class="mask">
	                        <div class="info">Quick View</div>
			            </div>
				   	  </a>
				</div>
				    <h4><a href="#"><?php echo $row['producttitle']; ?></a></h4>
				     <p><?php echo $row['description']; ?></p>
				     Rs. <?php echo $row['price']; ?>
			   	</div>
              </div>
			 
		</div>
		<?php } ?>
	</div>
	<?php
			  include "elements/left.php";
			  ?>
	<div class="clearfix"> </div>
</div>
	<!---->
	<?php
	include "elements/footer.php";
	?>
</body>
</html>