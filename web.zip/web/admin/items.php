
<html>
	<head>
		<style>
			.ahead{
				margin-left:20px;
				font-size:18px;
				color:blue;
			}
		</style>
		
<!--function getState(val) {
	alert(val);
	$.ajax({
	type: "POST",
	url: "category/get_state.php",
	data:'country_id='+val,
	success: function(data){
		$("#state-list").html(data);
	}
	});
	return true;
}-->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
	function getState(id){
		var val=id.value;
		var pass_data = {
			'category' : id,
		};
		$.ajax({
			url : "category/get_state.php",
			type : "POST",
			data : pass_data,
			success : function(data) {
				$("#subcategory").html(data);
			}
		});
		return true;
	}

function selectCountry(id) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>
	</head>
	<body>
		<div class="ahead">
			<a href="items.php">Product</a>&nbsp; &nbsp; <a href="slider.php">Slider image</a>&emsp;  <a href="multipleimg.php">Sub images</a>
			<a href="logout.php" style="margin-left: 1200px;">Logout</a>
		</div>
	</body>
</html>
<?php
if(isset($_POST['submit']))
{
	$category=$_POST['category'];
	$subcategory=$_POST['subcategory'];
	$producttitle=$_POST['title'];
	$image=$_FILES['file']['name'];
	$img=$_FILES['file']['tmp_name'];
	$target_dir="images/";
	if(move_uploaded_file($img,$target_dir.$image))
	{
		echo "";
	}
		else
		 	{
				echo "not";
			}
				$price=$_POST['price'];
				$availablity=$_POST['availablity'];
				$description=$_POST['desc'];
				$con=mysql_connect("localhost","root","") or die(mysql_error());
				$db=mysql_select_db("core",$con) or die(mysql_error());
				$sql="insert into items values('','$category','$subcategory','$producttitle','$image','$price','$availablity','$description')";
				$query=mysql_query($sql,$con);
				if($query)
				{
					echo "<script>alert('successfully inserted')</script>";
				}
					else
						{
							echo "<script>alert('fail to insert')</script>";
						}
							mysql_close($con);
}
?>
<html>
	<head>
		<script src="//tinymce.cachefly.net/4.2/tinymce.min.js"></script>
<script>tinymce.init({selector:'textarea'});</script>
	</head>
	<body>
		<form method="post" name="myform" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
		<table border="0" cellspacing="5" cellpadding="10" align="center">
			<th style="font-size: 20px; color: green;">&nbsp; &nbsp; Insert new product</th>
			
			<tr>
					<td>Category</td><td>
				<?php
			$con=mysql_connect("localhost","root","") or die(mysql_error());
			$db=mysql_select_db("core",$con) or die(mysql_error());
			$sql="select * from categories where status=0";
			$result=mysql_query($sql,$con) ?>		
						<select name="category" id="category" class="demoInputBox" onchange="getState(this.value);">
					
					<option value=""></option>
					<?php
				while($row=mysql_fetch_array($result)){ ?>
					<option value="<?php echo $row["id"]; ?>"><?php echo $row['category']; ?></option>
					<?php } ?>
					</select>
					
				</td>
			</tr>
			
			<tr>
				<td>Sub Category</td><td>
					
<select name="subcategory" id="subcategory" class="demoInputBox">
<option value="">Select State</option>
</select>
				</td>
			</tr>
			<tr>
				<td>Product title</td><td><input type="text" name="title" id="producttitle"></td>
			</tr>
			<tr>
				<td>image</td><td><input type="file" name="file" id="image"></td>
			</tr>
			<tr>
				<td>price</td><td><input type="text" name="price" id="price"></td>
			</tr>
			<tr>
				<td>Availablity</td><td><input type="text" name="availablity" id="availablity"></td>
			</tr>
			<tr>
				<td>Description</td><td><textarea name="desc" cols="30" rows="10" id="description"></textarea></td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="Submit">&nbsp; &nbsp;<input type="reset" name="reset" value="Reset"></td>
			</tr>
		</table>
	</body>
</html>

