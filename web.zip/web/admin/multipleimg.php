
<form method="post" action="" enctype="multipart/form-data">
Album : <input type="text" name="album" id="album"><br><br>
Images : <input type="file" name="file[]" multiple><br><br>
<input type="submit" name="submit" value="Submit">
</form>
<?php
if(isset($_POST['submit'])){
$con=mysql_connect("localhost","root","") or die(mysql_error());
$db=mysql_select_db("core",$con) or die(mysql_error());
$targetPath = "album/";
$album=$_POST['album'];
$image=$_FILES['file']['name'];
$img=$_FILES['file']['tmp_name'];

	foreach ($_FILES['file']['name'] as $name => $value)//loop for excute the all uploaded files
	{
		
		if(move_uploaded_file($img[$name],$targetPath.$value))
		{
			$sql="insert into album values('','$album','$value')";
				$result=mysql_query($sql,$con);	
		}	 
			
		}
}
 ?> 

