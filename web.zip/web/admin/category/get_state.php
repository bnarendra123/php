<?php
$v=intval($_REQUEST['category']);
//require_once("dbcontroller.php");
//$db_handle = new DBController();
include "../elements/config.php";
if(!empty($_REQUEST["category"])) {
	$sql ="SELECT * FROM subcategories WHERE status = '" . $_REQUEST["category"] . "'";
	//$results = $db_handle->runQuery($query);
	$result=mysql_query($sql);
?>
	<option value="">Select State</option>
<?php
	//foreach($results as $state) 
	while($row=mysql_fetch_array($result)){
?>
	<option value="<?php echo $row["status"]; ?>"><?php echo $row["name"]; ?></option>
<?php
	}
}
?>