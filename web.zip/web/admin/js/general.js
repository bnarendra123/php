function reg(){
	var name=$('#name').val();
	var email=$('#email').val();
	var phone=$('#phone').val();
	var password=$('#password').val();
	var rpassword=$('#rpassword').val();
	var gender=$('input[type="radio"]:checked').val();
	var errorcount=0;
	if(name==""){
		$('#namer').html("please enter name");
		$('#namer').css("color","red");
		errorcount++;
	}else{
		$('#namer').html("");
	}
	if(email==""){
		$('#emailr').html("please enter email");
		$('#emailr').css("color","red");
	}else{
		$('#emailr').html("");
	}
	if (phone == "") {
		$('#phoner').html("Enter your Mobile number");
		$('#phoner').css("color", "red");
		errorcount++;
	} else {
		if (isNaN(phone)) {
			$("#phoner").html("Enter the valid Mobile Number");
			$("#phoner").css("color", "red");
			errorcount++;
		}
		if ((phone.length != 10)) {
			$("#phoner").html("Please enter 10 digit mobile no");
			$("#phoner").css("color", "red");
			errorcount++;
		} else {
			$("#phoner").html("");
		}
	}
	if(password==""){
		$('#passwordr').html("Please enter password");
		$('#passwordr').css("color","red");
		errorcount++;
	}else{
		$('#passwordr').html("");
	}
	if(rpassword==""){
		$('#passwordre').html("Please enter repeat password");
		$('#passwordre').css("color","red");
		errorcount++;
	}else{
		$('#passwordre').html("");
	}
	if($('input[type="radio"]:checked').length=="0")
	{
		$('#genr').html("Please enter gender");
		$('#genr').css("color","red");
		errorcount++;
	}else{
		$('#genr').html("");
	}
	
	if(errorcount>0){
		return false;
	}
	return true;
}

function log(){
	var email=$('#email').val();
	var password=$('#password').val();
	var errorcount=0;
	if(email==""){
		$('#emaill').html("please enter email");
		$('#emaill').css("color","red");
		errorcount++;
	}else{
		$('#emaill').html("");
	}
	if(password==""){
		$('#pwdl').html("please enter password");
		$('#pwdl').css("color","red");
		errorcount++;
	}else{
		$('#pwdl').html("");
	}
	if(errorcount >0){
	return false;
	}
	return true;
}

