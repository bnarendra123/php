<?php
include "elements/header.php";
?>
	<!---->
	<div class="container">
		
      	   <div class="account_grid">
			   <div class=" login-right">
			  	<h3>REGISTERED CUSTOMERS</h3>
				<p>If you have an account with us, please log in.</p>
				<form>
				  <div>
					<span>Email Address<label>*</label></span>
					<input type="text" name="email" id="email"> <span id="emaill"></span>
				  </div>
				  <div>
					<span>Password<label>*</label></span>
					<input type="password" name="password" id="password"> <span id="pwdl"></span>
				  </div>
				  <a class="forgot" href="#">Forgot Your Password?</a>
				  <input type="submit" value="Login" name="submit" onclick="return log();">
			    </form>
			   </div>	
			    <div class=" login-left">
			  	 <h3>NEW CUSTOMERS</h3>
				 <p>By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
				 <a class="acount-btn" href="register.php">Create an Account</a>
			   </div>
			   <div class="clearfix"> </div>
			 </div>
			 <?php
			  include "elements/left.php";
			  ?>
			  <div class="clearfix"> </div>
      	 </div>
	<!---->
	<?php
	include "elements/footer.php";
	?>
</body>
</html>