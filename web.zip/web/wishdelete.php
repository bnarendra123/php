<?php
$id=$_GET['id'];
$con=mysql_connect("localhost","root","") or die(mysql_error());
$db=mysql_select_db("core",$con) or die(mysql_error());
$query = mysql_query("delete from wishlist where id='$id'");
if($query){
	echo "<script>alert('successfully deleted')</script>";
}
else{
	echo "<script>alert('fail to delete')</script>";
}
