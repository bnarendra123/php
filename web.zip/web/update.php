<?php
session_start();
$quantity=$_REQUEST['quantity'];
$id=$_REQUEST['id'];
$sid=$_SESSION['id'];
include "elements/config.php";
$sql="update cart set quantity='$quantity' where id='$id' and user='$sid'";
$result=mysql_query($sql,$con);
if($result){
	header("Refresh:0; url=cart.php");
}else{
	echo "<script>alert('fail')</script>";
}
?>

