<?php
include "elements/header.php";
include "elements/left.php";
?>
<?php
$id=$_SESSION['id'];
?>
<?php
$con=mysql_connect("localhost","root","") or die(mysql_error());
$db=mysql_select_db("core",$con) or die(mysql_error());
$sql="select * from registration where id='$id' ";
$result=mysql_query($sql,$con);
?>
<a href="changepass.php">Change Password</a><br>
<table border="1" cellspacing="5" cellpadding="5" align="center" style="margin-left: 50px; margin-top: 100px;" width="500px" height="100px">
	<th>Name</th><th>Email</th><th></th>
	<?php
	while($row=mysql_fetch_array($result)){
		?>
		<tr>
			<td>&emsp; <?php echo $row['name']; ?></td>
			<td>&emsp; &nbsp; <?php echo $row['email']; ?></td>
			<td><a href="editpro.php?id=<?php echo $row['id']; ?>">Edit</a></td>
		</tr>
		<?php
	}
	?>
</table>
