<?php
include "elements/header.php";
?>
	<!---->
	<div class="container"> 
			         
		<div class="register">
		  	  <form method="post" action=""> 
				 <div class="  register-top-grid">
					<h3>PERSONAL INFORMATION</h3>
					<div class="mation">
						<span>Name<label>*</label></span>
						<input type="text" name="name" id="name"> <span id="namer"></span>
					
						
					 
						 <span>Email Address<label>*</label></span>
						 <input type="text" name="email" id="email"> <span id="emailr"></span>
						 
						 <span>Password<label>*</label></span>
						 <input type="password" name="password" id="password"> <span id="passwordr"></span>
					</div>
					
					   
					 </div>
				    
			
				<div class="clearfix"> </div>
				<div class="register-but">
				   
					   <input type="submit" value="submit" name="submit" onclick="return reg();">
					   <div class="clearfix"> </div>
				   </form>
				</div>
		   </div>
		   <?php
			  include "elements/left.php";
			  ?>
	</div>
	<!---->
	<?php
	include "elements/footer.php";
	?>
</body>
</html>