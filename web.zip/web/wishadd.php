<?php
session_start();
$id=$_REQUEST['id'];
$sid=$_SESSION['id'];
include "elements/config.php";
$count="select id,user from wishlist where pid='$id' and user='$sid'";
$results=mysql_query($count);
if(mysql_num_rows($results)==0)
{
	$sql="select * from wishlist where id='$id' and user='$sid'";
	$result=mysql_query($sql,$con);
	while($row=mysql_fetch_array($result))
	{
		$id=$row['id'];
		$producttitle=$row['producttitle'];
		$image=$row['image'];
		$price=$row['price'];
		$quantity=1;
		$category=$row['category'];
		$description=$row['description'];
		$sql1="insert into cart values ('','$id','$category','$producttitle','$image','$quantity','$price','$description','$sid')";
		$result1=mysql_query($sql1,$con);
		if($result1)
		{
			$sql2="delete from wishlist where id='$id' and user='$sid'";
			$result2=mysql_query($sql2);
			if($result2)
			{
				echo "<script>alert('item added to cart')</script><script>location.href='index.php';</script>";
			}
		}
	
	}
}
	else
	{
		echo "<script>alert('item already added to cart')</script>";
	}
