-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: sql103.lockernerd.co.uk
-- Generation Time: Mar 04, 2016 at 02:33 AM
-- Server version: 5.6.27-76.0
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lnw_16862589_core`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `album`
--

CREATE TABLE IF NOT EXISTS `album` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `album` varchar(100) NOT NULL,
  `images` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `album`
--

INSERT INTO `album` (`id`, `album`, `images`) VALUES
(33, 'Celkon a107', 'celkon a107-2.jpg'),
(34, 'Celkon a107', 'Celkon-A107-3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL,
  `category` varchar(100) NOT NULL,
  `producttitle` varchar(100) NOT NULL,
  `image` varchar(80) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `price` int(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `status`) VALUES
(1, 'Mobiles', 0),
(2, 'Desktop', 0),
(3, 'Laptop', 0),
(4, 'Sports', 0),
(5, 'Shoes', 0);

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE IF NOT EXISTS `details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(80) NOT NULL,
  `address` varchar(200) NOT NULL,
  `user` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`id`, `name`, `email`, `phone`, `address`, `user`) VALUES
(6, 'raj', 'raj@gmail.com', '9848032919', 'hyd', 61),
(7, 'raj', 'raj@gmail.com', '9848032919', 'hyd', 61);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  `producttitle` varchar(100) NOT NULL,
  `image` varchar(80) NOT NULL,
  `price` int(100) NOT NULL,
  `availablity` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `pid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `category`, `producttitle`, `image`, `price`, `availablity`, `description`, `pid`) VALUES
(1, 'Mobile phones', 'Celkon a107', 'Celkon-A107.jpg', 6000, 'in stock', '<p>Celkon a107</p>', 1),
(2, 'Mobile phones', 'redmi', 'redmi 2  1.jpg', 6000, 'in stock', '<p>Xiaomi redmi 2</p>', 1),
(3, 'Laptop', 'Acer laptop', 'acer1.png', 32000, 'in stock', '<p>Acer laptop</p>', 3),
(4, 'Laptop', 'Toshiba', 'd8xc15y6pp_toshiba.jpg', 28000, 'in stock', '<p>Toshiba laptop</p>', 3),
(5, 'Laptop', 'acer', 'acer.jpg', 20000, 'instock', '<p>acer</p>', 3),
(6, 'Mobile phones', 'Celkon a42', 'xolo-a42.jpg', 5000, 'in stock', 'Celkon a42', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `category` varchar(200) NOT NULL,
  `producttitle` varchar(100) NOT NULL,
  `image` varchar(80) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `pid`, `category`, `producttitle`, `image`, `quantity`, `price`, `description`, `user`) VALUES
(2, 0, 'Mobile phones', 'Celkon a107', 'Celkon-A107.jpg', 1, '6000', '<p>Celkon a107</p>', 61);

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE IF NOT EXISTS `reg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `rpassword` varchar(200) NOT NULL,
  `phone` varchar(80) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `dob` varchar(150) NOT NULL,
  `qualification` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`id`, `name`, `email`, `password`, `rpassword`, `phone`, `gender`, `language`, `dob`, `qualification`) VALUES
(61, 'raj', 'raj@gmail.com', '111', '111', '8686692971', 'male', 'Hindi', '30-9-1964', ''),
(62, 'suresh', 'suresh@gmail.com', 'suresh', 'suresh', '8686692971', 'male', 'Hindi', '9-1-1990', ''),
(63, 'srikanth', 'sree@gmail.com', '123', '123', '1231231231', 'male', 'Telugu', '--', '10th class');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(80) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `name`, `email`, `password`) VALUES
(3, 'raj', 'raj@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `summary` varchar(100) NOT NULL,
  `review` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(150) NOT NULL,
  `url` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`id`, `image`, `url`) VALUES
(4, '1446486720banner_hunting.jpg', 'https://www.google.com');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE IF NOT EXISTS `subcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `name`, `status`) VALUES
(1, 'Nokia', 1),
(2, 'Samsung', 1),
(3, 'Acer laptop', 3),
(4, 'Dell laptop', 3);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(10) NOT NULL,
  `category` varchar(100) NOT NULL,
  `producttitle` varchar(100) NOT NULL,
  `image` varchar(80) NOT NULL,
  `price` varchar(100) NOT NULL,
  `description` varchar(150) NOT NULL,
  `user` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `pid`, `category`, `producttitle`, `image`, `price`, `description`, `user`) VALUES
(1, 1, 'Mobile phones', 'Celkon a107', 'Celkon-A107.jpg', '6000', '<p>Celkon a107</p>', '3');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
