<form method="post" action="" align="center" style="margin-top:50px;">
<select id="date" name="date">
<option value="-6">Last 6 days</option>
<option value="-2">Last 2 days</option>
</select><br><br>
<input type="submit" name="submit" value="Submit">
</form>
<?php
if(isset($_POST['submit'])){
	$date=$_POST['date'];
	$con=mysql_connect("localhost","root","123");
	$db=mysql_select_db("date");
	$sql="select value from sort
where date between adddate(now(),$date) and now();";
	$result=mysql_query($sql);
	while($row=mysql_fetch_array($result)){
		echo $row['value'];
	}
}
?>

<?php
$val=array('1','2','3');
$val1=array('31','43','56');
// combine two arrays
echo $merge=json_encode(array_merge($val,$val1));
echo "<br>";
/// sum and merge of the two arrays
echo $merge=json_encode(array_sum(array_merge($val,$val1)));
?>
<span id="demo" onclick="return sample();">Demo</span>
<script type="text/javascript">
function sample(){
	alert(dsfds);
	var value=$('#demo').val();
	alert(value);
}
</script>