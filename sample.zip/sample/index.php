<form method="post" action="" enctype="multipart/form-data">
<input type="radio" name="r1" value="<img src='images/image1.jpg'>"><img src="images/image1.jpg" width="50px" height="50px"><br/>
<input type="radio" name="r1" value="<img src='images/image2.jpg'>"><img src="images/image2.jpg" width="50px" height="50px"><br/>
<input type="radio" name="r1" value="Both" />Both<br/>
</form>
 
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
$("input:radio[type=radio]").click(function() {
var value = $(this).val();
$('#showoption').html(value);
$('#defaultImage').hide();
    });
</script>
 
<label>Value</label>
<div class="image">
<img id="defaultImage" src="images/image2.jpg" width="50px" height="50px" class="thumbnail"/>
     <div id="showoption" class="thumbnail" width="50px" height="50px">
</div>
</div>
    </label>
	
	<style>
	.image{
		border:1px solid black;
	}
	</style>