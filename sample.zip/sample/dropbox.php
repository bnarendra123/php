<html>
  <head>
    <meta charset="utf-8">
    <title>Select - onchange example</title>
  </head>
  
  <body>
    <label for="meetingPlace">Meeting place: </label>
    <select id="meetingPlace">
      <option>Please select</option>
      <option>Buckingham Palace</option>
      <option>The White House</option>
      <option>Mount Everest</option>
    </select>
	<select>
	<option id="results"></option>
	</select>
    
	
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script>
      $("#meetingPlace").on("change", function(){
        var selected = $(this).val();
        $("#results").html(selected);
      })
    </script>
  </body>
</html>