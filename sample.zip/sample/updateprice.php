<form method="post" action="">
<input type="text" name="startdate"><br><br>
<input type="text" name="enddate"><br><br>
<input type="submit" name="submit" value="Submit">
</form>
<?php
if(isset($_POST['submit'])){
   $startdate=$_POST['startdate'];
    $enddate=$_POST['enddate'];
    $stdate=strtotime($startdate);
$eddate=strtotime($enddate);
echo $diff=abs($eddate-$stdate)/3600;
}
?>