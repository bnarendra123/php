<script type="text/javascript">
            $(document).ready(function () {
                $('select.option').change(function () {
                    var OriginalPrice = $('#thisIsOriginal').text();
                    var OriginalCurrency = OriginalPrice.substring(0, 1);
                    OriginalPrice = OriginalPrice.substring(1);
					OriginalPrice = OriginalPrice.replace(",","");
                    var finalPriceValue = OriginalPrice;
                    $('select.option').each(function (e) {
                        var newPriceValue = $(this).find('option:selected').text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(2);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
                    $('input.radiooption:checked').each(function (e) {
						var newPriceValue = $(this).closest("label").text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(2);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
					
                    $('input.checkboxoption:checked').each(function (e) {
                        var newPriceValue = $(this).closest("label").text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(2);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
                    $('#priceUpdate').text(OriginalCurrency + finalPriceValue)
                });
                // radio buttons

                var prv;
                $('input.radiooption').click(function (g) {
                    if (prv === this && this.checked) {
                        this.checked = false;
                        prv = null; 
                    } else {
                        prv = this;
                    }
                    var OriginalPrice = $('#thisIsOriginal').text();
                    var OriginalCurrency = OriginalPrice.substring(0, 1);
                    OriginalPrice = OriginalPrice.substring(1);
					OriginalPrice = OriginalPrice.replace(",","");
                    var finalPriceValue = OriginalPrice;
                    $('input.radiooption:checked').each(function (e) {
                        var newPriceValue = $(this).closest("label").text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(3);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
                    $('select.option').each(function (e) {
                        var newPriceValue = $(this).find('option:selected').text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(2);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
                    $('input.checkboxoption:checked').each(function (e) {
                        var newPriceValue = $(this).closest("label").text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(3);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
                    $('#priceUpdate').text(OriginalCurrency + finalPriceValue);

                });
				//checkboxes
                $('input.checkboxoption').click(function (g) {

                    var OriginalPrice = $('#thisIsOriginal').text();
                    var OriginalCurrency = OriginalPrice.substring(0, 1);
                    OriginalPrice = OriginalPrice.substring(1);
					OriginalPrice = OriginalPrice.replace(",","");
                    var finalPriceValue = OriginalPrice;
                    $('input.checkboxoption:checked').each(function (e) {
                        var newPriceValue = $(this).closest("label").text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(2);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
                    $('select.option').each(function (e) {
                        var newPriceValue = $(this).find('option:selected').text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(2);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
                    $('input.radiooption:checked').each(function (e) {
                        var newPriceValue = $(this).closest("label").text();
                        var position1 = newPriceValue.indexOf("(");
                        var position2 = newPriceValue.indexOf(")");
                        position1 = position1 + 3;
                        newPriceValue = newPriceValue.substring(position1, position2);
                        if (newPriceValue.indexOf('.') == -1)
                        {
                            newPriceValue = "0";
                        }
                        if (finalPriceValue.indexOf('.') == -1)
                        {
                            finalPriceValue = "0";
                        }
                        finalPriceValue = parseFloat(finalPriceValue) + parseFloat(newPriceValue);
                        finalPriceValue = finalPriceValue.toFixed(2);
						finalPriceValue = finalPriceValue.replace(',','');
                    });
                    $('#priceUpdate').text(OriginalCurrency + finalPriceValue);

                });
				
            });
        </script>
		
		 <h2><span id="priceUpdate">20,000</span></h2>
		


<input type="checkbox" class="checkboxoption">2,000			
		 