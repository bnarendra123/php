<form method="post" action="">
<input type="text" name="name" id="name"><span id="rname"></span><br>
<input type="submit" name="submit" value="Submit" onclick="return check();">
</form>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
function check(){
var name=$('#name').val();
var errorcount=0;
if(name==""){
	$('#rname').html("Please enter name");
	$('#rname').css("color","red");
	errorcount++;
}else{
	$('#rname').html("");
}
var pass_data={
	'name':name,
}
else{
	$.ajax({
			url : "",
			type : "POST",
			data : pass_data,
			success : function(data) {
				alert(data);
				
			}
		});
	}
	return false;
}
</script>
<?php
echo $name=$_POST['name'];
?>
<!--<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img border="0" src="https://4.bp.blogspot.com/-mQev41I9V-A/V15a4etc4jI/AAAAAAAAAn0/ILWoA91_eVMoS2AD2i1dF42OPE1h96KygCLcB/s1600/daphnis.png" />
<img border="0" src="https://1.bp.blogspot.com/-RNYYg-ziW1s/V15cJVYj1SI/AAAAAAAAAjY/o5gdQu_1bdYCLOFAEWH4tfvvn-LWa82rwCLcB/s1600/accel.png" />
<img border="0" height="88" src="https://1.bp.blogspot.com/-yBYSDzFRWak/V15X7Y67S1I/AAAAAAAAAjM/Tr_8pcXbtpY0QhbSf5kGlKlhSZS2C4w9ACLcB/s320/cybertech.jpg" width="320" />
<img border="0" src="https://3.bp.blogspot.com/-KCFhlfmYLJI/V1qiXni5CdI/AAAAAAAAAng/BD24_LPOEmM-QAOkMy6rj8TyRnWoikJFACLcB/s1600/sbi.jpg" />
<img border="0" src="https://1.bp.blogspot.com/-_R6zWF_-qag/V1qj9mgYptI/AAAAAAAAAi8/YXI9jXiBQm8079H-o4U26DvBUfUYPKuagCLcB/s1600/indus%2Bsoft.jpg" />
<img border="0" src="https://4.bp.blogspot.com/-pjmQc2L0ctM/V1qiLI5mPGI/AAAAAAAAAiw/HEMYNDn3XZklsLC6bSihLR7X1BuMQFV1gCLcB/s1600/zensar.png" />
<img border="0" height="116" src="https://1.bp.blogspot.com/-zGgs_PtaRvA/V1qdqtv-q3I/AAAAAAAAAik/T_XzhOdXehUfuBM6Uvz3S6Ejoxg45KwdgCLcB/s200/bank%2Bof%2Bindia.png" width="200" />
<img border="0" height="63" src="https://1.bp.blogspot.com/-QBCYL1B0BLY/V1qYX86bRDI/AAAAAAAAAiU/C6A_ZfuY-pgU8rU3bWibZi-hbwIykhtQACLcB/s320/icici%2Bbank.png" width="320" />
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img border='0' height='72' src='https://3.bp.blogspot.com/-3Z3zxxmOK2k/V1FwI5Adr6I/AAAAAAAAAlk/bq_mkwNs1IoGKpkxD8FoqybBOvujGqjrgCLcB/s72-c/jpmorgan.jpg' width='72'/>
<img border='0' height='72' src='https://3.bp.blogspot.com/-zQ8EXMm-zPY/VzVsrkCjCNI/AAAAAAAAAJs/4du3XvOz4rACELUM2XNIM5Pvu6f8DNySgCLcB/s72-c/Cyient.jpg' width='72'/>
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
<img height='18' src='https://img1.blogblog.com/img/icon18_wrench_allbkg.png' width='18'/>
