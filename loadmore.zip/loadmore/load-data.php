<?php
echo "<script>alert('fdsfds')</script>";
$con=mysql_connect("localhost","root","");
$output='';
$id='';
$db=mysql_select_db("core",$con);
$sql="select * from loadmore where id>".$_POST["id"]." LIMIT 2";
$result=mysql_query($sql,$con);
	while($row=mysql_fetch_array($result)){
		$$id=$row["id"];
		$output.='
			<tbody>
			<tr>
			<td>'.$row["data"].'</td>
			</tr></tbody>
		';
	}
	$output .='
		<tbody><tr id="remove_row">
		<td><button type="button" name="btn_more" data-vid="'.$id .'" id="btn_more" class="btn btn-success form-control">More</button></td>
	';
	echo $output;
?>


<!-----------------------
	Youtube Url : https://www.youtube.com/watch?v=IWEgjmQgLTU 
	------------------->
