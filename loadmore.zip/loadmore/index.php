<?php
$con=mysql_connect("localhost","root","");
$db=mysql_select_db("core",$con);
$sql="select * from loadmore LIMIT 0,2";
$result=mysql_query($sql,$con);
?>
<div class="container">
	<div class="table-responsive">
		<h2 align="center">Load More data</h2>
		<table class="table table-bordered" id="load_data_table">
			<?php
			while($row=mysql_fetch_array($result)){ ?>
				<tr>
					<td><?php echo $row['data']; ?></td>
				</tr>
				<?php
				$id=$row["id"];
			}
			?>
			<tr id="remove_row">
				<td><button name="btn_more" id="btn-more" data-vid="<?php echo $id; ?>" class="btn btn-success form-control">More</button></td>
			</tr>
		</table>
	</div>
</div>
<script>
	$(document).ready(function(){
		$(document).on('click','#btn_more', function(){
			var id=$(this).data("vid");
			$('##btn_more').html("Loading....");
			$.ajax({
				url:"load-data.php",
				method:"POST",
				data:{id:id},
				dataType:"text",
				success: function(data)
				{
					if(data !==''){
						$('#remove_row').remove();
						$('#load_data_table').append(data);
					}else{
						$('#btn_more').html("No_data");
					}
				}
			});
		});
	});
</script>