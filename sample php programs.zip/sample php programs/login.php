<?php
session_start();
?>
<html>
	<head>
		<style>
			.log{
					text-align="right";
					font-size:18px;
				}
		</style>
	</head>
	<body>
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<table border="0" cellspacing="2" cellpadding="3" align="center">
			<th align="center" style="font-size:20px;">Login form</th>
			<tr>
				<td>Username:</td><td><input type="text" name="uname" placeholder="Enter username"></td>
			</tr>
			<tr>
				<td>Password:</td><td><input type="password" name="password" placeholder="Enter password"</td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="Submit">&nbsp; &nbsp; <input type="reset" name="reset" value="Reset"></td>
			</tr>
			
			<?php
			if(isset($_POST['submit']))
			{
				$username=$_POST['uname'];
				$password=$_POST['password'];
				$con=mysql_connect("localhost","root","");
				$db=mysql_select_db("sample",$con);
				$result=mysql_query("select * from reg where email='$email' and password='$password'");
				while($row=mysql_fetch_array($result))
				{
					$id = $row['id'];
				}	
					$_SESSION['id']=$id;
		
					$num_row=mysql_num_rows($result);
					if($num_row>0)
					{
						echo "login success";
					}
					else
					{
						echo "invalid login details";
					}
					  mysql_close($con);
			}
			?>
		</table>
		</form>
	</body>
</html>