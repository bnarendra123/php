<?php  
$bday = new DateTime('22.3.1992'); // Your date of birth  
$today = new Datetime(date('d.m.Y'));  
$diff = $today->diff($bday);  
printf(' Your age : %d years, %d month, %d days', $diff->y, $diff->m, $diff->d);  
?>  