1) Mage::getmodel() and Mage::getsingleton() : Mage::getmodel() creates new object and Mage::getsingleton() always looks existing object.

2)Eav(Entity attribute value): It allows you to add a unlimited columns to your table virtually. It is also called object attribute value model.

3)