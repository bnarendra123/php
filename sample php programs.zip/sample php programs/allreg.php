
<div class="regtab">
	<body>
		<form method="post" action="">
		<table border="0" cellspacing="10" cellpadding="10" style="margin-left: 100px;" align="center">
			
			<tr><td>&nbsp; </td></tr>
			<tr>
				<td>Name:</td><td><input type="text" name="name" style="width:230px;" id="name"></td><td><span id="namer"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td>Email:</td><td><input type="text" name="email" style="width:230px;" id="email"></td><td><span id="emailr"></span></td>
			</tr>
			<tr><td>&nbsp; </td></tr>
			<tr>
				<td>Password:</td><td><input type="password" name="password" style="width:230px" id="password"></td><td><span id="passwordr"></span></td>
			</tr>
			
			<tr><td>&nbsp; &nbsp; </td></tr>
			<tr>
				<td>Repeat password:</td><td><input type="password" name="rpassword" style="width:230px" id="rpassword"></td><td><span id="passwordre"></span></td>
			</tr>
			
			<tr>
				<td>&nbsp; &nbsp;</td>
			</tr>
			<tr>
			<td>Mobile number:</td><td><input type="text" name="phone" id="phone" style="width:230px;"></td><td><span id="phoner"></span></td>
			</tr>
			<tr>
				<td>&nbsp; &nbsp; </td>
			</tr>
			<tr>
				<td>Gender:</td><td><input type="radio" name="sex" id="gen" value="male" checked>Male<input type="radio" name="sex" value="female" id="gen">Female</td><td><span id="genr"></span></td>
			</tr>
			<tr>
				<td>&nbsp; &nbsp; </td>
			</tr>
			<tr><td>Languages known:</td><td><input type="checkbox" name="language" id="language" value="Telugu">Telugu<input type="checkbox" name="language" id="language" value="English">English<input type="checkbox" name="language" id="language" value="Hindi">Hindi</td><td><span id="langr"></span></td></tr>
			<tr>
				<td>&nbsp; &nbsp; </td>
			</tr>
			<tr>
				<td>D.o.b</td><td>
			
				<?php
			
	// month array 
			
	$month = array( 1 => 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August','September','October','November','December');
							
		echo  '<select name="month">';	

		foreach ( $month as $k => $v ) {

			echo '<option name="'. $v . '"  value="' . $k . '">' . $v . '</option><br />';
		}
		
		echo '</select>&nbsp;<select name="date">';
			
		for ( $i = 1; $i <= 31; $i++) {
					
                     echo '<option name="'. $i . '"  value="' . $i . '">' . $i . '</option><br />';

		}
			
	
		echo '</select>&nbsp;<select name="year">';
			
		for ( $i = 1950; $i <= 2050; $i++) {
			echo '<option name="'. $i . '"  value="' . $i . '">' . $i . '</option><br />';

		}
			
		echo '</select>';
				
?>		</td>
			</tr>
			<tr>
				<td>&nbsp; &nbsp; </td>
			</tr>
			<tr>
				<td>Qualification:</td><td><select name="qualification" id="qualification">
				    <option value=""></option>
					<option value="10th class">10th class</option>
					<option value="B.tech">B.tech</option>
					<option value="M.tech">M.tech</option>
				</select></td><td><span id="qlt1"></span></td>
			</tr>
			<tr><td>&nbsp; &nbsp; </td></tr>
			
			<tr>
				<td><input type="submit" name="submit" value="Submit" style="margin-left:100px; font-size:15px;" onclick="return reg();">&nbsp; &nbsp; <input type="reset" name="reset" value="Reset" style="margin-left:10px; font-size:15px;"></td>
			</tr>
		</table>
	</div>
	</body>
</html>
</form>
------------------------------   js functions ---------------------------

function reg(){
	var name=$('#name').val();
	var email=$('#email').val();
	var emailreg=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
	var phone=$('#phone').val();
	var password=$('#password').val();
	var rpassword=$('#rpassword').val();
	var gender=$('input[type="radio"]:checked').val();
	var language=$('#language').val();
	var dob=$('#dob').val();
	var qualification=$('#qualification').val();
	var errorcount=0;
	if(name==""){
		$('#namer').html("please enter name");
		$('#namer').css("color","red");
		errorcount++;
	}else{
		$('#namer').html("");
	}
	if(email==""){
		$('#emailr').html("please enter email");
		$('#emailr').css("color","red");
	}else{
		$('#emailr').html("");
	}
	elseif(!emailreg.test(email)){
		$('#emailr').html("please enter valid email");
		$('#emailr').css("color","red");
	}else{
		$('#emailr').html("");
	}
	if (phone == "") {
		$('#phoner').html("Enter your Mobile number");
		$('#phoner').css("color", "red");
		errorcount++;
	} else {
		if (isNaN(phone)) {
			$("#phoner").html("Enter the valid Mobile Number");
			$("#phoner").css("color", "red");
			errorcount++;
		}
		if ((phone.length != 10)) {
			$("#phoner").html("Please enter 10 digit mobile no");
			$("#phoner").css("color", "red");
			errorcount++;
		} else {
			$("#phoner").html("");
		}
	}
	if(password==""){
		$('#passwordr').html("Please enter password");
		$('#passwordr').css("color","red");
		errorcount++;
	}else{
		$('#passwordr').html("");
	}
	if(rpassword==""){
		$('#passwordre').html("Please enter repeat password");
		$('#passwordre').css("color","red");
		errorcount++;
	}else{
		$('#passwordre').html("");
	}
	if($('#password').val() != $('#rpassword').val()) {
            alert("Password and Confirm Password don't match");
            // Prevent form submission
            event.preventDefault();
            return false;
        }
	if($('input[type="radio"]:checked').length=="0")
	{
		$('#genr').html("Please enter gender");
		$('#genr').css("color","red");
		errorcount++;
	}else{
		$('#genr').html("");
	}
	if(qualification==""){
		$('#qlt1').html("please enter qualification");
		$('#qlt1').css("color","red");
		errorcount++;
	}else{
		$('#qlt1').html("");
	}
	if(errorcount>0){
		return false;
	}
	else {
		var pass_data = {
			'name' : name,
			'email' : email,
			'password' : password,
			'rpassword' : rpassword,
			'phone' : phone,
			'gender' : gender,
			'language' : language,
			'dob' : dob,
			'qualification' : qualification,
		};
		$.ajax({
			url : "set/reg.php",
			type : "POST",
			data : pass_data,
			success : function(data) {
				alert(data);
				if (data.trim() == 'ok') {
					alert("successfully registered");
					//document.location ="index.php";
					//location.reload();
				}
				if (data.trim() == 'fail') {
					alert('Fail to send.');
					location.reload();
				}
			}
		});
	}
	return false;
}

----------------------------------   db connect -----------------------------------------

<?php
    $id=$_POST['id'];
    $name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$rpassword=$_POST['rpassword'];
	$phone=$_POST['phone'];
	$gender=$_POST['gender'];
	$language=$_POST['language'];
	$dob = $_POST["date"] . "-" . $_POST["month"] . "-" . $_POST["year"];
	$qualification = $_POST['qualification'];
	include "../includes/config.php";
	$sql="insert into reg values('','$name','$email','$password','$rpassword','$phone','$gender','$language','$dob','$qualification')";
	$query=mysql_query($sql,$con);
	if($query){
		//echo "<script>alert('successfully registered')</script>";
		die('ok');
	}else{
		//echo "<script>alert('insert failed')</script>";
		die('fail');
	}
	mysql_close($con);
?>