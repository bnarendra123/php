<script src="//code.jquery.com/jquery-1.9.1.js"></script>
<script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script>
$(function() {
    var availableTags = ["ActionScript","AppleScript","Asp","BASIC","Scheme"];
    $( "#tags" ).autocomplete({source: availableTags});
});
</script>
</head>
<body>
  <div class="ui-widget">
    <label for="tags">Tags: </label>
    <input id="tags">
  </div>
</body>
</html>