<html>
	<head>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
	 <script type="text/javascript">
	 	function hidebutton(){
	 		document.getElementById("docid").style.display='none';
	 	}
	 	function sub(){
	 		alert("dsds");
	 		var name=$("#name").val();
	 		alert(name);
	 	}
	 </script>
	</head>
	<body>
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<input type="text" name="name" id="name"><br/>
		<input type="submit" name="submit" id="docid" style="visibility: hidden;" onclick="return sub();">
		</form>
	</body>
	
</html>

<?php
$image="fsfsd";
echo $count=strtoupper($image);
echo "<br>";
echo $count=strtolower($image);
echo "<br>";
echo $count=strpos("$image","d");
echo "<br>";

?>