<form method="post" style="font-size: 100%" action="">
<div id="color"> 
    <input type="radio"  name="radio1"  id="radio1" onclick = "MyAlert()" value="blue"/>Blue  <br /></p>  
    <p> <input type="radio"  name="radio1" id="radio1" onclick = "MyAlert()" value="red"/>Red  
  
	</div>
  </form>


<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">  
function MyAlert()  
    {  
var radio1=$('input[type="radio"]:checked').val();
var pass_data = {
            'radio1' : radio1,
        };
        $.ajax({
    url : "post.php",
    type : "POST",
    data: pass_data,
    success : function(data) {
       $("#color").html(data)
    }
});
        return true;
    }  
</script>