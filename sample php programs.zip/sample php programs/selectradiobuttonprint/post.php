
<?php
	$radio1=$_POST['radio1'];
	echo $radio1;
?>