<html>
	<head>
		<body>
			
			<table>
				<form action="#" name="myform"  method="post" >
					<tr>
						<td>Name :</td>
						<td><input type="text" name="name" id="name" value=""/></td>
						
							<td><span id="err_name" err="name" style="color: red" ></span></td>
						</tr>
                	<tr>
						<td>Mobileno :</td>
						<td><input type="text" name="mobileno" id="mobileno" value=""/></td>
						
							<td><span id="err_mobileno" err="mobileno" style="color: red"></span></td>
						</tr>
                       <tr>
						<td>Address :</td>
						<td><input type="text" name="Address" id="address" value=""/></td>
						
							<td><span id="err_address" err="address" style="color: red"></span></td>
						</tr>
                     <tr>
						<td>Gender :</td>
						<td><input type="radio" name="female" id="gender" value="0"/>Female
							<input type="radio" name="male" id="gender" value="1"/>male</td>
						
							<td><span id="err_gender" err="gender" style="color: red"></span></td>
						</tr>
                       <tr>
						<td>Select :</td>
						<td><select name="color" id="color" >
							<option value="">select</option>
							<option value="0">red</option>
							<option value="1">orange</option>
							<option value="2">green</option>
						</select></td>
						
							<td><span id="err_color" err="color" style="color: red"></span></td>
						<tr>
						<td>Vehicals :</td>
						<td><input type="checkbox" name="car" id="vehical" value="car"/>car
							<input type="checkbox" name="lorry" id="vehical" value="lorry"/>lorry
							<input type="checkbox" name="bus" id="vehical" value="bus"/>bus
							<input type="checkbox" name="cycle" id="vehical" value="cycle"/>cycle
							</td>
						
							<td><span id="err_vehical" err="vehical" style="color: red"></span></td>
						</tr>
                       <tr>
                       	<td>Submit </td>
                       	<td><input type="submit" id="id" onclick="return submitt1();" /></td>
                       </tr>					
				</form>
			</table>
			
			
		</body>
	</head>
	<script type="text/javascript">
		function submitt1 () {
			
			//alert('hai');
			var errCount=0;
			
			if (document.myform.name.value == "") 
			 {
				document.getElementById('err_name').innerHTML = "please enter the name";
				
				myform.name.focus();
				
				
				 errCount++;
				 
			}
		  if (document.myform.mobileno.value == "") 
			 {
				document.getElementById('err_mobileno').innerHTML = "please enter the no";
				
				myform.mobileno.focus();
				
				 errCount ++;
			}
			if (document.myform.address.value == "") 
			 {
				document.getElementById('err_address').innerHTML = "please enter the address";
				
				myform.address.focus();
				
				 errCount ++;
			}
			if (!document.myform.gender[0].checked && !document.myform.gender[1].checked )
			 
			 {
				document.getElementById('err_gender').innerHTML = "please enter the gender :male or female";
				
				
				
				errCount++;
			}
			if (document.myform.color.value == "") 
			 {
				document.getElementById('err_color').innerHTML = "please select color";
				
				myform.color.focus();
				
				 errCount ++;
			}
			if (!document.myform.vehical[0].checked && !document.myform.vehical[1].checked&& !document.myform.vehical[2].checked && !document.myform.vehical[3].checked )  
			 {
				document.getElementById('err_vehical').innerHTML = "please select the vehicals";
				
				
				 errCount ++;
			}
			if (errCount > 0) {
		   return false;
				}
			return true;
		}
		
	</script>
</html>