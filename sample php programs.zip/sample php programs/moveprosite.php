In 1 st select the table to get the values from that table 

<?php
defined('QC_VALID') or die('Restricted Access!');
/// get the table all products 
$product = getproduct();

echo json_encode($product);
die();
?>



In another site creates 1 file write this code

<script type="text/javascript"></script>
<?php
$content =file_get_contents("http://app.mir4kle.com/sendproductstoerp/");

$json = json_decode($content, true);
echo "<pre>";
print_r($json);
foreach ($json as $pro_name => $pro) {
    $id_product= $pro['id_product'];
}
die();

?>



