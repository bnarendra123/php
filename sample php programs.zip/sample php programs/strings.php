<?php
$str="suresh babu";
$count=strlen($str);
echo $count;
?>
<br>
<br>

<?php
$str="shajahan basha";
$upper=strtoupper($str);
echo $upper;
?>
<br>
<br>

<?php
$str="helloworld";
$lower=strtolower($str);
echo $lower;
?>
<br>
<br>

<?php
$str="sreekanth";
$reverse=strrev($str);
echo $reverse;
?>
<br>
<br>

<?php
$str="sudha";
$sub=substr($str,3);
echo $sub;
?>
<br>
<br>

<?php
$str="swamy das";
$replace ="das";
$with ="vivekananda";
$strreplace=str_replace($replace,$with,$str);
echo $strreplace;
?>
<br>
<br>

<?php
$str="narendra";
$ucfirst=ucfirst($str);
echo $ucfirst;
?>
<br>
<br>

<?php
$str="narendra";
$ucwords=ucwords($str);
echo $ucwords;
?>






