<?php
$array=array(500,100,300,200);
sort($array);
foreach($array as $key => $value);{
echo "$value <br>";
}
?>
<br>
<?php
$array = array(500,200,400,100);
rsort($array); // Sort the array in reverse
foreach($array as $key => $value) {
    echo "$value <br />";
}
?>
<br>
<?php
$array=array(300,200,100);
ksort($array);
foreach($array as $key => $value){
	echo "$value <br />";
}
?>
<br>
<?php
$array=array(400,500,200);
krsort($array);
foreach($array as $key => $value){
	echo "$value <br />";
}
?>
