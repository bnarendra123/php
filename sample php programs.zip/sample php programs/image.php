<html>
	<head>
	</head>
	<body>
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
			<table border="0" cellspacing="0" cellpadding="0" align="center" style="margin-top: 50px;">
				<tr>
					<td>Upload image &nbsp; &nbsp;<input type="file" name="file"></td>
				</tr>
				<tr>
					<td>&nbsp; &nbsp;</td>
				</tr>
				<tr>
					<td><input type="submit" name="submit" value="Submit"> &nbsp; &nbsp; <input type="reset" name="reset" value="Reset"></td>
				</tr>
				<?php
				if(isset($_POST['submit'])){
					$image=$_FILES['file']['name'];
					$img=$_FILES['file']['tmp_name'];
					
					$target_dir="uploads/";
 if(move_uploaded_file($img, $target_dir.$image))
 {
  echo " ";
 }
 else {
  echo "not";
 }
					$con=mysql_connect("localhost","root","");
				    mysql_select_db("sample");
					$sql="insert into image values('$image')";
	
					$query=mysql_query($sql,$con);
					if($query){
						echo "success";
						}
else{
	echo "failure";
					}
					mysql_close($con);
				}
				?>
			</table>
		</form>
	</body>
</html>