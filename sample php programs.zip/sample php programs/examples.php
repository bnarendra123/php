
------------------------------   Sorting examples -----------------------------------
<?php
$array=array(500,100,300,200);
sort($array);
foreach($array as $key => $value);{
echo "$value <br>";
}
?>
<br>
<?php
$array = array(500,200,400,100);
rsort($array); // Sort the array in reverse
foreach($array as $key => $value) {
    echo "$value <br />";
}
?>
<br>
<?php
$array=array(300,200,100);
ksort($array);
foreach($array as $key => $value){
	echo "$value <br />";
}
?>
<br>
<?php
$array=array(400,500,200);
krsort($array);
foreach($array as $key => $value){
	echo "$value <br />";
}
?>
---------------------------------------------------------------------
----------------------------------  Javascript Examples ------------------------------------------
<script type="text/javascript">
	var book="maths";
	if(book=="maths"){
		document.write("<b>This is maths book</b>");
	}else{
		document.write("<b>This is not a maths book</b>")
	}
</script>
-------------------------  Display prime number and even, odd number -------------------------------
<?php
$number=11;
	if($number%2==0)
	{
		echo $number. "is even number";
		
	}
else{
	echo $number. "is odd number";
}
?>
-------
<?php
$i=1;
	for($i=0;$i<=20;$i++)
	{
		if($i%2)
		{
			echo $i;
		}
	}
	?>
	<?php
$i=1;
for($i=1;$i<=10;$i++){
	if($i%2>0){
		echo $i;
	}
} ?>
---------------------   Number series program ------------------------------------
<?php
$i=1;
for($i=1;$i<=5;$i++){
	for($j=1;$j<=$i;$j++){
echo $j;
		
	}
	echo "<br>";
}
?>
print 1 series 

<?php
$i=1;
for($i=0;$i<=5;$i++){
	for($j=1;$j<=$i;$j++){
echo "1";
		}
	echo "<br>";
} ?>

print 5 table series

<?php
for($i=5;$i<=50;$i++){
	if($i%5==0){
echo $i;
echo "<br>";
}
} ?>

print 2 table

<?php
$i=2;
for($i=2;$i<=2;$i++){
	for($j=1;$j<=10;$j++){
	echo $i*$j."<br>";
}
} ?>
----------------



