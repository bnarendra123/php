<html>
	<head>
		<body>
			<h1> hello world!</h1>
			<p id="demo">
				hello hai thay canbe change!
			</p>
			<button type="button"  onclick="document.getElementById('demo').innerHTML='hello java script '"/>
			click me .</button>

			<h2>css changes</h2>
			<p id="function">
				hello world!!!!!----
			</p>
			<button type="button"  onclick="myfunction()">
				clickme!
			</button>
			<script>
				function myfunction() {
					var y = document.getElementById("function");
					y.style.color = " red";
					y.style.fontsize = "20px";
				}

			</script>
			<!--paragraph change-->
			<p id="hai">
				hello hai!!
			</p>
			<button type="button"  onclick="document.getElementById('hai').innerHTML=' welcome confianza'"/>
			Tryit .</button>

			<!--window alert-->
			<p>
				windoe alert!!!
			</p>
			<script>
				window.alert(12 + 12);
			</script>
			<!-- document.writ-->
			<h1> document.write</h1>
			<script>
				document.write(12 * 12);
			</script>
			<!-- onclick-->
			<p id="A" >
				adding two numbers!!!
			</p>
			<button type="button" onclick="document.write(15+11)"/>
			tryit</button> <!-- inner.html-->
			<p id="AS">
				inner.html
			</p>
			<button type="button" onclick="myfunction2()"/>
			tryit</button>
			<script>
				function myfunction2() {
					document.getElementById('AS').innerHTML = 12 + 24;
				}
			</script>
			<!-- console.log-->
			<h2>console.log</h2>
			<script>
				console.log(13 + 14);
			</script>
			<!--script program-->
			<p >
				all javascript elements are writen by semicolan
			</p>
			<p >
				all x,yand z values are asigend by 2,3and5:
			</p>

			<p id="W"></p>
			<script>
				var x = 2;
				var y = 3;
				var z = x + y;
				document.getElementById("W").innerHTML = z;

			</script>
			<p id=D>
				my friend
			</p>
			<script>
				document.getElementById('D').innerHTML = 'hello hai';
			</script>
			<p>
				*multiplocation
			</p>
			<p id="G"></p>
			<script>
				a = 10;
				b = 20;
				c = a * b;
				document.getElementById('G').innerHTML = c;
			</script>
			<p id="Z">
				hello hai
			</p>
			<p id="C">
				this is my world
			</p>
			<button type="button" onclick="myfunction4()"/>
			clickme!</button>
			<script>
				function myfunction4() {
					document.getElementById('Z').innerHTML = 'hai this is banu';
					document.getElementById('C').innerHTML = 'hai this is bhavya';

				}
			</script>
			<p>
				total calucation
			</p>
			<script>
				var price1 = 4;
				var price2 = 5;
				var total = price1 + price2;
				document.write("the total is:" + total);
			</script>
			<p id="details"></p>
			<script>
				var Name = "bhavya";
				var price = 6000;
				var designation = "developer"
				//	document.getElementById('details').innerHTML=Name;
				document.getElementById('details').innerHTML = price;
				//document.getElementById('details').innerHTML=designation;
			</script>
			<p id="F">
				sdhsds
			</p>
			<script>
				var k = "Bhavya" + " " + "Sree";
				document.getElementById('F').innerHTML = k;
			</script>
			<h2 id="b">assignment operations</h2>
			<script>
           var d=15;
           d%=13;
              document.getElementById('b').innerHTML=d;
			</script>
			<!--function call-->
			<p>
				This example calls a function which performs a calculation, and returns the result:
			</p>

			<p id="demo1"></p>

			<script>
				function myFunction6(a, b) {
					return a * b;
				}


				document.getElementById("demo1").innerHTML = myFunction6(4, 3);
			</script>
			<!--object creation-->
			<p id="u"></p
				<script>
					var details{
						Name="bhavya"
						profision="developer"'
						Salary=2000
						
					};
					
						document.getElemenyById('u').innerHTML= details[Name]+details[Profision]+details[Salary];
					
				</script>
				<p id="i"> today date</p>
				<button type="button" onclick="document.getElementById('i').innerHTML=Date()"/> clickme</button>
				<!-- str.length-->
				<p id="t"></p>
				<script>
					var d="bhavyasree";
					document.getElementById('t').innerHTML=d.length;
				</script>
				<p id="1"></p>
				<script>
					var a="bhavya";
					var b="sree";
					document.getElementById('1').innerHTML=a.concat("",b);
				</script>
				<p id="demo7"></p>

                     <script>
                        var d = new Date();
                        document.getElementById("demo7").innerHTML = d.getDay();
               </script>
               <p >Math.random() selct math number0 to8</p>
               <p id="q"></p>
               <button type="button" onclick="myfunction9()"/>clickme</button>
               <script>
               function myfunction9 () {
                 document.getElementById('q').innerHTML=Math.random();
               }
               	
               </script>
               <p id="demo7"></p>

<script>
document.getElementById("demo7").innerHTML = 
    typeof "john" + "<br>" +
    typeof 3.14 + "<br>" +
    typeof NaN + "<br>" +
    typeof false + "<br>" +
    typeof [1,2,3,4] + "<br>" +
    typeof {name:'john', age:34} + "<br>" +
    typeof new Date() + "<br>" +
    typeof function () {} + "<br>" +
    typeof myCar + "<br>" +
    typeof null;
</script>
<p id="demo8"></p>
<script>
	var x="";
	var i;
	for(i=0;i<12; i++){
		if (i===5) {break;}
			x+="bhavyasree"+"<break>"+i+ "<br>";
		
		
	}
	document.getElementById("demo8").innerHTML = x;
</script>

		</body>
	</head>
</html>