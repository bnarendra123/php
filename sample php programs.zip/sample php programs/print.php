<html>
	<head>
		<script type="text/javascript">
		</script>
	</head>
	<form>
		<input type="button" value="print" onclick="window.print()">
	</form>
</html>