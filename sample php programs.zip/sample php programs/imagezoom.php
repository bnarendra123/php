<script type="text/javascript" src="jquery-1.8.0.min.js"></script>
<link rel="stylesheet"  type="text/css" href="jquery.jqzoom.css">
<script type="text/javascript" src="jquery.jqzoom-core-pack.js"></script>

<script type="text/javascript">
     jQuery(document).ready(function(){
             jQuery(\'a#demo1\').jqzoom();
                jQuery(\'a#demo2\').jqzoom({
                zoomType: \'reverse\'
            });
                jQuery(\'a#demo3\').jqzoom({
                zoomType: \'drag\'
            });
                jQuery(\'a#demo4\').jqzoom({
                zoomType: \'innerzoom\'
            });
});
     </script>
     
<div class="clearfix demo">
    <div class="clearfix" style="position:relative;">
         <a href="images/1_big.png"  rel="gal1" id="demo1"  title="PHPGang.com ZoomIn" >
            <img src="images/1_small.png"  title="PHPGang.com ZoomIn"  style="border: 1px solid #666;">
         </a>
    </div>
</div>