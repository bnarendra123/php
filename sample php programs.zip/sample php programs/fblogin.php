Login with fb : 

https://www.youtube.com/watch?v=E8tHz5CdMrY

https://www.youtube.com/watch?v=tRWlWuOWe8I&ebc=ANyPxKoXz-PEqbzOOV_zmd9PrdqyqplQ1JkwP2uKKfN6VYAGDjx9RrFQSF6y1wEZjhHvgQ4CFvEfnt4LdLfObgcpOHMAJrfmSg