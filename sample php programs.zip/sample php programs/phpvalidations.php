<?php

$nameErr=$emailErr=$addressErr=$contactnoErr=$genderErr=$colorErr=$vehicalErr="";
$name=$email=$address=$contactno=$gender=$color=$vehical="";
if(isset($_POST['submit']))
{
	if ($_SERVER["REQUEST_METHOD"] == "POST")
	{
		if(empty($_POST['name'])){
			$nameErr="please enter the name";
		}else{
			$name=$_POST['name'];
		}
		if(empty($_POST['email'])){
			$emailErr="please enter the email";
		}else{
			$email=$_POST['email'];
		}
		if(empty($_POST['address'])){
			$addressErr="please enter the address";
		}else{
			$address=$_POST['address'];
		}
		if(empty($_POST['contactno'])){
			$contactnoErr="please enter the no";
		}else{
			$contactno=$_POST['contactno'];
		}
		if(empty($_POST['gender'])){
			$genderErr="please enter the gender";
		}else{
			$gender=$_POST['gender'];
		}
		if(empty($_POST['color'])){
			$colorErr="please enter the color";
		}else{
			$color=$_POST['color'];
		}
		if(empty($_POST['vehical'])){
			$vehicalErr="please enter the vehicals";
		}else{
			$vehical=$_POST['vehical'];
		}
	}
}
?>
<html>
	<head>
		<style>
		body{
			background-image:url("images/Desert.jpg"); 
			 background-repeat:no-repeat;
            
                background-size: cover;
		     
			 
		}
		  h1{
				text-align: center;
				color: red;
			}
		        
			td{
				size:80px;
				color: yellow;
				padding: 4px;
			}
			input
           {
         -moz-border-radius: 15px;
          border-radius: 15px;
          border:solid 2px green;
          color:brown;
          padding:8px;
               }
            .Error{
               color: blue;
             }
           
		</style>
		<body>
			
			<h1>*Registration form*</h1>
			
			<table align="center" width="350px" height="100px"   />
				
				<form action="#" method="post">
					<tr>
						<td>Name :</td>
						<td><input type="text" name="name" value="" /></td>
					</tr>
					<tr>
						<td></td>
							<td><span class="Error"> <?php echo $nameErr; ?> </span>
						</td>
					</tr>
					<tr><td></td></tr>
					<tr>
						<td>Email :</td>
						<td><input type="text" name="email" value="" /></td>
					</tr>
					<tr>
						<td></td>
						<td>	<span class="Error" ><?php echo $emailErr; ?></span>
						</td>
					</tr>
					<tr><td></td></tr>
                     <tr>
						<td>Address :</td>
						<td><input type="text" name="address" value="" /></td>
						</tr>
						<tr>
							<td></td>
							<td><span class="Error"> <?php echo $addressErr; ?> </span>
						</td>
					</tr>
					<tr><td></td></tr>
                    <tr>
						<td>Contact no :</td>
						<td><input type="text" name="contactno" value="" /></td>
						</tr>
						<tr>
							<td></td>
							<td><span class="Error"> <?php echo $contactnoErr; ?> </span>
						</td>
					</tr>
					<tr><td></td></tr>
					<tr>
						<td>Gender :</td>
						<td>
							<input type="radio" name="gender" value="female" />Female
							<input type="radio" name="gender" value="male" />Male</td>
						</tr>
						<tr>
							<td></td>
							<td><span class="Error"> <?php echo $genderErr; ?> </span>
						</td>
					</tr>
					<tr><td></td></tr>
					<tr>
						<td>Select color :</td>
						<td><select name="color" >
							<option value="">select</option>
							<option value="0">red</option>
							<option value="1">green</option>
							<option value="2">blue</option>
							</select></td>
						</tr>
						<tr>
							<td></td>
							<td><span class="Error"> <?php echo $colorErr; ?> </span>
						</td>
					</tr>
					<tr><td></td></tr>
					<tr>
						<td>Vehical :</td>
						<td>
							<input type="checkbox" name="vehical" />car
							<input type="checkbox" name="vehical" />bike
							<input type="checkbox" name="vehical" />bus</td>
						</tr>
						<tr>
							<td></td>
						<td><span class="Error"> <?php echo $vehicalErr; ?> </span>
						</td>
					</tr>
					<tr><td></td></tr>
                    <tr>
						<td>submit :</td>
						<td><input type="submit" name="submit" value="submit" /></td>
					</tr>
     					
				</form>
			</table>
		</body>
	</head>
</html>