<?php
//strings in php
$Z="hai hello goodmorning!!!";
var_dump($Z);
echo "<br>";
//INTERGER;
$X=1200;
var_dump($X);
echo "<br>";
//flot values
$y=12.5454;
var_dump($y);
echo "<br>";
//array values
$cars=array("red","blue","orange");
var_dump($cars);
echo "<br>";
//object declration
class Colors{
	function Colors(){
		$this->Colors="black";
	}
}
$x=new Colors;
echo "$x->Colors";
echo "<br>";
//null values;
$n="hellow world";
$n=null;
var_dump($n);
echo "<br>";
//@ string statements@
//string length
echo strlen("hai this is my world");
echo "<br>";
echo str_replace('bha', 'sree', 'bhavyasree');
echo "<br";
echo str_word_count("Hello world!");

?>