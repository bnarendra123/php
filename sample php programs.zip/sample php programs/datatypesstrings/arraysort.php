<?php
$bag=array('red','black','green');
sort($bag);
$blength=count($bag);
for ($i=0; $i <$blength ; $i++) {
	echo $bag[$i];
	echo "<br>"; 
	
}
echo "<br>";
$car=array('orange','brown','yellow');
asort($car);
foreach ($car as $x => $x_value) {
	echo "key=".$x,"value=" .$x_value;
echo "<br>";	
}
?>