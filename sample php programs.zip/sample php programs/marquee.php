<html>
<head>
<title>HTML marquee Tag</title>
</head>
<body>
<marquee direction="left" style="margin-top:200px;">This text will scroll from left to right</marquee>
</body>
</html>