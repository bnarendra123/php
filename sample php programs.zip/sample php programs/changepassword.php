<html>
     <head>
     	
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>Password Change</title>
   
     </head>
    <body>
    <p align="center" style="font-size:25px; text-decoration: underline;"><b>Change Password</b></p>
   <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
   	
    <table border="0" cellspacing="2" cellpadding="3" align="center">
    
     <tr>
    <td>username</td>
    <td><input type="text" size="10" name="user"></td>
    </tr>
    <tr>
    <td>Password</td>
    <td><input type="text" size="10" name="password"></td>
    </tr>
  <tr>
    <td>New password:</td>
    <td><input type="text" size="10" name="newpassword"></td>
    </tr>
    <tr>
   <td>Confirm new password:</td>
   <td><input type="text" size="10" name="confirmnewpassword"></td>
    </tr>
    <tr>
    <td><input type="submit" value="Submit" name="submit"></td></tr>
    
      
<?php

if(isset($_POST['submit'])){
         
	$username = $_POST['user'];
     $oldpassword = $_POST['password'];
        $new = $_POST['newpassword'];
        $renew = $_POST['confirmnewpassword'];
		
        if($new == $renew)
        {
        $con=mysql_connect("localhost","root","") or die(mysql_error());
		$db=mysql_select_db("sample",$con) or die(mysql_errror());
		
	   $sql1="select password from login where username='$username' ";
		
		$result = mysql_query($sql1);
	while ($db_field = mysql_fetch_assoc($result))  
		$a= $db_field['password'];
		if ($oldpassword == $a){
	 
        $sql="UPDATE login SET password='$new' where username='$username' and password='$oldpassword' ";
         
		$query=mysql_query($sql,$con);
	     if($query)
		         echo "Congratulations You have successfully changed your password";
          mysql_close($con);
        }
		 else 
			{
				echo "old password is not correct";
			}
		}
else
	{
		echo "passwords not match";
	}
		}
 mysql_close($con);
      ?>
      </table>
      </form>
   </body>
    </html>