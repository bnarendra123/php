
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Autocomplete search using PHP, MySQLi, ajax and jQuery</title>
<script type="text/javascript" src="//code.jquery.com/jquery-1.8.0.min.js"></script>
<script type="text/javascript">
$(function(){
$(".search_keyword").keyup(function() 
{ 
    var search_keyword_value = $(this).val();
    var dataString = 'search_keyword='+ search_keyword_value;
    if(search_keyword_value!='')
    {
        $.ajax({
            type: "POST",
            url: "search.php",
            data: dataString,
            cache: false,
            success: function(html)
                {
                    $("#result").html(html).show();
                }
        });
    }
    return false;    
});

$("#result").live("click",function(e){
    var $clicked = $(e.target);
    var $name = $clicked.find('.country_name').html();	
    var decoded = $("<div/>").html($name).text();
    $('#search_keyword_id').val(decoded);
});

$(document).live("click", function(e) { 
    var $clicked = $(e.target);
    if (! $clicked.hasClass("search_keyword")){
        $("#result").fadeOut(); 
    }
});

$('#search_keyword_id').click(function(){
    $("#result").fadeIn();
});
});
</script>
</head>

<body>
    <div class='web'>
        <input type="text" class="search_keyword" id="search_keyword_id" placeholder="Country Search" />
        <div id="result"></div>
    </div>
</body>
</html>

<style type="text/css">
	.web{
		font-family:tahoma;
		size:12px;
		top:10%;
		border:1px solid #CDCDCD;
		border-radius:10px;
		padding:10px;
		width:38%;
		margin:auto;
	}
	#search_keyword_id
	{
		width:300px;
		border:solid 1px #CDCDCD;
		padding:10px;
		font-size:14px;
	}
	#result
	{
		position:absolute;
		width:320px;
		display:none;
		margin-top:-1px;
		border-top:0px;
		overflow:hidden;
		border:1px #CDCDCD solid;
		background-color: white;
	}
	.show
	{
		font-family:tahoma;
		padding:10px; 
		border-bottom:1px #CDCDCD dashed;
		font-size:15px; 
	}
	.show:hover
	{
		background:#364956;
		color:#FFF;
		cursor:pointer;
	}
</style>

------------------------    search.php -----------------------------------------


<?php
    include('db_connection.php');
    if(isset($_POST['search_keyword']))
    {
        $search_keyword = $dbConnection->real_escape_string($_POST['search_keyword']);
        $sqlCountries="SELECT countries_id,countries_name FROM tbl_countries WHERE countries_name LIKE '%$search_keyword%'";
        $resCountries=$dbConnection->query($sqlCountries);

        if($resCountries === false) {
            trigger_error('Error: ' . $dbConnection->error, E_USER_ERROR);
        }else{
            $rows_returned = $resCountries->num_rows;
        }

	$bold_search_keyword = '<strong>'.$search_keyword.'</strong>';
	if($rows_returned > 0){
            while($rowCountries = $resCountries->fetch_assoc()) 
            {		
                echo '<div class="show" align="left"><span class="country_name">'.str_ireplace($search_keyword,$bold_search_keyword,$rowCountries['countries_name']).'</span></div>'; 	
            }
        }else{
            echo '<div class="show" align="left">No matching records.</div>'; 	
        }
    }	
?>

-----------------------  Database table -------------------------------------------


<?php
    define('_HOST_NAME', 'localhost');
    define('_DATABASE_USER_NAME', 'xxxxx');
    define('_DATABASE_PASSWORD', 'xxxxx');
    define('_DATABASE_NAME', 'xxxxx');
	
    $dbConnection = new mysqli(_HOST_NAME, _DATABASE_USER_NAME, _DATABASE_PASSWORD, _DATABASE_NAME);
    if ($dbConnection->connect_error) {
        trigger_error('Connection Failed: '  . $dbConnection->connect_error, E_USER_ERROR);
    }
?>