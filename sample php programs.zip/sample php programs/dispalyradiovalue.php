<input type="radio" value="Test"/>Test<br/>
<input type="radio" value="Practice" />Practice<br/>
<input type="radio" value="Both" />Both<br/>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
$("input:radio[type=radio]").click(function() {
var value = $(this).val();
$('#showoption').val(value);
    });
</script>

<label>Value</label>
      <input type="text" name="name" id="showoption" disabled="disabled"/>      
    </label>