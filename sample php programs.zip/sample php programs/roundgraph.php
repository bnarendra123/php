 <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="x_panel tile fixed_height_320 overflow_hidden">
                            <div class="x_title">
                                <h2><?php echo OPERATING_SYSTEMS; ?></h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>
                                    <li class="dropdown">
                                        <!--<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>-->
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">

                                <table class="" style="width:100%">
                                    <tr>
                                        <th style="width:37%;">
                                        </th>
                                        <th>
                                            <div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
                                                <p class=""><?php echo OS; ?></p>
                                            </div>
                                            <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">
                                                <p class=""><?php echo PERCENT; ?></p>
                                            </div>
                                        </th>
                                    </tr>
                                    <tr>
                                        <td>
                                            <canvas id="canvas1" height="140" width="140" style="margin: 15px 10px 10px 0"></canvas>
                                        </td>
                                        <td>
                                            <table class="tile_info">
                                            	<?php foreach(getAppOs() as $o) : ?>
                                                <tr>
                                                    <td>
                                                        <p><i class="fa fa-square blue" style="color: <?php echo $o['color'] ?>"></i><?php echo $o['name']; ?></p>
                                                    </td>
                                                    <td><?php echo $o['per']; ?>%</td>
                                                </tr>
                                                <?php endforeach; ?>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
-----------------  in general.php --------------------------------------
<?php
function getAppOs()
{
	Core::_setDatabase( Config::_get('db.name.ps') );

    $doughnutDataColors = array("#3498DB","#26B99A","#BDC3C7","#9B59B6","#455C73");
    
	$arrayBind = array();
	
	$query = "select o.name, count(*) as total from ps_operating_system o join ps_guest g on g.id_operating_system = o.id_operating_system group by g.id_operating_system ";
 	$results = Core::_getAllRows($query, $arrayBind);
	
	$stats = array();
	$total = 0;
	foreach( $results as $k => $r )
	{
		$stats[$r->total] = array("name" => $r -> name, "count" => $r->total, "per" => 0, "color" => "" );
		$total += $r->total; 
	}
	foreach( $stats as $k => $v )
	{
		$stats[$k]['per'] = round($v['count'] * 100 / $total,2);
	}
	krsort($stats);

	$i = 0;
	foreach( $stats as $k => $v )
	{
		$stats[$k]['color'] = $doughnutDataColors[$i % 5];
		$i++;
	}
	
    Core::_setDatabase( Config::_get('db.name') );
 
    return $stats;

}
?>