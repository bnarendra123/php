<form id="payment" class="nice" method="POST" action="" style="margin-bottom:30px;">    
    <div class="text">
       <p class="amount-text">Your final price is <span class="amount">$249.99</span></p>
    </div>
    <p class="">
        <input type="checkbox" class="large-check" for="id_chair" name="more" value="99.99" />Add Chair <span style="font-weight: bold;">$99.99</span>
    </p>
    <p class="">
        <input type="checkbox" class="large-check" for="id_desk" name="more" value="200.00" />Add Desk <span style="font-weight: bold;">$200.00</span>
    </p>
   
</form>
 <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript">
$(':checkbox').change(function(){
    var sum = 249.99;
    var names = $(':checked').map(function(){
        sum += (this.value - 0);
        return this.name;
    }).get().join(',');
    $('span.amount').text(sum);
});
</script>


<script type="text/javascript">
var a = parseFloat("10") + "<br>";
var b = parseFloat("10.00") + "<br>";
var c = parseFloat("10.33") + "<br>";
var d = parseFloat("34 45 66") + "<br>";
var e = parseFloat(" 60 ") + "<br>";
var f = parseFloat("40 years") + "<br>";
var g = parseFloat("He was 40") + "<br>";
?>
</script>