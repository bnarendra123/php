
<?php
// include the phpmailer class file
require_once "phpmailer/class.phpmailer.php";

// my message to send to the user
$lastID = $DB->lastInsertId();

$message = '<html><head>
           <title>Email Verification</title>
           </head>
           <body>';
$message .= '<h1>Hi ' . $name . '!</h1>';
$message .= '<p><a href="'.SITE_URL.'activate.php?id=' . base64_encode($lastID) . '">CLICK TO ACTIVATE YOUR ACCOUNT</a>';
$message .= "</body></html>";

// php mailer code starts
$mail = new PHPMailer(true);
// telling the class to use SMTP
$mail->IsSMTP();
// enable SMTP authentication
$mail->SMTPAuth = true;   
// sets the prefix to the server
$mail->SMTPSecure = "ssl"; 
// sets GMAIL as the SMTP server
$mail->Host = "smtp.gmail.com"; 
// set the SMTP port for the GMAIL server
$mail->Port = 465; 

// set your username here
$mail->Username = 'youremail@gmail.com';
$mail->Password = 'your password';

// set your subject
$mail->Subject = trim("Email Verifcation - www.thesoftwareguy.in");

// sending mail from
$mail->SetFrom('youremail@gmail.com', 'Your Name');
// sending to
$mail->AddAddress($email);
// set the message
$mail->MsgHTML($message);

try {
  $mail->send();
} catch (Exception $ex) {
  echo $msg = $ex->getMessage();
}
?>

-------------


<?php
if (isset($_GET["id"])) {
  $id = intval(base64_decode($_GET["id"]));

  $sql = "SELECT * from tbl_users where id = :id";
  try {
    $stmt = $DB->prepare($sql);
    $stmt->bindValue(":id", $id);
    $stmt->execute();
    $result = $stmt->fetchAll();

    if (count($result) > 0) {

      if ($result[0]["status"] == "approved") {
        $msg = "Your account has already been activated.";
        $msgType = "info";
      } else {
        $sql = "UPDATE `tbl_users` SET  `status` =  'approved' WHERE `id` = :id";
        $stmt = $DB->prepare($sql);
        $stmt->bindValue(":id", $id);
        $stmt->execute();
        $msg = "Your account has been activated.";
        $msgType = "success";
      }
    } else {
      $msg = "No account found";
      $msgType = "warning";
    }
  } catch (Exception $ex) {
    echo $ex->getMessage();
  }
}
?>