<?php
$con = mysqli_connect("localhost","root","","graphs");
$data[] = array('Employee','Markes');
$sql = "select * from courses";
$query = mysqli_query($con,$sql);
while($result = mysqli_fetch_array($query))
{
$data[] = array($result['subject'],(int)$result['number']);
  
}




//	$data = array($data);			
echo json_encode($data);
?>
