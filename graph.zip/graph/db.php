<?php
$con = mysql_connect("localhost","root","","graphs");
if(!$con)
{
	echo "Connection Not Created";
}


?>