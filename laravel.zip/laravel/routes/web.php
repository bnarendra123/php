<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::get('/', function () {
    return view('home');
});

Route::get('/about', function () {
    return view('about');
});

Route::get('/contact', function () {
    return view('contact');
});
Route::get('/login', function () {
    return view('login');
});

Route ::get('/adduser', function() {
	return view('adduser');
});



Route::get('insert','ContactInsertController@insertform');
Route::post('/contactstore','ContactInsertController@insert');

Route::get('/contactrequests','ContactInsertController@getcontact');
Route::get('/viewcontactdetails/{id}','ContactInsertController@viewcontactdetails');

Route::get('session/get','SessionController@accessSessionData');
Route::get('session/set','SessionController@storeSessionData');
Route::get('session/remove','SessionController@deleteSessionData');

Route::post('/login','ContactInsertController@login');
Route::post('/adduserstore','ContactInsertController@adduser');

Route::get('/editcontactuser/{id}','ContactInsertController@editcuser');
Route::get('/updatedetails/{id}','ContactInsertController@updatedetailsuser');
Route::get('/deletecontact/{id}','ContactInsertController@deletecontactuser');