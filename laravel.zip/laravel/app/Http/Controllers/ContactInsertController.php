<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ContactInsertController extends Controller {
   public function insertform(){
      return view('contact');
   }
	
   public function insert(Request $request)
   {
	   /*$validatedData = $request->validate
     ([
        'name' => 'required|max:2',
        'email' => 'required |unique:posts',
    ]);*/
      $name = $request->input('name');
	   $email = $request->input('email');
      DB::insert('insert into contact (name,email) values(?,?)',[$name,$email]);
      //echo "Record inserted successfully.";
      //echo '<a href = "contact">Click Here</a> to go back.';
	  //return view('contact');
      return redirect('/contact')->with('success', 'Thanks for contact with us.'); 
   }
   
   public function getcontact()
    {
    	$data['data'] = DB::table('contact')->get();
		return view('contactrequests',$data);
    }
	
	public function viewcontactdetails($id)
	{
		$cddata = DB::table('contact')->where('id',$id)->get(); 
		return view('viewcontactdetails',compact('cddata'));
	}

  public function login(Request $request)
 {
   $email=$request->input('email');
   $password=$request->input('password');
	 $ldata=DB::select("select * from login where email='$email' and password='$password'");
   if($ldata>1){
	 return view('home',$ldata);
   } else {

    echo "invalid login credentials.";
   }
 }

  public function adduser(Request $request){
    $name=$request->input('name');
    $email=$request->input('email');
    $message=$request->input('message');
    DB::insert('insert into adduser(name,email,message) values(?,?,?)',[$name,$email,$message]);
    echo "User Added Successfully";
  }


  public function editcuser($id)
  {

   $eddata = DB::table('contact')->where('id',$id)->get(); 
   return view('editcontactuser',compact('eddata'));
  }
  
  public function updatedetailsuser(Request $request,$id){
      echo "<script>alert('update')</script>";
       $name=$request->input('name');
       $email=$request->input('email');
      
      $sdata=DB::update('update contact(name,email) values(?,?)',[$name,$email])->where('id',$id);
      if($sdata){
          echo "updated successfully";
      }else {
          echo "Fail to update success.";
      }
  }

  public function deletecontactuser(Request $request,$id)
  {
    $dcuser=DB::table('contact')->where('id', $id)->delete();
    return redirect('/contactrequests');
  }
}