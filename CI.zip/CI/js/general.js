//....del items in cart page
function delitem(pid) {
	//alert("hello");
	//alert(pid);
	var pass_data = {
		'pid' : pid,
	};
	//alert(pass_data);
	$.ajax({
		type : "post",
		url : baseUrl + "/index.php/fashion/del_item",
		data : pass_data,
		success : function(data) {
			//alert(data);
			//console.log(data);
			if (data.trim() == 'ok') {
				location.reload();
				//alert("Product added to cart");
				//document.location = "<?php echo base_url();?>index.php/fashion/checkout";
			} else {

				alert("Product was not deleted");
				//document.location = "<?php echo base_url();?>index.php/fashion/checkout";
			}
		}
	});
	return false;
}

//....its for login validation
function logincheck() {
	var emailid = $('#email').val();
	var pwd = $('#password').val();
	var emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var errorcount = 0;
	if (emailid == "") {
		$('#email').attr("placeholder", "Please enter Email-ID");
		$('#email').css("border", " solid 2px red");
		errorcount++;
	} else {
		if (!emailRegex.test(emailid)) {
			$('#email').attr("placeholder", "Please enter valid email id");
			$('#email').css("border", " solid 2px red");
			errorcount++;
		} else {
			$('#email').attr("placeholder", "");
			$('#email').css("border", "");
		}
	}
	if (pwd == "") {
		$('#password').attr("placeholder", "Please enter Password");
		$('#password').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#password').attr("placeholder", "");
		$('#password').css("border", "");
	}
	if (errorcount > 0) {
		return false;
	} else {
		var pass_data = {

			'em' : emailid,
			'pw' : pwd,
		};
		//alert(pass_data);
		$.ajax({
			type : "post",
			url : baseUrl + "/index.php/fashion/login_val",
			data : pass_data,
			success : function(data) {
				//alert(data);
				//console.log(data);
				if (data.trim() == 'ok') {
					alert("user login successfully ");
					document.location = baseUrl + 'index.php/fashion/homepage';
					//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
				} else {
					alert("not a valid user");
					location.reload();
				}
			}
		});
		return false;
	}
}

//registeration validation
function signup() {
	var fname = $('#firstname').val();
	var lname = $('#lastname').val();
	var emailid = $('#email').val();
	var pwd = $('#password').val();
	var emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

	var errorcount = 0;
	if (fname == "") {
		$('#firstname').attr("placeholder", "Please enter firstname");
		$('#firstname').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#firstname').attr("placeholder", "");
		$('#firstname').css("border", "");
	}
	if (lname == "") {
		$('#lastname').attr("placeholder", "Please enter lastname");
		$('#lastname').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#lastname').attr("placeholder", "");
		$('#lastname').css("border", "");
	}
	if (emailid == "") {
		$('#email').attr("placeholder", "Please enter Email-ID");
		$('#email').css("border", " solid 2px red");
		errorcount++;
	} else {
		if (!emailRegex.test(emailid)) {
			$('#email').attr("placeholder", "Please enter valid email id");
			$('#email').css("border", " solid 2px red");
			errorcount++;
		} else {
			$('#email').attr("placeholder", "");
			$('#email').css("border", "");
		}
	}
	if (pwd == "") {
		$('#password').attr("placeholder", "Please enter Password");
		$('#password').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#password').attr("placeholder", "");
		$('#password').css("border", "");
	}
	if (errorcount > 0) {
		return false;
	} else {
		var pass_data = {
			'fn' : fname,
			'ln' : lname,
			'em' : emailid,
			'pw' : pwd,
		};
		//alert(pass_data);
		$.ajax({
			type : "POST",
			url : baseUrl + "/index.php/fashion/register_val",
			data : pass_data,
			success : function(data) {
				//alert(data);
				console.log(data);
				if (data.trim() == 'ok') {
					alert("user successfully registered");
					document.location = baseUrl + "/index.php/fashion/login";
				} else {
					alert("user already registered");
					location.reload();
				}
			}
		});
		return false;
	}
}

//...contact us validation
function contact() {
	var uname = $('#name').val();
	var emailid = $('#email').val();
	var phno = $('#phonenumber').val();
	var cmsg = $('#msg').val();
	var emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	//alert(emailid);
	var errorcount = 0;
	if (uname == "") {
		$('#name').attr("placeholder", "Please enter your name");
		$('#name').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#name').attr("placeholder", "");
		$('#name').css("border", "");
	}
	if (emailid == "") {
		$('#email').attr("placeholder", "Please enter Email-ID");
		$('#email').css("border", " solid 2px red");
		errorcount++;
	} else {
		if (!emailRegex.test(emailid)) {
			$('#email').attr("placeholder", "Please enter valid email id");
			$('#email').css("border", " solid 2px red");
			errorcount++;
		} else {
			$('#email').attr("placeholder", "");
			$('#email').css("border", "");
		}
	}

	if (phno == "") {
		$('#phonenumber').attr("placeholder", "Please enter Mobile number");
		$('#phonenumber').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#phonenumber').attr("placeholder", "");
		$('#phonenumber').css("border", "");
	}
	if (cmsg == "") {
		$('#msg').attr("placeholder", "Please enter your message");
		$('#msg').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#msg').attr("placeholder", "");
		$('#msg').css("border", "");
	}
	if (errorcount > 0) {
		return false;
	} else {
		var pass_data = {
			'un' : uname,
			'em' : emailid,
			'phno' : phno,
			'msg' : cmsg,
		};
		//alert(pass_data);
		$.ajax({
			type : "POST",
			url : baseUrl + "/index.php/fashion/contact_val",
			data : pass_data,
			success : function(data) {
				//alert(data);
				//console.log(data);
				if (data.trim() == 'ok') {
					alert("Mail Send!!");
					location.reload();
				} else {
					alert("Mail Sending Fail!!");
					location.reload();
				}
			}
		});
		return false;
	}
}

//...change password valiadtion
function change_pwd() {
	var pwd1 = $('#npassword').val();
	var pwd2 = $('#repassword').val();
	var errorcount = 0;
	if (pwd1 == "") {
		$('#npassword').attr("placeholder", "Please enter your new password here...");
		$('#npassword').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#npassword').attr("placeholder", "");
		$('#npassword').css("border", "");
	}
	if (pwd2 == "") {
		$('#repassword').attr("placeholder", "Please enter your confirm password");
		$('#repassword').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#repassword').attr("placeholder", "");
		$('#repassword').css("border", "");
	}

	if (errorcount > 0) {
		return false;
	} else {
		var pass_data = {
			'p1' : pwd1,
			'p2' : pwd2,

		};
		//alert(pass_data);
		$.ajax({
			type : "POST",
			url : baseUrl + "/index.php/fashion/pwd_up",
			data : pass_data,
			success : function(data) {
				//alert(data);
				//console.log(data);
				if (data.trim() == 'ok') {
					alert("Your password was updated");
					document.location = baseUrl + "/index.php/fashion/homepage";
				} else {
					alert("password was not updated");
					location.reload();
				}
			}
		});
		return false;
	}
}

//..in cart page quantity updating
function qty(qty, pid) {
	//alert(qty);
	//alert(pid);
	var pass_data = {
		'qty' : qty,
		'pid' : pid,
	};
	$.ajax({
		type : "post",
		url : baseUrl + "/index.php/fashion/cartupdate",
		data : pass_data,
		success : function(data) {
			//alert(data);
			//console.log(data);
			if (data.trim() == 'ok') {
				alert("Product Quantity was Updated");
				location.reload();
				//alert("Product added to cart");
				//document.location = "<?php echo base_url();?>index.php/fashion/checkout";
			} else {
				alert("sorry Try Gain to Update your Quantity");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/checkout";
			}
		}
	});
	return false;
}

//..billing script
function billing(totalamount) {
	//alert(totalamount);
	var pass_data = {
		'tamount' : totalamount,
	};
	$.ajax({
		type : "post",
		url : baseUrl + "/index.php/fashion/billing",
		data : pass_data,
		success : function(data) {
			alert(data);
			console.log(data);
			if (data.trim() == 'ok') {
				alert("payment was success");
				//location.reload();
				//alert("Product added to cart");
				document.location = baseUrl + "/index.php/fashion/checkout";
			} else {
				alert("payment was not success");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/checkout";
			}
		}
	});
	return false;
}

//edit profile validation
function edit_profile() {
	var fname = $('#firstname').val();
	var lname = $('#lastname').val();
	var emailid = $('#email').val();

	//alert(fname);
	var errorcount = 0;
	if (fname == "") {
		$('#firstname').attr("placeholder", "Please enter firstname");
		$('#firstname').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#firstname').attr("placeholder", "");
		$('#firstname').css("border", "");
	}
	if (lname == "") {
		$('#lastname').attr("placeholder", "Please enter lastname");
		$('#lastname').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#lastname').attr("placeholder", "");
		$('#lastname').css("border", "");
	}
	if (emailid == "") {
		$('#email').attr("placeholder", "Please enter Email-ID");
		$('#email').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#email').attr("placeholder", "");
		$('#email').css("border", "");
	}

	if (errorcount > 0) {
		return false;
	} else {
		var pass_data = {
			'fn' : fname,
			'ln' : lname,
			'em' : emailid,

		};
		//alert(pass_data);
		$.ajax({
			type : "POST",
			url : baseUrl + "/index.php/fashion/edit_pr_up",
			data : pass_data,
			success : function(data) {
				//alert(data);
				//console.log(data);
				if (data.trim() == 'ok') {
					alert("Your Details are Updated");
					document.location = baseUrl + "/index.php/fashion/homepage";
				} else {
					alert("Your Details are not Updated Just Refresh the Page");
					location.reload();
				}
			}
		});
		return false;
	}
}

//products will add to cart
function addtocart(pid, details) {
	//alert("hello");
	//alert(pid);
	//alert(details);
	var pass_data = {
		'pid' : pid,
		'uid' : details,
	};
	//alert(pass_data);
	$.ajax({
		type : "post",
		url : baseUrl + "/index.php/fashion/cart_up",
		data : pass_data,
		success : function(data) {
			//alert(data);
			//console.log(data);
			if (data.trim() == 'ok') {
				alert("Product added to cart");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
			} else {
				alert("Product will already in your cart Check it once!!!");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
			}
		}
	});
	return false;
}

//cus_payment validation
function cust() {
	var name = $('#username').val();
	var email = $('#email').val();
	var mobile = $('#mnumber').val();
	var city = $('#city').val();
	var account = $('#account').val();
	var errorcount = 0;

	if (name == "") {
		$('#username').attr("placeholder", "Please enter name");
		$('#username').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#username').attr("placeholder", "");
		$('#username').css("border", "");
	}

	if (email == "") {
		$('#email').attr("placeholder", "Please enter Email-ID");
		$('#email').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#email').attr("placeholder", "");
		$('#email').css("border", "");
	}
	if (mobile == "") {
		$('#mnumber').attr("placeholder", "Please enter Mobile number");
		$('#mnumber').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#mnumber').attr("placeholder", "");
		$('#mnumber').css("border", "");
	}
	if (city == '') {
		//$('#city').attr("placeholder","");
		$("#city").focus();
		//return false;
	}
	if (account == "") {
		$('#account').attr("placeholder", "Please enter Account Number");
		$('#account').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#account').attr("placeholder", "");
		$('#account').css("border", "");
	}
	if (errorcount > 0) {
		return false;
	} else {

		var pass_data = {
			'n' : name,
			'em' : email,
			'mob' : mobile,
			'city' : city,
			'acno' : account,
		};
		//alert(pass_data);
		$.ajax({
			type : "post",
			url : baseUrl + "/index.php/fashion/customer",
			data : pass_data,
			success : function(data) {
				//alert(data);
				//console.log(data);
				if (data.trim() == 'ok') {
					alert("Billing was success");
					location.reload();
					document.location = baseUrl + "/index.php/fashion/homepage";
				} else {
					alert("Billing was not Success");
					location.reload();
					//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
				}
			}
		});
		return false;
	}
}

//add to wishlist
function addtowishlist(pid, details) {
	//alert("123");
	var pass_data = {
		'pid' : pid,
		'uid' : details,
	};
	//alert(pass_data);
	$.ajax({
		type : "post",
		url : baseUrl + "/index.php/fashion/wish_list",
		data : pass_data,
		success : function(data) {
			//alert(data);
			//console.log(data);
			if (data.trim() == 'ok') {
				alert("Product added to wishlist");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
			} else {
				alert("Product will already in your wishlist  Check it once!!!");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
			}
		}
	});
	return false;
}

//categories wise products display on products page
function elements(smenu, mmenu) {

	var pass_data = {
		'sub_menu' : smenu,
		'main_menu' : mmenu,
	};
	//alert(pass_data);
	$.ajax({
		type : "post",
		url : baseUrl + "/index.php/fashion/products",
		data : pass_data,
		success : function(data) {
			alert(data);
			console.log(data);
			if (data.trim() == 'ok') {
				alert("yes");
				location.reload();
				document.location = "<?php echo base_url();?>index.php/fashion/products";
			} else {
				alert("nfffo");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
			}
		}
	});
	return false;
}

function item_add_w_c(w_id, details) {
	//alert(w_id);
	//	alert(details);
	var pass_data = {
		'w_id' : w_id,
		'uid' : details,
	};
	$.ajax({
		type : "post",
		url : baseUrl + "/index.php/fashion/w_add_cart",
		data : pass_data,
		success : function(data) {
			//alert(data);
			//console.log(data);
			if (data.trim() == 'ok') {
				alert("added to cart");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/products";
			} else {
				alert("Sorry Try Again!!");
				location.reload();
				//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
			}
		}
	});
	return false;
}

function a_login() {
	//alert(123);
	var emailid = $('#email').val();
	var pwd = $('#password').val();
	var emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var errorcount = 0;
	if (emailid == "") {
		$('#email').attr("placeholder", "Please enter Email-ID");
		$('#email').css("border", " solid 2px red");
		errorcount++;
	} else {
		if (!emailRegex.test(emailid)) {
			$('#email').attr("placeholder", "Please enter valid email id");
			$('#email').css("border", " solid 2px red");
			errorcount++;
		} else {
			$('#email').attr("placeholder", "");
			$('#email').css("border", "");
		}
	}
	if (pwd == "") {
		$('#password').attr("placeholder", "Please enter Password");
		$('#password').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#password').attr("placeholder", "");
		$('#password').css("border", "");
	}
	if (errorcount > 0) {
		return false;
	} else {
		var pass_data = {
			'email' : emailid,
			'password' : pwd,

		};
		//alert(pass_data);
		$.ajax({
			type : "POST",
			url : baseUrl + "/index.php/admin/dashboard/admin_log_val",
			data : pass_data,
			success : function(data) {
				alert(data);
				console.log(data);
				if (data.trim() == 'ok') {
					alert("Welcome to your account");
					document.location = baseUrl + "index.php/admin/dashboard/home";
				} else {
					alert("Sorry Please check your Account Details");
					location.reload();
				}
			}
		});
		return false;
	}
}

function getSearch(e){
	
					var sea = e.keyCode;
	
					//alert(sea);
					if ( sea == 13){
	
						//alert(sea);
					getresults();
					}
					}
	
				
				
				function getresults()
				{
					//alert(123);
					//var data = {};
									
					var sea = $("#searchBox").val();
									
					var pass_data = {
										
					'search' : sea,
									};
					//alert(pass_data);
						
			$.ajax({
			type : "POST",
			url :baseUrl + "/index.php/fashion/search_fun",
			data : pass_data,
			success : function(data) {
				//alert(data);
				console.log(data);
				if (data.trim() == 'ok') {
					alert("Welcome ");
					document.location =  baseUrl + "/index.php/fashion/search_fun";
				} else {
					alert("Sorry");
					location.reload();
				}
			}
		});
		return false;
	}

function newsletter(){
	var email=$('#email').val();
	var errorcount=0;
	if(email==""){
		$('#email').attr("Placeholder","Enter email");
		$('#email').css("border","solid 1px red");
		errorcount++;
	}else{
		$('#email').attr("Placeholder","");
		$('#email').css("border","none");
	}
	if(errorcount>0){
	return false;
	}else {
		var pass_data = {
			'email' : email,
		};
		alert(pass_data);
		$.ajax({
			type : "POST",
			url : baseUrl + "/index.php/fashion/news",
			data : pass_data,
			success : function(data) {
				alert(data);
				if (data.trim() == 'ok') {
					alert("successfully subscribed");
					//document.location ="index.php";
					//location.reload();
				}
				if (data.trim() == 'fail') {
					alert('Fail to send.');
					location.reload();
				}
			}
		});
	}
	return false;
}
