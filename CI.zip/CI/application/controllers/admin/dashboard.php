
<?php defined('BASEPATH') OR exit('No direct script access allowed');
 session_start(); 
class Dashboard extends CI_Controller
{
 
  function __construct()
  {
    parent::__construct();
	$this -> load -> library(array('form_validation', 'pagination', 'cart', 'upload','csvimport','Datatables','table','session'));
	$this->load->view('admin/elements/a_header');
	$this -> load -> model("fmodel");
	
  }
  
  public function index()
  {
  	$this->load->view('admin/a_login');
  }
  public function admin_log_val()
  {
  		$em=$this->input->post('email');
		$pw=$this->input->post('password');
		$this -> fmodel -> admin_login_details($em, $pw);
  }
 
	public function home()
  {
  	
    $this->load->view('admin/dashboard_view');
	$this->load->view('admin/elements/a_footer');
  }
	
	public function ad_logout()
	{
		$ad_data = array('user_id' => '', 'first_name' => '', 'last_name' => '', 'user_email' => '', 'user_password' => '', 'logged_in' => FALSE, );
		$this -> session -> unset_userdata($ad_data);
		//$this -> session -> sess_destroy();
		$this->session->sess_destroy();
		redirect('admin/dashboard', 'refresh');
	}
	public function products()
	{
		$data['productsbook'] = $this->fmodel->get_products();
		$this->load->view('admin/products_upload',$data);
		$this->load->view('admin/elements/a_footer');
	}  

	public function importcsv()
	{
		$data['productsbook'] = $this->fmodel->get_products();
		$data['error'] ='';
		$config['upload_path'] = './uploads/';
		
		$config['allowed_types'] = 'csv';
		$config['max_size'] = '1000';
		//$this->upload->intialize($config);
		$this->load->library('upload', $config);
		if (!$this->upload->do_upload())
		 	{
            	$data['error'] = $this->upload->display_errors();
            	$this->load->view('admin/products_upload', $data);
        	}
			else 
			{
					$file_data = $this->upload->data();
            		$file_path =  './uploads/'.$file_data['file_name'];
					if ($this->csvimport->get_array($file_path))
			 		{
                		$csv_array = $this->csvimport->get_array($file_path);
						foreach($csv_array as $row)
						{
							$insert_data = array(
                        	'menu_id'=>$row['menu_id'],
                        	'submenu_id'=>$row['submenu_id'],
                        	'submenu_id'=>$row['image'],
                        	'imagename'=>$row['imagename'],
                        	'price'=>$row['price'],
                         	'availablity'=>$row['availablity'],
                         	'description'=>$row['description']
                    			);
					 		$q1= $this->fmodel->csv($insert_data);
						}
						$this->session->set_flashdata('success', 'Csv Data Imported Succesfully');
					}
					else
						$data['error'] = "Error occured";
                		$this->load->view('admin/products_upload', $data);	 
			}
	}
}