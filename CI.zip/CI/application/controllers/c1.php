<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
//session_start(); 
	class C1 extends CI_Controller
 	{
 		
		public function __construct()
    {
        parent::__construct();
       // $this->load->library('Datatables');
       // $this->load->library('table');
        //$this->load->database();
    }
	
	function index()
    {
    	//$tmp1 = array('table_open' => '<table id = "big_table" border= "1" celpadding = "2" cellspacing= "1" class ="mytable">');
		
		//$this->table->set_template($tmp1);
		
		//$this->table->set_heading('name','username','email id');
		
 		$this->load->view('data_table');
	}
	
	public function datatable()
	{
		 $this->load->model('c1_m');
        $re['r'] = $this->c1_m->getDatax();
		$this->load->view('data_table',$re);
        //echo json_encode($result);
	}
 
		 
}
	?>