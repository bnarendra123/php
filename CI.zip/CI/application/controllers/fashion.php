 <?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
session_start(); 
	class Fashion extends CI_Controller
 	{
	//constructor
		public function __construct()
		{
			parent::__construct();
			$this -> load -> helper(array('form', 'url', 'file','date','birthdate'));
			$this -> load -> library(array('form_validation', 'pagination', 'cart', 'upload','csvimport','Datatables','table','session','calendar'));
			$uid = $this -> session -> userdata('user_id');
			$this -> load -> model("fmodel");
			$data1['cat']=$this->fmodel->cat_view();
			$data1['sub_cat']=$this->fmodel->sub_cat_view();
			$data1['r'] =  $this->fmodel->countdisp($uid);
			$this -> load -> view('elements/header',$data1);	
		}
		//main page
		public function index()
		{
			if (($this -> session -> userdata('id') != "")) {
				$this -> homepage();
				} else {
			$this -> load -> model('fmodel');
			$data['row'] = $this -> fmodel -> getitems();
			//print_r($data);
			$this -> load -> view('elements/banner');
			$this -> load -> view('bodycontent', $data);
			$this -> load -> view('elements/footer');
		}
	}

	function signup() {

		$this -> load -> view('register');	
		
		$this -> load -> view('elements/footer');
		
		//echo $this->calendar->generate();
	}

	function register_val() {

		$data = array('firstname' => $this -> input -> post('fn'), 'lastname' => $this -> input -> post('ln'), 'email' => $this -> input -> post('em'), 'password' => $this -> input -> post('pw'), );
		$email = $this -> input -> post('em');
		$this -> load -> model('fmodel');
		$this -> fmodel -> add_user($data, $email);
	}

	function login() {
		$this -> load -> view('login');
		$this -> load -> view('elements/footer');
	}

	function login_val() {

		$email = $this -> input -> post('em');
		$password = $this -> input -> post('pw');
		$this -> load -> model('fmodel');
		$this -> fmodel -> login_details($email, $password);
	}

	function homepage() {
		$this -> load -> model('fmodel');
		$data['row'] = $this -> fmodel -> getitems();
		
		$this -> load -> view('homepage', $data);
		$this -> load -> view('elements/footer');
	}

	function edit_p() {
		$uid = $this -> session -> userdata('user_id');
		$this -> load -> model('fmodel');
		$data['row'] = $this -> fmodel -> edit_profile($uid);
		$this -> load -> view('editprofile', $data);
		$this -> load -> view('elements/footer');
	}

	function edit_pr_up() {
		$data = array('firstname' => $this -> input -> post('fn'), 'lastname' => $this -> input -> post('ln'), 'email' => $this -> input -> post('em'), );
		$uid = $this -> session -> userdata('user_id');
		$this -> load -> model('fmodel');
		$this -> fmodel -> edit_update($data, $uid);

	}

	function contactus() {
		$this -> load -> view('contactus');
		$this -> load -> view('elements/footer');
	}

	function contact_val() {
		$data = array('name' => $this -> input -> post('un'), 'email' => $this -> input -> post('em'), 'phonenumber' => $this -> input -> post('phno'), 'message' => $this -> input -> post('msg'), );
		$this -> load -> model('fmodel');
		$this -> fmodel -> sendmail($data);

	}

	function logout() {
		$newdata = array('user_id' => '', 'first_name' => '', 'last_name' => '', 'user_email' => '', 'user_password' => '', 'logged_in' => FALSE, );
		$this -> session -> unset_userdata($newdata);
		 $this->session->sess_destroy();
		redirect('fashion/index','refresh');
		
	}

	public function pwd_change() {
		$this -> load -> view('changepwd');
		$this -> load -> view('elements/footer');
	}

	function pwd_up() {
		$uid = $this -> session -> userdata('user_id');
		$pwd1 = $this -> input -> post('p1');
		$pwd2 = $this -> input -> post('p2');
		$data = array('password' => $this -> input -> post('p2'));
		$this -> load -> model('fmodel');
		$this -> fmodel -> password($pwd1, $pwd2, $uid, $data);
	}

	//single product preview shows
	public function view() {
		$id = $_REQUEST['id'];
		$data['imgresult'] = $this -> fmodel -> imagepreview($id);
		$this -> load -> view('single', $data);
		$this -> load -> view('elements/footer');
	}

	public function checkout() {
		$uid = $this -> session -> userdata('user_id');
		$data['c_items']=$this->fmodel->cart_items_view($uid);
		$this -> load -> view('checkout',$data);
		$this -> load -> view('elements/footer');
	}

	//get all data frproducts_dispom database
	public function products() 
	{
		/*
		$sid = $_REQUEST['subid'];
				$mid = $_REQUEST['mid'];
				$config['base_url'] = "http://127.0.0.1:8888/srikanthcodeigniter/index.php/fashion/products";
				$config['per_page'] = 6;
				$config['num_links'] = 7;
				//$config['total_rows']
				$this->db->where('menu_id',$mid);
				$this->db->where('submenu_id',$sid);
				$config['total_rows'] = $this -> db -> get('products') -> num_rows();
				$this -> pagination -> initialize($config);
				$data['query'] = $this -> db -> get('products', $config['per_page'], $this -> uri -> segment(3));
				$this -> load -> view('products', $data);
				$this -> load -> view('elements/footer');*/
		
		
		$sub_menu = $_REQUEST['subid'];
		$main_menu = $_REQUEST['mid'];
		$data['rows']=$this->fmodel->products_disp($sub_menu,$main_menu);
		$this->load->view('products',$data);
		$this->load->view('elements/footer');
	}	
	
	//...add to cart...
	public function cart_up()
	{
		$pr_id=$this->input->post('pid');
		$u_id=$this->input->post('uid');
		$this->load->model('fmodel');
		$this->fmodel->in_cart($pr_id,$u_id);
		$this -> load -> view('products');
		$this -> load -> view('elements/footer');
	}
	
	//delete item from cart page
	public function del_item()
	{
		$p_id=$this->input->post('pid');
		$this->load->model('fmodel');
		$this->fmodel->del_it_cart($p_id);
		
	}
	
	//in cart update the quantity
	public function cartupdate()
	{
		$uid = $this -> session -> userdata('user_id');
		$p_pid=$this->input->post('pid');
		$data = array('qty' => $this -> input -> post('qty'));
		$this->fmodel->cart_update($data,$p_pid,$uid);
	}
	//payment function
	public function billing()
	{
		$uid = $this -> session -> userdata('user_id');
		$data['paydetails']=$this->fmodel->pay($uid);
		$this->load->view('cus_payment',$data);
		$this->load->view('elements/footer');
	}
	//customer details
	public function customer()
	{
		$uid = $this -> session -> userdata('user_id');
		$data = array('name' =>$this->input->post('n'),
						'email' => $this->input->post('em'),
						'mobile' =>$this->input->post('mob'),
						'city' =>$this->input->post('city'),
						'accountno' =>$this->input->post('acno')
						
						);
						//print_r($data);
		$this->fmodel->customer_det_in($data,$uid);
	}
	
	public function orderdetails()
	{$uid = $this -> session -> userdata('user_id');
		$data['odetails']=$this->fmodel->o_details_show($uid);
		$this->load->view('or_details',$data);
		$this->load->view('elements/footer');
	}
	
	//function for wishlist
	public function wish_list()
	{
		$pr_id=$this->input->post('pid');
		$u_id=$this->input->post('uid');
		$this->fmodel->in_wish($pr_id,$u_id);
		
	}
	//view the products in wishlist page
	public function wish()
	{
		$uid = $this -> session -> userdata('user_id');
		$data['w_items']=$this->fmodel->wish_items_view($uid);
		$this -> load -> view('wishdetails',$data);
		$this -> load -> view('elements/footer');
	}
	public function w_add_cart()
	{
		$w_id=$this->input->post('w_id');
		$uid=$this->input->post('uid');
		$this->fmodel->wish_to_cart($w_id,$uid);	
	}
	public function admin()
	{
		 $data['addressbook'] = $this->fmodel->get_addressbook();
		$this->load->view('admin_dashboard',$data);
		$this->load->view('elements/footer');
	}
	
	 public function importcsv()
	 {
       	$data['addressbook'] = $this->fmodel->get_addressbook();
        $data['error'] = '';    //initialize image upload error array to empty 
        $config['upload_path'] = './up/';
		//$config['upload_path'] = 'up';
        $config['allowed_types'] = 'csv';
        $config['max_size'] = '1000';
		$this->upload->initialize($config);
       // $this->load->library('upload', $config);
        // If upload failed, display error
        if (!$this->upload->do_upload())
		 {
            $data['error'] = $this->upload->display_errors();
            $this->load->view('admin_dashboard', $data);
        }
		 else
		 {
            $file_data = $this->upload->data();
            $file_path =  './up/'.$file_data['file_name'];
 			 if ($this->csvimport->get_array($file_path))
			 {
                $csv_array = $this->csvimport->get_array($file_path);
                foreach ($csv_array as $row) 
                {
                    $insert_data = array(
                        'menu_id'=>$row['menu_id'],
                        'submenu_id'=>$row['submenu_id'],
                        'image'=>$row['image'],
                        'imagename'=>$row['imagename'],
                        'price'=>$row['price'],
                        'availablity'=>$row['availablity'],
                         'description'=>$row['description'],	
                    );
                   $q1= $this->fmodel->insert_csv($insert_data);
				  // print_r($q1);
                }
                $this->session->set_flashdata('success', 'Csv Data Imported Succesfully');
				// $this->load->view('admin_dashboard', $data);
              //redirect(site_url('fashion/importcsv'));
               // echo "<pre>"; print_r($insert_data);
            } 
            else 
                $data['error'] = "Error occured";
                $this->load->view('admin_dashboard', $data);
            }     
			}	
			
			public function datatable()
			{
				
				$tmpl = array ( 'table_open'  => '<table id="big_table" border="1" cellpadding="2" cellspacing="1" class="mytable">' );
       $this->table->set_template($tmpl); 
        
       // $this->table->set_heading('cd_id','cd_name','number of copies','owner');

       // $this->load->view('data_table');
				
				//$re['r']=$this->datatables->select('*')
        
        //->from('cds');
       // $re['r'] = $this->fmodel->getDatax();
       // $this->load->view('data_table',$re);
       ///  //$this->datatables->generate();
		
        		/*
				$re['r'] = $this->fmodel->getDatax();
								$this->load->view('data_table',$re);*/
				
				//echo json_encode($result);
				
				$this->datatables->select('id,cd_title,cd_no_of_copies,cd_owner')
        ->unset_column('id')
        ->from('cds');
        
        $this->datatables->generate();
			}
			
			function search()
			{
				$data['query'] = $this->fmodel->get_search();
				
				$this->load->view(search, $data);	
			}

		public function news(){
			$data=array('email'=>$this->input->post('email'));
		$data['reg']=$this->fmodel->inews($data);	
		}
			
}
		