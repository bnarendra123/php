<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
//session_start(); 
	class Search extends CI_Controller
 	{
	//constructor
		public function __construct()
		{
			parent::__construct();
			$this->load->model("search_m");
		}
		
		public function index()
		{
			//$this->load->view('search');
			$this->search();
		}
		
		public function search()
		{
			$s=$this->input->post('search');
			
			$postlist['Searchop'] = $this->search_m->getSearch($s);
			
			print_r($postlist);
    		$this->load->view('search', $postlist);
					
			
		}
		
		
	}
	
	