<div align="center">
	<table border="1" style="margin-top: 100px; border:1px solid black;" width="600px" height="auto">
			<tr style="border:1px solid black;">
				<th>image</th><th>price</th><th>Add to cart</th><th>Delete</th>
			</tr>
			<?php foreach($w_items as $key)
			{
				$details = $this->session->userdata('user_id');
				$w_id=$key->pid;
				 $w_price=$key->price;
				 $w_img=$key->image; ?>
<form>
			<tr>
			<td><a href="#"><img src="<?php echo base_url(). 'images/'.$w_img;?>"alt=" broken" width="80px" height="80px" style="margin-left:10px; margin-top:5px; margin-bottom: 5px;" ></a></td>
				<td><?php echo $w_price; ?></td>
				
				<td><a href="#" onClick="item_add_w_c(<?php echo $w_id;?>,<?php echo $details; ?>);"><img src="<?php echo base_url(); ?>images/add-to-cart.jpg" alt="" width="40px" height="30px"></a></td>
				<td><a href="#" onClick="itemremovewishlist();"><img src="<?php echo base_url(); ?>images/delete-big.jpg" alt="" width="40px" height="30px"></a></td>
			</tr>
			<?php } ?>
			</form>
</table>
