<div class="account">
	<div class="container">
		<h1>Change Password</h1>
		<div class="account_grid">
			   <div class="col-md-6 login-right">
				<form name="f3" id="f3" method= "post">
					
					
					<span> New Password</span>
					<input type="password" name="npassword" id="npassword"> 
				
					<span>Re-Enter Password</span>
					<input type="password" name="repassword" id="repassword"> 
					<div class="word-in">
				  		
				 		 <input type="submit" name="submit" id="submit" value="Update" onclick="return change_pwd();">
				  	</div>
			    </form>
			   </div>	
			    
			   <div class="clearfix"> </div>
			 </div>
	</div>
</div>