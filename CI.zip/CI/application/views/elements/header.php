<!DOCTYPE html>
<html>
	<head>
		<title>Fashion Mania</title>
		<link href="<?php echo base_url(); ?>css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
			<script type="text/javascript">var baseUrl =  '<?php echo base_url(); ?>';</script>
		<script src="<?php echo base_url(); ?>js/general.js"></script>
		<!-- Custom Theme files -->
		<!--theme-style-->
		<link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet" type="text/css" media="all" />
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,600' rel='stylesheet' type='text/css'>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<!--//theme-style-->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
		Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
		 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,600' rel='stylesheet' type='text/css'>
     <!--caleder-->
  
     <!--caleder-->
		<script type="application/x-javascript">
			addEventListener("load", function() {
				setTimeout(hideURLbar, 0);
			}, false);
			function hideURLbar() {
				window.scrollTo(0, 1);
			}
		</script>
		<!-- start menu -->
		<link href="<?php echo base_url(); ?>css/memenu.css" rel="stylesheet" type="text/css" media="all" />
		<script type="text/javascript" src="<?php echo base_url(); ?>js/memenu.js"></script>
		<script>
			$(document).ready(function() {
				$(".memenu").memenu();
			});
		</script>
		<script src="<?php echo base_url(); ?>js/simpleCart.min.js"></script>
		<!-- slide -->
		<script src="<?php echo base_url(); ?>js/responsiveslides.min.js"></script>
		<script>
			$(function() {
				$("#slider").responsiveSlides({
					auto : true,

					speed : 500,
					namespace : "callbacks",
					pager : true,
				});
			});
		</script>
	</head>
	<body>
		<?php //print_r($details=$this->session->userdata('first_name')); ?>
		<!--header-->
		<div class="header">
			<div class="header-top">
				<div class="container">
					<div class="col-sm-4 world">
						<!--<ul >
							
							<li>
															<select class="in-drop">
																<option>English</option>
																<option>Japanese</option>
																<option>French</option>
															</select>
														</li>-->
							
							<!--
							<li>
															<select class="in-drop1">
																<option>Dollar</option>
																<option>Euro</option>
																<option>Yen</option>
															</select>
														</li>
							
						</ul>-->
					</div>
					<div class="col-sm-4 logo">
						<a href="<?=site_url('fashion/index') ?>"><img src="<?php echo base_url(); ?>images/logo.png" alt=""></a>
					</div>
					<div class="col-sm-4 header-left">
						<p class="log">
							<?php $uid = $this->session->userdata('user_id');
							if($uid>0) { ?>
								<a href="<?=site_url('fashion/edit_p') ?>"  >Edit Profile</a>
								<a href="<?=site_url('fashion/logout') ?>"  >Logout</a>
								<a href="<?=site_url('fashion/orderdetails') ?>"  >Order Details</a>
								<a href="<?=site_url('fashion/wish') ?>" >WishList</a>
								
								<?php } else { ?>
									 
							<a href="<?=site_url('fashion/login') ?>"  >Login</a>
							<span>or</span><a  href="<?=site_url('fashion/signup') ?>"  >Signup</a>
							<?php } ?>
						</p>
						<!--user logged cart was shows like not logged user else part shows-->
						<?php $u_detail=$this->session->userdata('user_id');
						if($u_detail>0)
						{?>
							<div class="cart box_1">
							<a href="<?=site_url('fashion/checkout') ?>"> <h3>
							<div class="total">
								<span class=""><?php echo $r  ?></span>
							</div><img src="<?php echo base_url(); ?>images/cart.png" alt=""></h3> </a>
							<p>
								<a href="" class="simpleCart_empty">Empty Cart</a>
							</p>
						</div>
						<?php }else { ?>
						<div class="cart box_1">
							<a href="<?=site_url('fashion/checkout') ?>"> <h3>
							<div class="total">
								<span class="">0</span>
							</div><img src="<?php echo base_url(); ?>images/cart.png" alt=""></h3> </a>
							<p>
								<a href="" class="simpleCart_empty">Empty Cart</a>
							</p>
						</div>
						<?php } ?>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="container">
				<div class="head-top">
					<div class="col-sm-2 number">
						<span><i class="glyphicon glyphicon-phone"></i>9848032919</span>
						
					</div>
					<div class="col-sm-8 h_menu4">
						<ul class="memenu skyblue">
							<li class=" grid">
								<?php if($uid>0) { ?>
								<a  href="<?=site_url('fashion/homepage') ?>">Home</a>
								<?php } else { ?>
									<a  href="<?=site_url('fashion/index') ?>">Home</a>
									<?php } ?>
							</li>
							<li>
								<?php foreach($cat as $v_main_cat)
								{
									$categorynames=$v_main_cat->menu_name;
									$menu_id=$v_main_cat->menu_id;
								?>
								<?php if($menu_id>0){?>
								<li><a  href="#"><?php echo $categorynames; ?></a>	
								
								<div class="mepanel">
									<div class="row">
										<div class="col1">
											<div class="h_nav">
									<h4>All Clothing</h4>
									<ul>
										<?php foreach($sub_cat as $v_allsubmenus)
										{?>
											<?php if($vat=$v_allsubmenus->menu_id == $v_main_cat->menu_id){
												//echo $vat;
												?>
										<!--<li><a href="<?php echo base_url().$v_allsubmenus->url; ?>?subid=<?php echo $v_allsubmenus->submenu_id;?>?mid=<?php echo $v_allsubmenus->submenu_id;?>"><?php echo $v_allsubmenus->submenuname;?></a></li>-->
										<li><a href="<?=site_url('fashion/products') ?>?subid=<?php echo $v_allsubmenus -> submenu_id; ?>&mid=<?php echo $v_allsubmenus -> menu_id; ?>"><?php echo $v_allsubmenus -> submenuname; ?></a></li>
										<!--<li><a href="" onclick="elements(<?php echo $smenu=$v_allsubmenus->submenu_id;?>,<?php echo $mmenu=$v_allsubmenus->menu_id; ?>)"><?php echo $v_allsubmenus->submenuname;?></a></li>-->
										<?php } ?>
										<?php } ?>
									</ul>	
								</div>	
									</div>
								</div>
								<?php } } ?> 
							</li>
							<li>
								<a  href="typo.html">Blog</a>
							</li>
							<li>
								<a class="color6" href="<?=site_url('fashion/contactus') ?>">Conact</a>
							</li>
						</ul>
					</div>
					<div class="col-sm-2 search">
						
								<!--<input type="text" value="" ><input type="submit" name="search" value="search">-->
						<a class="play-icon popup-with-zoom-anim" href="#small-dialog"><i class="glyphicon glyphicon-search"> </i> </a>
					</div>
					<div class="clearfix"></div>
					<!---pop-up-box---->
					<script type="text/javascript" src="<?php echo base_url(); ?>js/modernizr.custom.min.js"></script>
					<link href="<?php echo base_url(); ?>css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
					<script src="<?php echo base_url(); ?>js/jquery.magnific-popup.js" type="text/javascript"></script>
					<!---//pop-up-box---->
					<div id="small-dialog" class="mfp-hide">
						<div class="search-top">
							<div class="login">
								<input type="submit" name="search" value="search">
								<input type="text" value="" >
							</div>
							<p>
								Shopping
							</p>
						</div>
					</div>
					<script>
						$(document).ready(function() {
							$('.popup-with-zoom-anim').magnificPopup({
								type : 'inline',
								fixedContentPos : false,
								fixedBgPos : true,
								overflowY : 'auto',
								closeBtnInside : true,
								preloader : false,
								midClick : true,
								removalDelay : 300,
								mainClass : 'my-mfp-zoom-in'
							});

						});
					</script>
					<!---->
				</div>
			</div>
		</div>
<!--code for view page--!>
	<script src="<?php echo base_url(); ?>js/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>js/imagezoom.js"></script>
<!-- start menu -->
<link href="<?php echo base_url(); ?>css/memenu.css" rel="stylesheet" type="text/css" media="all" />
<script type="text/javascript" src="<?php echo base_url(); ?>js/memenu.js"></script>
<script>
	$(document).ready(function() {
		$(".memenu").memenu();
	}); 
</script>
<script src="<?php echo base_url(); ?>js/simpleCart.min.js"></script>
<!--initiate accordion-->
						<script type="text/javascript">
							$(function() {
								var menu_ul = $('.menu-drop > li > ul'), menu_a = $('.menu-drop > li > a');
								menu_ul.hide();
								menu_a.click(function(e) {
									e.preventDefault();
									if (!$(this).hasClass('active')) {
										menu_a.removeClass('active');
										menu_ul.filter(':visible').slideUp('normal');
										$(this).addClass('active').next().stop(true, true).slideDown('normal');
									} else {
										$(this).removeClass('active');
										$(this).next().stop(true, true).slideUp('normal');
									}
								});

							});
						</script>
						<!-- FlexSlider -->
  <script defer src="<?php echo base_url(); ?>js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="<?php echo base_url(); ?>css/flexslider.css" type="text/css" media="screen" />

<script>
	// Can also be used with $(document).ready()
	$(window).load(function() {
		$('.flexslider').flexslider({
			animation : "slide",
			controlNav : "thumbnails"
		});
	}); 
</script>
<!---pop-up-box---->
					<link href="<?php echo base_url(); ?>css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
					<script src="<?php echo base_url(); ?>js/jquery.magnific-popup.js" type="text/javascript"></script>
					<!---//pop-up-box---->
					 <script>
						$(document).ready(function() {
							$('.popup-with-zoom-anim').magnificPopup({
								type : 'inline',
								fixedContentPos : false,
								fixedBgPos : true,
								overflowY : 'auto',
								closeBtnInside : true,
								preloader : false,
								midClick : true,
								removalDelay : 300,
								mainClass : 'my-mfp-zoom-in'
							});

						});
				</script>	
<!--view page code end-->				