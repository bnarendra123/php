<<div class="footer">
	<div class="container">
		<div class="footer-top">
			<div class="col-md-8 top-footer">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d243647.25176871577!2d78.40804554999998!3d17.412348700000006!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9192e14d6c11%3A0x43ccdc3dd087585f!2sConfianza+Technologies!5e0!3m2!1sen!2sin!4v1443585436230" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>
			<div class="col-md-4 top-footer1">
				<h2>Newsletter</h2>
					<form method="post" action="">
						<input type="text" name="email" id="email">
						<input type="submit" name="submit" value="SUBSCRIBE" onclick="return newsletter();">
					</form>
			</div>
			
			<div class="clearfix"> </div>	
		</div>	
	</div>
	<div class="footer-bottom">
		<div class="container">
				<div class="clearfix"> </div>
				<p class="footer-class"> © 2015 Fashion Mania All Rights Reserved | Design by <a href="http://confianza.co.in/" target="_blank">confianza</a> </p>
			</div>
	</div>
</div>
<!--//footer-->
</body>
</html>