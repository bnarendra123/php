<head>
		<title>Admin_Page</title>
		<link href="<?php echo base_url(); ?>css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
			<script type="text/javascript">
					var baseUrl = '<?php echo base_url(); ?>';
			</script>
		<script src="<?php echo base_url(); ?>js/general.js"></script>
		<!-- Custom Theme files -->
		<!--theme-style-->
		<link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet" type="text/css" media="all" />
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,600' rel='stylesheet' type='text/css'>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<!--//theme-style-->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Fashion Mania Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
		Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
		 <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,600' rel='stylesheet' type='text/css'>
		
		<!-- start menu -->
		<link href="<?php echo base_url(); ?>css/memenu.css" rel="stylesheet" type="text/css" media="all" />
		<script type="text/javascript" src="<?php echo base_url(); ?>js/memenu.js"></script>
		
	</head><div class="account">
	<div class="container">
		<h1>Login Page</h1>
		<div class="account_grid">
			   <div class="col-md-6 login-right">
				<form name="f2" id="f2" method= "post" action ="">
					<span>Email Address</span>
					<input type="email" name="email" id="email" value=""> 
				
					<span>Password</span>
					<input type="password" name="password" id="password"> 
					<div class="word-in">
				  		<a class="forgot" href="#">Forgot Your Password?</a>
				 		 <input type="submit" name="submit"  value="Login" id="submit" onclick= " return a_login();">
				  	</div>
			   </form>
			   </div>	
			    <div class="col-md-6 login-left">
			  	 
			   </div>
			   <div class="clearfix"> </div>
			 </div>
	</div>
</div>
