<body>
              <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
                <form method="post" action="<?=site_url('admin/dashboard/importcsv')?>" enctype="multipart/form-data">
                    <input type="file" name="userfile" ><br><br>
                    <input type="submit" name="submit" value="UPLOAD" class="btn btn-primary">
                </form>
 
            <br><br>
            <table class="table table-striped table-hover table-bordered">
                <caption>Bluck Products Uploading "Here"</caption>
                <thead>
                    <tr>
                        <th>Catagory</th>
                         <th>Sub-Catagory</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Availablity</th>
                         <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($productsbook == FALSE): ?>
                        <tr><td //colspan="4">There are currently No Products</td></tr>
                    <?php else: ?>
                        <?php foreach ($productsbook as $row): ?>
                            <tr>
                                <td><?php echo $row['menu_id']; ?></td>
                                <td><?php echo $row['submenu_id']; ?></td>
                                <td><?php echo $row['imagename']; ?></td>
                                <td><?php echo $row['price']; ?></td>
                                <td><?php echo $row['availablity']; ?></td>
                                 <td><?php echo $row['description']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
    </body>
