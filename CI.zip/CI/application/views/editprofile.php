<div class="container">
	<div class="register">
		<h1>Edit your Profile</h1>
		<?php
	foreach ($row as $key) {
		$fn = $key -> firstname;
		$ln = $key -> lastname;
		$em = $key -> email;
	}/*
	 if(isset($fn) && ($ln) && ($em))
	 {
	 $f=$fn;
	 $l=$ln;
	 $e=$em;
	 }
	 else {
	 $f='';
	 $l='';
	 $e='';
	 }*/
		?>
		<form name="f3" id="f3" method= "post">
			<div class="col-md-6  register-top-grid">
				<div class="mation">
					<span>First Name</span>
					<input type="text" name="firstname" id="firstname" value="<?php echo $fn; ?>">
					<?php echo form_error('firstname'); ?>
					<span>Last Name</span>
					<input type="text" name="lastname" id="lastname" value="<?php echo $ln; ?>">
					<?php echo form_error('lastname'); ?>
					<span>Email Address</span>
					<input type="email" name="email" id="email" value="<?php echo $em; ?>">
					<?php echo form_error('email'); ?>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="col-md-6 login-left">
				
				
				<h4>If you want change your password</h4>
				<p>
					....
				</p>
				<a class="acount-btn" href="<?=site_url('fashion/pwd_change') ?>">Change Password</a>
				
			</div>
			<div class="clearfix"></div>
			<div class="register-but">
				<input type="submit"  name="submit" id= "submit" onclick="return edit_profile();">
				<div class="clearfix"></div>
			</div>
		</form>
	</div>
</div>