
<div class="contact">
			<div class="container">
				<h1>Contact</h1>
				<div class="contact-grids">
					<div class="contact-form">
							<form name="f4" id="f4" method= "post">
								<div class="contact-bottom">
									<div class="col-md-4 in-contact">
										<span>Name</span>
										<input type="text" name="name" id="name" placeholder="name"> 
									</div>
									<div class="col-md-4 in-contact">
										<span>Email</span>
										<input type="email" name="email" id="email" placeholder="email">
									</div>
									<div class="col-md-4 in-contact">
										<span>Phonenumber</span>
										<input type="text" name="phonenumber" id="phonenumber" placeholder="mobile number">
									</div>
									<div class="clearfix"> </div>
								</div>
							
								<div class="contact-bottom-top">
									<span>Message</span>
									<textarea name="textarea" placeholder="message..." id="msg"></textarea>							
									</div>
								<input type="submit"  name="submit" id= "submit" value="send" onclick = "return contact();" >
							</form>
						</div>
				<div class="address">
					<div class=" address-more">
						<h2>Address</h2>
						<div class="col-md-4 address-grid">
							<i class="glyphicon glyphicon-map-marker"></i>
							<div class="address1">
								<p>Lorem ipsum dolor</p>
								<p>TL 19034-88974</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="col-md-4 address-grid ">
							<i class="glyphicon glyphicon-phone"></i>
							<div class="address1">
								<p>+885699655</p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="col-md-4 address-grid ">
							<i class="glyphicon glyphicon-envelope"></i>
							<div class="address1">
								<p><a href="mailto:@example.com"> @example.com</a></p>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="clearfix"> </div>
					</div>
				</div>
			</div>
		</div>
	</div>
	