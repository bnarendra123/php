<div align="center">
	<table border="1" style="margin-top: 100px; border:1px solid black;" width="600px" height="auto">
			<tr style="border:1px solid black;">
				<th>image</th><th>date</th><th>Item name</th><th>price</th><th>Quantity</th><th>Order Status</th>
			</tr>
			<?php foreach($odetails as $r)
			{
				$op_id=$r->pid;
				$op_date=$r->date;
				$op_img=$r->image;
				$op_img_name=$r->imagename;
				$op_price=$r->price;
				$op_qty=$r->qty;
				$op_id=$r->pid;
			?>
<form>
			<tr>
	<td><a href="#"><img src="<?php echo base_url(). 'images/'.$op_img;?>"alt=" broken" width="80px" height="80px" style="margin-left:10px; margin-top:5px; margin-bottom: 5px;" ></a></td>
				<td><?php echo $op_date; ?></td>
				<td><?php echo $op_img_name; ?></td>
				<td><?php echo $op_price; ?></td>
				<td><?php echo $op_qty; ?></td>
				<td>processing..</td>
				
			</tr>
			<?php } ?>
			</form>
</table>
