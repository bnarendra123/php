
<div class="account">
	<div class="container">
		<h1>Account</h1>
		<div class="account_grid">
			   <div class="col-md-6 login-right">
				<form name="f2" id="f2" method= "post" action ="">
					<span>Email Address</span>
					<input type="email" name="email" id="email" value=""> 
				
					<span>Password</span>
					<input type="password" name="password" id="password"> 
					<div class="word-in">
				  		<a class="forgot" href="#">Forgot Your Password?</a>
				 		 <input type="submit" name="submit"  value="Login" id="submit" onclick= " return logincheck();">
				  	</div>
				  	 
			   </form>
			   </div>	
			    <div class="col-md-6 login-left">
			  	 <h4>NEW CUSTOMERS</h4>
				 <p>By creating an account with our store, you will be able to move through the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>
				 <a class="acount-btn" href="<?=site_url('fashion/signup') ?>">Create an Account</a>
				<!--
				 <a class="acount-btn" href="<?=site_url('fashion/admin') ?>">display details</a>
								 <a class="acount-btn" href="<?=site_url('fashion/u_details') ?>">Admin User Details</a>
								 <a class="acount-btn" href="<?=site_url('fashion/d_display') ?>">Display Data In Formats</a>
								  <a class="acount-btn" href="<?=site_url('fashion/datatable') ?>">Datatables</a>-->
				
			   </div>
			   <div class="clearfix"> </div>
			 </div>
	</div>
</div>
