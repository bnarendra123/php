<?php //print $details=$this->session->userdata('user_id'); ?>
<div class="content">
	<div class="container">
		<div class="content-top">
			<h1>Recent Products</h1>
			<div class="content-top1">
				<?php foreach ($row as $r)
{
	$details=$this->session->userdata('user_id');
		$prid=$r->id;
	  $img=$r->image;
	 $imgname=$r->imagename;
	 $imgprice=$r->price;
 ?>
				<div class="col-md-3 col-md2 pad">	
					<div class="col-md1 simpleCart_shelfItem">
						<a href="<?=site_url('fashion/view') ?>?id=<?php echo $prid ?>">
							<img class="img-responsive" src="<?php echo base_url(). 'images/'.$img;?>" alt="" />
						</a>
						<h3><a href="<?=site_url('fashion/view')?>?id=<?php echo $prid ?>"><?php echo $imgname; ?></a></h3>
						<div class="price">
								<h5 class="item_price">$<?php echo $imgprice; ?></h5>
								<a href="<?=site_url('fashion/view')?>?id=<?php echo $prid ?>" class="item_add">More Details</a>
								<div class="clearfix"> </div>
						</div>
					</div>
				</div>	
				<?php } ?>
			<div class="clearfix"> </div>
			</div>		
		</div>
	</div>
</div>
