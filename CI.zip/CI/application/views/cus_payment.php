<?php $total = "";
 foreach($paydetails as $r)
{
	$p_price=$r->price;
	$p_qty= $r->qty;
	$subtotal=$p_price *$r->qty;
	$total=$total + $subtotal;
}
?>
			<body>
		<div align="center">
			<h3>Billing Form</h3>
			<form  method="post" name="form" action="" id="myform">
				<table>

						<div align ="center">
						
						<h6>TOTAL AMOUNT:<?php echo $total;?></h6>
					    </div>
					<tr>
						<td>USERNAME:</td><td>
						<input type="text"  name="username" id="username" />
						</td>
					</tr>
					
					<tr>
						<td>EMAIL:</td><td>
						<input type="email" name="email" id="email" />
						</td>
					</tr>
					<tr>
						<td>MOBILE NUMBER:</td><td>
						<input type="text" name="mnumber" id="mnumber" />
						</td>
					</tr>
					<tr>
						<td>City</td><td>
						<select id="city" name="city">
							<option value=""></option>
							<option value="Pune">Pune</option>
							<option value="Hyd">Hyd</option>
						</select>
						<br />
						<br>
						</td>
					</tr>
					<tr>
						<td>Account Number:</td><td>
						<input type="text" name="account" id="account" placeholder="XXXX-XXX-XXX-XXX" />
						</td>
					</tr>
					<tr>
						<td>
						<input type="submit" id="submit" name="submit"  value="submit" onclick="return cust();">
						</td>
					</tr>
				</table>
			</form>
		</div>
		</body>