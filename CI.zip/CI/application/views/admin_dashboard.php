
    <body>
              <?php if (isset($error)): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
                <form method="post" action="<?=site_url('fashion/importcsv') ?>" enctype="multipart/form-data">
                    <input type="file" name="userfile" ><br><br>
                    <input type="submit" name="submit" value="UPLOAD" class="btn btn-primary">
                </form>
 
            <br><br>
            <table class="table table-striped table-hover table-bordered">
                <caption>List Of Products</caption>
                <thead>
                    <tr>
                        <th>Category ID</th>
                        <th>Sub_categroy</th>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Availablity</th>
                        <th>Description</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($addressbook == FALSE): ?>
                        <tr><td //colspan="4">Currently There are no Products</td></tr>
                    <?php else: ?>
                        <?php foreach ($addressbook as $row): ?>
                            <tr>
                                <td><?php echo $row['menu_id']; ?></td>
                                <td><?php echo $row['submenu_id']; ?></td>
                                <td><?php echo $row['imagename']; ?></td>
                                <td><?php echo $row['price']; ?></td>
                                <td><?php echo $row['availablity']; ?></td>
                                <td><?php echo $row['description']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
    </body>