<div class="container">
	<div class="register">
		<h1>Register</h1>
		  	<!-- <?php  echo form_open('fashion/reg_val', array('id'=>'regform'));?>-->
		  	<form name="f1" id="f1" method= "post">
				 <div class="col-md-6  register-top-grid">
					
					<div class="mation">
						<span>First Name</span>
						<input type="text" name="firstname" id="firstname" placeholder="Firstname">
					
						<span>Last Name</span>
						<input type="text" name="lastname" id="lastname" placeholder="Lastname">  
					 
						 <span>Email Address</span>
						 <input type="email" name="email" id="email" placeholder="Email">  
					</div>
					 <div class="clearfix"> </div>
					   <a class="news-letter" href="#">
						 <label class="checkbox"><input type="checkbox" name="checkbox" checked=""><i> </i>Sign Up</label>
					   </a>
					 </div>
				     <div class=" col-md-6 register-bottom-grid">
						   
							<div class="mation">
								<span>Password</span>
								<input type="password" name="password" id="password" placeholder="password">  
								
							</div>
							
					 </div>
					 <div class="clearfix"> </div>
					 <div class="register-but">
					   <input type="submit"  name="submit" id= "submit1" onclick="return signup();" >
					   <div class="clearfix"> </div>
				</div>
				 </form>
		   </div>
</div>
