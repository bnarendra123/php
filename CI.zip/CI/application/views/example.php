<html>
	<?php echo "hello";?>
	<h6>hai</h6>
</html>