
<div class="container">
	<div class="check-out">
		<h1>Checkout</h1>
    	    <table >
		  <tr>
			<th>Item</th>
			<th>Qty</th>		
			<th>Prices</th>
			<th>Delery Detials</th>
			<th>Subtotal</th>
		  </tr>
		  <?php $totalamount="";
		  foreach($c_items as $list) {
			$c_id=$list->id;
			 $c_im=$list->image;
			  $c_imn=$list->imagename; 
			  $c_p=$list->price;
			   $list->qty;
			  //  $details=$this->session->userdata('user_id');
			    ?>
		  <tr>
			<td class="ring-in">
				<a href="" class="at-in" onclick="delitem(<?php echo $pid=$list->id;?>);">
					<img src="<?php echo base_url(). 'images/'.$c_im;?>" class="img-responsive" alt="">
					<div class="project-info">
					<img src="<?php echo base_url(); ?>images/Delete.png" class="img-responsive" alt="" width="30" height="30">
					</div>
					</a>
			<div class="sed">
				<h5>Sed ut perspiciatis unde</h5>
				<p>(At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium) </p>
			</div>
			<div class="clearfix"> </div></td>
			<td class="check"><input type="number" name="qty" value="<?php echo $list->qty;?>" min ="1" max = "6" id="<?php echo $pid=$list->id ?>" onchange="return qty(this.value,<?php echo $pid=$list->id;?>)"></td>		
			<td>$<?php echo $c_p; ?></td>
			<td>FREE SHIPPING</td>
			<td>$<?php echo $subtotal=$list->qty * $c_p;?></td>
		  </tr>
		  <?php $totalamount=$totalamount + $subtotal;?>
		  <?php } ?> 
	</table>
	<a href="<?=site_url('fashion/billing')?>" class=" to-buy" >PROCEED TO BUY</a>
	<div class="clearfix"> </div>
    </div>
</div>
