
<div class="content">
	<div class="container">
		
		<div class="content-top">
			<h1>Recent Products</h1>
			
			<div class="content-top1">
				<?php
				//print_r($row); 
				foreach ($row as $r)
{
		$prid=$r->id;
	  $img=$r->image;
	 $imgname=$r->imagename;
	 $imgprice=$r->price;
 ?>
				<div class="col-md-3 col-md2 pad">	
					<div class="col-md1 simpleCart_shelfItem">
						<a href="<?=site_url('/fashion/view') ?>?id=<?php echo $prid ?>">
							<img class="img-responsive" src="<?php echo base_url().'images/'.$img;?>" alt="" />
						</a>
						<h3><a href="<?=site_url('fashion/view') ?>"><?php echo $imgname; ?></a></h3>
						<div class="price">
								<h5 class="item_price">$<?php echo $imgprice;?></h5>
								<!--<a href="#" class="item_add" onclick="addtocart(<?php echo $pid=$r->id; ?>);">Add To Cart</a>-->
								<a href="<?=site_url('fashion/login') ?>" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
					</div>
				</div>	
			<?php } ?>
			<!--line gap-->
			<div class="clearfix"> </div>
			</div>
			<!--line gap-->	
		</div>
	</div>
</div>