<?php
 
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
 
function assets_url() {
    return base_url();
}
 
/* End of file assets_helper.php */
/* Location: ./application/helpers/assets_helper.php */