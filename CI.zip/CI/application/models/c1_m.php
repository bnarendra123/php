<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class C1_m extends CI_model
{
	 function __construct()
    {
        parent::__construct();
    }
	
	public function getDatax()
	{
		$this -> db -> select('*');
		$this -> db -> from('cds');
		return $this -> db -> get() -> result();
		//$query=$this->db->get('products');
		return $query -> result();
		
		/*
		 $output = array(
						"aData" => array()
					);
				$this->db->select('*');
				$query=$this->db->get('cds');
				$output["aData"] = $query->result();
				return $output;*/
		/*
			
		*/
	}
}
