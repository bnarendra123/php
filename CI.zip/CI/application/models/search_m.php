<?php
if (!defined('BASEPATH'))exit('No direct script access allowed');

class Search_m extends CI_Model {
	
	public function __construct()
	{
		parent::__construct();
	}
	
	function getSearch($s)
	{
		if(empty($s))
		
       		return array();

    $result = $this->db->like('firstname', $s)
             ->or_like('lastname', $s)
             ->get('addressbook');

    return $result->result();
			
		
	}
	
}