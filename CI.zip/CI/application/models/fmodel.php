<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Fmodel extends CI_Model {
	public function __construct() {
		parent::__construct();
	}

	public function add_user($data, $email) {
		$this -> db -> where('email', $email);
		$query = $this -> db -> get('users');
		if ($query -> num_rows() > 0) {
			die('fail');
		} else {
			$this -> db -> insert('users', $data);
			die('ok');
		}
	}

	function login_details($email, $password) {
		$this -> db -> where('email', $email);
		$this -> db -> where('password', $password);
			$this -> db -> where('admin', '0');
		$query = $this -> db -> get('users');
		if ($query -> num_rows() > 0) {
			foreach ($query->result() as $key) {
				$newdata = array('user_id' => $key -> id, 'first_name' => $key -> firstname, 'last_name' => $key -> lastname, 'user_email' => $key -> email, 'user_password' => $key -> password, 'logged_in' => TRUE, );
			}
			$query=$this -> session -> set_userdata($newdata);
			//print_r($query);
			die('ok');
		}
		die('fail');
	}

	function edit_profile($uid) {
		$this -> db -> where('id', $uid);
		$query = $this -> db -> get('users');
		return $query -> result();
	}

	function edit_update($data, $uid) {
		$this -> db -> where('id', $uid);
		$query = $this -> db -> update('users', $data);
		if ($query) {
			die('ok');
		} else {
			die('fail');
		}
	}

	function sendmail($data) {
		$query = $this -> db -> insert('contact', $data);
		if ($query) {
			die('ok');
		} else {
			die('fail');
		}
	}

	public function password($pwd1, $pwd2, $uid, $data) {
		$this -> db -> where('id', $uid);
		$query = $this -> db -> get('users');
		if ($query) {
			if ($pwd1 == $pwd2) {
				$this -> db -> where('id', $uid);
				//$this->db->where('password',$pwd2);
				$query = $this -> db -> update('users', $data);
				if ($query) {
					die('ok');
				}
			} else {
				die('fail');
			}
		} else {
			die('fail');
		}
	}

	//get products and display on page
	public function getitems() {
		$this -> db -> select('*');
		$this -> db -> from('products');
		$this -> db -> limit(8);
		return $this -> db -> get() -> result();
		//$query=$this->db->get('products');
		return $query -> result();
	}

	//countof products display on header
	public function countdisp($uid) {
		//print_r($uid);
		$this -> db -> where('uid', $uid);
		$count = $this -> db -> count_all_results('cart_products');
		//var_dump($count);
		return $count;
	}

	//product image was display on single page
	public function imagepreview($id) {
		$row = $this -> db -> get_where('products', array('id' => $id));
		//$this->db->where('id',$id);
		$query = $this -> db -> get('products') -> row();
		return $row -> result();
	}

	public function in_cart($pr_id, $u_id) {
		$this -> db -> where('id', $pr_id);
		$query = $this -> db -> get('products');
		//print_r($query);
		foreach ($query->result() as $r) {

			$p_id = $r -> id;
			$u_id;
			$p_img = $r -> image;
			$p_im_name = $r -> imagename;
			$p_price = $r -> price;

		}
		$this -> db -> where('id', $p_id);
		$this -> db -> where('uid', $u_id);
		$count = $this -> db -> count_all_results('cart_products');
		//return $count->result();
		//print_r($count);
		if ($count > 0) {
			die('fail');
		} else {

			$this -> db -> set('id', $p_id);
			$this -> db -> set('uid', $u_id);
			$this -> db -> set('image', $p_img);
			$this -> db -> set('imagename', $p_im_name);
			$this -> db -> set('price', $p_price);
			$q1 = $this -> db -> insert('cart_products');
			if ($q1) {
				die('ok');
			}
		}
	}

	public function cart_items_view($uid) {
		$this -> db -> where('uid', $uid);
		$query = $this -> db -> get('cart_products');
		//print_r($query);
		return $query -> result();
	}

	public function del_it_cart($p_id) {
		$this -> db -> where('id', $p_id);
		$query = $this -> db -> delete('cart_products');
		//return $query->result();
		if ($query) {
			die('ok');
		} else {
			die('fail');
		}

	}

	public function cart_update($data, $p_pid, $uid) {
		//$this->db->where('qty',$p_qty);
		$this -> db -> where('id', $p_pid);
		$this -> db -> where('uid', $uid);
		$query = $this -> db -> update('cart_products', $data);
		if ($query) {
			die('ok');
		} else {
			die('fail');
		}
	}

	public function pay($uid) {
		$this -> db -> where('uid', $uid);
		$query = $this -> db -> get('cart_products');
		return $query -> result();
	}

	public function customer_det_in($data, $uid) {
		$this -> db -> set('userid', $uid);
		$query = $this -> db -> insert('customer', $data);
		if ($query) {
			$this -> db -> where('uid', $uid);
			$q = $this -> db -> get('cart_products');
			foreach ($q->result() as $r) {
				$uid = $r -> uid;
				$p_id = $r -> id;
				$p_img = $r -> image;
				$p_img_name = $r -> imagename;
				$p_price = $r -> price;
				$p_qty = $r -> qty;
				$p_date = date('Y-m-d');
			}
			$this -> db -> set('uid', $uid);
			$this -> db -> set('pid', $p_id);
			$this -> db -> set('image', $p_img);
			$this -> db -> set('imagename', $p_img_name);
			$this -> db -> set('price', $p_price);
			$this -> db -> set('qty', $p_qty);
			$this -> db -> set('date', $p_date);
			$q1 = $this -> db -> insert('orderdetails');
			if ($q1) {
				$this -> db -> where('uid', $uid);
				$query = $this -> db -> delete('cart_products');
				if ($query) {
					die('ok');
				} else {
					die('ok');
				}
			}
		}
	}

	public function o_details_show($uid) {
		$this -> db -> where('uid', $uid);
		$query = $this -> db -> get('orderdetails');
		return $query -> result();
	}

	//view category name on header
	public function cat_view() {
		$query = $this -> db -> get('categories');
		return $query -> result();
	}

	public function sub_cat_view() {
		$query = $this -> db -> get('submenus');
		return $query -> result();
	}

	public function products_disp($sub_menu, $main_menu) {
		$this -> db -> where('menu_id', $main_menu);
		$this -> db -> where('submenu_id', $sub_menu);
		$query = $this -> db -> get('products');
		return $query -> result();
	}

	public function in_wish($pr_id, $u_id) {
		$this -> db -> where('id', $pr_id);
		$query = $this -> db -> get('products');
		foreach ($query->result() as $r) {
			$p_id = $r -> id;
			$u_id;
			$p_img = $r -> image;
			$p_price = $r -> price;
		}
		$this -> db -> where('pid', $p_id);
		$this -> db -> where('uid', $u_id);
		$count = $this -> db -> count_all_results('wishlist');
		if ($count > 0) {
			die('fail');
		} else {
			$this -> db -> set('pid', $p_id);
			$this -> db -> set('uid', $u_id);
			$this -> db -> set('image', $p_img);
			$this -> db -> set('price', $p_price);
			$query = $this -> db -> insert('wishlist');
			if ($query) {
				die('ok');
			}
		}
	}

	public function wish_items_view($uid) {
		$this -> db -> where('uid', $uid);
		$query = $this -> db -> get('wishlist');
		//print_r($query);
		return $query -> result();
	}

	public function wish_to_cart($w_id, $uid) {
		$this -> db -> where('uid', $uid);
		$this -> db -> where('pid', $w_id);
		$query = $this -> db -> get('wishlist');
		foreach ($query->result() as $key) {
			$pid = $key -> pid;
			$uid = $key -> uid;
			$img = $key -> image;
			$price = $key -> price;
		}
		$this -> db -> set('id', $pid);
		$this -> db -> set('uid', $uid);
		$this -> db -> set('image', $img);
		$this -> db -> set('price', $price);
		$query = $this -> db -> insert('cart_products');
		if ($query) {
			$this -> db -> where('pid', $pid);
			$this -> db -> where('uid', $uid);
			$this -> db -> delete('wishlist');
			die('ok');
		} else {
			die('fail');
		}
	}

	public function get_addressbook() {
		$query = $this -> db -> get('products');
		//print_r($query);
		if ($query -> num_rows() > 0) {
			return $query -> result_array();
		} else {
			return FALSE;
		}
	}

	public function insert_csv($data) {
	$this -> db -> insert('products', $data);
	//redirect('fashion/importcsv','refresh');
	}

	public function admin_login_details($em, $pw)
	{
		$this -> db -> where('email', $em);
		$this -> db -> where('password', $pw);
		$this -> db -> where('admin', '1');
		$query = $this -> db -> get('users');
		if ($query -> num_rows() > 0)
		{
			foreach ($query->result() as $key)
			{
				$ad_data = array('user_id' => $key -> id, 'first_name' => $key -> firstname, 'last_name' => $key -> lastname, 'user_email' => $key -> email, 'user_password' => $key -> password, 'logged_in' => TRUE, );
			}
			$this -> session -> set_userdata($ad_data);
			die('ok');
		}else{ die('fail');}
	}
	
	public function get_products()
	{
		$query = $this -> db -> get('products');
		//print_r($query);
		if ($query -> num_rows() > 0) {
			return $query -> result_array();
		} else {
			return FALSE;
		}
	}
	
	public function csv($data) {
		$this -> db -> insert('products', $data);
	}
	
	public function disp_items()
	{
		$query=$this->db->get('products');
		return $query->result();
	}
	
	public function getDatax()
	{
		$this -> db -> select('*');
		$this -> db -> from('cds');
		return $this -> db -> get() -> result();
		//print_r($q);
		//$query=$this->db->get('products');
		return $query -> result();
	}
	public function inews($data){
		$query=$this->db->insert('newsletter',$data);
		redirect(site_url(''));
	}
	
}
