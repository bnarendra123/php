-- phpMyAdmin SQL Dump
-- version 4.1.4
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2016 at 12:41 PM
-- Server version: 5.6.15-log
-- PHP Version: 5.4.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `code`
--

-- --------------------------------------------------------

--
-- Table structure for table `addressbook`
--

CREATE TABLE IF NOT EXISTS `addressbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `phone` int(15) NOT NULL,
  `email` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `addressbook`
--

INSERT INTO `addressbook` (`id`, `firstname`, `lastname`, `phone`, `email`) VALUES
(83, 'narendra', 'n', 2147483647, 'narendra@gmail.com'),
(82, 'swami', 'c', 1234567890, 'swami@gmail.com'),
(81, 'srikanth', 'p', 1234567890, 'sree@gmail.com'),
(80, 'narendra', 'n', 2147483647, 'narendra@gmail.com'),
(79, 'swami', 'c', 1234567890, 'swami@gmail.com'),
(78, 'srikanth', 'p', 1234567890, 'sree@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `cart_products`
--

CREATE TABLE IF NOT EXISTS `cart_products` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` int(5) NOT NULL,
  `uid` int(5) NOT NULL,
  `category` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `imagename` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `size` varchar(10) NOT NULL,
  `moneytype` varchar(10) NOT NULL,
  `availablity` int(10) NOT NULL,
  `qty` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`cart_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `cart_products`
--

INSERT INTO `cart_products` (`cart_id`, `id`, `uid`, `category`, `image`, `imagename`, `price`, `size`, `moneytype`, `availablity`, `qty`) VALUES
(61, 2, 51, '', 'pi3.png', 'Shirt', 200, '', '', 0, 1),
(60, 3, 51, '', 'pi4.png', 'Shirt', 100, '', '', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `menu_id` int(11) NOT NULL AUTO_INCREMENT,
  `submenu_id` int(2) NOT NULL,
  `menu_name` text NOT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`menu_id`, `submenu_id`, `menu_name`) VALUES
(1, 1, 'MEN'),
(2, 2, 'WOMEN');

-- --------------------------------------------------------

--
-- Table structure for table `cds`
--

CREATE TABLE IF NOT EXISTS `cds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cd_title` varchar(10) NOT NULL,
  `cd_no_of_copies` int(5) NOT NULL,
  `cd_owner` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `cds`
--

INSERT INTO `cds` (`id`, `cd_title`, `cd_no_of_copies`, `cd_owner`) VALUES
(1, 'a', 10, 'A'),
(2, 'b', 5, 'B'),
(3, 'c', 6, 'C'),
(4, 'd', 7, 'D'),
(5, 'e', 4, 'E'),
(6, 'f', 5, 'F');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `email` varchar(25) NOT NULL,
  `phonenumber` int(20) NOT NULL,
  `message` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phonenumber`, `message`) VALUES
(18, 'fwaewfwfrwfw', 'srikanth@confianza.co.in', 1231231231, 'dfsfsfsf'),
(17, 'B1', 'srikanth@confianza.co.in', 1231231231, 'fgvdzgdfbdbbdg'),
(16, 'srikanth', 'srikanth@confianza.co.in', 1231231231, 'helloooooooooooooooooooooooooooooo');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(5) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(40) NOT NULL,
  `mobile` int(20) NOT NULL,
  `city` text NOT NULL,
  `accountno` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `userid`, `name`, `email`, `mobile`, `city`, `accountno`) VALUES
(19, 66, 'srikanth', 'srikanth@confianza.co.in', 1231231231, 'Pune', 2147483647),
(17, 50, 'a', 'sree@gmail.com', 1221212121, 'Pune', 2147483647),
(18, 65, 'sree', 'srikanth@confianza.co.in', 2147483647, 'Pune', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE IF NOT EXISTS `orderdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(5) NOT NULL,
  `pid` int(10) NOT NULL,
  `date` date NOT NULL,
  `image` varchar(200) NOT NULL,
  `imagename` varchar(200) NOT NULL,
  `price` int(10) NOT NULL,
  `qty` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`id`, `uid`, `pid`, `date`, `image`, `imagename`, `price`, `qty`) VALUES
(4, 65, 318, '2015-11-25', 'pi7.png', '', 500, 1),
(3, 50, 2, '2015-10-09', 'pi3.png', 'shirt', 200, 1),
(5, 66, 342, '2016-01-07', 'pi6.png', 'Jeans', 1000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(5) NOT NULL,
  `submenu_id` int(5) NOT NULL,
  `image` varchar(100) NOT NULL,
  `imagename` varchar(100) NOT NULL,
  `price` int(10) NOT NULL,
  `availablity` int(10) NOT NULL DEFAULT '10',
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=481 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `menu_id`, `submenu_id`, `image`, `imagename`, `price`, `availablity`, `description`) VALUES
(480, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(479, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(478, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(477, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(476, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(475, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(474, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(473, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(472, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(471, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(469, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(470, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(468, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(467, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(466, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(464, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(465, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(463, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(462, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(461, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(460, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(459, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(458, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(457, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(456, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(455, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(454, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(453, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(452, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(451, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(449, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(450, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(448, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(447, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(446, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(445, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(444, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(443, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(442, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(441, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(440, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(438, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(439, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(437, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(436, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(435, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(434, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(433, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(432, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(431, 1, 4, 'pr2.png', 'Formal-Shirt', 1500, 10, 'I am trying to upload multiple images using this custom library.'),
(430, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(429, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(428, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(427, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(426, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(425, 1, 3, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(424, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(423, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(422, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(421, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(420, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(419, 1, 2, 'pi2.png', 'T-Shirt', 450, 10, 'I am trying to upload multiple images using this custom library.'),
(418, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(417, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(416, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(415, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(414, 1, 1, 'pi3.png', 'Shirt', 300, 10, 'I am trying to upload multiple images using this custom library.'),
(413, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(412, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(411, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(410, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(409, 2, 5, 'ce.png', 'Shirt', 400, 10, 'I am trying to upload multiple images using this custom library.'),
(408, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(407, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(406, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(405, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(404, 2, 6, 'pi7.png', 'T-Shirt', 500, 10, 'I am trying to upload multiple images using this custom library.'),
(403, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(402, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(401, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(400, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(399, 2, 8, 'pi6.png', 'Jeans', 1000, 10, 'I am trying to upload multiple images using this custom library.'),
(398, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(397, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(396, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(395, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(394, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.'),
(393, 2, 7, 'pi1.png', 'Top', 900, 10, 'I am trying to upload multiple images using this custom library.');

-- --------------------------------------------------------

--
-- Table structure for table `submenus`
--

CREATE TABLE IF NOT EXISTS `submenus` (
  `submenu_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_id` int(2) NOT NULL,
  `submenuname` varchar(10) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`submenu_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `submenus`
--

INSERT INTO `submenus` (`submenu_id`, `menu_id`, `submenuname`, `url`) VALUES
(1, 1, 'Shirts', '/index.php/fashion/products'),
(2, 1, 'T-shirts', '/index.php/fashion/products'),
(3, 1, 'Jeans', '/index.php/fashion/products'),
(4, 1, 'Formals', '/index.php/fashion/products'),
(5, 2, 'Shirts', '/index.php/fashion/products'),
(6, 2, 'T-Shirts', '/index.php/fashion/products'),
(7, 2, 'Tops', '/index.php/fashion/products'),
(8, 2, 'Jeans', '/index.php/fashion/products');

-- --------------------------------------------------------

--
-- Table structure for table `subscriber`
--

CREATE TABLE IF NOT EXISTS `subscriber` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first` text NOT NULL,
  `last` text NOT NULL,
  `email` varchar(25) NOT NULL,
  `Avatar` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `subscriber`
--

INSERT INTO `subscriber` (`id`, `first`, `last`, `email`, `Avatar`) VALUES
(1, 'naveen', 'n', 'naveen@gmail.com', 'nave.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin` int(2) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(10) NOT NULL,
  `gender` varchar(9) NOT NULL,
  `phone_number` int(15) NOT NULL,
  `profile_image` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `admin`, `firstname`, `lastname`, `email`, `password`, `gender`, `phone_number`, `profile_image`) VALUES
(51, 0, 'srikanth', 'ss', 'swami@gmail.com', '123', '', 0, ''),
(50, 1, 'srikanth', 'p', 'sree@gmail.com', '123', '', 0, ''),
(64, 0, 'suresh', 's', 'suresh@gmail.com', '123', '', 0, ''),
(65, 0, 'sree', 'shanthi', 'shanthi@gmail.com', '123', '', 0, ''),
(66, 0, 'sree', 'kanth', 'srikanth@confianza.co.in', '123', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(5) NOT NULL,
  `pid` int(5) NOT NULL,
  `category` varchar(100) NOT NULL,
  `productname` varchar(100) NOT NULL,
  `image` varchar(500) NOT NULL,
  `price` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `uid`, `pid`, `category`, `productname`, `image`, `price`) VALUES
(5, 50, 2, '', '', 'pi3.png', 200);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
