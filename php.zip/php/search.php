<?php
include "includes/header.php";
echo "<br><br>";
?>
<?php
	     if(isset($_POST['submit'])){
	     	$letter=$_POST['name'];
	     	$con=mysql_connect("localhost","root","") or die(mysql_error());
            $db=mysql_select_db("core",$con) or die(mysql_error());
			$sql="SELECT * FROM items WHERE  producttitle LIKE '%" . $letter . "%' or description LIKE '%" . $letter . "%' or category LIKE '%" . $letter . "%'";
			$result=mysql_query($sql,$con);
				
	   
?>
<table border="0" cellspacing="5" cellpadding="10" width="800px">
	<tr>
		<th>Image</th><th>Product title</th><th>Price</th><th>Availablity</th><th>Description</th>
	</tr>
	<?php
	while($row=mysql_fetch_array($result)){
	?>
	<tr>
		<td>&emsp; &emsp; &emsp; <img src="admin/images/<?php echo $row['image']; ?>" width="100px" height="100px"/></td>
	<td>&emsp; <?php echo $row['producttitle']; ?></td>
	<td>&emsp; <?php echo $row['price']; ?></td>
	<td>&emsp; <?php echo $row['availablity']; ?></td>
	<td><?php echo $row['description']; ?></td>
	<?php
				if(isset($_SESSION['id']) > 0){
					?>
	<td><a href="cart.php?id=<?php echo $row['id']; ?>">&emsp; Add to Cart</td>
		<?php } else{ ?>
			<td><a href="login.php">&emsp; Add to Cart</td>
				<?php } ?>
				<?php
				if(isset($_SESSION['id']) > 0){
					?>
	<td><a href="wishlist.php?id=<?php echo $row['id']; ?>">&emsp;  Add to Wishlist</td>
		<?php } else{ ?>
		<td><a href="login.php">&emsp; Add to Wishlist</td>
			<?php } ?>
			<?php
				if(isset($_SESSION['id']) > 0){
					?>
	<td><a href="checkout.php?id=<?php echo $row['id']; ?>">&emsp; Buy now</td>
		<?php } else{ ?>
		<td><a href="login.php">&emsp; Buy now</td>
			<?php } ?>
	</tr>
<?php 
} 
}
?>

</table>
<?php
include "includes/footer.php"; 
?>
