<?php
include "includes/header.php";
include "includes/left.php";
?>


<div class="regtab">
	<body>
		<form method="post" action="">
		<table border="0" cellspacing="10" cellpadding="10" style="margin-left: 100px;" align="center">
			
			<tr><td>&nbsp; </td></tr>
			<tr>
				<td>Email:</td><td><input type="text" name="email" style="width:200px;" id="email"></td><td><span id="emaill"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td>Password:</td><td><input type="password" name="password" style="width:200px;" id="password"></td><td><span id="pwdl"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td><input type="submit" name="submit" value="Login" style="margin-left:100px; font-size:15px;" onclick="return log()">&nbsp; &nbsp; <input type="reset" name="reset" value="Reset" style="margin-left:10px; font-size:15px;"></td>
			</tr>
		</table>
	</div>
	</body>
</html>
</form>
