<?php
include "includes/header.php";
include "includes/left.php";
?>
<?php 
$id=$_GET['id'];
$con=mysql_connect("localhost","root","") or die(mysql_error());
$db=mysql_select_db("core",$con) or die(mysql_error());
$sql="select * from reg where id='$id' ";
$result=mysql_query($sql,$con);
?>
<form method="post" action="">
<table border="1" align="center" cellspacing="5" cellpadding="10">
	<?php
	while($row=mysql_fetch_array($result)){
		?>
		<div class="useredit">
		<tr>
			<td>Name : </td><td><input type="text" name="name" value="<?php echo $row['name']; ?>" id="name"></td><td><span id="uname"></span></td></tr>
			<tr><td>&nbsp; &nbsp; </td></tr>
			<tr><td>Email : </td><td><input type="email" name="email" value="<?php echo $row['email']; ?>" id="email"></td><td><span id="uemail"></span></td></tr>
			<tr><td>&nbsp; &nbsp; </td></tr>
			<tr><td>Mobile number : </td><td><input type="text" name="phone" value="<?php echo $row['phone']; ?>" id="phone"></td><td><span id="uphone"></span></td></tr>
			<tr><td>&nbsp; &nbsp; </td></tr>
		<tr><td><input type="submit" name="submit" value="Update" onclick="return updatepro();">&nbsp; &nbsp; <input type="reset" name="reset" value="Reset"></td></tr>
		</div>
</table>
<?php
	}
	?>
	</form>