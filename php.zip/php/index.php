



<?php

	  include "includes/header.php";
	  include "includes/left.php";
	include "includes/config.php";
	
	?>
	<?php
	include "includes/config.php";
	$sql="select * from slider";
	$query=mysql_query($sql,$con);
	?>
					 				 
					 	<?php
					 	while($row=mysql_fetch_array($query)){ ?>
										<div class="header_bottom_right">
						             	<div class="slide">
						             		<div id="mover">
						             	 <div class="slider-img">
									     <a href="preview.php"><img src="admin/slider/<?php echo $row['image']; ?>" name="slide"/></a>
									  </div>						             					                 
				                </div>
								</div>	 			             					                 
				              </div>
			                 		<?php } ?>
					 <div class="clear"></div>					       

 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>New Products</h3>
    		</div>
    		<div class="see">
    			<p><a href="#">See all Products</a></p><br>
    			<p><form method="post" action="">
    				<input type="submit" name="submit" value="Low To High">
    			</form></p>
    		</div>
    </div>
    </div>
    	</div>
   <?php
   if(isset($_POST['submit'])){
   	$sql=""
   }
	      <div class="section group">
	      	<?php
	      	$sql="select * from items";
	$result=mysql_query($sql,$con);
    	while($row=mysql_fetch_array($result)){
    		?>
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="preview.php?id=<?php echo $row['id']; ?>"><img src="admin/images/<?php echo $row['image']; ?>" width="150px" height="150px" alt="" /></a>
					 <h2><?php echo $row['producttitle']; ?></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees"><?php echo $row['price']; ?></span></p>
					    </div>
					       		<div class="add-cart">								
									<h4><a href="login.php">Add to Cart</a></h4>
							     </div>
					</div>
				</div>
				<?php
		}
		?>
				</div>


   <?php
   include "includes/footer.php";
   ?>