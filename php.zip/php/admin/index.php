<?php
include "includes/header.php";
?>
<div class="adminlog">
	<body>
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<table border="0" cellspacing="10" cellpadding="10" style="margin-left: 100px;" align="center">
			
			<tr><td>&nbsp; </td></tr>
			<tr>
				<td>Email:</td><td><input type="text" name="email" style="width:200px;" id="email"></td><td><span id="emaill"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td>Password:</td><td><input type="password" name="password" style="width:200px;" id="password"></td><td><span id="pwdl"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td><input type="submit" name="submit" value="Login" style="margin-left:100px; font-size:15px;" onclick="return adminlog()">&nbsp; &nbsp; <input type="reset" name="reset" value="Reset" style="margin-left:10px; font-size:15px;"></td>
			</tr>
		</table>
	</div>
	</body>
</html>
</form>
<?php
if(isset($_POST['submit'])){
	$email=$_POST['email'];
	$password=$_POST['password'];
	$con=mysql_connect("localhost","root","") or die(mysql_error());
	$db=mysql_select_db("core",$con) or die(mysql_error());
	$result=mysql_query("select email,password from admin where email='$email' and password='$password'");
	$row = mysql_fetch_array($result);
if($row["email"]==$email && $row["password"]==$password)
    echo "<script>alert('login success')</script><script>location.href='items.php'</script>";
else
    echo "<script>alert('invalid login details')";
	}
?>