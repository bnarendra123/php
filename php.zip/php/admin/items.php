
<html>
	<head>
		<style>
			.ahead{
				margin-left:20px;
				font-size:18px;
				color:blue;
			}
		</style>
	</head>
	<body>
		<div class="ahead">
			<a href="items.php">Product</a>&nbsp; &nbsp; <a href="slider.php">Slider image</a>&emsp;  <a href="multipleimg.php">Sub images</a>
			<a href="logout.php" style="margin-left: 1200px;">Logout</a>
		</div>
	</body>
</html>
<?php
if(isset($_POST['submit']))
{
	$category=$_POST['category'];
	$producttitle=$_POST['title'];
	$image=$_FILES['file']['name'];
	$img=$_FILES['file']['tmp_name'];
	$target_dir="images/";
	if(move_uploaded_file($img,$target_dir.$image))
	{
		echo "";
	}
		else
		 	{
				echo "not";
			}
				$price=$_POST['price'];
				$availablity=$_POST['availablity'];
				$description=$_POST['desc'];
				$con=mysql_connect("localhost","root","") or die(mysql_error());
				$db=mysql_select_db("core",$con) or die(mysql_error());
				$sql="insert into items values('','$category','$producttitle','$image','$price','$availablity','$description')";
				$query=mysql_query($sql,$con);
				if($query)
				{
					echo "<script>alert('successfully inserted')</script>";
				}
					else
						{
							echo "<script>alert('fail to insert')</script>";
						}
							mysql_close($con);
}
?>
<html>
	<head>
		<script src="//tinymce.cachefly.net/4.2/tinymce.min.js"></script>
<script>tinymce.init({selector:'textarea'});</script>
	</head>
	<body>
		<form method="post" name="myform" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
		<table border="0" cellspacing="5" cellpadding="10" align="center">
			<th style="font-size: 20px; color: green;">&nbsp; &nbsp; Insert new product</th>
			<tr>
					<td>Category</td><td><select name="category" id="category">
					<option></option>
					<option>Mobile phones</option>
					<option>Desktop</option>
					<option>Laptop</option>
					<option>Shoes</option>
					<option>Household items</option>
					<option>Kids</option>				
					</select>
				</td>
			</tr>
			<tr>
				<td>Product title</td><td><input type="text" name="title" id="producttitle"></td>
			</tr>
			<tr>
				<td>image</td><td><input type="file" name="file" id="image"></td>
			</tr>
			<tr>
				<td>price</td><td><input type="text" name="price" id="price"></td>
			</tr>
			<tr>
				<td>Availablity</td><td><input type="text" name="availablity" id="availablity"></td>
			</tr>
			<tr>
				<td>Description</td><td><textarea name="desc" cols="30" rows="10" id="description"></textarea></td>
			</tr>
			<tr>
				<td><input type="submit" name="submit" value="Submit">&nbsp; &nbsp;<input type="reset" name="reset" value="Reset"></td>
			</tr>
		</table>
	</body>
</html>

