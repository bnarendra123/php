
<html>
	<head>
	<style>
			.ahead{
				margin-left:20px;
				font-size:18px;
				color:blue;
			}
		</style>
	</head>
	<body>
	<div class="ahead">
			<a href="items.php">Product</a>&nbsp; &nbsp; <a href="slider.php">Slider image</a>
		</div><br><br>
		<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
			<table border="0" cellspacing="0" cellpadding="0" style="margin-left: 200px;">
				<tr>
					<td>Upload image : &emsp; </td><td><input type="file" name="file" id="image"></td>
				</tr>
				<tr>
				<td>&nbsp; &nbsp; </td>
				</tr>
				<tr>
					<td>Url : </td><td><input type"text" name="url"></td>
				</tr>
				<tr>
				<td>&nbsp; &nbsp; </td>
				</tr>
				<tr>
					<td><input type="submit" name="submit" value="Submit"></td>
				</tr>
			</table>
		</form>
		<?php 
		if(isset($_POST['submit'])){
			$url=$_POST['url'];
			$image=$_FILES['file']['name'];
			$img=$_FILES['file']['tmp_name'];
					
					$target_dir="slider/";
 if(move_uploaded_file($img, $target_dir.$image))
 {
  echo " ";
 }
 else {
  echo "not";
 }
		$con=mysql_connect("localhost","root","");
		$db=mysql_select_db("core",$con);
		$sql="insert into slider values('','$image','$url')";
		$query=mysql_query($sql,$con);
		if($query){
			echo "<script>alert('success')</script>";
		}else{
			echo "<script>alert('fail')</script>";
		}
		mysql_close($con);
		}
		
		?>
	</body>
</html>