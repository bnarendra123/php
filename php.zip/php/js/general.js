function reg(){
	var name=$('#name').val();
	var email=$('#email').val();
	var phone=$('#phone').val();
	var password=$('#password').val();
	var rpassword=$('#rpassword').val();
	var gender=$('input[type="radio"]:checked').val();
	var language=$('#language').val();
	var dob=$('#dob').val();
	var qualification=$('#qualification').val();
	var errorcount=0;
	if(name==""){
		$('#namer').html("please enter name");
		$('#namer').css("color","red");
		errorcount++;
	}else{
		$('#namer').html("");
	}
	if(email==""){
		$('#emailr').html("please enter email");
		$('#emailr').css("color","red");
	}else{
		$('#emailr').html("");
	}
	if (phone == "") {
		$('#phoner').html("Enter your Mobile number");
		$('#phoner').css("color", "red");
		errorcount++;
	} else {
		if (isNaN(phone)) {
			$("#phoner").html("Enter the valid Mobile Number");
			$("#phoner").css("color", "red");
			errorcount++;
		}
		if ((phone.length != 10)) {
			$("#phoner").html("Please enter 10 digit mobile no");
			$("#phoner").css("color", "red");
			errorcount++;
		} else {
			$("#phoner").html("");
		}
	}
	if(password==""){
		$('#passwordr').html("Please enter password");
		$('#passwordr').css("color","red");
		errorcount++;
	}else{
		$('#passwordr').html("");
	}
	if(rpassword==""){
		$('#passwordre').html("Please enter repeat password");
		$('#passwordre').css("color","red");
		errorcount++;
	}else{
		$('#passwordre').html("");
	}
	if($('#password').val() != $('#rpassword').val()) {
            alert("Password and Confirm Password don't match");
            // Prevent form submission
            event.preventDefault();
            return false;
        }
	if($('input[type="radio"]:checked').length=="0")
	{
		$('#genr').html("Please enter gender");
		$('#genr').css("color","red");
		errorcount++;
	}else{
		$('#genr').html("");
	}
	if(qualification==""){
		$('#qlt1').html("please enter qualification");
		$('#qlt1').css("color","red");
		errorcount++;
	}else{
		$('#qlt1').html("");
	}
	if(errorcount>0){
		return false;
	}
	else {
		var pass_data = {
			'name' : name,
			'email' : email,
			'password' : password,
			'rpassword' : rpassword,
			'phone' : phone,
			'gender' : gender,
			'language' : language,
			'dob' : dob,
			'qualification' : qualification,
		};
		$.ajax({
			url : "set/reg.php",
			type : "POST",
			data : pass_data,
			success : function(data) {
				alert(data);
				if (data.trim() == 'ok') {
					alert("successfully registered");
					//document.location ="index.php";
					//location.reload();
				}
				if (data.trim() == 'fail') {
					alert('Fail to send.');
					location.reload();
				}
			}
		});
	}
	return false;
}

function log(){
	var email=$('#email').val();
	var password=$('#password').val();
	var errorcount=0;
	if(email==""){
		$('#emaill').html("please enter email");
		$('#emaill').css("color","red");
		errorcount++;
	}else{
		$('#emaill').html("");
	}
	if(password==""){
		$('#pwdl').html("please enter password");
		$('#pwdl').css("color","red");
		errorcount++;
	}else{
		$('#pwdl').html("");
	}
	if(errorcount >0){
	return false;
	}else {
		var pass_data = {
			'email' : email,
			'password' : password,
		};
		$.ajax({
			url : "set/login.php",
			type : "POST",
			data : pass_data,
			success : function(data) {
				alert(data);
				if (data.trim() == 'ok') {
					document.location ="index.php";
					//location.reload();
				}
				if (data.trim() == 'fail') {
					alert('Fail to send.');
					location.reload();
				}
			}
		});
	}
	return false;
}

function updatepro(){
	var name=$('#name').val();
	var email=$('#email').val();
	var phone=$('#phone').val();
	var errorcount=0;
	if(name==""){
		$('#uname').html("Please enter name");
		$('#uname').css("color","red");
		errorcount++;
	}else{
		$('#uname').html("");
	}
	if(email==""){
		$('#uemail').html("Please enter email");
		$('#uemail').css("color","red");
		errorcount++;
	}else{
		$('#uemail').html("");
	}
	if (phone == "") {
		$('#uphone').html("Enter your Mobile number");
		$('#uphone').css("color", "red");
		errorcount++;
	} else {
		if (isNaN(phone)) {
			$("#uphone").html("Enter the valid Mobile Number");
			$("#uphone").css("color", "red");
			errorcount++;
		}
		if ((phone.length != 10)) {
			$("#uphone").html("Please enter 10 digit mobile no");
			$("#uphone").css("color", "red");
			errorcount++;
		} else {
			$("#uphone").html("");
		}
	}
	if(errorcount>0){
		return false;
	}
	else{
		var pass_data={
			'name' :  name,
			'email' : email,
			'phone' : phone,
		};
		
		$.ajax({
			url : "set/updatepro.php",
			type : "POST",
			data : pass_data,
			success: function(data){
				alert(data);
				//console.log(data);
				if (data.trim() == 'ok') {
					alert("profile updated successfully");
					//document.location ="index.php";
					location.reload();
				}
				if (data.trim() == 'fail') {
					alert('Fail to updated.');
					location.reload();
				}
			}
	});
	}
	return true;
	}

function submit(id, quantity) {
	var pass_data = {
		'id' : id,
		'quantity' : quantity,
	};
	$.ajax({
		url : 'set/updateqty.php',
		type : "POST",
		data : pass_data,
		success : function(data) {
			alert(data);
			if (data.trim() == 'success') {
				location.reload();
			}
			if (data.trim() == 'fail') {
				location.reload();
			}
		}
	});
	return true;
}

function con(){
	var name=$("#cname").val();
	var email=$("#cemail").val();
	var companyname=$("#ccompanyname").val();
	var subject=$("#subject").val();
	var errorcount=0;
	if(name==""){
		$("#cname").attr("placeholder","Enter name");
		$("#cname").css("border","2px solid red");
		errorcount++;
	}else{
		$("#cname").attr("placeholder","");
		$("#cname").css("border","none");
	}
	if(email==""){
		$("#cemail").attr("placeholder","Enter email");
		$("#cemail").css("border","2px solid red");
		errorcount++;
	}else{
		$("#cemail").attr("placeholder","");
		$("#cemail").css("border","none");
	}
	if(companyname==""){
		$("#ccompanyname").attr("placeholder","Enter companyname");
		$("#ccompanyname").css("border","2px solid red");
		errorcount++;
	}else{
		$("#ccompanyname").attr("placeholder","");
		$("#ccompanyname").css("border","none");
	}
	if(subject==""){
		$("#csubject").attr("placeholder","Enter subject");
		$("#csubject").css("border","2px solid red");
		errorcount++;
	}else{
		$("#csubject").attr("placeholder","");
		$("#csubject").css("border","none");
	}
	if(errorcount>0){
		return false;
	}else{
	var pass_data={
		'cname' : cname,
		'cemail' : cemail,
		'ccompanyname' : ccompanyname,
		'csubject' : csubject,
	};
	alert(pass_data);
	$.ajax({
			url : "set/contact.php",
			type : "POST",
			data : pass_data,
			success: function(data){
				alert(data);
				console.log(data);
				if (data.trim() == 'ok') {
					alert("success");
					//document.location ="index.php";
					location.reload();
				}
				if (data.trim() == 'fail') {
					alert('Fail to post.');
					location.reload();
				}
			}
	});
	}
	return true;
	}

function change() {
	var password = $('#password').val();
	var newpassword = $('#newpassword').val();
	var confirmpassword = $('#confirmpassword').val();
	var errorcount = 0;
	if (password == "") {
		$('#password').attr("placeholder", "Enter your old password");
		$('#password').css("border", "solid 2px red");
		errorcount++;
	} else {
		$('#password').attr("placeholder", "hai");
		$('#password').css("border", "none");
	}
	if (newpassword == "") {
		$('#newpassword').attr("placeholder", "Enter your new password");
		$('#newpassword').css("border", "solid 2px red");
		errorcount++;
	} else {
		$('#newpassword').attr("placeholder", "hai");
		$('#newpassword').css("border", "none");
	}
	if (confirmpassword == "") {
		$('#confirmpassword').attr("placeholder", "Enter your confirm password");
		$('#confirmpassword').css("border", "solid 2px red");
		errorcount++;
	} else {
		$('#confirmpassword').attr("placeholder", "hai");
		$('#confirmpassword').css("border", "none");
	}
	if (errorcount > 0)
		return false;
	else {
		var pass_data = {
			'password' : password,
			'newpassword' : newpassword,
			'confirmpassword' : confirmpassword,
		};
		$.ajax({
			url : "set/changepass.php",
			type : "POST",
			data : pass_data,
			success : function(data) {
				alert(data);
				if (data.trim() == 'ok') {
					
					location.reload();
				}
				if (data.trim() == 'fail') {
					
					location.reload();
				}
			}
		});
	}
	return true;
}