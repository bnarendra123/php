<?php
include "includes/header.php";
include "includes/left.php";
include "includes/config.php";
$id=$_REQUEST['id'];

/*$sqlQuery = "SELECT * from items";

    if($category == "Mobile phones") {
       $sqlQuery = "SELECT * from items
                    WHERE category='Mobile phones'";
    } elseif ($category == "Desktop") {
        $sqlQuery = "SELECT * from items
                    WHERE category='Desktop'";
    } elseif ($category == "Laptop") { 
            $sqlQuery = "SELECT * from items
                    WHERE category='Laptop'";
    } elseif ($category == "Shoes") {                 
       $sqlQuery = "SELECT * from items  WHERE category='Shoes'";
    }
	?>*/
	
	$sql="select * from items where pid='$id'";
	
$result=mysql_query($sql,$con);
while($row=mysql_fetch_array($result))
{
	$id=$row['id'];
	$pid=$row['pid'];
		$producttitle=$row['producttitle'];
	$image=$row['image'];
	$price=$row['price'];
	$qty = 1;
	$availablity = $row['availablity'];
	$description=$row['description'];
	
?>
			<div class="grid_1_of_4 images_1_of_4">
				<a href="preview.php?id=<?php echo $row['id']; ?>"><img src="admin/images/<?php echo $image; ?>" width="150px" height="150px" alt="" /></a>
				<h2><?php echo $row['producttitle']; ?></h2>
				<div class="price-details">
				      <div class="price-number">
							<p><span class="rupees"><?php echo $row['price']; ?></span></p>
					    </div>
					       	  <div class="add-cart">								
									<h4><a href="preview.php">Add to Cart</a></h4>
							  </div>
				</div>
			</div>
<?php } ?>
