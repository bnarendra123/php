<?php
include "includes/config.php";
$sql="select * from categories where status='0' ";
$result=mysql_query($sql,$con);
?>
		
			<div class="header_bottom_left">				
				<div class="categories">
					<h3>Categories</h3>
					<?php
					while($row=mysql_fetch_array($result)){ ?>
					<ul>
				  	<li><a id="displayText" href="javascript:toggle();"><?php echo $row['category']; ?></a></li>
				  </ul>
				  	<?php
$sql1="select c.* from subcategories c join categories t where t.id=c.status";
$query=mysql_query($sql1,$con);
?>
				<div id="toggleText" style="display:none">
					<?php
					while($row1=mysql_fetch_array($query)){
						if($row1['status']==$row['id']){
							?>
							<li><?php echo $row1['name']; ?></li>
						
						<?php } }?>
					</div>
				
				  <?php } ?>
				</div>				
	  	     </div>
	  	      
	 <script type="text/javascript">

function toggle(){
	var ele=document.getElementById("toggleText");
	var text=document.getElementById("displayText");
	if(ele.style.display=="block"){
		ele.style.display="none";
		
	}

	else{
		ele.style.display="block";
		
	}
}

</script>

				