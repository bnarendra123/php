
<?php
session_start();
include "set/lang.php";
?>
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<head>
<title>Free Home Shoppe Website Template | Home :: w3layouts</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/slider.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="js/move-top.js"></script>
<script type="text/javascript" src="js/easing.js"></script>
<script type="text/javascript" src="js/startstop-slider.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="js/general.js"></script>

</head>
<body>
  <div class="wrap">
	<div class="header">
		<div class="headertop_desc">
			<div class="call">
				 <p><span>Need help?</span> call us <span class="number">040-223-45678</span></span></p>
			</div>
			<form method="post" action="">
			<a href="?lang=en"><img src="images/us.png"/></a>
			<a href="?lang=sp"><img src="images/spain.png"/></a>
			</select>
			</form>
			
			<?php
				if(isset($_SESSION['id']) > 0){
					?>
					<div class="account_desc">
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="profile.php">Profile</a></li>
					<li><a href="orders.php">Orders</li>
					<li><a href="cart.php">Cart</a></li>
					<li><a href="wishlist.php">Wishlist</a></li>
					<li><a href="set/logout.php">logout</a></li>
				</ul>
			</div>
			<?php }else{
			?>
			<div class="account_desc">
				<ul>
					<li><a href="register.php"><?php echo CONTENT_REGISTER; ?></a></li>
					<li><a href="#" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="background-color: white; border: white;">Login</a></li>
					<li><a href="login.php">My Account</a></li>
				</ul>
			</div>
				<?php } ?>
			<div class="clear"></div>
		</div>
					<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

  <!-- Trigger the modal with a button -->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login</h4>
        </div>
        <div class="modal-body">
          <p>
<div class="regtab">
	<body>
		<form method="post" action="">
		<table border="0" cellspacing="10" cellpadding="10" align="center">
			<tr>
				<td>Email : </td><td><input type="text" name="email" id="email"></td><td><span id="emaill"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td>Password : </td><td><input type="password" name="password" id="password"></td><td><span id="pwdl"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td><input type="submit" name="submit" value="Login"  style="margin-left: 10px;" onclick="return log()">&nbsp; &nbsp; <input type="reset" name="reset" value="Reset" style="margin-left:10px; font-size:15px;"></td>
			</tr>
		</table>
	</div>
	</body>
</html>
</form>

</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

</body>
</html>

		<div class="header_top">
			<div class="logo">
				<a href="index.php"><img src="images/logo.png" alt="" /></a>
			</div>
			  <div class="cart">
			  	   <p>Welcome to our Online Store! <!--<span>Cart:</span><div id="dd" class="wrapper-dropdown-2"> 0 item(s) - $0.00
			  	   	<ul class="dropdown">
							<li>you have no items in your Shopping cart</li>-->
					</ul></div></p>
			  </div>
			  <script type="text/javascript">
			function DropDown(el) {
				this.dd = el;
				this.initEvents();
			}
			DropDown.prototype = {
				initEvents : function() {
					var obj = this;

					obj.dd.on('click', function(event){
						$(this).toggleClass('active');
						event.stopPropagation();
					});	
				}
			}

			$(function() {

				var dd = new DropDown( $('#dd'));

				$(document).click(function() {
					// all dropdowns
					$('.wrapper-dropdown-2').removeClass('active');
				});

			});

		</script>
	 <div class="clear"></div>
  </div>
	<div class="header_bottom">
	     	<div class="menu">
	     		<ul>
			    	<li class="active"><a href="index.php">Home</a></li>
			    	<li><a href="about.php">About</a></li>
			    	<li><a href="delivery.php">Delivery</a></li>
			    	<li><a href="news.php">News</a></li>
			    	<li><a href="contact.php">Contact</a></li>
			    	<div class="clear"></div>
     			</ul>
	     	</div>
	     	<div class="search_box">
	     		<form method="post" action="search.php">
	     			<input type="text" name="name" value="Search" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search';}"><input type="submit" name="submit" value=""></a>
	     			
	     		</form>
	     	</div>
	     	<div class="clear"></div>
	     </div>
	     
<script type="text/javascript">
	function mul(id){
		var val=id.value;
		var pass_data = {
			'lang' : val,
			
		};
		$.ajax({
			url : "set/lang.php",
			type : "POST",
			data : pass_data,
			success : function(data) {
				alert(data);
				if (data.trim() == 'ok') {
					
					location.reload();
				}
				if (data.trim() == 'fail') {
					
					location.reload();
				}
			}
		});
		return true;
	}
</script>


