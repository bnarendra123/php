<?php
define('CONTENT_REGISTER','Registro');
?>