<?php
alert("dsfds");
echo "sfds";
 ?>
