<?php
session_start();
$id=$_SESSION['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];

$con=mysql_connect("localhost","root","") or die(mysql_error());
$db=mysql_select_db("core",$con) or die(mysql_error());
$sql="update reg set name='$name', email='$email', phone='$phone' where id='$id' ";
$result=mysql_query($sql,$con);
if($result){
	die('profile updated successfully');
}else{
	die('fail');
}
mysql_close($con);
?>
