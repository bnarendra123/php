<?php
session_start();
echo $id=$_GET['id'];
echo $sid=$_SESSION['id']; 
$con=mysql_connect("localhost","root","") or die(mysql_error());
$db=mysql_select_db("core",$con);
$sql="delete from cart where id='$id' and user='$sid'";
$query=mysql_query($sql,$con);
if($query){
	echo "<script>alert('successfully deleted')</script>";
	header("location: ../index.php");
}
else{
	echo "<script>alert('fail to delete')</script>";
}
