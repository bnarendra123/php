<?php
    $id=$_POST['id'];
    $name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	$rpassword=$_POST['rpassword'];
	$phone=$_POST['phone'];
	$gender=$_POST['gender'];
	$language=$_POST['language'];
	$dob = $_POST["date"] . "-" . $_POST["month"] . "-" . $_POST["year"];
	$qualification = $_POST['qualification'];
	include "../includes/config.php";
	$sql="insert into reg values('','$name','$email','$password','$rpassword','$phone','$gender','$language','$dob','$qualification')";
	$query=mysql_query($sql,$con);
	if($query){
		//echo "<script>alert('successfully registered')</script>";
		die('ok');
	}else{
		//echo "<script>alert('insert failed')</script>";
		die('fail');
	}
	mysql_close($con);
?>