<?php
session_start();
session_destroy();
include "../includes/config.php";
header("location: ../index.php");
?>

