<?php
alert("sdfds");
$id=$_POST['id'];
$qty=$_POST['qty'];
include "includes/config.php";
$sql = "UPDATE `cart` SET  `quantity` ='$qty' WHERE id='$qty' ";
	/*$sql="update cart set quantity=:quantity where idUser =:idUser and id=:id";*/
	$result = mysql_query($sql, $con);
if ($result) {
	die('success');
} else {
	die('provided quantity is not there');
	location.reload();
}
