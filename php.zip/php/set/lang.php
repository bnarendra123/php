<?php
function setLanguage()
{
	if(isset($_GET['lang']))
	{
	 	$_SESSION['language'] = $_GET['lang'];  
	}	
	if(isset($_SESSION['language']))
	{
		$language = $_SESSION['language'];
	
		if($language=='sp')
		{
			include "languages/sp.php";
		}
		else
		{
			$_SESSION['language']='en';
			
			$language = $_SESSION['language'];
			
			if($language=='en')
			{
				include "languages/en.php";
			}			
		}
	}
	else
	{
		$_SESSION['language']='en';
			
		$language = $_SESSION['language'];
			
		if($language=='en')
		{
			include "languages/en.php";
		}
	}

}
setLanguage();
?>
