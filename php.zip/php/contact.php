<?php
include "includes/header.php";
?>

</div>
 <div class="main">
    <div class="content">
    	<div class="section group">
				<div class="col span_2_of_3">
				  <div class="contact-form">
				  	<h2>Contact Us</h2>
					    <form method="post" action="">
					    	<div>
						    	Name: <input type="text" name="cname" id="cname">
						    </div>
						    <div>
						    	<span><label>E-mail</label></span>
						    	<span><input name="cemail" type="text" class="textbox" id="cemail"></span>
						    </div>
						    <div>
						     	<span><label>Company Name</label></span>
						    	<span><input name="ccompanyname" type="text" class="textbox" id="ccompanyname"></span>
						    </div>
						    <div>
						    	<span><label>Subject</label></span>
						    	<span><textarea name="csubject" id="csubject"> </textarea></span>
						    </div>
						   <div>
						   		<span><input type="submit" value="Submit" name="submit" onclick="return con();"></span>
						  </div>
					    </form>
				  </div>
  				</div>
				<div class="col span_1_of_3">
					<div class="contact_info">
    	 				<h3>Find Us Here</h3>
					    	  <div class="map">
							   	    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3805.3437350519416!2d78.39598441440288!3d17.491097404410613!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb91a4b39f8e17%3A0xc385ed01b72c7169!2sConfianza+TechnoSoft+Solutions!5e0!3m2!1sen!2sin!4v1455963551615" width="600" height="175" frameborder="0" style="border:0" allowfullscreen></iframe>
							  </div>
      				</div>
      			<div class="company_address">
				     	<h3>Company Information :</h3>
						    	<p>Flat No 102, GP Rao Enclave, Road No 3, Kphb Colony</p>
						    	<p>K P H B Phase 1, Kukatpally</p>
						   		<p>Hyderabad</p>
				   		<p>Phone:(040 222 666 444)</p>
				 	 	<p>Email: <span>info@confianza.co.in</span></p>
				   		<p>Follow on: <span>Facebook</span>, <span>Twitter</span></p>
				   </div>
				 </div>
			  </div>		
         </div> 
    </div>
 </div>
   <?php
   include "includes/footer.php";
   ?>
   </body>
</html>

