<table border="0" cellspacing="5" cellpadding="5" width="800px" style="margin-left:200px;">
	<th>Image</th><th>Producttitle</th><th>Price</th><th>Quantity</th><th>Amount</th><th>Description</th>
<?php
include "includes/header.php";
echo "<br><br>";
$sid=$_SESSION['id'];
include "includes/config.php";
$sql="select * from orders where user='$sid'";
$result=mysql_query($sql,$con);
			?>
<?php while($row=mysql_fetch_array($result)){ ?>
	<tr>
		<td>&nbsp; </td>
	</tr>	
	<tr>
			<td>&emsp; &emsp; &emsp; <img src="admin/images/<?php echo $row['image']; ?>" width="100px" height="100px"/></td>
			<td>&emsp; <?php echo $row['producttitle']; ?></td>
			<td>&emsp; <?php echo $row['price']; ?></td>
			<td>&emsp; <?php echo $row['quantity'] ?></td>
			<td>&emsp; <?php echo $amount=$row['quantity'] *$row['price'] ?></td>
			<td><?php echo $row['description']; ?></td>
		</tr>
<?php } ?>