<?php
include "includes/header.php";
include "includes/left.php";
?>
<div class="regtab">
	<body>
		<form method="post" action="">
		<table border="0" cellspacing="10" cellpadding="10" style="margin-left: 100px;" align="center">
			
			<tr><td>&nbsp; </td></tr>
			<tr>
				<td>Name:</td><td><input type="text" name="name" style="width:230px;" id="name"></td><td><span id="namer"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td>Email:</td><td><input type="text" name="email" style="width:230px;" id="email"></td><td><span id="emailr"></span></td>
			</tr>
			<tr><td>&nbsp; </td></tr>
			<tr>
				<td>Password:</td><td><input type="password" name="password" style="width:230px" id="password"></td><td><span id="passwordr"></span></td>
			</tr>
			
			<tr><td>&nbsp; &nbsp; </td></tr>
			<tr>
				<td>Repeat password:</td><td><input type="password" name="rpassword" style="width:230px" id="rpassword"></td><td><span id="passwordre"></span></td>
			</tr>
			
			<tr>
				<td>&nbsp; &nbsp;</td>
			</tr>
			<tr>
			<td>Mobile number:</td><td><input type="text" name="phone" id="phone" style="width:230px;"></td><td><span id="phoner"></span></td>
			</tr>
			<tr>
				<td>&nbsp; &nbsp; </td>
			</tr>
			<tr>
				<td>Gender:</td><td><input type="radio" name="sex" id="gen" value="male" checked>Male<input type="radio" name="sex" value="female" id="gen">Female</td><td><span id="genr"></span></td>
			</tr>
			<tr>
				<td>&nbsp; &nbsp; </td>
			</tr>
			<tr><td>Languages known:</td><td><input type="checkbox" name="language" id="language" value="Telugu">Telugu<input type="checkbox" name="language" id="language" value="English">English<input type="checkbox" name="language" id="language" value="Hindi">Hindi</td><td><span id="langr"></span></td></tr>
			<tr>
				<td>&nbsp; &nbsp; </td>
			</tr>
			<tr>
				<td>D.o.b</td><td>
			
				<?php
			
	// month array 
			
	$month = array( 1 => 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August','September','October','November','December');
							
		echo  '<select name="month">';	

		foreach ( $month as $k => $v ) {

			echo '<option name="'. $v . '"  value="' . $k . '">' . $v . '</option><br />';
		}
		
		echo '</select>&nbsp;<select name="date">';
			
		for ( $i = 1; $i <= 31; $i++) {
					
                     echo '<option name="'. $i . '"  value="' . $i . '">' . $i . '</option><br />';

		}
			
	
		echo '</select>&nbsp;<select name="year">';
			
		for ( $i = 1950; $i <= 2050; $i++) {
			echo '<option name="'. $i . '"  value="' . $i . '">' . $i . '</option><br />';

		}
			
		echo '</select>';
				
?>		</td>
			</tr>
			<tr>
				<td>&nbsp; &nbsp; </td>
			</tr>
			<tr>
				<td>Qualification:</td><td><select name="qualification" id="qualification">
				    <option value=""></option>
					<option value="10th class">10th class</option>
					<option value="B.tech">B.tech</option>
					<option value="M.tech">M.tech</option>
				</select></td><td><span id="qlt1"></span></td>
			</tr>
			<tr><td>&nbsp; &nbsp; </td></tr>
			
			<tr>
				<td><input type="submit" name="submit" value="Submit" style="margin-left:100px; font-size:15px;" onclick="return reg();">&nbsp; &nbsp; <input type="reset" name="reset" value="Reset" style="margin-left:10px; font-size:15px;"></td>
			</tr>
		</table>
	</div>
	</body>
</html>
</form>
<?php
include "includes/footer.php";
?>

