<?php
define('CONTENT_REGISTER','Register');
define('Add_To_WISHLIST','Add to Wishlist');
