<?php
define('CONTENT_REGISTER','Registro');
define('Add_To_WISHLIST','Añadir a la lista de deseos');
?>