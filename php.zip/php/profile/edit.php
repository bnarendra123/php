<?php
include "includes/header.php";
include "includes/left.php";
?>
<?php 
$id=$_GET['id'];
$con=mysql_connect("localhost","root","") or die(mysql_error());
$db=mysql_select_db("core",$con) or die(mysql_error());
$sql="select * from reg where id='$id' ";
$result=mysql_query($sql,$con);
?>
<table border="1" align="center">
	<?php
	while($row=mysql_fetch_array($result)){
		?>
		<tr>
			<td>Name : </td><td><input type="text" name="name" value="<?php echo $row['name']; ?>"</td></tr>
			<td>Email : </td><td><input type="text" name="email" value="<?php echo $row['email']; ?>"</td></tr>
			<td>Mobile number : </td><td><input type="text" name="phone" value="<?php echo $row['phone']; ?>"</td></tr>
				
</table>
<?php
	}
	?>