<?php
include "includes/header.php";
?>
<form method="post" action="">
<table border="0" cellspacing="5" cellpadding="10" align="center">
<p align="center" style="margin-top: 100px;">
Old Password &emsp; : &nbsp; <input type="password" name="password" id="password"><br><br>
New Password &emsp; : &nbsp; <input type="password" name="newpassword" id="newpassword"><br><br>
Confirm Password : &nbsp; <input type="password" name="confirmpassword" id="confirmpassword"><br><br>

<input type="submit" name="submit" value="Update Password" onclick="return change();"> &emsp; &emsp; <input type="reset" name="reset" value="Reset"></p>
</table>
</form>

<?php
include "includes/footer.php";
?>