<html>
	<head>
		<body>
			<p> This our country!!</p>
			<p>
				This is very harmfull!
			</p>
			<button id="hide">hide</button>
			<button id="show">show</button>
		</body>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script>
			$(document).ready(function(){
				$("#hide").click(function(){
					$("p").hide();
				});
					$("#show").click(function(){
						$("p").show();
					
				});
			});
		</script>
	</head>
</html>