<?php
	session_start();
	if(isset($_SESSION['userid'])){
	$servername = "127.0.0.1";
		$username = "root";
		$password = "";
		$dbname = "login22";
	
		$conn = mysqli_connect($servername, $username, $password, $dbname);
	
		if (!$conn)
		{
			die("Connection failed: " . mysqli_connect_error());
		}else{
			//echo "fghjgjgjk";
		}
		
		$sql = "SELECT Email FROM bhavya WHERE id='".$_SESSION['userid']."'";
		$result = mysqli_query($conn,$sql);
		$details = mysqli_fetch_assoc($result);
		if(isset($_POST["submit"])) {
			//die('gchghg');
		extract($_POST);
			print_r($_POST);
	
		$sql ="UPDATE  bhavya SET Email='".$newemail."' WHERE id='".$_SESSION['userid']."'";
		//$id=$_SESSION['userid'];
		//$result=mysqli_query($sql);
	//while($rows=mysql_fetch_array($result)){
		   if (mysqli_query($conn, $sql))
		{
				
			header("Location: welcome.php");
			
		}
		else
		{
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	
		mysqli_close($conn);
	}

	?>
	<html>
		<head>
			<body>
				<table>
				
				<form onsubmit="return submitt();" method="post">	
					<tr>
					<td>Email</td>
					<td><input type="text" name="email" value="<?php echo $details['Email'] ?>" /></td>
				</tr>
				<tr>
					<td>Newemail</td>
					<td><input type="text" name="newemail" value="" /></td>
					<td><span class="error" err="newemail" > </span></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="password" value="" /></td>
					<td><span class="error" err="password" > </span></td>
				</tr>
					<tr>
					
					<td><input type="submit"  name="submit" value="submit" /></td>
				</form>
				</tr>
				
				</table>
				<script type="text/javascript">
			        function submitt() {
				       alert('hai');
				var email = document.getElementById('newemail').value;
				var password = document.getElementById('password').value;
				
		        if (a == 0 || a == "") {

					alert("please enter the newemail");
					return false;
				}

				if (b == 0 || b == "") {
					alert("please enter the password");
					return false;
				}
				return true;
			}
				</script>
			</body>
		</head>
	</html>
	<?php }?>