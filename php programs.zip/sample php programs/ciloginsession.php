<form method="post" action="">
	Email : <input type="text" name="name"><br>
	password : <input type="text" name="password"><br>
	<input type="submit" name="submit" value="Submit" onclick="return logincheck();">&emsp; <input type="reset" name="reset" value="Reset">
</form>
<script type="text/javascript">
	function logincheck() {
	var emailid = $('#email').val();
	var pwd = $('#password').val();
	var emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var errorcount = 0;
	if (emailid == "") {
		$('#email').attr("placeholder", "Please enter Email-ID");
		$('#email').css("border", " solid 2px red");
		errorcount++;
	} else {
		if (!emailRegex.test(emailid)) {
			$('#email').attr("placeholder", "Please enter valid email id");
			$('#email').css("border", " solid 2px red");
			errorcount++;
		} else {
			$('#email').attr("placeholder", "");
			$('#email').css("border", "");
		}
	}
	if (pwd == "") {
		$('#password').attr("placeholder", "Please enter Password");
		$('#password').css("border", " solid 2px red");
		errorcount++;
	} else {
		$('#password').attr("placeholder", "");
		$('#password').css("border", "");
	}
	if (errorcount > 0) {
		return false;
	} else {
		var pass_data = {

			'em' : emailid,
			'pw' : pwd,
		};
		//alert(pass_data);
		$.ajax({
			type : "post",
			url : baseUrl + "/index.php/Welcome/login_val",
			data : pass_data,
			success : function(data) {
				//alert(data);
				//console.log(data);
				if (data.trim() == 'ok') {
					alert("user login successfully ");
					document.location = baseUrl + 'index.php/fashion/homepage';
					//document.location = "<?php echo base_url();?>index.php/fashion/homepage";
				} else {
					alert("not a valid user");
					location.reload();
				}
			}
		});
		return false;
	}
}
</script>

-------------------   controller ------------------------------------
In controller top add session_start(); function. 
<?php
function login_val() {

		$email = $this -> input -> post('em');
		$password = $this -> input -> post('pw');
		$this -> load -> model('fmodel');
		$this -> fmodel -> login_details($email, $password);
	}
?>

----------------   Mymodel ----------------------------------------
<?php
function login_details($email, $password) {
		$this -> db -> where('email', $email);
		$this -> db -> where('password', $password);
			
		$query = $this -> db -> get('register');
		if ($query -> num_rows() > 0) {
			foreach ($query->result() as $key) {
				$newdata = array('user_id' => $key -> id, 'name' => $key -> name, 'email' => $key -> email, 'password' => $key -> password, 'logged_in' => TRUE, );
			}
			$query=$this -> session -> set_userdata($newdata);
			//print_r($query);
			die('ok');
		}
		die('fail');
	}
?>

----------------  After login change the header titles ----------------------

<?php $uid = $this->session->userdata('user_id');
							if($uid>0) { ?>
								<a href="<?=site_url('fashion/edit_p') ?>"  >Edit Profile</a>
								<?php } else{ ?>
									<a href="<?=site_url('fashion/login') ?>"  >Login</a>
									<?php } ?>
