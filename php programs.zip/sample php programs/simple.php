<a href="#"><img src="admin/images/<?php echo $row['image']; ?>" width="300px" height="280px" onmouseover="bigImg(this)" onmouseout="normalImg(this)"/></a>


<script type="text/javascript">
	function bigImg(x){
			 x.style.height = "300px";
    		x.style.width = "1200px";
		}
		function normalImg(x) {
			
    x.style.height = "300px";
    x.style.width = "300px";
}
</script>


-----------------  rightclick disable --------------------------------------

 <script type="text/javascript">
   	function iPlan(){
   		alert("You can not select the text");
   		return(false);
   	}
   	document.oncontextmenu = iPlan;
   		   </script>
   		   
------------------  print a page ---------------------------------------------
<html>
	<head>
		<script type="text/javascript">
		</script>
	</head>
	<form>
		<input type="button" value="print" onclick="window.print()">
	</form>
</html>

--------------------  datepicker jquery -----------------------------------------

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  </script>
</head>
<body>
 
<p>Date: <input type="text" id="datepicker"></p>
 
 
</body>
</html>

------------------  datetime --------------------------------------
<?php

echo date("d/m/y");
?>

------------------   fb login ---------------------------------
Login with fb : 

https://www.youtube.com/watch?v=E8tHz5CdMrY

https://www.youtube.com/watch?v=tRWlWuOWe8I&ebc=ANyPxKoXz-PEqbzOOV_zmd9PrdqyqplQ1JkwP2uKKfN6VYAGDjx9RrFQSF6y1wEZjhHvgQ4CFvEfnt4LdLfObgcpOHMAJrfmSg

-----------------  magento soap error -------------------------------------

http://stackoverflow.com/questions/14732009/magento-uncaught-soapfault-exception-0-unable-to-load-soap-extension-on-the-s

---------------- Current time ---------------------------------------

<?php  
ini_set('date.timezone','America/New_York');   
echo '<p>'.date("g:i A").'</p>';  
?>  
------------------   Age caluclate -----------------------------------------

<?php  
$bday = new DateTime('22.3.1992'); // Your date of birth  
$today = new Datetime(date('d.m.Y'));  
$diff = $today->diff($bday);  
printf(' Your age : %d years, %d month, %d days', $diff->y, $diff->m, $diff->d);  
?>  

--------------------  Marquee tag ---------------------------------------------

<marquee direction="left" style="margin-top:200px;">This text will scroll from left to right</marquee>


