------------------  frontend --------------

<ul>
					<li><a href="?lan=en" title="English"><img src="images/us.png" alt=""/></a>&emsp; 
					<a href="?lan=sp" title="Spanish"><img src="images/spain.png" alt=""/></a> &emsp; &emsp;
					</li>
					</ul>
                                </a>
                            
------------------------------  multilang.phtml --------------------------------

<?php
function setLanguage()
{
	if(isset($_GET['lan']))
	{
		$_SESSION['language'] = $_GET['lan'];  
	}	
	if(isset($_SESSION['language']))
	{
		$language = $_SESSION['language'];
	
		if($language=='sp')
		{
			require_once('languages/sp.php');
		}
		else
		{
			$_SESSION['language']='en';
			
			$language = $_SESSION['language'];
			
			if($language=='en')
			{
				require_once('languages/en.php');
			}			
		}
	}
	else
	{
		$_SESSION['language']='en';
			
		$language = $_SESSION['language'];
			
		if($language=='en')
		{
			require_once('languages/en.php');
		}
	}

}
setLanguage();
?>

-----------------------------    en.php -------------------------

<?php
define('CONTENT_TITLE','My');
?>
------------------------------  sp.php ----------------------------

<?php
define('CONTENT_TITLE','hsc');
?>