<li><a href="#" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="background-color: white; border: white;">Login</a></li>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

  <!-- Trigger the modal with a button -->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Login</h4>
        </div>
        <div class="modal-body">
          <p>
<div class="regtab">
	<body>
		<form method="post" action="">
		<table border="0" cellspacing="10" cellpadding="10" align="center">
			<tr>
				<td>Email : </td><td><input type="text" name="email" id="email"></td><td><span id="emaill"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td>Password : </td><td><input type="password" name="password" id="password"></td><td><span id="pwdl"></span></td>
			</tr>
			<tr><td>&nbsp;</td></tr>
			<tr>
				<td><input type="submit" name="submit" value="Login"  style="margin-left: 10px;" onclick="return log()">&nbsp; &nbsp; <input type="reset" name="reset" value="Reset" style="margin-left:10px; font-size:15px;"></td>
			</tr>
		</table>
	</div>
	</body>
</html>
</form>

</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  
</div>

</body>
</html>