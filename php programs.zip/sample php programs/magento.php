1) Magento : Magento is a feature rich ecommerce platform built an opensource technology. Magento uses php as a web server scripting language
			and mysql.Latest version of magento is 1.7 and "varien began" develop the magento in jan 2007.

2) Mage::getmodel() and Mage::getsingleton() : Mage::getmodel() creates new object and Mage::getsingleton() always looks existing object.

3)Eav(Entity attribute value): It allows you to add a unlimited columns to your table virtually. It is also called object attribute value model.

4)If login is not working the we add <?php echo  $this->getBlockHtml('formkey'); ?> below the form method

5) Cart is not update add <input type="hidden" value="<?php echo Mage :: getSingleton('core/session')->getFormKey(); ?>" name="form_key"/>

6)SSH login : Open putty.exe
				Host name : bjcproducts.biz
				Login as : root
				pwd      : 
				go to  : cd /
				go to : cd /home/zulushop/public_html
						cd shell
						php -f indexer.php reindex all
						
7) Add cart in top link : <a href="<?php echo Mage:: helper('checkout/url')->getCheckoutUrl(); ?>">Cart</a>

8) Check if user logged in or not : <?php if($this->helper('customer')->isLoggedIn()); ?>

9) How to display products left in magento : <?php echo Mage::getModel('cataloginventory/stock_item')->loadByProduct()->getQty(); ?>

10)Change config url in magento : in phpmyadmin->core_config_data->change secure and unsecure base url.

11)Modules in magento : 1) core modules  2) community modules   3) commercial modules
						Core and community modules are installed via administration.
12) Features in magneto : 1) magento has built in web services
						  2) Magento has search engine optimization from the start	
						  3)Basic features are payment,shipping,checkout,tools and order management are in built.
						  4) Magneto supports over 60 languages and multiple currencies& tax rates.

13) To get the product price : <?php echo $_product->getprice(); ?>

14)Get date& time in magento : <?php echo Mage::getModel('core/date')->date('y-m-d H:i:s'); ?>

15) Index management : Magento indexes most of ites data in order to access it faster. When you make changes in your store you need to 
						reindex the data so that changes are shown in frontend.
						product attributes,product prices,catalog url rewrites, product flat data, category flat data, stock status
