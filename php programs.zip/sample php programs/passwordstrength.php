<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <title>How to create Password Strength checker in jQuery | PGPGang.com</title>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <script type="text/javascript" src="jquery-1.8.0.min.js"></script>
    <script type="text/javascript" src="jquery.pwdMeter.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
 
                $("#password").pwdMeter();
 
            });
    </script>
    <style>
        .veryweak{
            color:#B40404;
        }
        .weak{
            color:#DF7401;
        }
        .medium{
            color:#FFFF00;
        }
        .strong{
            color:#9AFE2E;
        }
        .verystrong{
            color:#0B610B;
        }
    </style>
  </head>
  <body>
    <h2>How to create Password Strength checker in jQuery example.&nbsp;&nbsp;&nbsp; <a href="http://www.phpgang.com/">Home</a> | <a href="http://demo.phpgang.com/">More Demos</a></h2>
    <div style="margin-left:auto;margin-right:auto; width:260px;"><input type="password" id="password" />&nbsp;
    <span id="pwdMeter" class="neutral"></span></div><br />
  </body>
</html>