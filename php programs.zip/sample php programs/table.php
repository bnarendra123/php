<div class="col-md-6 col-sm-6 col-xs-12" style="width: 100%;">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2><?php echo LAST_5_ORDERS; ?></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
									
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th><?php echo NAME; ?></th>
                                                <th><?php echo PRODUCTS; ?></th>
                                                <th><?php echo AMOUNT; ?></th>
                                                <th><?php echo DATE; ?></th>
                                                <th><?php echo STATUS; ?></th>
                                                <th><?php echo PAYMENT; ?></th>
                                            </tr>
                                        </thead>
                                        <?php $order= getTopFiveorders();
                            	foreach($order as $o){
									?>
                                        <tbody>
                                            <tr>
                                                <td><?php echo $o->firstname; ?></td>
                                                <td><?php echo $o->product_count; ?></td>
                                                <td><?php echo round($o->total_paid,2); ?> &euro;</td>
                                                <td><?php echo $o->date_add; ?></td>
                                                <td><?php echo $o->name; ?></td>
                                                <td><?php echo $o->payment; ?></td>
                                            </tr>
                                          
                                        </tbody>
                                        <?php
								}
                            	?>
                                    </table>
								 
                                </div>
                            </div>
                        </div>