<?php
session_start();
?>
<!DOCTYPE HTML> 
<html>
<head>
<style>
.error {color: #FF0000;}
.center{
	margin-left:500px;
}
</style>
</head>
<body> 

<?php
// define variables and set to empty values
$nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   if (empty($_POST["name"])) {
     $nameErr = "Name is required";
   } else {
     $name = test_input($_POST["name"]);
     // check if name only contains letters and whitespace
     if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
       $nameErr = "Only letters and white space allowed"; 
     }
   }
   
   if (empty($_POST["email"])) {
     $emailErr = "Email is required";
   } else {
     $email = test_input($_POST["email"]);
     // check if e-mail address is well-formed
     if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
       $emailErr = "Invalid email format"; 
     }
   }
 
   
   if(empty($_POST["comment"])) {
     $commentErr = "comment is required";
   } else {
     $commentErr = test_input($_POST["comment"]);
   }

   if (empty($_POST["gender"])) {
     $genderErr = "Gender is required";
   } else {
     $gender = test_input($_POST["gender"]);
   }
 if (empty($_POST["language"])) {
     $tErr = "Language is required";
   } else {
     $t = test_input($_POST["t"]);
   }
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
<div class="center">
<h2 style="color: green;">PHP Form Validation</h2>
<form method="post" action="<?php echo $_SERVER["PHP_SELF"];?> " enctype="multipart/form-data"> 
   Name: <input type="text" name="name" value="<?php echo $name;?>">
   <span class="error"><?php echo $nameErr;?></span>
   <br><br>
   E-mail: <input type="text" name="email" value="<?php echo $email;?>">
   <span class="error"><?php echo $emailErr;?></span>
   <br><br>

   Comment: <textarea name="comment" rows="5" cols="40" required><?php echo $comment;?></textarea>
   
   <br><br>
   Gender:
   <input type="radio" name="gender" <?php if (isset($gender) && $gender=="female") echo "checked";?>  value="female">Female
   <input type="radio" name="gender" <?php if (isset($gender) && $gender=="male") echo "checked";?>  value="male">Male
   <span class="error">	<?php echo $genderErr;?></span>
   
   <br><br>
  Hobbies: <select name="check"required>
  
  	<option></option>
  	<option>Cricket</option>
  	<option>Reading</option>
  	<option>Football</option>
  </select>
  <br><br>
   Languages known: <input type="checkbox" name="t" required>Telugu <input type="checkbox" name="h">Hindi <input type="checkbox" name="e">English
   <br><br>   
   <input type="submit" name="submit" value="Submit"> &nbsp; &nbsp; <input type="reset" name="reset" value="Reset"> 
   </div> 
</form>



</body>
</html>