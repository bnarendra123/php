<?php
//define to create the constent in define function
define('WISHING', 'to confianza');
echo WISHING;
echo "<br>";
define("GREETING", "to confianza",true);
echo greeting;
echo"<br>";
//specifice text with ina string
echo strpos("sree luckey", "luck");
echo "<br>";
//word count;
echo str_word_count("Hello world!");
echo "<br>";

//string revers
echo strrev('bhavyasree');
echo "<br";
//constents are globle
define('WISHING', 'to confianza');

function myTest(){
echo WISHING;		
}
myTest();


?>