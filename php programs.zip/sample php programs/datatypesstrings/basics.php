<?php
echo "this is our team.";
$color="red";
echo "<br>";
echo "my flower color is " . $color . "<br>";
echo "<br>";
//adding variables;
$a=10;
$b=10;
$c=$a+$b;
echo "$c";
echo "<br>";
//print the variables;
$w="hello hai this is confianza";
$e="hello";
$r=10;
$t=20;
$s=$r*$t;
print"<h1>$w</h2>";

print "hai $e";
echo "<br>";
print"$s";
echo "<br>";
//string suffile
echo str_shuffle('bhavyaseweew');
echo "<br>";
?>