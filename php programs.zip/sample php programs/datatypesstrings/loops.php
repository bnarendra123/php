<?php
//for loop
$x="red";
for($x=0;$x<5;$x++){
	echo "the flower is: $x <br>";
}
echo "<br>";
//for each
$color=array('red','blue','orange','green');
foreach ($color as  $value) {
	echo "$value .<br>";
}
echo "<br>";
//while condition
$i=0;
while ($i <= 6) {
	echo "hai this is confianza!! <br>";
	$i++;
}
echo "<br>";
//do while condition
$m=0;
do{
	echo"this is my world!! <br>";
	$m++;
}while($m<=9);
?>