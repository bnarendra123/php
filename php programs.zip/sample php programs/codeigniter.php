Codeigniter turorial steps:
1) Download codeigniter

2) go to database.php: write database name and give username as root

3)config.php: remove baseUrl and give $config['index_page'] = 'index.php';
				  some times encryption password write $config['encryption_key'] = 'somename';
				  
4)routes.php : give controller name and check whether controller name="controllername.php" file are must be same.

5)autoload.php : $autoload['helper']=array('file','url');
					 $autoload['libraries']=array('database','session',form_validation');

6)In header page write <script type="text/javascript">var baseUrl=<?php echo base_url(); ?></script>

7)Create model.php file in model and paste the code as controller change controller name to model & modelname="modelname.php" are same.

8)In controller page add public function __construct()
						{
							parent:: __construct();
							$this->load->helper('url');
							$this->load->view('includes/header');
						}
