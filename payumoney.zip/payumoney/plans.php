<?php

$udf1 = $_POST['udf1'];
$firstname = $_POST['firstname'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$productinfo = $_POST['productinfo'];
$surl = $_POST['surl'];
$furl = $_POST['furl'];
$udf2 = $_POST['udf2'];
$udf3 = $_POST['udf3'];
$udf4 = $_POST['udf4'];
?>

<?php include 'header.php';?>
<link rel="stylesheet" href="css/style4567.css">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>

	<section id="pricePlans" style="height:600px;margin-top:150px;">
	
	
	
	
		<ul id="plans">
		
		
		<form action="" method="post?ek=1">
			<li class="plan">
				<ul class="planContainer">
					<li class="title"><h2>Basic</h2></li>
					<li class="price"><p>Rs/-12,000<span>/Per Annum(12 Visits)</span></p></li>
					<li>
						<ul class="options" style="margin-bottom:275px;">
<?php

include 'customer/dbconnect.php';

 $get = "select type from plans where Basic='yes'";
 $get1 = mysqli_query($connect,$get);

while($get2 = mysqli_fetch_assoc($get1)){

?>
							<li><span class="glyphicon glyphicon-ok"></span> <?php echo $get2['type']; ?></li>
<?php } ?>
							
						</ul>
					</li>
					<button type="submit" name="submit">SELECT</button>
				</ul>
			</li>
</form>



<form action="" method="post?ek=2">
			<li class="plan">
				<ul class="planContainer">
					<li class="title"><h2 class="bestPlanTitle">ECONOMY</h2></li>
					<li class="price"><p class="bestPlanPrice">Rs/-16,000/Per Annum(12 Visits)<span class="glyphicon glyphicon-eye-open"></span></p></li>
					
					
					
					
					
					
					<li>
						<ul class="options" style="margin-bottom:173px;">
<?php

include 'customer/dbconnect.php';

 $get = "select type from plans where Economy='yes'";
 $get1 = mysqli_query($connect,$get);

while($get2 = mysqli_fetch_assoc($get1)){
?>
							<li><span class="glyphicon glyphicon-ok"></span> <?php echo $get2['type']; ?></li>
<?php } ?>
						</ul>
					</li>
					<button type="submit" name="submit">SELECT</button>
				</ul>
			</li>
			
			</form>
			
<form action="" method="post?ek=3">
			<li class="plan">
				<ul class="planContainer">
					<li class="title"><h2>PREMIUM</h2></li>
					<li class="price"><p>Rs/-20,000<span>/Per Annum(12 Visits)</span></p></li>
					
					
					<li>					
						<ul class="options">
<?php 
include 'customer/dbconnect.php';

 $get = "select type from plans where Premium='yes'";
 $get1 = mysqli_query($connect,$get);

while($get2 = mysqli_fetch_assoc($get1)){
?>
							<li><span class="glyphicon glyphicon-ok"></span> <?php echo $get2['type']; ?></li>
<?php } ?>
							
						</ul>
					</li>
					<button type="submit" name="submit">SELECT</button>
				</ul>
			</li>
			
			</form>
			
			<form action="" method="post?ek=4">

			<li class="plan">
				<ul class="planContainer">
					<li class="title"><h2 class="bestPlanTitle">ULTRA</h2></li>
					<li class="price"><p class="bestPlanPrice">Rs/-24,000/Per Annum(12 Visits)</p></li>
					
					
					<li>
						<ul class="options">
							
						<?php

include 'customer/dbconnect.php';

 $get = "select type from plans where Ultra='yes'";
 $get1 = mysqli_query($connect,$get);

while($get2 = mysqli_fetch_assoc($get1)){
?>
							<li><span class="glyphicon glyphicon-ok"></span> <?php echo $get2['type']; ?></li>
<?php } ?>
							
						</ul>
					</li>
					<button type="submit" name="submit">SELECT</button>
				</ul>
			</li>
			
			</form>
			
			
		</ul> <!-- End ul#plans -->
		
	</section>
<?php include 'footer.php';?>