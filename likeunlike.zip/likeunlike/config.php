<?php

$host = "localhost";    /* Host name */
$user = "root";         /* User */
$password = "";         /* Password */
$dbname = "likedislike";   /* Database name */

$con = mysqli_connect($host, $user, $password, $dbname) or die("Unable to connect");

// selecting database
//$db = mysql_select_db($dbname, $con) or die("Database not found");