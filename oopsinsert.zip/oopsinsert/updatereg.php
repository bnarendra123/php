<?php
include_once("function.php");
$updatedata=new DB_con();
if(isset($_POST['submit'])){
	$id=$_POST['editid']; 	
	$name=$_POST['name'];
	$email=$_POST['email'];
	 $result = $updatedata->execute("UPDATE register SET name='$name',email='$email' WHERE id='$id'");
	 if($result)
	 {
		echo '<meta http-equiv="refresh" content="0; URL=selectreg.php">';
	 }
	 
}
?>