<?php
include_once("function.php");
$deletedata=new DB_con();
$id = $deletedata->escape_string($_GET['id']);

$result = $deletedata->getdeleteData("delete FROM register WHERE id=$id");
if($result)
{
	echo '<meta http-equiv="refresh" content="0; URL=selectreg.php">';
}
?>