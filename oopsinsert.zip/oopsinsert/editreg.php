<?php
include_once("function.php");
$editdata=new DB_con();
$id = $editdata->escape_string($_GET['id']);

$result = $editdata->getData("SELECT * FROM register WHERE id=$id");
 
foreach ($result as $res) {
    $name = $res['name'];
    $email = $res['email'];
	$id=$res['id'];
}

?>


<?php
include_once("function.php");
$updatedata=new DB_con();
if(isset($_POST['submit'])){
	$id1=$_POST['editid']; 	
	$name=$_POST['name'];
	$email=$_POST['email'];
	 $result = $updatedata->execute("UPDATE register SET name='$name',email='$email' WHERE id='$id1'");
	 if($result)
	 {
		echo '<meta http-equiv="refresh" content="0; URL=selectreg.php">';
	 }
	 
}
?>


<form name="insert" method="post" action="">
Name : <input type="text" name="name" value="<?php echo $name; ?>"><br>
Email : <input type="text" name="email" value="<?php echo $email; ?>"><br>
<input type="hidden" name="editid" value="<?php echo $_GET['id']; ?>">
<input type="submit" name="submit" value="Submit">
</form>