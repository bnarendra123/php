<table border="0">
<tr><th>Name</th<th>Email</th><th>Actions</th></tr>
<?php
include_once("function.php");
$insertdata=new DB_con();
$sql=$insertdata->getregister();
while($row=mysqli_fetch_array($sql)){
?>
<tr><td><?php echo $row['name']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><a href="editreg.php?id=<?php echo $row['id']; ?>">Edit</a></td>
<td><a href="deletereg.php?id=<?php echo $row['id']; ?>" onclick="retrun confirm('Are you sure you want to delete');">Delete</a></td>
</tr>
<?php

}
?>
</table>