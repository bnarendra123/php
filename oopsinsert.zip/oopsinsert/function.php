<?php
define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_NAME','oopsinsert');
class DB_con
{
function __construct()
{
$con=mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_NAME);
$this->dbh=$con;
}
public function insert($name,$email)
{
	$ret=mysqli_query($this->dbh,"insert into register(id,name,email) values(NULL,'$name','$email')");
return $ret;

}
}
?>