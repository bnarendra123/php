<?php
define('DB_SERVER','localhost');
define('DB_USER','root');
define('DB_PASSWORD','');
define('DB_NAME','oopsinsert');
class DB_con
{
function __construct()
{
$con=mysqli_connect(DB_SERVER,DB_USER,DB_PASSWORD,DB_NAME);
$this->dbh=$con;
}
public function insert($name,$email)
{
	$ret=mysqli_query($this->dbh,"insert into register(id,name,email) values(NULL,'$name','$email')");
return $ret;

}

public function getregister()
{
	$getreg=mysqli_query($this->dbh,"select * from register");
	return $getreg;
}

public function escape_string($value)
    {
        return $this->dbh->real_escape_string($value);
    }
	
	public function getData($query)
    {        
        $result = $this->dbh->query($query);
        
        if ($result == false) {
            return false;
        } 
        
        $rows = array();
        
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        
        return $rows;
    }
	
	public function execute($query) 
    {
        $result = $this->dbh->query($query);
        
        if ($result == false) {
            echo 'Error: cannot execute the command';
            return false;
        } else {
            return true;
        }        
    }
	
	public function getdeleteData($query)
    {        
        $result = $this->dbh->query($query);
		if ($result == false) {
            return false;
        } 
		else  { return true; }
	}
	
}
?>