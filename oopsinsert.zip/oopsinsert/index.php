<form name="insert" method="post" action="">
<input type="text" name="name"><br>
<input type="text" name="email"><br>
<input type="submit" name="submit" value="Submit">
</form>


<?php
include_once("function.php");
$insertdata=new DB_con();
if(isset($_POST['submit']))
{
$name=$_POST['name'];
$email=$_POST['email'];

$sql=$insertdata->insert($name,$email);
if($sql)
{
echo "<script>alert('Data inserted');</script>";
}
else
{
echo "<script>alert('Data not inserted');</script>";
}
}
 ?>

